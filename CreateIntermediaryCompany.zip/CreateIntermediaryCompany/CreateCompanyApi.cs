﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using System.Web;

namespace CreateIntermediaryCompany
{
    public class CreateCompanyApi : CodeActivity
    {
        [RequiredArgument]
        [Input("Account")]
        [ReferenceTarget("account")]
        public InArgument<EntityReference> Account { get; set; }

        [Output("LoyatyPortalId")]
        public OutArgument<int> LoyatyPortalId { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            //string firstName = string.Empty;
            //string lastName = string.Empty;
            string company = string.Empty;
            string email = string.Empty;
            string phone = string.Empty;
            string websiteUrl = string.Empty;
            //int isDemo = 0;

            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference accountref = Account.Get(executionContext);
            Entity account = service.Retrieve("account", accountref.Id, new ColumnSet(true));

            //if (account.Attributes.Contains("fullname"))
            //{
            //    firstName = account.Attributes["first_name"].ToString();
            //}
            //if (account.Attributes.Contains("fullname"))
            //{
            //    lastName = account.Attributes["fullname"].ToString();
            //}
            if (account.Attributes.Contains("name"))
            {
                company = account.Attributes["name"].ToString();
            }
            if (account.Attributes.Contains("emailaddress1"))
            {
                email = account.Attributes["emailaddress1"].ToString();
            }
            if (account.Attributes.Contains("telephone1"))
            {
                phone = account.Attributes["telephone1"].ToString();
            }
            if (account.Attributes.Contains("websiteurl"))
            {
                websiteUrl = account.Attributes["websiteurl"].ToString();
            }

            var postData = new List<KeyValuePair<string, string>>
            {
                //new KeyValuePair<string, string>("first_name",firstName),
                //new KeyValuePair<string, string>("last_name",lastName),
                new KeyValuePair<string, string>("company",company),
                new KeyValuePair<string, string>("email",email),
                new KeyValuePair<string, string>("phone",phone),
                new KeyValuePair<string, string>("website",websiteUrl),
                //new KeyValuePair<string, string>("isDemo",Convert.ToString(isDemo)),
            };

            var client = new HttpClient();
            client.BaseAddress = new Uri("http://loyaltyportal.lucidtestbed.co.uk/addCompanyByCRM");
            var companyRequest = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress) { Content = new FormUrlEncodedContent(postData) };
            var response = CreateCompany(client, companyRequest);
            tracingService.Trace("Response " + response);
            if (response.GetType().GetProperty("Result").GetValue(response).ToString() != "failed")
            {
                int id = Convert.ToInt32(response.GetType().GetProperty("Result").GetValue(response));
                this.LoyatyPortalId.Set(executionContext, id);
            }
        }

        public async Task<string> CreateCompany(HttpClient client, HttpRequestMessage request)
        {
            HttpResponseMessage companyResponse = await client.SendAsync(request);
            var reponse = companyResponse.Content.ReadAsStringAsync();
            return await Task.FromResult(reponse.Result);
        }
    }
}