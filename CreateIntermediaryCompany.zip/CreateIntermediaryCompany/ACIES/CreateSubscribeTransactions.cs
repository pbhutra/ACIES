﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CreateIntermediaryCompany
{
    public class CreateSubscribeTransactions : CodeActivity
    {
        [Input("Subscribe Quote")]
        [ReferenceTarget("lux_subscribepiquote")]
        public InArgument<EntityReference> SubscribeQuote { get; set; }

        [Input("Subscribe Policy")]
        [ReferenceTarget("lux_subscribepolicy")]
        public InArgument<EntityReference> SubscribePolicy { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference quoteref = SubscribeQuote.Get<EntityReference>(executionContext);
            Entity quote = new Entity(quoteref.LogicalName, quoteref.Id);
            quote = service.Retrieve("lux_subscribepiquote", quoteref.Id, new ColumnSet(true));

            EntityReference policyref = SubscribePolicy.Get<EntityReference>(executionContext);
            Entity policy = new Entity(policyref.LogicalName, policyref.Id);
            policy = service.Retrieve("lux_subscribepolicy", policyref.Id, new ColumnSet(true));

            var IsInstallment = quote.Attributes.Contains("lux_premiumpayablebyinstalments") ? quote.GetAttributeValue<bool>("lux_premiumpayablebyinstalments") : false;
            var SignedShare = quote.Attributes.Contains("lux_signedsharepercentage") ? quote.GetAttributeValue<decimal>("lux_signedsharepercentage") : 100;

            decimal totalExcludingIptFee = quote.Attributes.Contains("lux_signedsharepolicypremiumbeforetax") ? quote.GetAttributeValue<Money>("lux_signedsharepolicypremiumbeforetax").Value : 0;
            decimal pslCommAmt = quote.GetAttributeValue<decimal>("lux_signedsharemgacommissionpercentage");
            decimal brokerCommAmt = quote.GetAttributeValue<decimal>("lux_signedsharebrokercommissionpercentage");
            decimal adminFee = quote.Attributes.Contains("lux_signedsharepolicyfee") ? quote.GetAttributeValue<Money>("lux_signedsharepolicyfee").Value : 0;
            var DueDate = quote.GetAttributeValue<DateTime>("lux_inceptiondate");

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_subscribeinstalmenttable'>
                                <attribute name='lux_instalmentnumber' />
                                <attribute name='lux_duedate' />
                                <attribute name='lux_instalmentvalue' />
                                <attribute name='lux_instalmentpercentage' />
                                <attribute name='lux_policyadminfee' />
                                <attribute name='lux_taxamount' />
                                <attribute name='lux_subscribeinstalmenttableid' />
                                <order attribute='lux_instalmentnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_subscribepiquote' operator='eq' uiname='' uitype='lux_subscribepiquote' value='{quote.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (IsInstallment == true && service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    var instalmentNumber = Convert.ToInt32(item.FormattedValues["lux_instalmentnumber"]);
                    decimal percentage = item.GetAttributeValue<decimal>("lux_instalmentpercentage");
                    var totalExcludingIPTFEE = totalExcludingIptFee * percentage / 100;

                    if (instalmentNumber != 1)
                    {
                        adminFee = 0;
                    }

                    Entity invoice = new Entity("lux_invoice");
                    invoice["lux_subscribepiquote"] = new EntityReference("lux_subscribepiquote", quote.Id);
                    invoice["lux_subscribepolicy"] = new EntityReference("lux_subscribepolicy", policy.Id);
                    invoice["lux_broker"] = new EntityReference("account", policy.GetAttributeValue<EntityReference>("lux_brokercompany").Id);
                    invoice["transactioncurrencyid"] = new EntityReference("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                    invoice["lux_product"] = new EntityReference("product", quote.GetAttributeValue<EntityReference>("lux_product").Id);
                    invoice["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                    invoice["lux_insured"] = policy.Attributes["lux_name"].ToString();
                    invoice["lux_policynumber"] = policy.Attributes["lux_policynumber"].ToString();
                    invoice["lux_risktransaction"] = new OptionSetValue(972970001);
                    invoice["lux_instalmentpercentage"] = percentage;
                    if (policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
                    {
                        invoice["lux_risktransaction"] = new OptionSetValue(972970002);
                    }

                    invoice["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("createdon");
                    invoice["lux_transactiontype"] = new OptionSetValue(972970002);

                    invoice["lux_aciescommissionrate"] = pslCommAmt.ToString();
                    invoice["lux_commissionrate"] = brokerCommAmt.ToString();
                    invoice["lux_aciescommissionamount"] = new Money(totalExcludingIPTFEE * pslCommAmt / 100);
                    invoice["lux_commissionamount"] = new Money(totalExcludingIPTFEE * brokerCommAmt / 100);

                    invoice["lux_fee"] = new Money(adminFee);
                    invoice["lux_duedate"] = item.GetAttributeValue<DateTime>("lux_duedate");
                    invoice["lux_grosspremiumexciptfee"] = new Money(totalExcludingIPTFEE);

                    if (instalmentNumber == 1)
                    {
                        invoice["lux_isfirstinstalmenttransaction"] = true;
                    }

                    var IPTRate = quote.Attributes.Contains("lux_policytotaltax") ? quote.GetAttributeValue<decimal>("lux_policytotaltax") : 0M;

                    invoice["lux_iptrate"] = IPTRate;
                    invoice["lux_ipt"] = new Money(totalExcludingIPTFEE * IPTRate / 100);

                    invoice["lux_subscribesplit"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommAmt / 100 - totalExcludingIPTFEE * brokerCommAmt / 100);
                    invoice["lux_totalpremiumincludingiptfee"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 + adminFee);

                    service.Create(invoice);
                }
            }
            else
            {
                var totalExcludingIPTFEE = totalExcludingIptFee;

                Entity invoice = new Entity("lux_invoice");
                invoice["lux_subscribepiquote"] = new EntityReference("lux_subscribepiquote", quote.Id);
                invoice["lux_subscribepolicy"] = new EntityReference("lux_subscribepolicy", policy.Id);
                invoice["lux_broker"] = new EntityReference("account", policy.GetAttributeValue<EntityReference>("lux_brokercompany").Id);
                invoice["transactioncurrencyid"] = new EntityReference("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                invoice["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                invoice["lux_insured"] = policy.Attributes["lux_name"].ToString();
                invoice["lux_policynumber"] = policy.Attributes["lux_policynumber"].ToString();
                invoice["lux_risktransaction"] = new OptionSetValue(972970001);
                invoice["lux_product"] = new EntityReference("product", quote.GetAttributeValue<EntityReference>("lux_product").Id);
                if (policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
                {
                    invoice["lux_risktransaction"] = new OptionSetValue(972970002);
                }

                invoice["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("createdon");
                invoice["lux_transactiontype"] = new OptionSetValue(972970002);

                invoice["lux_aciescommissionrate"] = pslCommAmt.ToString();
                invoice["lux_commissionrate"] = brokerCommAmt.ToString();
                invoice["lux_aciescommissionamount"] = new Money(totalExcludingIPTFEE * pslCommAmt / 100);
                invoice["lux_commissionamount"] = new Money(totalExcludingIPTFEE * brokerCommAmt / 100);

                invoice["lux_fee"] = new Money(adminFee);
                invoice["lux_duedate"] = new DateTime(DueDate.Year, DueDate.Month, 1).AddMonths(2).AddDays(-1);
                invoice["lux_grosspremiumexciptfee"] = new Money(totalExcludingIPTFEE);

                var IPTRate = quote.Attributes.Contains("lux_policytotaltax") ? quote.GetAttributeValue<decimal>("lux_policytotaltax") : 0M;

                invoice["lux_iptrate"] = IPTRate;
                invoice["lux_ipt"] = new Money(totalExcludingIPTFEE * IPTRate / 100);

                invoice["lux_subscribesplit"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommAmt / 100 - totalExcludingIPTFEE * brokerCommAmt / 100);
                invoice["lux_totalpremiumincludingiptfee"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 + adminFee);

                service.Create(invoice);
            }
        }
    }
}