﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CreateIntermediaryCompany
{
    public class CreateSubscribeInstalments : CodeActivity
    {
        [Input("Subscribe Quote")]
        [ReferenceTarget("lux_subscribepiquote")]
        public InArgument<EntityReference> SubscribeQuote { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference quoteref = SubscribeQuote.Get<EntityReference>(executionContext);
            Entity quote = new Entity(quoteref.LogicalName, quoteref.Id);
            quote = service.Retrieve("lux_subscribepiquote", quoteref.Id, new ColumnSet(true));
            var DueDate = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
            var IsInstallment = quote.Attributes.Contains("lux_premiumpayablebyinstalments") ? quote.GetAttributeValue<bool>("lux_premiumpayablebyinstalments") : false;

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_subscribeinstalmenttable'>
                                <attribute name='lux_instalmentnumber' />
                                <attribute name='lux_duedate' />
                                <attribute name='lux_instalmentvalue' />
                                <attribute name='lux_instalmentpercentage' />
                                <attribute name='lux_subscribeinstalmenttableid' />
                                <order attribute='lux_instalmentnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_subscribepiquote' operator='eq' uiname='' uitype='lux_subscribepiquote' value='{quote.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (IsInstallment == true && service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
            {
                var NoOfInstallment = Convert.ToInt32(quote.FormattedValues["lux_numberofinstalments"]);
                for (int i = 1; i <= NoOfInstallment; i++)
                {
                    Entity instalment = new Entity("lux_subscribeinstalmenttable");
                    instalment["lux_subscribepiquote"] = new EntityReference("lux_subscribepiquote", quote.Id);

                    instalment["transactioncurrencyid"] = new EntityReference("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                    instalment["lux_instalmentnumber"] = new OptionSetValue(972970000 + i);
                    if (i == 1)
                    {
                        instalment["lux_duedate"] = new DateTime(DueDate.Year, DueDate.Month, 1).AddMonths(2).AddDays(-1);
                    }

                    if (NoOfInstallment == 1)
                    {
                        instalment["lux_instalmentpercentage"] = new Decimal(100);
                    }
                    else if (NoOfInstallment == 2)
                    {
                        instalment["lux_instalmentpercentage"] = new Decimal(50);
                    }
                    else if (NoOfInstallment == 3)
                    {
                        if (i == 1)
                        {
                            instalment["lux_instalmentpercentage"] = new Decimal(33.34);
                        }
                        else
                        {
                            instalment["lux_instalmentpercentage"] = new Decimal(33.33);
                        }
                    }
                    else if (NoOfInstallment == 4)
                    {
                        instalment["lux_instalmentpercentage"] = new Decimal(25);
                    }

                    instalment["lux_selectedquoteoption"] = new EntityReference("lux_subscribequoteoption", quote.GetAttributeValue<EntityReference>("lux_quoteoptions").Id);

                    service.Create(instalment);
                }
            }
        }
    }
}