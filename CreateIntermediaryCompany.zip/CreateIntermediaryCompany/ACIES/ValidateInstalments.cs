﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CreateIntermediaryCompany
{
    public class ValidateInstalments : CodeActivity
    {
        [Input("Construction Quote")]
        [ReferenceTarget("lux_constructionquotes")]
        public InArgument<EntityReference> ConstructionQuote { get; set; }

        [Output("IsValidated")]
        public OutArgument<bool> IsValidated { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            IsValidated.Set(executionContext, true);

            EntityReference quoteref = ConstructionQuote.Get<EntityReference>(executionContext);
            Entity quote = new Entity(quoteref.LogicalName, quoteref.Id);
            quote = service.Retrieve("lux_constructionquotes", quoteref.Id, new ColumnSet(true));
            var DueDate = quote.GetAttributeValue<DateTime>("lux_inceptiondate").AddMonths(1);
            var IsInstallment = quote.Attributes.Contains("lux_premiumpayablebyinstalments") ? quote.GetAttributeValue<bool>("lux_premiumpayablebyinstalments") : false;


            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_constructionpremiuminstalment'>
                                <attribute name='lux_instalmentnumber' />
                                <attribute name='lux_duedate' />
                                <attribute name='lux_instalmentvalue' />
                                <attribute name='lux_instalmentpercentage' />
                                <attribute name='lux_constructionpremiuminstalmentid' />
                                <order attribute='lux_instalmentnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_constructionquote' operator='eq' uiname='' uitype='lux_constructionquotes' value='{quote.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (IsInstallment == true && service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var NoOfInstallment = Convert.ToInt32(quote.FormattedValues["lux_numberofinstalments"]);
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    if (item.Attributes.Contains("lux_instalmentvalue") && item.Attributes.Contains("lux_duedate"))
                    {
                        IsValidated.Set(executionContext, true);
                    }
                    else
                    {
                        IsValidated.Set(executionContext, false);
                    }
                }
            }
        }
    }
}