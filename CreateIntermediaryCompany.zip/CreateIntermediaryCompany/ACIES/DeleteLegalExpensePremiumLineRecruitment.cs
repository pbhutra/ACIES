﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CreateIntermediaryCompany
{
    public class DeleteLegalExpensePremiumLineRecruitment : CodeActivity
    {
        [Input("Recruitment Quote")]
        [ReferenceTarget("lux_recruitmentquotes")]
        public InArgument<EntityReference> RecruitmentQuote { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference recruitmentQuoteref = RecruitmentQuote.Get<EntityReference>(executionContext);
            Entity recruitmentQuote = new Entity("lux_recruitmentquotes", recruitmentQuoteref.Id);
            recruitmentQuote = service.Retrieve("lux_recruitmentquotes", recruitmentQuoteref.Id, new ColumnSet(true));

            var Ratingfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_specialistschemerecruitmentpremuim'>
                                <attribute name='lux_name' />
                                <attribute name='lux_section' />
                                <attribute name='lux_technicalpremium' />
                                <attribute name='lux_policypremium' />
                                <attribute name='lux_recruitmentquote' />
                                <attribute name='transactioncurrencyid' />
                                <attribute name='lux_specialistschemerecruitmentpremuimid' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_recruitmentquote' operator='eq' uiname='' uitype='lux_recruitmentquotes' value='{recruitmentQuote.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            var RateItem = service.RetrieveMultiple(new FetchExpression(Ratingfetch)).Entities;
            var LE = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970023);

            var IsLECover = recruitmentQuote.Attributes.Contains("lux_islegalexpensescoverrequired") ? recruitmentQuote.GetAttributeValue<bool>("lux_islegalexpensescoverrequired") : false;
            if (IsLECover == false)
            {
                var LeTechnicalPremium = recruitmentQuote.Attributes.Contains("lux_letechnicalpremiumexcle") ? recruitmentQuote.GetAttributeValue<Money>("lux_letechnicalpremiumexcle").Value : 0;
                var LePolicyPremium = recruitmentQuote.Attributes.Contains("lux_lepolicypremiumexcle") ? recruitmentQuote.GetAttributeValue<Money>("lux_lepolicypremiumexcle").Value : 0;

                var TechnicalPremium = recruitmentQuote.Attributes.Contains("lux_technicalpremiumbeforetaxexclegal") ? recruitmentQuote.GetAttributeValue<Money>("lux_technicalpremiumbeforetaxexclegal").Value : 0;
                var PolicyPremium = recruitmentQuote.Attributes.Contains("lux_policypremiumbeforetaxexclegal") ? recruitmentQuote.GetAttributeValue<Money>("lux_policypremiumbeforetaxexclegal").Value : 0;

                if (LE != null)
                {
                    service.Delete("lux_specialistschemerecruitmentpremuim", LE.Id);
                }

                //var TechnicalPremium = RateItem.Where(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value != 972970023).Sum(x => x.Attributes.Contains("lux_technicalpremium") ? x.GetAttributeValue<Money>("lux_technicalpremium").Value : 0);
                //var PolicyPremium = RateItem.Where(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value != 972970023).Sum(x => x.Attributes.Contains("lux_policypremium") ? x.GetAttributeValue<Money>("lux_policypremium").Value : 0);

                Entity application = service.Retrieve("lux_recruitmentquotes", recruitmentQuote.Id, new ColumnSet(false));

                application["lux_techbrokercommamount_manual"] = new Money(recruitmentQuote.GetAttributeValue<Money>("lux_techbrokercommexclegal_manual").Value);
                application["lux_techaciescommamount_manual"] = new Money(recruitmentQuote.GetAttributeValue<Money>("lux_techaciescommexclegal_manual").Value);
                application["lux_techtotalcommamount_manual"] = new Money(recruitmentQuote.GetAttributeValue<Money>("lux_techtotalcommexclegal_manual").Value);
                application["lux_technicalpremiumbeforetax"] = new Money(recruitmentQuote.GetAttributeValue<Money>("lux_technicalpremiumbeforetaxexclegal").Value);
                application["lux_technicallegalpremiumbeforetaxinc"] = new Money(0);
                application["lux_techtaxamount_manual"] = new Money(recruitmentQuote.GetAttributeValue<Money>("lux_techtaxexclegal_manual").Value);
                application["lux_totaltechpremiuminc_manual"] = new Money(recruitmentQuote.GetAttributeValue<Money>("lux_totaltechpremiumexclegal_manual").Value);

                application["lux_policybrokercommamount_manual"] = new Money(recruitmentQuote.GetAttributeValue<Money>("lux_policybrokercommexclegal_manual").Value);
                application["lux_policyaciescommamount_manual"] = new Money(recruitmentQuote.GetAttributeValue<Money>("lux_policyaciescommexclegal_manual").Value);
                application["lux_policytotalcommamount_manual"] = new Money(recruitmentQuote.GetAttributeValue<Money>("lux_policytotalcommexclegal_manual").Value);
                application["lux_policypremiumbeforetax"] = new Money(recruitmentQuote.GetAttributeValue<Money>("lux_policypremiumbeforetaxexclegal").Value);
                application["lux_lepolicypremium"] = new Money(0);
                application["lux_policytaxamount_manual"] = new Money(recruitmentQuote.GetAttributeValue<Money>("lux_policytaxexclegal_manual").Value);
                application["lux_totalpolicypremiuminc_manual"] = new Money(recruitmentQuote.GetAttributeValue<Money>("lux_totalpolicypremiumexclegal_manual").Value);

                service.Update(application);
            }
        }
    }
}