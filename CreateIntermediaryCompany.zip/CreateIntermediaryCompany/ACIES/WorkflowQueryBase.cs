﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Xml;

namespace CreateIntermediaryCompany.ACIES
{
    public abstract class WorkflowQueryBase: CodeActivity
    {
        protected string MetadataHeaderFormat = "{0}_Metadata_{1}";

        [Input("Pick a System View to Use")]
        [ReferenceTarget("savedquery")]
        public InArgument<EntityReference> SavedQuery { get; set; }

        [Input("or pick a Personal View to Use")]
        [ReferenceTarget("userquery")]
        public InArgument<EntityReference> UserQuery { get; set; }

        [Input("or enter FetchXML to Use")]
        public InArgument<string> FetchXml { get; set; }


        protected QueryResult ExecuteQueryForRecords(CodeActivityContext context)
        {
            QueryResult returnValue = new QueryResult() { RecordIds = new List<Guid>() };
            if (this.SavedQuery.Get(context) == null && this.UserQuery.Get(context) == null && String.IsNullOrEmpty(this.FetchXml.Get(context)))
            {
                throw new ArgumentNullException("You need to either a pick System View, a Personal View, or specify FetchXML for the query");
            }

            IWorkflowContext workflowContext = context.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(workflowContext.InitiatingUserId);


            string layoutXml = String.Empty;
            string fetchXml = this.FetchXml.Get(context);
            if (this.UserQuery.Get(context) != null)
            {
                Entity queryEntity = service.Retrieve("userquery", this.UserQuery.Get(context).Id, new Microsoft.Xrm.Sdk.Query.ColumnSet("fetchxml", "layoutxml"));
                fetchXml = queryEntity.Contains("fetchxml") ? queryEntity["fetchxml"].ToString() : String.Empty;
                layoutXml = queryEntity.Contains("layoutxml") ? queryEntity["layoutxml"].ToString() : String.Empty;
            }
            else if (this.SavedQuery.Get(context) != null)
            {
                Entity queryEntity = service.Retrieve("savedquery", this.SavedQuery.Get(context).Id, new Microsoft.Xrm.Sdk.Query.ColumnSet("fetchxml", "layoutxml"));
                fetchXml = queryEntity.Contains("fetchxml") ? queryEntity["fetchxml"].ToString() : String.Empty;
                layoutXml = queryEntity.Contains("layoutxml") ? queryEntity["layoutxml"].ToString() : String.Empty;
            }
            this.LimitQueryToCurrentRecord(service, ref fetchXml, workflowContext.PrimaryEntityName, workflowContext.PrimaryEntityId);
            EntityCollection ec = null;
            try
            {
                FetchExpression fe = new FetchExpression(fetchXml);
                ec = service.RetrieveMultiple(fe);
            }
            catch (System.ServiceModel.FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
            {
                throw new ArgumentException("There was an error executing the query. Message: " + ex.Message);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            returnValue.EntityName = ec.EntityName;

            RetrieveEntityRequest entityMetadataRequest = new RetrieveEntityRequest() { LogicalName = returnValue.EntityName };
            var response = service.Execute(entityMetadataRequest) as RetrieveEntityResponse;
            if (response == null || response.EntityMetadata == null)
            {
                throw new InvalidOperationException($"Entity metadata not found for entity {returnValue.EntityName}");
            }
            returnValue.Metadata = response.EntityMetadata;

            string primaryKeyField = returnValue.Metadata.PrimaryIdAttribute;

            returnValue.RecordIds.AddRange(ec.Entities.Select(e => e.Id).ToList());

            return returnValue;
        }

        protected void LimitQueryToCurrentRecord(IOrganizationService service, ref string fetchXml, string entityName, Guid entityId)
        {
            Microsoft.Xrm.Sdk.Messages.RetrieveEntityRequest metadataRequest = new Microsoft.Xrm.Sdk.Messages.RetrieveEntityRequest() { LogicalName = entityName };
            Microsoft.Xrm.Sdk.Messages.RetrieveEntityResponse metadataResponse = service.Execute(metadataRequest) as Microsoft.Xrm.Sdk.Messages.RetrieveEntityResponse;
            if (metadataResponse == null)
            {
                return;
            }

            XmlDocument fetchXmlDoc = new XmlDocument();
            fetchXmlDoc.LoadXml(fetchXml);
            this.UpdateConditionRecursively(fetchXmlDoc, fetchXmlDoc.FirstChild, entityId, entityName, metadataResponse.EntityMetadata.PrimaryIdAttribute);
            fetchXml = fetchXmlDoc.OuterXml;
        }

        protected void UpdateConditionRecursively(XmlDocument xmlDoc, XmlNode currentNode, Guid entityId, string entityName, string primaryKeyField)
        {
            if (currentNode.Name == "condition")
            {
                if (currentNode.Attributes["attribute"] != null && currentNode.Attributes["attribute"].Value == primaryKeyField &&
                    currentNode.Attributes["operator"] != null && currentNode.Attributes["operator"].Value == "not-null" &&
                    currentNode.ParentNode != null && currentNode.ParentNode.Name == "filter" &&
                    currentNode.ParentNode.ParentNode != null && currentNode.ParentNode.ParentNode.Name == "link-entity" &&
                    currentNode.ParentNode.ParentNode.Attributes["name"] != null && currentNode.ParentNode.ParentNode.Attributes["name"].Value == entityName)
                {
                    XmlAttribute keyAttribute = xmlDoc.CreateAttribute("value");
                    keyAttribute.Value = entityId.ToString();
                    currentNode.Attributes["operator"].Value = "eq";
                    currentNode.Attributes.Append(keyAttribute);
                }
            }
            foreach (XmlNode child in currentNode.ChildNodes)
            {
                this.UpdateConditionRecursively(xmlDoc, child, entityId, entityName, primaryKeyField);
            }
        }

        public struct QueryResult
        {
            public string EntityName { get; set; }
            public List<Guid> RecordIds { get; set; }
            public EntityMetadata Metadata { get; set; }
        }
        public class ColumnInformation
        {
            public string Header { get; set; }
            public string QueryResultAlias { get; set; }
        }
        public class QueryAttribute
        {
            public string AttribueAlias { get; set; }
            public string Attribute { get; set; }
            public string EntityAlias { get; set; }
            public string EntityName { get; set; }
            public string AttributeLabel { get; set; }
        }
    }
}