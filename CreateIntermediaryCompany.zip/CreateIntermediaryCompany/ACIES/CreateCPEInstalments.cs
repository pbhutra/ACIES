﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CreateIntermediaryCompany
{
    public class CreateCPEInstalments : CodeActivity
    {
        [Input("CPE Quote")]
        [ReferenceTarget("lux_contractorsplantandequipmentquote")]
        public InArgument<EntityReference> PortTerminalsQuote { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference quoteref = PortTerminalsQuote.Get<EntityReference>(executionContext);
            Entity quote = new Entity(quoteref.LogicalName, quoteref.Id);
            quote = service.Retrieve("lux_contractorsplantandequipmentquote", quoteref.Id, new ColumnSet(true));
            var DueDate = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
            var IsInstallment = quote.Attributes.Contains("lux_premiumpayablebyinstalments") ? quote.GetAttributeValue<bool>("lux_premiumpayablebyinstalments") : false;

            var ArgentaPer = 0M;
            var AXAPer = 0M;
            var GreatAmericanPer = 0M;
            var LancashirePer = 0M;
            var Probitas1492Per = 0M;
            var CincinnatiInsurancePer = 0M;

            var ArgentaFee = 0M;
            var AXAFee = 0M;
            var GreatAmericanFee = 0M;
            var LancashireFee = 0M;
            var Probitas1492Fee = 0M;
            var CincinnatiInsuranceFee = 0M;

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_cpeinstalmenttable'>
                                <attribute name='lux_instalmentnumber' />
                                <attribute name='lux_duedate' />
                                <attribute name='lux_instalmentvalue' />
                                <attribute name='lux_instalmentpercentage' />
                                <attribute name='lux_cpeinstalmenttableid' />
                                <order attribute='lux_instalmentnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_contractorsplantandequipmentquote' operator='eq' uiname='' uitype='lux_contractorsplantandequipmentquote' value='{quote.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            var capacityFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_phoenixcapacitysplittable'>
                                                    <attribute name='lux_linepercentagecalculated' />
                                                    <attribute name='lux_lineamountcalculated' />
                                                    <attribute name='lux_insurername' />
                                                    <attribute name='lux_linefee' />
                                                    <attribute name='lux_phoenixcapacitysplittableid' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_contractorsplantandequipmentquote' operator='eq' uiname='' uitype='lux_contractorsplantandequipmentquote' value='{quote.Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

            var capacity = service.RetrieveMultiple(new FetchExpression(capacityFetch)).Entities;
            if (capacity.Count > 0)
            {
                ArgentaPer = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Argenta")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                AXAPer = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("AXA")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                GreatAmericanPer = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Great America")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                LancashirePer = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Lancashire")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                Probitas1492Per = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Probitas")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                CincinnatiInsurancePer = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Cincinnati")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);

                ArgentaFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Argenta")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                AXAFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("AXA")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                GreatAmericanFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Great America")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                LancashireFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Lancashire")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                Probitas1492Fee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Probitas")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                CincinnatiInsuranceFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Cincinnati")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
            }

            if (IsInstallment == true && service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
            {
                var NoOfInstallment = Convert.ToInt32(quote.FormattedValues["lux_numberofinstalments"]);
                for (int i = 1; i <= NoOfInstallment; i++)
                {
                    Entity instalment = new Entity("lux_cpeinstalmenttable");
                    instalment["lux_contractorsplantandequipmentquote"] = new EntityReference("lux_contractorsplantandequipmentquote", quote.Id);

                    instalment["lux_argentaholdingsltd"] = ArgentaPer;
                    instalment["lux_axainsuranceplc"] = AXAPer;
                    instalment["lux_greatamericaninternationalinsurancelimite"] = GreatAmericanPer;
                    instalment["lux_lancashiregroup"] = LancashirePer;
                    instalment["lux_probitas1492"] = Probitas1492Per;
                    instalment["lux_cincinnatiinsurance"] = CincinnatiInsurancePer;

                    instalment["lux_argentalinefee"] = new Money(ArgentaFee);
                    instalment["lux_axalinefee"] = new Money(AXAFee);
                    instalment["lux_greatamericanlinefee"] = new Money(GreatAmericanFee);
                    instalment["lux_lancashirelinefee"] = new Money(LancashireFee);
                    instalment["lux_probitas1492linefee"] = new Money(Probitas1492Fee);
                    instalment["lux_cincinnatiinsurancelinefee"] = new Money(CincinnatiInsuranceFee);

                    instalment["transactioncurrencyid"] = new EntityReference("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                    instalment["lux_instalmentnumber"] = new OptionSetValue(972970000 + i);
                    if (i == 1)
                    {
                        instalment["lux_duedate"] = new DateTime(DueDate.Year, DueDate.Month, 1).AddMonths(2).AddDays(-1);
                    }

                    if (NoOfInstallment == 1)
                    {
                        instalment["lux_instalmentpercentage"] = new Decimal(100);
                    }
                    else if (NoOfInstallment == 2)
                    {
                        instalment["lux_instalmentpercentage"] = new Decimal(50);
                    }
                    else if (NoOfInstallment == 3)
                    {
                        if (i == 1)
                        {
                            instalment["lux_instalmentpercentage"] = new Decimal(33.34);
                        }
                        else
                        {
                            instalment["lux_instalmentpercentage"] = new Decimal(33.33);
                        }
                    }
                    else if (NoOfInstallment == 4)
                    {
                        instalment["lux_instalmentpercentage"] = new Decimal(25);
                    }
                    else if (NoOfInstallment == 5)
                    {
                        instalment["lux_instalmentpercentage"] = new Decimal(20);
                    }
                    else if (NoOfInstallment == 6)
                    {
                        if (i == 1)
                        {
                            instalment["lux_instalmentpercentage"] = new Decimal(16.70);
                        }
                        else
                        {
                            instalment["lux_instalmentpercentage"] = new Decimal(16.66);
                        }
                    }
                    else if (NoOfInstallment == 7)
                    {
                        if (i == 1)
                        {
                            instalment["lux_instalmentpercentage"] = new Decimal(14.32);
                        }
                        else
                        {
                            instalment["lux_instalmentpercentage"] = new Decimal(14.28);
                        }
                    }
                    else if (NoOfInstallment == 8)
                    {
                        instalment["lux_instalmentpercentage"] = new Decimal(12.5);
                    }
                    else if (NoOfInstallment == 9)
                    {
                        if (i == 1)
                        {
                            instalment["lux_instalmentpercentage"] = new Decimal(11.12);
                        }
                        else
                        {
                            instalment["lux_instalmentpercentage"] = new Decimal(11.11);
                        }
                    }
                    else if (NoOfInstallment == 10)
                    {
                        instalment["lux_instalmentpercentage"] = new Decimal(10);
                    }
                    service.Create(instalment);
                }
            }
        }
    }
}