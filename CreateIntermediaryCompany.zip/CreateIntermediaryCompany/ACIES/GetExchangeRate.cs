﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Metadata.Query;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CreateIntermediaryCompany
{
    public class GetExchangeRate : CodeActivity
    {
        //[Input("Construction Quote")]
        //[ReferenceTarget("lux_constructionquotes")]
        //public InArgument<EntityReference> ConstructionQuote { get; set; }

        [RequiredArgument]
        [Input("RecordURL")]
        public InArgument<string> RecordURL { get; set; }

        [Output("ExchangeRate")]
        public OutArgument<decimal> ExchangeRate { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            //EntityReference quoteref = ConstructionQuote.Get<EntityReference>(executionContext);
            //Entity quote = new Entity(quoteref.LogicalName, quoteref.Id);
            //quote = service.Retrieve("lux_constructionquotes", quoteref.Id, new ColumnSet(true));

            string _recordURL = this.RecordURL.Get(executionContext);

            string[] urlParts = _recordURL.Split("?".ToArray());
            string[] urlParams = urlParts[1].Split("&".ToCharArray());
            string PrimaryObjectTypeCode = urlParams[0].Replace("etc=", "");
            string PrimaryentityName = sGetEntityNameFromCode(PrimaryObjectTypeCode, service);
            string PrimaryId = urlParams[1].Replace("id=", "");

            Entity quote = new Entity(PrimaryentityName, new Guid(PrimaryId));
            quote = service.Retrieve(PrimaryentityName, new Guid(PrimaryId), new ColumnSet(true));

            if (quote.Attributes.Contains("transactioncurrencyid"))
            {
                var Currency = service.Retrieve("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id, new ColumnSet(true));
                var CurrencyCode = Currency.Attributes["isocurrencycode"].ToString();

                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_exchangerate'>
                                <attribute name='createdon' />
                                <attribute name='lux_rate' />
                                <attribute name='lux_exchangeratedate' />
                                <attribute name='lux_exchangeratetime' />
                                <attribute name='lux_isocurrencycode_to' />
                                <attribute name='lux_isocurrencycode_from' />
                                <attribute name='lux_exchangerateid' />
                                <order attribute='lux_exchangeratedate' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_isocurrencycode_from' operator='eq' value='{CurrencyCode}' />
                                </filter>
                              </entity>
                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    var curr = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                    ExchangeRate.Set(executionContext, curr.GetAttributeValue<decimal>("lux_rate"));
                }
                else
                {
                    ExchangeRate.Set(executionContext, 1M);
                }
            }
            else
            {
                ExchangeRate.Set(executionContext, 1M);
            }
        }

        public string sGetEntityNameFromCode(string ObjectTypeCode, IOrganizationService service)
        {
            MetadataFilterExpression entityFilter = new MetadataFilterExpression(LogicalOperator.And);
            entityFilter.Conditions.Add(new MetadataConditionExpression("ObjectTypeCode", MetadataConditionOperator.Equals, Convert.ToInt32(ObjectTypeCode)));
            EntityQueryExpression entityQueryExpression = new EntityQueryExpression()
            {
                Criteria = entityFilter
            };
            RetrieveMetadataChangesRequest retrieveMetadataChangesRequest = new RetrieveMetadataChangesRequest()
            {
                Query = entityQueryExpression,
                ClientVersionStamp = null
            };
            RetrieveMetadataChangesResponse response = (RetrieveMetadataChangesResponse)service.Execute(retrieveMetadataChangesRequest);

            EntityMetadata entityMetadata = (EntityMetadata)response.EntityMetadata[0];
            return entityMetadata.SchemaName.ToLower();
        }
    }
}
