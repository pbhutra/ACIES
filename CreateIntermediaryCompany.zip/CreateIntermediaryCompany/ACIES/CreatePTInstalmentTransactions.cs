﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CreateIntermediaryCompany
{
    public class CreatePTInstalmentTransactions : CodeActivity
    {
        [Input("PT Quote")]
        [ReferenceTarget("lux_portandterminalsquote")]
        public InArgument<EntityReference> PTQuote { get; set; }

        [Input("PT Policy")]
        [ReferenceTarget("lux_portandterminalspolicy")]
        public InArgument<EntityReference> PTPolicy { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference quoteref = PTQuote.Get<EntityReference>(executionContext);
            Entity quote = new Entity(quoteref.LogicalName, quoteref.Id);
            quote = service.Retrieve("lux_portandterminalsquote", quoteref.Id, new ColumnSet(true));

            EntityReference policyref = PTPolicy.Get<EntityReference>(executionContext);
            Entity policy = new Entity(policyref.LogicalName, policyref.Id);
            policy = service.Retrieve("lux_portandterminalspolicy", policyref.Id, new ColumnSet(true));

            var IsInstallment = quote.Attributes.Contains("lux_premiumpayablebyinstalments") ? quote.GetAttributeValue<bool>("lux_premiumpayablebyinstalments") : false;

            decimal totalExcludingIptFee = quote.GetAttributeValue<Money>("lux_quotedsharepolicypremiumbeforetax").Value;

            decimal tedmarCommPct = quote.GetAttributeValue<decimal>("lux_quotedsharemgacommissionpercentage");
            decimal brokerCommPct = quote.GetAttributeValue<decimal>("lux_quotedsharebrokercommissionpercentage");

            decimal totalbrokerCommAmt = quote.GetAttributeValue<Money>("lux_quotedsharebrokercommissionamount").Value;
            decimal totaltedmarCommAmt = quote.GetAttributeValue<Money>("lux_quotedsharemgacommissionamount").Value;

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_portandterminalsinstalment'>
                                <attribute name='lux_instalmentnumber' />
                                <attribute name='lux_duedate' />
                                <attribute name='lux_instalmentvalue' />
                                <attribute name='lux_policyadministrationfee' />
                                <attribute name='lux_instalmentpercentage' />
                                <attribute name='lux_taxamount' />
                                <attribute name='lux_portandterminalsinstalmentid' />
                                <order attribute='lux_instalmentnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_portandterminalsquote' operator='eq' uiname='' uitype='lux_portandterminalsquote' value='{quote.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (IsInstallment == true && service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    var instalmentNumber = Convert.ToInt32(item.FormattedValues["lux_instalmentnumber"]);
                    decimal percentage = item.GetAttributeValue<decimal>("lux_instalmentpercentage");
                    var totalExcludingIPTFEE = item.GetAttributeValue<Money>("lux_instalmentvalue").Value;

                    decimal brokerCommAmt = totalbrokerCommAmt * percentage / 100;
                    decimal tedmarCommAmt = totaltedmarCommAmt * percentage / 100;

                    decimal AdminFee = item.GetAttributeValue<Money>("lux_policyadministrationfee").Value;

                    Entity invoice = new Entity("lux_invoice");
                    invoice["lux_portandterminalsquote"] = new EntityReference("lux_portandterminalsquote", quote.Id);
                    invoice["lux_portandterminalspolicy"] = new EntityReference("lux_portandterminalspolicy", policy.Id);
                    invoice["lux_broker"] = new EntityReference("account", policy.GetAttributeValue<EntityReference>("lux_brokercompany").Id);
                    invoice["transactioncurrencyid"] = new EntityReference("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                    invoice["lux_product"] = new EntityReference("product", quote.GetAttributeValue<EntityReference>("lux_product").Id);
                    invoice["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                    invoice["lux_insured"] = policy.Attributes["lux_insuredname"].ToString();
                    invoice["lux_policynumber"] = policy.Attributes["lux_name"].ToString();
                    invoice["lux_risktransaction"] = new OptionSetValue(972970001);
                    invoice["lux_instalmentpercentage"] = percentage;
                    if (policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
                    {
                        invoice["lux_risktransaction"] = new OptionSetValue(972970002);
                    }

                    invoice["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("createdon");
                    invoice["lux_transactiontype"] = new OptionSetValue(972970002);

                    invoice["lux_aciescommissionrate"] = tedmarCommPct.ToString();
                    invoice["lux_commissionrate"] = brokerCommPct.ToString();

                    invoice["lux_aciescommissionamount"] = new Money(tedmarCommAmt);
                    invoice["lux_commissionamount"] = new Money(brokerCommAmt);

                    invoice["lux_fee"] = new Money(AdminFee);
                    invoice["lux_duedate"] = item.GetAttributeValue<DateTime>("lux_duedate");
                    invoice["lux_grosspremiumexciptfee"] = new Money(totalExcludingIPTFEE);

                    if (instalmentNumber == 1)
                    {
                        invoice["lux_isfirstinstalmenttransaction"] = true;
                    }

                    var IPTRate = quote.Attributes.Contains("lux_policytotaltax") ? quote.GetAttributeValue<decimal>("lux_policytotaltax") : 0M;

                    invoice["lux_iptrate"] = IPTRate;

                    invoice["lux_ipt"] = new Money(totalExcludingIPTFEE * IPTRate / 100);
                    invoice["lux_ptsplit"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - tedmarCommAmt - brokerCommAmt);
                    invoice["lux_totalpremiumincludingiptfee"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 + AdminFee);

                    service.Create(invoice);
                }
            }
        }
    }
}