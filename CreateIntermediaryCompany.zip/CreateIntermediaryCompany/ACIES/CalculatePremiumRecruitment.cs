﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CreateIntermediaryCompany
{
    public class CalculatePremiumRecruitment : CodeActivity
    {
        [Input("Recruitment Quote")]
        [ReferenceTarget("lux_recruitmentquotes")]
        public InArgument<EntityReference> RecruitmentQuote { get; set; }

        [Input("Broker")]
        [ReferenceTarget("account")]
        public InArgument<EntityReference> Broker { get; set; }

        [RequiredArgument]
        [Input("Product")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> Product { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference recruitmentQuoteref = RecruitmentQuote.Get<EntityReference>(executionContext);
            Entity recruitmentQuote = new Entity("lux_recruitmentquotes", recruitmentQuoteref.Id);
            recruitmentQuote = service.Retrieve("lux_recruitmentquotes", recruitmentQuoteref.Id, new ColumnSet(true));

            var Ratingfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_specialistschemerecruitmentpremuim'>
                                <attribute name='lux_name' />
                                <attribute name='lux_section' />
                                <attribute name='lux_recruitmentquote' />
                                <attribute name='transactioncurrencyid' />
                                <attribute name='lux_specialistschemerecruitmentpremuimid' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_recruitmentquote' operator='eq' uiname='' uitype='lux_recruitmentquotes' value='{recruitmentQuote.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            var RateItem = service.RetrieveMultiple(new FetchExpression(Ratingfetch)).Entities;

            var PublicLiabilityPerms = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970001);
            var TempsCAM = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970002);
            var TempsCAMSDC = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970003);
            var TempsCIT = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970004);
            var TempsCITSDC = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970005);
            var TempsPT = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970006);
            var TempsPTSDC = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970007);
            var TempsMNC = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970008);
            var TempsMNCSDC = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970009);
            var TempsDWL = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970010);
            var TempsDWLSDC = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970011);

            var EL = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970012);
            var PI = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970013);
            var Building = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970014);
            var TI = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970015);
            var OC = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970016);
            var CEE = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970017);
            var AllRisksUK = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970018);
            var AllRisksEU = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970019);
            var AllRisksWW = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970020);

            var BILGR = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970021);
            var BIICOW = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970022);
            var LE = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970023);
            var DN = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970026);

            //new
            var TempsCH = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970027);
            var TempsCHSDC = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970028);
            var TempsOP = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970029);
            var TempsOPSDC = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970030);
            var TempsCS = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970031);
            var TempsCSSDC = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970032);
            var TempsSCRW = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970033);
            var TempsSCRWSDC = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970034);
            var TempsSFS = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970035);
            var TempsSFSSDC = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970036);
            var TempsWW = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970037);
            var TempsWWSDC = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970038);
            var TempsOther = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970039);
            var TempsOtherSDC = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value == 972970040);

            var PublicLiabilityPermUK = recruitmentQuote.Attributes.Contains("lux_permanentestimateuk") ? recruitmentQuote.GetAttributeValue<Money>("lux_permanentestimateuk").Value : 0;
            var PublicLiabilityPermWorld = recruitmentQuote.Attributes.Contains("lux_permanentestimateworldwideexcusacanada") ? recruitmentQuote.GetAttributeValue<Money>("lux_permanentestimateworldwideexcusacanada").Value : 0;
            var PublicLiabilityPermUSACanada = recruitmentQuote.Attributes.Contains("lux_permanentestimateusacanada") ? recruitmentQuote.GetAttributeValue<Money>("lux_permanentestimateusacanada").Value : 0;
            var PublicLiabilityPerm = PublicLiabilityPermUK + PublicLiabilityPermWorld + PublicLiabilityPermUSACanada;

            Entity publicLiabilityPerms = new Entity("lux_specialistschemerecruitmentpremuim");
            if (PublicLiabilityPerms != null)
            {
                publicLiabilityPerms = service.Retrieve("lux_specialistschemerecruitmentpremuim", PublicLiabilityPerms.Id, new ColumnSet(true));
            }
            publicLiabilityPerms.Attributes["lux_section"] = new OptionSetValue(972970001);
            publicLiabilityPerms.Attributes["lux_name"] = "Public Liability Perms";
            publicLiabilityPerms.Attributes["lux_ratingfigures"] = new Money(PublicLiabilityPerm);
            publicLiabilityPerms.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
            publicLiabilityPerms.Attributes["lux_roworder"] = 1;

            if (PublicLiabilityPerms != null)
            {
                service.Update(publicLiabilityPerms);
            }
            else
            {
                service.Create(publicLiabilityPerms);
            }

            var PermOnly = recruitmentQuote.Attributes.Contains("lux_doesthebusinesssupplypermanentworkersonly") ? recruitmentQuote.FormattedValues["lux_doesthebusinesssupplypermanentworkersonly"] : "No";
            var ISSDC = recruitmentQuote.Attributes.Contains("lux_doesthebusinessacceptsupervisiondirection") ? recruitmentQuote.FormattedValues["lux_doesthebusinessacceptsupervisiondirection"] : "No";
            var ISCL = recruitmentQuote.Attributes.Contains("lux_doesthebusinesseveracceptcontractual") ? recruitmentQuote.FormattedValues["lux_doesthebusinesseveracceptcontractual"] : "No";

            if (PermOnly == "No")
            {
                var Catfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_recruitmentcategorys'>
                                    <attribute name='lux_totalpayroll' />
                                    <attribute name='createdon' />
                                    <attribute name='lux_recruitmentcategorysid' />
                                    <order attribute='lux_totalpayroll' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_recruitmentquotes' operator='eq' uiname='' uitype='lux_recruitmentquotes' value='{recruitmentQuote.Id}' />
                                    </filter>
                                    <link-entity name='lux_recruitmenttrades' from='lux_recruitmenttradesid' to='lux_trade' visible='false' link-type='outer' alias='trade'>
                                      <attribute name='lux_name' />
                                    </link-entity>
                                  </entity>
                                </fetch>";

                var CatItem = service.RetrieveMultiple(new FetchExpression(Catfetch)).Entities;
                foreach (var item in CatItem)
                {
                    string tradeName = ((String)((item.GetAttributeValue<AliasedValue>("trade.lux_name")).Value));

                    if (tradeName == "Clerical/Administration/Managerial")
                    {
                        if (ISSDC == "Yes" || ISCL == "Yes")
                        {
                            Entity tempsCAMSDC = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsCAMSDC != null)
                            {
                                tempsCAMSDC = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsCAMSDC.Id, new ColumnSet(true));
                            }
                            tempsCAMSDC.Attributes["lux_section"] = new OptionSetValue(972970003);
                            tempsCAMSDC.Attributes["lux_name"] = "Temps Clerical/Administration/Managerial (SDC figure)";
                            tempsCAMSDC.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsCAMSDC.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsCAMSDC.Attributes["lux_roworder"] = 3;

                            if (TempsCAMSDC != null)
                            {
                                service.Update(tempsCAMSDC);
                            }
                            else
                            {
                                service.Create(tempsCAMSDC);
                            }

                            if (TempsCAM != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsCAM.Id);
                            }
                        }
                        else
                        {
                            Entity tempsCAM = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsCAM != null)
                            {
                                tempsCAM = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsCAM.Id, new ColumnSet(true));
                            }
                            tempsCAM.Attributes["lux_section"] = new OptionSetValue(972970002);
                            tempsCAM.Attributes["lux_name"] = "Temps Clerical/Administration/Managerial";
                            tempsCAM.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsCAM.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsCAM.Attributes["lux_roworder"] = 2;

                            if (TempsCAM != null)
                            {
                                service.Update(tempsCAM);
                            }
                            else
                            {
                                service.Create(tempsCAM);
                            }

                            if (TempsCAMSDC != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsCAMSDC.Id);
                            }
                        }
                    }
                    else if (tradeName == "Computing and IT")
                    {
                        if (ISSDC == "Yes" || ISCL == "Yes")
                        {
                            Entity tempsCITSDC = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsCITSDC != null)
                            {
                                tempsCITSDC = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsCITSDC.Id, new ColumnSet(true));
                            }
                            tempsCITSDC.Attributes["lux_section"] = new OptionSetValue(972970005);
                            tempsCITSDC.Attributes["lux_name"] = "Temps Computing and IT (SDC figure)";
                            tempsCITSDC.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsCITSDC.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsCITSDC.Attributes["lux_roworder"] = 5;

                            if (TempsCITSDC != null)
                            {
                                service.Update(tempsCITSDC);
                            }
                            else
                            {
                                service.Create(tempsCITSDC);
                            }

                            if (TempsCIT != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsCIT.Id);
                            }
                        }
                        else
                        {
                            Entity tempsCIT = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsCIT != null)
                            {
                                tempsCIT = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsCIT.Id, new ColumnSet(true));
                            }
                            tempsCIT.Attributes["lux_section"] = new OptionSetValue(972970004);
                            tempsCIT.Attributes["lux_name"] = "Temps Computing and IT";
                            tempsCIT.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsCIT.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsCIT.Attributes["lux_roworder"] = 4;

                            if (TempsCIT != null)
                            {
                                service.Update(tempsCIT);
                            }
                            else
                            {
                                service.Create(tempsCIT);
                            }

                            if (TempsCITSDC != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsCITSDC.Id);
                            }
                        }
                    }
                    else if (tradeName == "Professional/Technical (non-manual)")
                    {
                        if (ISSDC == "Yes" || ISCL == "Yes")
                        {
                            Entity tempsPTSDC = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsPTSDC != null)
                            {
                                tempsPTSDC = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsPTSDC.Id, new ColumnSet(true));
                            }
                            tempsPTSDC.Attributes["lux_section"] = new OptionSetValue(972970007);
                            tempsPTSDC.Attributes["lux_name"] = "Temps Professional/Technical (non-manual) (SDC Figure)";
                            tempsPTSDC.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsPTSDC.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsPTSDC.Attributes["lux_roworder"] = 7;

                            if (TempsPTSDC != null)
                            {
                                service.Update(tempsPTSDC);
                            }
                            else
                            {
                                service.Create(tempsPTSDC);
                            }

                            if (TempsPT != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsPT.Id);
                            }
                        }
                        else
                        {
                            Entity tempsPT = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsPT != null)
                            {
                                tempsPT = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsPT.Id, new ColumnSet(true));
                            }
                            tempsPT.Attributes["lux_section"] = new OptionSetValue(972970006);
                            tempsPT.Attributes["lux_name"] = "Temps Professional/Technical (non-manual)";
                            tempsPT.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsPT.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsPT.Attributes["lux_roworder"] = 6;

                            if (TempsPT != null)
                            {
                                service.Update(tempsPT);
                            }
                            else
                            {
                                service.Create(tempsPT);
                            }

                            if (TempsPTSDC != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsPTSDC.Id);
                            }
                        }
                    }
                    else if (tradeName == "Medical/Nursing/Care (non domiciliary)")
                    {
                        if (ISSDC == "Yes" || ISCL == "Yes")
                        {
                            Entity tempsMNCSDC = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsMNCSDC != null)
                            {
                                tempsMNCSDC = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsMNCSDC.Id, new ColumnSet(true));
                            }
                            tempsMNCSDC.Attributes["lux_section"] = new OptionSetValue(972970009);
                            tempsMNCSDC.Attributes["lux_name"] = "Temps Medical/Nursing/Care (non domiciliary) (SDC figure)";
                            tempsMNCSDC.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsMNCSDC.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsMNCSDC.Attributes["lux_roworder"] = 9;

                            if (TempsMNCSDC != null)
                            {
                                service.Update(tempsMNCSDC);
                            }
                            else
                            {
                                service.Create(tempsMNCSDC);
                            }

                            if (TempsMNC != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsMNC.Id);
                            }
                        }
                        else
                        {
                            Entity tempsMNC = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsMNC != null)
                            {
                                tempsMNC = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsMNC.Id, new ColumnSet(true));
                            }
                            tempsMNC.Attributes["lux_section"] = new OptionSetValue(972970008);
                            tempsMNC.Attributes["lux_name"] = "Temps Medical/Nursing/Care (non domiciliary)";
                            tempsMNC.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsMNC.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsMNC.Attributes["lux_roworder"] = 8;

                            if (TempsMNC != null)
                            {
                                service.Update(tempsMNC);
                            }
                            else
                            {
                                service.Create(tempsMNC);
                            }

                            if (TempsMNCSDC != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsMNCSDC.Id);
                            }
                        }
                    }
                    else if (tradeName == "Manual (drivers/Warehouse/Light Industrial)")
                    {
                        if (ISSDC == "Yes" || ISCL == "Yes")
                        {
                            Entity tempsDWLSDC = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsDWLSDC != null)
                            {
                                tempsDWLSDC = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsDWLSDC.Id, new ColumnSet(true));
                            }
                            tempsDWLSDC.Attributes["lux_section"] = new OptionSetValue(972970011);
                            tempsDWLSDC.Attributes["lux_name"] = "Temps Manual (drivers/Warehouse/Light Industrial) (SDC figure)";
                            tempsDWLSDC.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsDWLSDC.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsDWLSDC.Attributes["lux_roworder"] = 11;

                            if (TempsDWLSDC != null)
                            {
                                service.Update(tempsDWLSDC);
                            }
                            else
                            {
                                service.Create(tempsDWLSDC);
                            }

                            if (TempsDWL != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsDWL.Id);
                            }
                        }
                        else
                        {
                            Entity tempsDWL = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsDWL != null)
                            {
                                tempsDWL = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsDWL.Id, new ColumnSet(true));
                            }
                            tempsDWL.Attributes["lux_section"] = new OptionSetValue(972970010);
                            tempsDWL.Attributes["lux_name"] = "Temps Manual (drivers/Warehouse/Light Industrial)";
                            tempsDWL.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsDWL.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsDWL.Attributes["lux_roworder"] = 10;

                            if (TempsDWL != null)
                            {
                                service.Update(tempsDWL);
                            }
                            else
                            {
                                service.Create(tempsDWL);
                            }

                            if (TempsDWLSDC != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsDWLSDC.Id);
                            }
                        }
                    }
                    else if (tradeName == "Manual (Construction/Heavy Industrial)")
                    {
                        if (ISSDC == "Yes" || ISCL == "Yes")
                        {
                            Entity tempsCHSDC = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsCHSDC != null)
                            {
                                tempsCHSDC = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsCHSDC.Id, new ColumnSet(true));
                            }
                            tempsCHSDC.Attributes["lux_section"] = new OptionSetValue(972970028);
                            tempsCHSDC.Attributes["lux_name"] = "Temps Manual (Construction/Heavy Industrial) (SDC figure)";
                            tempsCHSDC.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsCHSDC.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsCHSDC.Attributes["lux_roworder"] = 13;

                            if (TempsCHSDC != null)
                            {
                                service.Update(tempsCHSDC);
                            }
                            else
                            {
                                service.Create(tempsCHSDC);
                            }

                            if (TempsCH != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsCH.Id);
                            }
                        }
                        else
                        {
                            Entity tempsCH = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsCH != null)
                            {
                                tempsCH = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsCH.Id, new ColumnSet(true));
                            }
                            tempsCH.Attributes["lux_section"] = new OptionSetValue(972970027);
                            tempsCH.Attributes["lux_name"] = "Temps Manual (Construction/Heavy Industrial)";
                            tempsCH.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsCH.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsCH.Attributes["lux_roworder"] = 12;

                            if (TempsCH != null)
                            {
                                service.Update(tempsCH);
                            }
                            else
                            {
                                service.Create(tempsCH);
                            }

                            if (TempsCHSDC != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsCHSDC.Id);
                            }
                        }
                    }
                    else if (tradeName == "Offshore Manual (e.g. Oil rigs/platforms)")
                    {
                        if (ISSDC == "Yes" || ISCL == "Yes")
                        {
                            Entity tempsOPSDC = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsOPSDC != null)
                            {
                                tempsOPSDC = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsOPSDC.Id, new ColumnSet(true));
                            }
                            tempsOPSDC.Attributes["lux_section"] = new OptionSetValue(972970030);
                            tempsOPSDC.Attributes["lux_name"] = "Temps Offshore Manual (e.g. Oil rigs/platforms) (SDC figure)";
                            tempsOPSDC.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsOPSDC.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsOPSDC.Attributes["lux_roworder"] = 15;

                            if (TempsOPSDC != null)
                            {
                                service.Update(tempsOPSDC);
                            }
                            else
                            {
                                service.Create(tempsOPSDC);
                            }

                            if (TempsOP != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsOP.Id);
                            }
                        }
                        else
                        {
                            Entity tempsOP = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsOP != null)
                            {
                                tempsOP = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsOP.Id, new ColumnSet(true));
                            }
                            tempsOP.Attributes["lux_section"] = new OptionSetValue(972970029);
                            tempsOP.Attributes["lux_name"] = "Temps Offshore Manual (e.g. Oil rigs/platforms)";
                            tempsOP.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsOP.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsOP.Attributes["lux_roworder"] = 14;

                            if (TempsOP != null)
                            {
                                service.Update(tempsOP);
                            }
                            else
                            {
                                service.Create(tempsOP);
                            }

                            if (TempsOPSDC != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsOPSDC.Id);
                            }
                        }
                    }
                    else if (tradeName == "Offshore Non Manual (e.g. control systems/software engineer")
                    {
                        if (ISSDC == "Yes" || ISCL == "Yes")
                        {
                            Entity tempsCSSDC = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsCSSDC != null)
                            {
                                tempsCSSDC = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsCSSDC.Id, new ColumnSet(true));
                            }
                            tempsCSSDC.Attributes["lux_section"] = new OptionSetValue(972970032);
                            tempsCSSDC.Attributes["lux_name"] = "Temps Offshore Non Manual (e.g. control systems/software engineer) (SDC figure)";
                            tempsCSSDC.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsCSSDC.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsCSSDC.Attributes["lux_roworder"] = 17;

                            if (TempsCSSDC != null)
                            {
                                service.Update(tempsCSSDC);
                            }
                            else
                            {
                                service.Create(tempsCSSDC);
                            }

                            if (TempsCS != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsCS.Id);
                            }
                        }
                        else
                        {
                            Entity tempsCS = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsCS != null)
                            {
                                tempsCS = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsCS.Id, new ColumnSet(true));
                            }
                            tempsCS.Attributes["lux_section"] = new OptionSetValue(972970031);
                            tempsCS.Attributes["lux_name"] = "Temps Offshore Non Manual (e.g. control systems/software engineer)";
                            tempsCS.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsCS.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsCS.Attributes["lux_roworder"] = 16;

                            if (TempsCS != null)
                            {
                                service.Update(tempsCS);
                            }
                            else
                            {
                                service.Create(tempsCS);
                            }

                            if (TempsCSSDC != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsCSSDC.Id);
                            }
                        }
                    }
                    else if (tradeName == "Safety Critical Rail Work")
                    {
                        if (ISSDC == "Yes" || ISCL == "Yes")
                        {
                            Entity tempsSCRWSDC = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsSCRWSDC != null)
                            {
                                tempsSCRWSDC = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsSCRWSDC.Id, new ColumnSet(true));
                            }
                            tempsSCRWSDC.Attributes["lux_section"] = new OptionSetValue(972970034);
                            tempsSCRWSDC.Attributes["lux_name"] = "Temps Safety Critical Rail Work (SDC figure)";
                            tempsSCRWSDC.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsSCRWSDC.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsSCRWSDC.Attributes["lux_roworder"] = 19;

                            if (TempsSCRWSDC != null)
                            {
                                service.Update(tempsSCRWSDC);
                            }
                            else
                            {
                                service.Create(tempsSCRWSDC);
                            }

                            if (TempsSCRW != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsSCRW.Id);
                            }
                        }
                        else
                        {
                            Entity tempsSCRW = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsSCRW != null)
                            {
                                tempsSCRW = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsSCRW.Id, new ColumnSet(true));
                            }
                            tempsSCRW.Attributes["lux_section"] = new OptionSetValue(972970033);
                            tempsSCRW.Attributes["lux_name"] = "Temps Safety Critical Rail Work";
                            tempsSCRW.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsSCRW.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsSCRW.Attributes["lux_roworder"] = 18;

                            if (TempsSCRW != null)
                            {
                                service.Update(tempsSCRW);
                            }
                            else
                            {
                                service.Create(tempsSCRW);
                            }

                            if (TempsSCRWSDC != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsSCRWSDC.Id);
                            }
                        }
                    }
                    else if (tradeName == "Solicitors or Financial Services (FCA Regulated Activity)")
                    {
                        if (ISSDC == "Yes" || ISCL == "Yes")
                        {
                            Entity tempsSFSSDC = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsSFSSDC != null)
                            {
                                tempsSFSSDC = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsSFSSDC.Id, new ColumnSet(true));
                            }
                            tempsSFSSDC.Attributes["lux_section"] = new OptionSetValue(972970036);
                            tempsSFSSDC.Attributes["lux_name"] = "Temps Solicitors or Financial Services (FCA Regulated Activity) (SDC figure)";
                            tempsSFSSDC.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsSFSSDC.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsSFSSDC.Attributes["lux_roworder"] = 21;

                            if (TempsSFSSDC != null)
                            {
                                service.Update(tempsSFSSDC);
                            }
                            else
                            {
                                service.Create(tempsSFSSDC);
                            }

                            if (TempsSFS != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsSFS.Id);
                            }
                        }
                        else
                        {
                            Entity tempsSFS = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsSFS != null)
                            {
                                tempsSFS = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsSFS.Id, new ColumnSet(true));
                            }
                            tempsSFS.Attributes["lux_section"] = new OptionSetValue(972970035);
                            tempsSFS.Attributes["lux_name"] = "Temps Solicitors or Financial Services (FCA Regulated Activity)";
                            tempsSFS.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsSFS.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsSFS.Attributes["lux_roworder"] = 20;

                            if (TempsSFS != null)
                            {
                                service.Update(tempsSFS);
                            }
                            else
                            {
                                service.Create(tempsSFS);
                            }

                            if (TempsSFSSDC != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsSFSSDC.Id);
                            }
                        }
                    }
                    else if (tradeName == "Welders/Work involving use of heat")
                    {
                        if (ISSDC == "Yes" || ISCL == "Yes")
                        {
                            Entity tempsWWSDC = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsWWSDC != null)
                            {
                                tempsWWSDC = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsWWSDC.Id, new ColumnSet(true));
                            }
                            tempsWWSDC.Attributes["lux_section"] = new OptionSetValue(972970038);
                            tempsWWSDC.Attributes["lux_name"] = "Temps Welders/Work involving use of heat (SDC figure)";
                            tempsWWSDC.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsWWSDC.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsWWSDC.Attributes["lux_roworder"] = 23;

                            if (TempsWWSDC != null)
                            {
                                service.Update(tempsWWSDC);
                            }
                            else
                            {
                                service.Create(tempsWWSDC);
                            }

                            if (TempsWW != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsWW.Id);
                            }
                        }
                        else
                        {
                            Entity tempsWW = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsWW != null)
                            {
                                tempsWW = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsWW.Id, new ColumnSet(true));
                            }
                            tempsWW.Attributes["lux_section"] = new OptionSetValue(972970037);
                            tempsWW.Attributes["lux_name"] = "Temps Welders/Work involving use of heat";
                            tempsWW.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsWW.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsWW.Attributes["lux_roworder"] = 22;

                            if (TempsWW != null)
                            {
                                service.Update(tempsWW);
                            }
                            else
                            {
                                service.Create(tempsWW);
                            }

                            if (TempsWWSDC != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsWWSDC.Id);
                            }
                        }
                    }
                    else if (tradeName == "Other")
                    {
                        if (ISSDC == "Yes" || ISCL == "Yes")
                        {
                            Entity tempsOtherSDC = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsOtherSDC != null)
                            {
                                tempsOtherSDC = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsOtherSDC.Id, new ColumnSet(true));
                            }
                            tempsOtherSDC.Attributes["lux_section"] = new OptionSetValue(972970040);
                            tempsOtherSDC.Attributes["lux_name"] = "Temps Other (SDC figure)";
                            tempsOtherSDC.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsOtherSDC.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsOtherSDC.Attributes["lux_roworder"] = 25;

                            if (TempsOtherSDC != null)
                            {
                                service.Update(tempsOtherSDC);
                            }
                            else
                            {
                                service.Create(tempsOtherSDC);
                            }

                            if (TempsOther != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsOther.Id);
                            }
                        }
                        else
                        {
                            Entity tempsOther = new Entity("lux_specialistschemerecruitmentpremuim");
                            if (TempsOther != null)
                            {
                                tempsOther = service.Retrieve("lux_specialistschemerecruitmentpremuim", TempsOther.Id, new ColumnSet(true));
                            }
                            tempsOther.Attributes["lux_section"] = new OptionSetValue(972970039);
                            tempsOther.Attributes["lux_name"] = "Temps Other";
                            tempsOther.Attributes["lux_ratingfigures"] = item.GetAttributeValue<Money>("lux_totalpayroll");
                            tempsOther.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                            tempsOther.Attributes["lux_roworder"] = 24;

                            if (TempsOther != null)
                            {
                                service.Update(tempsOther);
                            }
                            else
                            {
                                service.Create(tempsOther);
                            }

                            if (TempsOtherSDC != null)
                            {
                                service.Delete("lux_specialistschemerecruitmentpremuim", TempsOtherSDC.Id);
                            }
                        }
                    }
                }
            }
            else
            {
                foreach (var item in RateItem.Where(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value >= 972970002 && x.GetAttributeValue<OptionSetValue>("lux_section").Value <= 972970011))
                {
                    service.Delete("lux_specialistschemerecruitmentpremuim", item.Id);
                }
            }

            var IsDriverCover = recruitmentQuote.Attributes.Contains("lux_isdriversnegligencecoverrequired") ? recruitmentQuote.GetAttributeValue<bool>("lux_isdriversnegligencecoverrequired") : false;
            if (IsDriverCover == true)
            {
                var maxDriver = recruitmentQuote.Attributes.Contains("lux_pleaseadvisethemaximumnumberofdrivers") ? recruitmentQuote.GetAttributeValue<string>("lux_pleaseadvisethemaximumnumberofdrivers") : "";

                Entity dn = new Entity("lux_specialistschemerecruitmentpremuim");
                if (DN != null)
                {
                    dn = service.Retrieve("lux_specialistschemerecruitmentpremuim", DN.Id, new ColumnSet(true));
                }
                dn.Attributes["lux_section"] = new OptionSetValue(972970026);
                dn.Attributes["lux_name"] = "Drivers Negligence";
                dn.Attributes["lux_ratingfigures"] = new Money(Convert.ToDecimal(maxDriver));
                dn.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                dn.Attributes["lux_roworder"] = 27;

                if (DN != null)
                {
                    service.Update(dn);
                }
                else
                {
                    service.Create(dn);
                }
            }
            else
            {
                if (DN != null)
                {
                    service.Delete("lux_specialistschemerecruitmentpremuim", DN.Id);
                }
            }

            var ELWageroll = recruitmentQuote.Attributes.Contains("lux_estimatedwagerollofagencysownstaff") ? recruitmentQuote.GetAttributeValue<Money>("lux_estimatedwagerollofagencysownstaff").Value : 0;

            Entity el = new Entity("lux_specialistschemerecruitmentpremuim");
            if (EL != null)
            {
                el = service.Retrieve("lux_specialistschemerecruitmentpremuim", EL.Id, new ColumnSet(true));
            }
            el.Attributes["lux_section"] = new OptionSetValue(972970012);
            el.Attributes["lux_name"] = "Employers Liability";
            el.Attributes["lux_ratingfigures"] = new Money(ELWageroll);
            el.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
            el.Attributes["lux_roworder"] = 28;

            if (EL != null)
            {
                service.Update(el);
            }
            else
            {
                service.Create(el);
            }


            var PILOI = recruitmentQuote.Attributes.Contains("lux_professionallimitofindemnity") ? Convert.ToInt32(recruitmentQuote.FormattedValues["lux_professionallimitofindemnity"].Replace("£", "").Replace(",", "")) : 0;

            Entity pI = new Entity("lux_specialistschemerecruitmentpremuim");
            if (PI != null)
            {
                pI = service.Retrieve("lux_specialistschemerecruitmentpremuim", PI.Id, new ColumnSet(true));
            }
            pI.Attributes["lux_section"] = new OptionSetValue(972970013);
            pI.Attributes["lux_name"] = "Professional Indemnity";
            pI.Attributes["lux_ratingfigures"] = new Money(PILOI);
            pI.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
            pI.Attributes["lux_roworder"] = 29;

            if (PI != null)
            {
                service.Update(pI);
            }
            else
            {
                service.Create(pI);
            }


            var IsPropertyCover = recruitmentQuote.Attributes.Contains("lux_ispropertycoverrequired") ? recruitmentQuote.GetAttributeValue<bool>("lux_ispropertycoverrequired") : false;
            if (IsPropertyCover == true)
            {
                var propfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='lux_recruitmentlocations'>
                                        <attribute name='lux_locationnumber' />
                                        <attribute name='lux_istheriskaddressthesameasregisteredaddres' />
                                        <attribute name='lux_location1postcode' />
                                        <attribute name='lux_location1housenumber' />
                                        <attribute name='lux_location1street' />
                                        <attribute name='lux_location1towncity' />
                                        <attribute name='lux_location1county' />
                                        <attribute name='lux_buildingssuminsured' />
                                        <attribute name='lux_geographicalarea' />
                                        <attribute name='lux_tenantsimprovementssuminsured' />
                                        <attribute name='lux_officecontentssuminsured' />
                                        <attribute name='lux_computerselectronicequipmentsuminsured' />
                                        <attribute name='lux_allriskssuminsuredoption' />
                                        <attribute name='lux_pleaseselectterritoriallimitsrequiredfor' />
                                        <attribute name='lux_recruitmentlocationsid' />
                                        <order attribute='lux_locationnumber' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='statecode' operator='eq' value='0' />
                                          <condition attribute='lux_recruitmentquotes' operator='eq' uiname='' uitype='lux_recruitmentquotes' value='{recruitmentQuote.Id}' />
                                        </filter>
                                      </entity>
                                    </fetch>";

                var AllRiskItem = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='lux_risksuminsureddetails'>
                                        <attribute name='lux_risksuminsureddetailsid' />
                                        <attribute name='lux_name' />
                                        <attribute name='lux_excess' />
                                        <attribute name='lux_suminsured' />
                                        <order attribute='lux_name' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='statecode' operator='eq' value='0' />
                                          <condition attribute='lux_recruitmentlocation' operator='in'>";
                foreach (var item in service.RetrieveMultiple(new FetchExpression(propfetch)).Entities)
                {
                    AllRiskItem += $@"<value uiname='' uitype='lux_recruitmentlocations'>{item.Id}</value>";
                }
                AllRiskItem += $@"</condition>
                                        </filter>
                                      </entity>
                                    </fetch>";

                var PropItem = service.RetrieveMultiple(new FetchExpression(propfetch)).Entities;

                var BuildingSI = PropItem.Sum(x => x.Attributes.Contains("lux_buildingssuminsured") ? x.GetAttributeValue<Money>("lux_buildingssuminsured").Value : 0);
                var TenantsSI = PropItem.Sum(x => x.Attributes.Contains("lux_tenantsimprovementssuminsured") ? x.GetAttributeValue<Money>("lux_tenantsimprovementssuminsured").Value : 0);
                var OfficeSI = PropItem.Sum(x => x.Attributes.Contains("lux_officecontentssuminsured") ? x.GetAttributeValue<Money>("lux_officecontentssuminsured").Value : 0);
                var ComputerSI = PropItem.Sum(x => x.Attributes.Contains("lux_computerselectronicequipmentsuminsured") ? x.GetAttributeValue<Money>("lux_computerselectronicequipmentsuminsured").Value : 0);
                var ISAllRiskSelected = PropItem.Where(x => (x.Attributes.Contains("lux_allriskssuminsuredoption") ? x.GetAttributeValue<bool>("lux_allriskssuminsuredoption") : false) == true);

                var AllRiskSIUK = 0M;
                var AllRiskSIEU = 0M;
                var AllRiskSIWorld = 0M;

                var AllRiskItems = service.RetrieveMultiple(new FetchExpression(AllRiskItem)).Entities;

                if (AllRiskItems.Count > 0)
                {
                    if (PropItem.FirstOrDefault().Attributes.Contains("lux_geographicalarea") && PropItem.FirstOrDefault().FormattedValues["lux_geographicalarea"] == "UK")
                    {
                        AllRiskSIUK = AllRiskItems.Sum(x => x.Attributes.Contains("lux_suminsured") ? x.GetAttributeValue<Money>("lux_suminsured").Value : 0);
                    }

                    if (PropItem.FirstOrDefault().Attributes.Contains("lux_geographicalarea") && PropItem.FirstOrDefault().FormattedValues["lux_geographicalarea"] == "UK and Europe")
                    {
                        AllRiskSIEU = AllRiskItems.Sum(x => x.Attributes.Contains("lux_suminsured") ? x.GetAttributeValue<Money>("lux_suminsured").Value : 0);
                    }

                    if (PropItem.FirstOrDefault().Attributes.Contains("lux_geographicalarea") && PropItem.FirstOrDefault().FormattedValues["lux_geographicalarea"] == "Worldwide")
                    {
                        AllRiskSIWorld = AllRiskItems.Sum(x => x.Attributes.Contains("lux_suminsured") ? x.GetAttributeValue<Money>("lux_suminsured").Value : 0);
                    }
                }

                if (BuildingSI > 0)
                {
                    Entity building = new Entity("lux_specialistschemerecruitmentpremuim");
                    if (Building != null)
                    {
                        building = service.Retrieve("lux_specialistschemerecruitmentpremuim", Building.Id, new ColumnSet(true));
                    }
                    building.Attributes["lux_section"] = new OptionSetValue(972970014);
                    building.Attributes["lux_name"] = "Buildings";
                    building.Attributes["lux_ratingfigures"] = new Money(BuildingSI);
                    building.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                    building.Attributes["lux_roworder"] = 30;

                    if (Building != null)
                    {
                        service.Update(building);
                    }
                    else
                    {
                        service.Create(building);
                    }
                }
                else
                {
                    if (Building != null)
                    {
                        service.Delete("lux_specialistschemerecruitmentpremuim", Building.Id);
                    }
                }

                if (TenantsSI > 0)
                {
                    Entity tI = new Entity("lux_specialistschemerecruitmentpremuim");
                    if (TI != null)
                    {
                        tI = service.Retrieve("lux_specialistschemerecruitmentpremuim", TI.Id, new ColumnSet(true));
                    }
                    tI.Attributes["lux_section"] = new OptionSetValue(972970015);
                    tI.Attributes["lux_name"] = "Tenants Improvements";
                    tI.Attributes["lux_ratingfigures"] = new Money(TenantsSI);
                    tI.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                    tI.Attributes["lux_roworder"] = 31;

                    if (TI != null)
                    {
                        service.Update(tI);
                    }
                    else
                    {
                        service.Create(tI);
                    }
                }
                else
                {
                    if (TI != null)
                    {
                        service.Delete("lux_specialistschemerecruitmentpremuim", TI.Id);
                    }
                }

                if (OfficeSI > 0)
                {
                    Entity oC = new Entity("lux_specialistschemerecruitmentpremuim");
                    if (OC != null)
                    {
                        oC = service.Retrieve("lux_specialistschemerecruitmentpremuim", OC.Id, new ColumnSet(true));
                    }
                    oC.Attributes["lux_section"] = new OptionSetValue(972970016);
                    oC.Attributes["lux_name"] = "Office Contents";
                    oC.Attributes["lux_ratingfigures"] = new Money(OfficeSI);
                    oC.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                    oC.Attributes["lux_roworder"] = 32;

                    if (OC != null)
                    {
                        service.Update(oC);
                    }
                    else
                    {
                        service.Create(oC);
                    }
                }
                else
                {
                    if (OC != null)
                    {
                        service.Delete("lux_specialistschemerecruitmentpremuim", OC.Id);
                    }
                }

                if (ComputerSI > 0)
                {
                    Entity cEE = new Entity("lux_specialistschemerecruitmentpremuim");
                    if (CEE != null)
                    {
                        cEE = service.Retrieve("lux_specialistschemerecruitmentpremuim", CEE.Id, new ColumnSet(true));
                    }
                    cEE.Attributes["lux_section"] = new OptionSetValue(972970017);
                    cEE.Attributes["lux_name"] = "Computers & Electronic Equipment";
                    cEE.Attributes["lux_ratingfigures"] = new Money(ComputerSI);
                    cEE.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                    cEE.Attributes["lux_roworder"] = 33;

                    if (CEE != null)
                    {
                        service.Update(cEE);
                    }
                    else
                    {
                        service.Create(cEE);
                    }
                }
                else
                {
                    if (CEE != null)
                    {
                        service.Delete("lux_specialistschemerecruitmentpremuim", CEE.Id);
                    }
                }

                if (AllRiskSIUK > 0)
                {
                    Entity allRisksUK = new Entity("lux_specialistschemerecruitmentpremuim");
                    if (AllRisksUK != null)
                    {
                        allRisksUK = service.Retrieve("lux_specialistschemerecruitmentpremuim", AllRisksUK.Id, new ColumnSet(true));
                    }
                    allRisksUK.Attributes["lux_section"] = new OptionSetValue(972970018);
                    allRisksUK.Attributes["lux_name"] = "All Risks UK";
                    allRisksUK.Attributes["lux_ratingfigures"] = new Money(AllRiskSIUK);
                    allRisksUK.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                    allRisksUK.Attributes["lux_roworder"] = 34;

                    if (AllRisksUK != null)
                    {
                        service.Update(allRisksUK);
                    }
                    else
                    {
                        service.Create(allRisksUK);
                    }
                }
                else
                {
                    if (AllRisksUK != null)
                    {
                        service.Delete("lux_specialistschemerecruitmentpremuim", AllRisksUK.Id);
                    }
                }


                if (AllRiskSIEU > 0)
                {
                    Entity allRisksEU = new Entity("lux_specialistschemerecruitmentpremuim");
                    if (AllRisksEU != null)
                    {
                        allRisksEU = service.Retrieve("lux_specialistschemerecruitmentpremuim", AllRisksEU.Id, new ColumnSet(true));
                    }
                    allRisksEU.Attributes["lux_section"] = new OptionSetValue(972970019);
                    allRisksEU.Attributes["lux_name"] = "All Risks EU & UK";
                    allRisksEU.Attributes["lux_ratingfigures"] = new Money(AllRiskSIEU);
                    allRisksEU.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                    allRisksEU.Attributes["lux_roworder"] = 35;

                    if (AllRisksEU != null)
                    {
                        service.Update(allRisksEU);
                    }
                    else
                    {
                        service.Create(allRisksEU);
                    }
                }
                else
                {
                    if (AllRisksEU != null)
                    {
                        service.Delete("lux_specialistschemerecruitmentpremuim", AllRisksEU.Id);
                    }
                }


                if (AllRiskSIWorld > 0)
                {
                    Entity allRisksWW = new Entity("lux_specialistschemerecruitmentpremuim");
                    if (AllRisksWW != null)
                    {
                        allRisksWW = service.Retrieve("lux_specialistschemerecruitmentpremuim", AllRisksWW.Id, new ColumnSet(true));
                    }
                    allRisksWW.Attributes["lux_section"] = new OptionSetValue(972970020);
                    allRisksWW.Attributes["lux_name"] = "All Risks WW";
                    allRisksWW.Attributes["lux_ratingfigures"] = new Money(AllRiskSIWorld);
                    allRisksWW.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                    allRisksWW.Attributes["lux_roworder"] = 36;

                    if (AllRisksWW != null)
                    {
                        service.Update(allRisksWW);
                    }
                    else
                    {
                        service.Create(allRisksWW);
                    }
                }
                else
                {
                    if (AllRisksWW != null)
                    {
                        service.Delete("lux_specialistschemerecruitmentpremuim", AllRisksWW.Id);
                    }
                }
            }
            else
            {
                foreach (var item in RateItem.Where(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value >= 972970014 && x.GetAttributeValue<OptionSetValue>("lux_section").Value <= 972970020))
                {
                    service.Delete("lux_specialistschemerecruitmentpremuim", item.Id);
                }
            }

            var IsBICover = recruitmentQuote.Attributes.Contains("lux_isbusinessinterruptioncoverrequired") ? recruitmentQuote.GetAttributeValue<bool>("lux_isbusinessinterruptioncoverrequired") : false;
            if (IsBICover == true)
            {
                var Basis = recruitmentQuote.Attributes.Contains("lux_pleaseselectthebasisofcover") ? recruitmentQuote.FormattedValues["lux_pleaseselectthebasisofcover"] : "";
                var BISI = recruitmentQuote.Attributes.Contains("lux_businessinterruptionsuminsured") ? recruitmentQuote.GetAttributeValue<Money>("lux_businessinterruptionsuminsured").Value : 0;

                if (Basis == "LOSS OF GROSS REVENUE")
                {
                    Entity bILGR = new Entity("lux_specialistschemerecruitmentpremuim");
                    if (BILGR != null)
                    {
                        bILGR = service.Retrieve("lux_specialistschemerecruitmentpremuim", BILGR.Id, new ColumnSet(true));
                    }
                    bILGR.Attributes["lux_section"] = new OptionSetValue(972970021);
                    bILGR.Attributes["lux_name"] = "Business Interruption LGR";
                    bILGR.Attributes["lux_ratingfigures"] = new Money(BISI);
                    bILGR.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                    bILGR.Attributes["lux_roworder"] = 37;

                    if (BILGR != null)
                    {
                        service.Update(bILGR);
                    }
                    else
                    {
                        service.Create(bILGR);
                    }

                    if (BIICOW != null)
                    {
                        service.Delete("lux_specialistschemerecruitmentpremuim", BIICOW.Id);
                    }
                }
                else
                {
                    Entity bIICOW = new Entity("lux_specialistschemerecruitmentpremuim");
                    if (BIICOW != null)
                    {
                        bIICOW = service.Retrieve("lux_specialistschemerecruitmentpremuim", BIICOW.Id, new ColumnSet(true));
                    }
                    bIICOW.Attributes["lux_section"] = new OptionSetValue(972970022);
                    bIICOW.Attributes["lux_name"] = "Business Interruption ICOW";
                    bIICOW.Attributes["lux_ratingfigures"] = new Money(BISI);
                    bIICOW.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                    bIICOW.Attributes["lux_roworder"] = 38;

                    if (BIICOW != null)
                    {
                        service.Update(bIICOW);
                    }
                    else
                    {
                        service.Create(bIICOW);
                    }

                    if (BILGR != null)
                    {
                        service.Delete("lux_specialistschemerecruitmentpremuim", BILGR.Id);
                    }
                }
            }
            else
            {
                foreach (var item in RateItem.Where(x => x.GetAttributeValue<OptionSetValue>("lux_section").Value >= 972970021 && x.GetAttributeValue<OptionSetValue>("lux_section").Value <= 972970022))
                {
                    service.Delete("lux_specialistschemerecruitmentpremuim", item.Id);
                }
            }

            var IsLECover = recruitmentQuote.Attributes.Contains("lux_islegalexpensescoverrequired") ? recruitmentQuote.GetAttributeValue<bool>("lux_islegalexpensescoverrequired") : false;
            if (IsLECover == true)
            {
                var LELOI = recruitmentQuote.Attributes.Contains("lux_legalexpenseslimitofindemnity") ? Convert.ToInt32(recruitmentQuote.FormattedValues["lux_legalexpenseslimitofindemnity"].Replace("£", "").Replace(",", "").Replace("Any One Claim", "").Trim()) : 0;
                Entity lE = new Entity("lux_specialistschemerecruitmentpremuim");
                if (LE != null)
                {
                    lE = service.Retrieve("lux_specialistschemerecruitmentpremuim", LE.Id, new ColumnSet(true));
                }
                lE.Attributes["lux_section"] = new OptionSetValue(972970023);
                lE.Attributes["lux_name"] = "Legal Expenses";
                lE.Attributes["lux_ratingfigures"] = new Money(LELOI);
                lE.Attributes["lux_recruitmentquote"] = new EntityReference("lux_recruitmentquotes", recruitmentQuote.Id);
                lE.Attributes["lux_roworder"] = 39;

                if (LE != null)
                {
                    service.Update(lE);
                }
                else
                {
                    service.Create(lE);
                }
            }
            else
            {
                if (LE != null)
                {
                    service.Delete("lux_specialistschemerecruitmentpremuim", LE.Id);
                }
            }

            var inceptionDate = recruitmentQuote.GetAttributeValue<DateTime>("lux_inceptiondate");
            var quotationDate = recruitmentQuote.Attributes.Contains("lux_quotationdate") ? recruitmentQuote.GetAttributeValue<DateTime>("lux_quotationdate") : inceptionDate;

            decimal BrokerComm = 25M;
            decimal aciesComm = 7.5M;

            var BrokerFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_brokercommission'>
                                            <attribute name='createdon' />
                                            <attribute name='lux_product' />
                                            <attribute name='lux_commission' />
                                            <attribute name='lux_renewalcommission' />
                                            <attribute name='lux_brokercommissionid' />
                                            <order attribute='createdon' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <filter type='or'>
                                                <condition attribute='lux_effectivefrom' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                <condition attribute='lux_effectivefrom' operator='null' />
                                              </filter>
                                              <filter type='or'>
                                                <condition attribute='lux_effectiveto' operator='on-or-after' value= '{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                <condition attribute='lux_effectiveto' operator='null' />
                                              </filter>
                                              <condition attribute='lux_broker' operator='eq' uiname='' uitype='account' value='{Broker.Get(executionContext).Id}' />
                                              <condition attribute='lux_product' operator='eq' uiname='' uitype='product' value='{Product.Get(executionContext).Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";
            if (service.RetrieveMultiple(new FetchExpression(BrokerFetch)).Entities.Count > 0)
            {
                var BrokerCommission = service.RetrieveMultiple(new FetchExpression(BrokerFetch)).Entities[0];
                BrokerComm = BrokerCommission.GetAttributeValue<decimal>("lux_commission");
                aciesComm = 32.5M - BrokerComm;
            }

            Entity application = service.Retrieve("lux_recruitmentquotes", recruitmentQuote.Id, new ColumnSet("lux_policybrokercommission", "lux_policyaciescommission"));
            application["lux_technicalbrokercommission"] = BrokerComm;
            application["lux_technicalaciescommission"] = aciesComm;
            application["lux_policybrokercommission"] = BrokerComm;
            application["lux_policyaciescommission"] = aciesComm;

            //if (!application.Attributes.Contains("lux_policybrokercommission"))
            //{
            //    application["lux_policybrokercommission"] = BrokerComm;
            //}
            //if (!application.Attributes.Contains("lux_policyaciescommission"))
            //{
            //    application["lux_policyaciescommission"] = aciesComm;
            //}
            service.Update(application);

            //var EmployeeToolsAnyOneEmp = recruitmentQuote.Attributes.Contains("lux_employeetoolsanyoneemployee") ? recruitmentQuote.GetAttributeValue<Money>("lux_employeetoolsanyoneemployee").Value : 0;
            //var HiredinPlant = recruitmentQuote.Attributes.Contains("lux_annualhiringcharges") ? recruitmentQuote.GetAttributeValue<Money>("lux_annualhiringcharges").Value : 0;
            //var OwnPlantValue = recruitmentQuote.Attributes.Contains("lux_totalownplantvalue") ? recruitmentQuote.GetAttributeValue<Money>("lux_totalownplantvalue").Value : 0;
            //var BoundShare = recruitmentQuote.Attributes.Contains("lux_phoenixsharebound") ? recruitmentQuote.GetAttributeValue<decimal>("lux_phoenixsharebound") : 0;

            //var FinalRatingfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            //                  <entity name='lux_recruitmenttechnicalpremiumcalculation'>
            //                    <attribute name='lux_name' />
            //                    <attribute name='lux_ratingbasis' />
            //                    <attribute name='lux_rate' />
            //                    <attribute name='lux_recruitmentquote' />
            //                    <attribute name='lux_grosspolicypremiumquoted' />
            //                    <attribute name='lux_grosspolicypremiumbound' />
            //                    <attribute name='lux_nettechnicalpremium' />
            //                    <attribute name='lux_ratingfigures' />
            //                    <attribute name='lux_section' />
            //                    <attribute name='transactioncurrencyid' />
            //                    <attribute name='lux_recruitmenttechnicalpremiumcalculationid' />
            //                    <order attribute='lux_name' descending='false' />
            //                    <filter type='and'>
            //                      <condition attribute='statecode' operator='eq' value='0' />
            //                      <condition attribute='lux_recruitmentquote' operator='eq' uiname='' uitype='lux_recruitmentquotes' value='{recruitmentQuote.Id}' />
            //                    </filter>
            //                  </entity>
            //                </fetch>";

            //var FinalRateItem = service.RetrieveMultiple(new FetchExpression(FinalRatingfetch)).Entities;
            //if (FinalRateItem.Count > 0)
            //{
            //    var NetPremium = FinalRateItem.Sum(x => x.Attributes.Contains("lux_nettechnicalpremium") ? x.GetAttributeValue<Money>("lux_nettechnicalpremium").Value : 0);
            //    var GrossPremiumQuoted = FinalRateItem.Sum(x => x.Attributes.Contains("lux_grosspolicypremiumquoted") ? x.GetAttributeValue<Money>("lux_grosspolicypremiumquoted").Value : 0);
            //    var GrossPremiumBound = FinalRateItem.Sum(x => x.Attributes.Contains("lux_grosspolicypremiumbound") ? x.GetAttributeValue<Money>("lux_grosspolicypremiumbound").Value : 0);

            //    var QuoteRateDeviation = (GrossPremiumQuoted / NetPremium) - 1;
            //    var BoundRateDeviation = (GrossPremiumBound / NetPremium) - 1;

            //    Entity application = service.Retrieve("lux_recruitmentquotes", recruitmentQuote.Id, new ColumnSet(false));
            //    application["lux_nettechnicalpremium"] = new Money(FinalRateItem.Sum(x => x.Attributes.Contains("lux_nettechnicalpremium") ? x.GetAttributeValue<Money>("lux_nettechnicalpremium").Value : 0));
            //    application["lux_ecv"] = new Money(FinalRateItem.Sum(x => x.Attributes.Contains("lux_grosspolicypremiumbound") ? x.GetAttributeValue<Money>("lux_grosspolicypremiumbound").Value : 0));
            //    application["lux_grosspolicypremiumbound"] = new Money(FinalRateItem.Sum(x => x.Attributes.Contains("lux_grosspolicypremiumbound") ? x.GetAttributeValue<Money>("lux_grosspolicypremiumbound").Value : 0));
            //    application["lux_quoteratedeviation"] = QuoteRateDeviation * 100;
            //    application["lux_boundratedeviation"] = BoundRateDeviation * 100;
            //    service.Update(application);
            //}
        }
    }
}