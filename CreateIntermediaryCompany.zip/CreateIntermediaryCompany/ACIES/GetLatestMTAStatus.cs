﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CreateIntermediaryCompany
{
    public class GetLatestMTAStatus : CodeActivity
    {
        [Input("Policy")]
        [ReferenceTarget("lux_policy")]
        public InArgument<EntityReference> Policy { get; set; }

        [Input("Construction Policy")]
        [ReferenceTarget("lux_constructionpolicy")]
        public InArgument<EntityReference> ConstructionPolicy { get; set; }

        [RequiredArgument]
        [Input("IsSME")]
        public InArgument<bool> IsSME { get; set; }

        [RequiredArgument]
        [Input("Product")]
        public InArgument<string> Product { get; set; }

        [Output("IsBound")]
        public OutArgument<bool> IsBound { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            if (IsSME.Get(executionContext) == true)
            {
                EntityReference policyref = Policy.Get<EntityReference>(executionContext);
                Entity pol = new Entity(policyref.LogicalName, policyref.Id);
                pol = service.Retrieve("lux_policy", policyref.Id, new ColumnSet(true));

                var ProductName = Product.Get(executionContext).Trim();
                IsBound.Set(executionContext, true);
                var fetch = "";
                if (ProductName != "Tradesman")
                {
                    fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_postcode' />
                                <attribute name='lux_insuredtitle' />
                                <attribute name='lux_quotenumber' />
                                <attribute name='statuscode' />
                                <attribute name='lux_inceptiondate' />
                                <attribute name='lux_broker' />
                                <attribute name='lux_quotedpremium' />
                                <attribute name='lux_producttype' />
                                <attribute name='lux_trade' />
                                <attribute name='lux_applicationtype' />
                                <attribute name='lux_underwriter' />
                                <attribute name='lux_propertyownersapplicationsid' />
                                <order attribute='createdon' descending='true' />
                                <order attribute='lux_quotenumber' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statuscode' operator='in'>
                                        <value>972970008</value>
                                        <value>972970009</value>
                                        <value>972970011</value>
                                        <value>1</value>
                                        <value>2</value>
                                        <value>972970012</value>
                                        <value>972970010</value>
                                        <value>972970005</value>
                                        <value>972970003</value>
                                        <value>972970007</value>
                                        <value>972970002</value>
                                        <value>972970004</value>
                                  </condition>
                                  <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{pol.Id}' />
                                </filter>
                              </entity>
                            </fetch>";
                }
                else if (ProductName == "Tradesman")
                {
                    fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_tradesman'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='statuscode' />
                                <attribute name='lux_quotenumber' />
                                <attribute name='lux_product' />
                                <attribute name='lux_postcode' />
                                <attribute name='lux_insuredtitle' />
                                <attribute name='lux_inceptiondate' />
                                <attribute name='lux_broker' />
                                <attribute name='lux_policypremiumbeforeipt' />
                                <attribute name='lux_applicationtype' />
                                <attribute name='lux_tradesmanid' />
                                <order attribute='createdon' descending='true' />
                                <order attribute='lux_quotenumber' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statuscode' operator='in'>
                                        <value>972970008</value>
                                        <value>972970009</value>
                                        <value>972970011</value>
                                        <value>1</value>
                                        <value>2</value>
                                        <value>972970012</value>
                                        <value>972970010</value>
                                        <value>972970005</value>
                                        <value>972970003</value>
                                        <value>972970007</value>
                                        <value>972970002</value>
                                        <value>972970004</value>
                                  </condition>
                                  <condition attribute='lux_policy' operator='eq' uiname='a' uitype='lux_policy' value='{pol.Id}' />
                                </filter>
                              </entity>
                            </fetch>";
                }

                var Records = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                if (Records.Count == 0)
                {
                    IsBound.Set(executionContext, true);
                }
                else
                {
                    IsBound.Set(executionContext, false);
                }
            }
            else
            {
                EntityReference policyref = ConstructionPolicy.Get<EntityReference>(executionContext);
                Entity pol = new Entity(policyref.LogicalName, policyref.Id);
                pol = service.Retrieve("lux_constructionpolicy", policyref.Id, new ColumnSet(true));

                var ProductName = Product.Get(executionContext).Trim();
                IsBound.Set(executionContext, true);
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_constructionquotes'>
                                    <attribute name='lux_name' />
                                    <attribute name='createdon' />
                                    <attribute name='statuscode' />
                                    <attribute name='lux_totalpayable' />
                                    <attribute name='lux_applicationtype' />
                                    <attribute name='lux_typeofpolicy2' />
                                    <attribute name='lux_broker' />
                                    <attribute name='lux_constructionunderwriter' />
                                    <attribute name='lux_inceptiondate' />
                                    <attribute name='lux_client' />
                                    <attribute name='lux_constructionquotesid' />
                                    <order attribute='lux_name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statuscode' operator='in'>
                                        <value>972970008</value>
                                        <value>972970009</value>
                                        <value>1</value>
                                        <value>2</value>
                                        <value>972970012</value>
                                        <value>972970010</value>
                                        <value>972970005</value>
                                        <value>972970003</value>
                                        <value>972970007</value>
                                        <value>972970002</value>
                                        <value>972970004</value>
                                      </condition>
                                      <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_constructionpolicy' value='{pol.Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                var Records = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                if (Records.Count == 0)
                {
                    IsBound.Set(executionContext, true);
                }
                else
                {
                    IsBound.Set(executionContext, false);
                }
            }
        }
    }
}