﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CreateIntermediaryCompany
{
    public class AssociateEndorsementsDataForMTA : CodeActivity
    {
        [Input("Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> Application { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            Entity appln = service.Retrieve("lux_propertyownersapplications", Application.Get(executionContext).Id, new ColumnSet("lux_quotationdate", "lux_applicationtype", "lux_insuranceproductrequired"));

            //var quotationDate = Convert.ToDateTime((appln.Contains("lux_quotationdate") ? appln.GetAttributeValue<DateTime>("lux_quotationdate") : DateTime.UtcNow), System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
            var ApplicationType = appln.Contains("lux_applicationtype") ? appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value : 972970001;
            var Product = appln.Attributes.Contains("lux_insuranceproductrequired") ? appln.FormattedValues["lux_insuranceproductrequired"] : "";

            if (ApplicationType == 972970002)
            {
                if (Product == "Property Owners" || Product == "Unoccupied")
                {
                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownerspremise'>
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_name' />
                                <attribute name='lux_locationnumber' />                               
                                <attribute name='lux_floodscore' />
                                <attribute name='lux_subsidencescore' />
                                <attribute name='lux_issubsidencecoverrequired' />
                                <attribute name='lux_crimescore' />
                                <attribute name='lux_isnewmtapremise' />                                
                                <attribute name='lux_propertyownerspremiseid' />
                                <attribute name='lux_propertyownersapplication' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                    {
                        var endorsementFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_endorsementlibrary'>
                                                            <attribute name='lux_name' />
                                                            <attribute name='new_product' />
                                                            <attribute name='lux_insurer' />
                                                            <attribute name='lux_endorsementdescription' />
                                                            <attribute name='new_endorsementnumber' />
                                                            <attribute name='lux_endorsementhtml' />
                                                            <attribute name='lux_endorsementlibraryid' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_name' operator='not-null' />
                                                              <filter type='or'>
                                                                <condition attribute='new_product' operator='eq' uiname='Property Owners' uitype='product' value='{"5CAE3BD2-1F78-EB11-A812-00224841494B"}' />
                                                                <condition attribute='new_product' operator='null' />
                                                              </filter>
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                        foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                        {
                            var isNewMTAPremise = item.Attributes.Contains("lux_isnewmtapremise") ? item.GetAttributeValue<bool>("lux_isnewmtapremise") : false;
                            var SubsidienceScore = item.Attributes.Contains("lux_subsidencescore") ? item.GetAttributeValue<int>("lux_subsidencescore") : 0;

                            if (service.RetrieveMultiple(new FetchExpression(endorsementFetch)).Entities.Count > 0)
                            {
                                if (isNewMTAPremise == true)
                                {
                                    var Endorsement7 = service.RetrieveMultiple(new FetchExpression(endorsementFetch)).Entities.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Increased Subsidence Excess - £2,500");
                                    if (Endorsement7 != null)
                                    {
                                        var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_applicationendorsements'>
                                                            <attribute name='lux_applicationendorsementsid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='lux_endorsementnumber' />
                                                            <attribute name='createdon' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_endorsementlibrary' operator='eq' uiname='' uitype='lux_endorsementlibrary' value='{Endorsement7.Attributes["lux_endorsementlibraryid"]}' />
                                                              <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";
                                        if ((SubsidienceScore == 6) && item.GetAttributeValue<bool>("lux_issubsidencecoverrequired") == true) //£750 Flood Excess
                                        {
                                            if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count == 0)
                                            {
                                                Entity ent = new Entity("lux_applicationendorsements");
                                                ent["lux_application"] = new EntityReference("lux_propertyownersapplications", appln.Id);
                                                ent["lux_isdefault"] = true;
                                                ent["lux_endorsementhtml"] = Endorsement7.Attributes["lux_endorsementhtml"];
                                                ent["lux_endorsementnumber"] = Endorsement7.Attributes["new_endorsementnumber"];
                                                ent["lux_name"] = Endorsement7.Attributes["lux_name"];
                                                ent["lux_endorsementlibrary"] = new EntityReference("lux_endorsementlibrary", new Guid(Endorsement7.Attributes["lux_endorsementlibraryid"].ToString()));
                                                service.Create(ent);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else if (Product == "Retail")
                {
                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersretail'>
                                <attribute name='lux_propertyownersretailid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_floodscore' />
                                <attribute name='lux_subsidencescore' />
                                <attribute name='lux_issubsidencecoverrequired' />
                                <attribute name='lux_crimescore' />
                                <attribute name='lux_isnewmtapremise' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                    {
                        var endorsementFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_endorsementlibrary'>
                                                            <attribute name='lux_name' />
                                                            <attribute name='new_product' />
                                                            <attribute name='lux_insurer' />
                                                            <attribute name='lux_endorsementdescription' />
                                                            <attribute name='lux_endorsementhtml' />
                                                            <attribute name='new_endorsementnumber' />
                                                            <attribute name='lux_endorsementlibraryid' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_name' operator='not-null' />
                                                              <filter type='or'>
                                                                <condition attribute='new_product' operator='eq' uiname='Retail' uitype='product' value='{"e9cadb06-a496-eb11-b1ac-002248413665"}' />
                                                                <condition attribute='new_product' operator='null' />
                                                              </filter>
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                        foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                        {
                            var isNewMTAPremise = item.Attributes.Contains("lux_isnewmtapremise") ? item.GetAttributeValue<bool>("lux_isnewmtapremise") : false;
                            var SubsidienceScore = item.Attributes.Contains("lux_subsidencescore") ? item.GetAttributeValue<int>("lux_subsidencescore") : 0;

                            if (service.RetrieveMultiple(new FetchExpression(endorsementFetch)).Entities.Count > 0)
                            {
                                if (isNewMTAPremise == true)
                                {
                                    var Endorsement7 = service.RetrieveMultiple(new FetchExpression(endorsementFetch)).Entities.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Increased Subsidence Excess - £2,500");
                                    if (Endorsement7 != null)
                                    {
                                        var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_applicationendorsements'>
                                                            <attribute name='lux_applicationendorsementsid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='lux_endorsementnumber' />
                                                            <attribute name='createdon' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_endorsementlibrary' operator='eq' uiname='' uitype='lux_endorsementlibrary' value='{Endorsement7.Attributes["lux_endorsementlibraryid"]}' />
                                                              <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";
                                        if ((SubsidienceScore == 6) && item.GetAttributeValue<bool>("lux_issubsidencecoverrequired") == true)
                                        {
                                            if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count == 0)
                                            {
                                                Entity ent = new Entity("lux_applicationendorsements");
                                                ent["lux_application"] = new EntityReference("lux_propertyownersapplications", appln.Id);
                                                ent["lux_isdefault"] = true;
                                                ent["lux_endorsementnumber"] = Endorsement7.Attributes["new_endorsementnumber"];
                                                ent["lux_endorsementhtml"] = Endorsement7.Attributes["lux_endorsementhtml"];
                                                ent["lux_name"] = Endorsement7.Attributes["lux_name"];
                                                ent["lux_endorsementlibrary"] = new EntityReference("lux_endorsementlibrary", new Guid(Endorsement7.Attributes["lux_endorsementlibraryid"].ToString()));
                                                service.Create(ent);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else if (Product == "Commercial Combined" || Product == "Office")
                {
                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_commercialcombinedapplication'>
                                <attribute name='lux_commercialcombinedapplicationid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_floodscore' />
                                <attribute name='lux_subsidencescore' />
                                <attribute name='lux_issubsidencecoverrequired' />
                                <attribute name='lux_crimescore' />
                                <attribute name='lux_isnewmtapremise' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                    {
                        var endorsementFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_endorsementlibrary'>
                                                            <attribute name='lux_name' />
                                                            <attribute name='new_product' />
                                                            <attribute name='lux_insurer' />
                                                            <attribute name='lux_endorsementdescription' />
                                                            <attribute name='lux_endorsementhtml' />
                                                            <attribute name='new_endorsementnumber' />
                                                            <attribute name='lux_endorsementlibraryid' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_name' operator='not-null' />
                                                              <filter type='or'>
                                                                <condition attribute='new_product' operator='eq' uiname='CC' uitype='product' value='{"8008008f-aaa1-eb11-b1ac-00224840d300"}' />
                                                                <condition attribute='new_product' operator='null' />
                                                              </filter>
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                        foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                        {
                            var isNewMTAPremise = item.Attributes.Contains("lux_isnewmtapremise") ? item.GetAttributeValue<bool>("lux_isnewmtapremise") : false;
                            var SubsidienceScore = item.Attributes.Contains("lux_subsidencescore") ? item.GetAttributeValue<int>("lux_subsidencescore") : 0;

                            if (service.RetrieveMultiple(new FetchExpression(endorsementFetch)).Entities.Count > 0)
                            {
                                if (isNewMTAPremise == true)
                                {
                                    var Endorsement7 = service.RetrieveMultiple(new FetchExpression(endorsementFetch)).Entities.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Increased Subsidence Excess - £2,500");
                                    if (Endorsement7 != null)
                                    {
                                        var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_applicationendorsements'>
                                                            <attribute name='lux_applicationendorsementsid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='lux_endorsementnumber' />
                                                            <attribute name='createdon' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_endorsementlibrary' operator='eq' uiname='' uitype='lux_endorsementlibrary' value='{Endorsement7.Attributes["lux_endorsementlibraryid"]}' />
                                                              <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";
                                        if ((SubsidienceScore == 6) && item.GetAttributeValue<bool>("lux_issubsidencecoverrequired") == true)
                                        {
                                            if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count == 0)
                                            {
                                                Entity ent = new Entity("lux_applicationendorsements");
                                                ent["lux_application"] = new EntityReference("lux_propertyownersapplications", appln.Id);
                                                ent["lux_isdefault"] = true;
                                                ent["lux_endorsementnumber"] = Endorsement7.Attributes["new_endorsementnumber"];
                                                ent["lux_endorsementhtml"] = Endorsement7.Attributes["lux_endorsementhtml"];
                                                ent["lux_name"] = Endorsement7.Attributes["lux_name"];
                                                ent["lux_endorsementlibrary"] = new EntityReference("lux_endorsementlibrary", new Guid(Endorsement7.Attributes["lux_endorsementlibraryid"].ToString()));
                                                service.Create(ent);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else if (Product == "Pubs & Restaurants" || Product == "Hotels and Guesthouses")
                {
                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_pubsrestaurantspropertyownersapplicatio'>
                                <attribute name='lux_pubsrestaurantspropertyownersapplicatioid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_floodscore' />
                                <attribute name='lux_subsidencescore' />
                                <attribute name='lux_issubsidencecoverrequired' />
                                <attribute name='lux_crimescore' />
                                <attribute name='lux_isnewmtapremise' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                    {
                        var endorsementFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_endorsementlibrary'>
                                                            <attribute name='lux_name' />
                                                            <attribute name='new_product' />
                                                            <attribute name='lux_insurer' />
                                                            <attribute name='lux_endorsementdescription' />
                                                            <attribute name='lux_endorsementhtml' />
                                                            <attribute name='new_endorsementnumber' />
                                                            <attribute name='lux_endorsementlibraryid' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_name' operator='not-null' />
                                                              <filter type='or'>
                                                                <condition attribute='new_product' operator='eq' uiname='Retail' uitype='product' value='{"0c49880c-aba1-eb11-b1ac-00224840d300"}' />
                                                                <condition attribute='new_product' operator='null' />
                                                              </filter>
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                        foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                        {
                            var isNewMTAPremise = item.Attributes.Contains("lux_isnewmtapremise") ? item.GetAttributeValue<bool>("lux_isnewmtapremise") : false;
                            var SubsidienceScore = item.Attributes.Contains("lux_subsidencescore") ? item.GetAttributeValue<int>("lux_subsidencescore") : 0;

                            if (service.RetrieveMultiple(new FetchExpression(endorsementFetch)).Entities.Count > 0)
                            {
                                if (isNewMTAPremise == true)
                                {
                                    var Endorsement7 = service.RetrieveMultiple(new FetchExpression(endorsementFetch)).Entities.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Increased Subsidence Excess - £2,500");
                                    if (Endorsement7 != null)
                                    {
                                        var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_applicationendorsements'>
                                                            <attribute name='lux_applicationendorsementsid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='lux_endorsementnumber' />
                                                            <attribute name='createdon' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_endorsementlibrary' operator='eq' uiname='' uitype='lux_endorsementlibrary' value='{Endorsement7.Attributes["lux_endorsementlibraryid"]}' />
                                                              <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                        if ((SubsidienceScore == 6) && item.GetAttributeValue<bool>("lux_issubsidencecoverrequired") == true)
                                        {
                                            if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count == 0)
                                            {
                                                Entity ent = new Entity("lux_applicationendorsements");
                                                ent["lux_application"] = new EntityReference("lux_propertyownersapplications", appln.Id);
                                                ent["lux_isdefault"] = true;
                                                ent["lux_endorsementnumber"] = Endorsement7.Attributes["new_endorsementnumber"];
                                                ent["lux_endorsementhtml"] = Endorsement7.Attributes["lux_endorsementhtml"];
                                                ent["lux_name"] = Endorsement7.Attributes["lux_name"];
                                                ent["lux_endorsementlibrary"] = new EntityReference("lux_endorsementlibrary", new Guid(Endorsement7.Attributes["lux_endorsementlibraryid"].ToString()));
                                                service.Create(ent);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}