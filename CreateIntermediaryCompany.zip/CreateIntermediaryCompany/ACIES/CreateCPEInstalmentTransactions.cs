﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CreateIntermediaryCompany
{
    public class CreateCPEInstalmentTransactions : CodeActivity
    {
        [Input("CPE Quote")]
        [ReferenceTarget("lux_contractorsplantandequipmentquote")]
        public InArgument<EntityReference> ConstructionQuote { get; set; }

        [Input("Construction Policy")]
        [ReferenceTarget("lux_constructionpolicy")]
        public InArgument<EntityReference> ConstructionPolicy { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference quoteref = ConstructionQuote.Get<EntityReference>(executionContext);
            Entity quote = new Entity(quoteref.LogicalName, quoteref.Id);
            quote = service.Retrieve("lux_contractorsplantandequipmentquote", quoteref.Id, new ColumnSet(true));

            EntityReference policyref = ConstructionPolicy.Get<EntityReference>(executionContext);
            Entity policy = new Entity(policyref.LogicalName, policyref.Id);
            policy = service.Retrieve("lux_constructionpolicy", policyref.Id, new ColumnSet(true));

            var applicationType = quote.Attributes.Contains("lux_applicationtype") ? quote.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value : 972970001;

            var Carrier = quote.Attributes.Contains("lux_carrier") ? quote.GetAttributeValue<OptionSetValue>("lux_carrier").Value : 0;
            var IsInstallment = quote.Attributes.Contains("lux_premiumpayablebyinstalments") ? quote.GetAttributeValue<bool>("lux_premiumpayablebyinstalments") : false;
            var SignedShare = quote.Attributes.Contains("lux_signedsharepercentage") ? quote.GetAttributeValue<decimal>("lux_signedsharepercentage") : 100;

            decimal totalExcludingIptFee = quote.GetAttributeValue<Money>("lux_policypremiumbeforetax").Value * SignedShare / 100;
            decimal pslCommAmt = quote.GetAttributeValue<decimal>("lux_policymgacommissionpercentage");
            decimal brokerCommAmt = quote.GetAttributeValue<decimal>("lux_policybrokercommissionpercentage");
            decimal adminFee = quote.Attributes.Contains("lux_policypolicyfee") ? quote.GetAttributeValue<Money>("lux_policypolicyfee").Value : 0;
            var DueDate = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
            var IPTRate = quote.Attributes.Contains("lux_policytotaltax") ? quote.GetAttributeValue<decimal>("lux_policytotaltax") : 0M;
            var TerrIPTRate = quote.Attributes.Contains("lux_addonpolicytotaltax") ? quote.GetAttributeValue<decimal>("lux_addonpolicytotaltax") : IPTRate;

            if (applicationType == 972970002)
            {
                totalExcludingIptFee = quote.GetAttributeValue<Money>("lux_mtapolicypremiumbeforetax").Value * SignedShare / 100;
                pslCommAmt = quote.GetAttributeValue<decimal>("lux_mtamgacommission");
                brokerCommAmt = quote.GetAttributeValue<decimal>("lux_mtabrokercommission");
                adminFee = quote.Attributes.Contains("lux_mtapolicyfee") ? quote.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0;
                DueDate = quote.GetAttributeValue<DateTime>("lux_effectivedate");
            }

            decimal TerrtotalExcludingIptFee = 0;
            decimal TerrpslCommAmt = 0;
            decimal TerrbrokerCommAmt = 0;
            decimal TerradminFee = 0;

            if ((quote.GetAttributeValue<bool>("lux_iscoverrequiredforterrorism") == true && quote.Attributes.Contains("lux_terrorismaddon")) || (quote.Attributes.Contains("lux_terrorismaddon") && applicationType == 972970002))
            {
                Entity addonappln = service.Retrieve("lux_additionalpolicypremium", quote.GetAttributeValue<EntityReference>("lux_terrorismaddon").Id, new ColumnSet(true));

                TerrtotalExcludingIptFee = addonappln.GetAttributeValue<Money>("lux_addonpolicypremiumbeforetax").Value * SignedShare / 100;
                TerrpslCommAmt = addonappln.GetAttributeValue<decimal>("lux_addonphoenixcommissionpercentage");
                TerrbrokerCommAmt = addonappln.GetAttributeValue<decimal>("lux_addonbrokercommissionpercentage");
                TerradminFee = addonappln.Attributes.Contains("lux_addonpolicyfee") ? addonappln.GetAttributeValue<Money>("lux_addonpolicyfee").Value : 0;

                if (applicationType == 972970002)
                {
                    TerrtotalExcludingIptFee = addonappln.GetAttributeValue<Money>("lux_addonmtapolicypremiumbeforetax").Value * SignedShare / 100;
                    TerrpslCommAmt = addonappln.GetAttributeValue<decimal>("lux_addonmtaphoenixcommission");
                    TerrbrokerCommAmt = addonappln.GetAttributeValue<decimal>("lux_addonmtabrokercommission");
                    TerradminFee = addonappln.Attributes.Contains("lux_addonmtapolicyfee") ? addonappln.GetAttributeValue<Money>("lux_addonmtapolicyfee").Value : 0;
                }
            }

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_cpeinstalmenttable'>
                                <attribute name='lux_instalmentnumber' />
                                <attribute name='lux_duedate' />
                                <attribute name='lux_instalmentvalue' />
                                <attribute name='lux_instalmentpercentage' />
                                <attribute name='lux_policyadminfee' />
                                <attribute name='lux_taxamount' />
                                <attribute name='lux_cpeinstalmenttableid' />
                                <order attribute='lux_instalmentnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_contractorsplantandequipmentquote' operator='eq' uiname='' uitype='lux_contractorsplantandequipmentquote' value='{quote.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (IsInstallment == true && service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    var instalmentNumber = Convert.ToInt32(item.FormattedValues["lux_instalmentnumber"]);
                    decimal percentage = item.GetAttributeValue<decimal>("lux_instalmentpercentage");
                    var totalExcludingIPTFEE = totalExcludingIptFee * percentage / 100;
                    var terrtotalExcludingIPTFEE = TerrtotalExcludingIptFee * percentage / 100;

                    if (instalmentNumber != 1)
                    {
                        adminFee = 0;
                        TerradminFee = 0;
                    }

                    Entity invoice = new Entity("lux_invoice");
                    invoice["lux_contractorsplantandequipmentquote"] = new EntityReference("lux_contractorsplantandequipmentquote", quote.Id);
                    invoice["lux_constructionpolicy"] = new EntityReference("lux_constructionpolicy", policy.Id);
                    invoice["lux_broker"] = new EntityReference("account", policy.GetAttributeValue<EntityReference>("lux_brokercompany").Id);
                    invoice["transactioncurrencyid"] = new EntityReference("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                    invoice["lux_product"] = new EntityReference("product", quote.GetAttributeValue<EntityReference>("lux_product").Id);

                    if (applicationType == 972970001 || applicationType == 972970003)
                    {
                        invoice["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                        invoice["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("createdon");
                        invoice["lux_transactiontype"] = new OptionSetValue(972970002);
                    }
                    else if (applicationType == 972970002 || applicationType == 972970004)
                    {
                        invoice["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_effectivedate");
                        invoice["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("modifiedon");
                        invoice["lux_transactiontype"] = new OptionSetValue(972970001);
                        if (totalExcludingIPTFEE < 0)
                        {
                            invoice["lux_transactiontype"] = new OptionSetValue(972970003);
                        }
                    }

                    invoice["lux_instalmentpercentage"] = percentage;
                    invoice["lux_insured"] = policy.Attributes["lux_name"].ToString();
                    invoice["lux_policynumber"] = policy.Attributes["lux_policynumber"].ToString();
                    invoice["lux_risktransaction"] = new OptionSetValue(972970001);
                    if (policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
                    {
                        invoice["lux_risktransaction"] = new OptionSetValue(972970002);
                    }

                    invoice["lux_aciescommissionrate"] = pslCommAmt.ToString();
                    invoice["lux_commissionrate"] = brokerCommAmt.ToString();
                    invoice["lux_aciescommissionamount"] = new Money(totalExcludingIPTFEE * pslCommAmt / 100);
                    invoice["lux_commissionamount"] = new Money(totalExcludingIPTFEE * brokerCommAmt / 100);

                    invoice["lux_fee"] = new Money(adminFee);
                    invoice["lux_duedate"] = item.GetAttributeValue<DateTime>("lux_duedate");
                    invoice["lux_grosspremiumexciptfee"] = new Money(totalExcludingIPTFEE);

                    if (instalmentNumber == 1)
                    {
                        invoice["lux_isfirstinstalmenttransaction"] = true;
                    }

                    invoice["lux_iptrate"] = IPTRate;
                    invoice["lux_ipt"] = new Money(totalExcludingIPTFEE * IPTRate / 100);

                    if (Carrier != 0)
                    {
                        if (Carrier == 972970001) //Global Binder
                        {
                            invoice["lux_globalcpesplit"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommAmt / 100 - totalExcludingIPTFEE * brokerCommAmt / 100);
                        }
                        else if (Carrier == 972970002) //AXA
                        {
                            invoice["lux_duetoaxa"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommAmt / 100 - totalExcludingIPTFEE * brokerCommAmt / 100);
                        }
                        else if (Carrier == 972970003) // Argenta
                        {
                            invoice["lux_duetoargenta"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommAmt / 100 - totalExcludingIPTFEE * brokerCommAmt / 100);
                        }
                        else if (Carrier == 972970004) // Great American
                        {
                            invoice["lux_duetogreatamerican"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommAmt / 100 - totalExcludingIPTFEE * brokerCommAmt / 100);
                        }
                        else if (Carrier == 972970005) // AXA & Great American
                        {
                            var axa = 50M;
                            var greatamerican = 50M;

                            invoice["lux_duetoaxa"] = new Money((totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommAmt / 100 - totalExcludingIPTFEE * brokerCommAmt / 1000) * axa / 100);
                            invoice["lux_duetogreatamerican"] = new Money((totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommAmt / 100 - totalExcludingIPTFEE * brokerCommAmt / 100) * greatamerican / 100);
                        }
                    }
                    else
                    {
                        invoice["lux_globalcpesplit"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommAmt / 100 - totalExcludingIPTFEE * brokerCommAmt / 100);
                    }
                    invoice["lux_totalpremiumincludingiptfee"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 + adminFee);

                    service.Create(invoice);

                    if ((quote.GetAttributeValue<bool>("lux_iscoverrequiredforterrorism") == true && quote.Attributes.Contains("lux_terrorismaddon")) || (quote.Attributes.Contains("lux_terrorismaddon") && applicationType == 972970002))
                    {
                        Entity invoice1 = new Entity("lux_invoice");
                        invoice1["lux_contractorsplantandequipmentquote"] = new EntityReference("lux_contractorsplantandequipmentquote", quote.Id);
                        invoice1["lux_constructionpolicy"] = new EntityReference("lux_constructionpolicy", policy.Id);
                        invoice1["lux_constructionproducttype"] = new OptionSetValue(972970002);
                        invoice1["lux_broker"] = new EntityReference("account", policy.GetAttributeValue<EntityReference>("lux_brokercompany").Id);
                        invoice1["transactioncurrencyid"] = new EntityReference("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                        invoice1["lux_product"] = new EntityReference("product", quote.GetAttributeValue<EntityReference>("lux_product").Id);

                        if (applicationType == 972970001 || applicationType == 972970003)
                        {
                            invoice1["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                            invoice1["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("createdon");
                            invoice1["lux_transactiontype"] = new OptionSetValue(972970002);
                        }
                        else if (applicationType == 972970002 || applicationType == 972970004)
                        {
                            invoice1["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                            invoice1["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("modifiedon");
                            invoice1["lux_transactiontype"] = new OptionSetValue(972970001);
                            if (terrtotalExcludingIPTFEE < 0)
                            {
                                invoice1["lux_transactiontype"] = new OptionSetValue(972970003);
                            }
                        }

                        invoice1["lux_instalmentpercentage"] = percentage;
                        invoice1["lux_insured"] = policy.Attributes["lux_name"].ToString();
                        invoice1["lux_policynumber"] = policy.Attributes["lux_policynumber"].ToString();
                        invoice1["lux_risktransaction"] = new OptionSetValue(972970001);
                        if (policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
                        {
                            invoice1["lux_risktransaction"] = new OptionSetValue(972970002);
                        }

                        invoice1["lux_aciescommissionrate"] = TerrpslCommAmt.ToString();
                        invoice1["lux_commissionrate"] = TerrbrokerCommAmt.ToString();

                        invoice1["lux_aciescommissionamount"] = new Money(terrtotalExcludingIPTFEE * TerrpslCommAmt / 100);
                        invoice1["lux_commissionamount"] = new Money(terrtotalExcludingIPTFEE * TerrbrokerCommAmt / 100);

                        invoice1["lux_fee"] = new Money(TerradminFee);
                        invoice1["lux_duedate"] = item.GetAttributeValue<DateTime>("lux_duedate");
                        invoice1["lux_grosspremiumexciptfee"] = new Money(terrtotalExcludingIPTFEE);

                        if (instalmentNumber == 1)
                        {
                            invoice1["lux_isfirstinstalmenttransaction"] = true;
                        }

                        invoice1["lux_isconstructionterrorismtransaction"] = true;
                        invoice1["lux_iptrate"] = TerrIPTRate;
                        invoice1["lux_ipt"] = new Money(terrtotalExcludingIPTFEE * TerrIPTRate / 100);
                        if (Carrier != 0)
                        {
                            if (Carrier == 972970001) //Global Binder
                            {
                                invoice1["lux_globalcpesplit"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommAmt / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommAmt / 100);
                            }
                            else if (Carrier == 972970002) //AXA
                            {
                                invoice1["lux_duetoaxa"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommAmt / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommAmt / 100);
                            }
                            else if (Carrier == 972970003) // Argenta
                            {
                                invoice1["lux_duetoargenta"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommAmt / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommAmt / 100);
                            }
                        }
                        else
                        {
                            invoice1["lux_globalcpesplit"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommAmt / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommAmt / 100);
                        }
                        invoice1["lux_totalpremiumincludingiptfee"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 + TerradminFee);
                        service.Create(invoice1);
                    }
                }
            }
            else
            {
                var totalExcludingIPTFEE = totalExcludingIptFee;
                var terrtotalExcludingIPTFEE = TerrtotalExcludingIptFee;

                Entity invoice = new Entity("lux_invoice");
                invoice["lux_contractorsplantandequipmentquote"] = new EntityReference("lux_contractorsplantandequipmentquote", quote.Id);
                invoice["lux_constructionpolicy"] = new EntityReference("lux_constructionpolicy", policy.Id);
                invoice["lux_broker"] = new EntityReference("account", policy.GetAttributeValue<EntityReference>("lux_brokercompany").Id);
                invoice["transactioncurrencyid"] = new EntityReference("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                invoice["lux_product"] = new EntityReference("product", quote.GetAttributeValue<EntityReference>("lux_product").Id);

                if (applicationType == 972970001 || applicationType == 972970003)
                {
                    invoice["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                    invoice["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("createdon");
                    invoice["lux_transactiontype"] = new OptionSetValue(972970002);
                }
                else if (applicationType == 972970002 || applicationType == 972970004)
                {
                    invoice["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                    invoice["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("modifiedon");
                    invoice["lux_transactiontype"] = new OptionSetValue(972970001);
                    if (totalExcludingIPTFEE < 0)
                    {
                        invoice["lux_transactiontype"] = new OptionSetValue(972970003);
                    }
                }

                invoice["lux_insured"] = policy.Attributes["lux_name"].ToString();
                invoice["lux_policynumber"] = policy.Attributes["lux_policynumber"].ToString();
                invoice["lux_risktransaction"] = new OptionSetValue(972970001);
                if (policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
                {
                    invoice["lux_risktransaction"] = new OptionSetValue(972970002);
                }

                invoice["lux_aciescommissionrate"] = pslCommAmt.ToString();
                invoice["lux_commissionrate"] = brokerCommAmt.ToString();
                invoice["lux_aciescommissionamount"] = new Money(totalExcludingIPTFEE * pslCommAmt / 100);
                invoice["lux_commissionamount"] = new Money(totalExcludingIPTFEE * brokerCommAmt / 100);

                invoice["lux_fee"] = new Money(adminFee);
                invoice["lux_duedate"] = new DateTime(DueDate.Year, DueDate.Month, 1).AddMonths(2).AddDays(-1);
                invoice["lux_grosspremiumexciptfee"] = new Money(totalExcludingIPTFEE);

                invoice["lux_iptrate"] = IPTRate;
                invoice["lux_ipt"] = new Money(totalExcludingIPTFEE * IPTRate / 100);
                if (Carrier != 0)
                {
                    if (Carrier == 972970001) //Global Binder
                    {
                        invoice["lux_globalcpesplit"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommAmt / 100 - totalExcludingIPTFEE * brokerCommAmt / 100);
                    }
                    else if (Carrier == 972970002) //AXA
                    {
                        invoice["lux_duetoaxa"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommAmt / 100 - totalExcludingIPTFEE * brokerCommAmt / 100);
                    }
                    else if (Carrier == 972970003) // Argenta
                    {
                        invoice["lux_duetoargenta"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommAmt / 100 - totalExcludingIPTFEE * brokerCommAmt / 100);
                    }
                }
                else
                {
                    invoice["lux_globalcpesplit"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommAmt / 100 - totalExcludingIPTFEE * brokerCommAmt / 100);
                }

                invoice["lux_totalpremiumincludingiptfee"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 + adminFee);

                service.Create(invoice);

                if ((quote.GetAttributeValue<bool>("lux_iscoverrequiredforterrorism") == true && quote.Attributes.Contains("lux_terrorismaddon")) || (quote.Attributes.Contains("lux_terrorismaddon") && applicationType == 972970002))
                {
                    Entity invoice1 = new Entity("lux_invoice");
                    invoice1["lux_contractorsplantandequipmentquote"] = new EntityReference("lux_contractorsplantandequipmentquote", quote.Id);
                    invoice1["lux_constructionpolicy"] = new EntityReference("lux_constructionpolicy", policy.Id);
                    invoice1["lux_constructionproducttype"] = new OptionSetValue(972970002);
                    invoice1["lux_broker"] = new EntityReference("account", policy.GetAttributeValue<EntityReference>("lux_brokercompany").Id);
                    invoice1["transactioncurrencyid"] = new EntityReference("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                    invoice1["lux_product"] = new EntityReference("product", quote.GetAttributeValue<EntityReference>("lux_product").Id);

                    if (applicationType == 972970001 || applicationType == 972970003)
                    {
                        invoice1["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                        invoice1["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("createdon");
                        invoice1["lux_transactiontype"] = new OptionSetValue(972970002);
                    }
                    else if (applicationType == 972970002 || applicationType == 972970004)
                    {
                        invoice1["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                        invoice1["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("modifiedon");
                        invoice1["lux_transactiontype"] = new OptionSetValue(972970001);
                        if (terrtotalExcludingIPTFEE < 0)
                        {
                            invoice1["lux_transactiontype"] = new OptionSetValue(972970003);
                        }
                    }

                    invoice1["lux_insured"] = policy.Attributes["lux_name"].ToString();
                    invoice1["lux_policynumber"] = policy.Attributes["lux_policynumber"].ToString();
                    invoice1["lux_risktransaction"] = new OptionSetValue(972970001);

                    if (policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
                    {
                        invoice1["lux_risktransaction"] = new OptionSetValue(972970002);
                    }

                    invoice1["lux_aciescommissionrate"] = TerrpslCommAmt.ToString();
                    invoice1["lux_commissionrate"] = TerrbrokerCommAmt.ToString();

                    invoice1["lux_aciescommissionamount"] = new Money(terrtotalExcludingIPTFEE * TerrpslCommAmt / 100);
                    invoice1["lux_commissionamount"] = new Money(terrtotalExcludingIPTFEE * TerrbrokerCommAmt / 100);

                    invoice1["lux_fee"] = new Money(TerradminFee);
                    invoice1["lux_duedate"] = new DateTime(DueDate.Year, DueDate.Month, 1).AddMonths(2).AddDays(-1);
                    invoice1["lux_grosspremiumexciptfee"] = new Money(terrtotalExcludingIPTFEE);

                    invoice1["lux_isconstructionterrorismtransaction"] = true;
                    invoice1["lux_iptrate"] = TerrIPTRate;
                    invoice1["lux_ipt"] = new Money(terrtotalExcludingIPTFEE * TerrIPTRate / 100);
                    if (Carrier != 0)
                    {
                        if (Carrier == 972970001) //Global Binder
                        {
                            invoice1["lux_globalcpesplit"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommAmt / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommAmt / 100);
                        }
                        else if (Carrier == 972970002) //AXA
                        {
                            invoice1["lux_duetoaxa"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommAmt / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommAmt / 100);
                        }
                        else if (Carrier == 972970003) // Argenta
                        {
                            invoice1["lux_duetoargenta"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommAmt / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommAmt / 100);
                        }
                    }
                    else
                    {
                        invoice1["lux_globalcpesplit"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommAmt / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommAmt / 100);
                    }
                    invoice1["lux_totalpremiumincludingiptfee"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 + TerradminFee);
                    service.Create(invoice1);
                }
            }
        }
    }
}