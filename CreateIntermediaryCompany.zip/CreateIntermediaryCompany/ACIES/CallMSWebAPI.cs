﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Metadata.Query;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace CreateIntermediaryCompany
{
    public class CallMSWebAPI : CodeActivity
    {
        [RequiredArgument]
        [Input("RecordURL")]
        public InArgument<string> RecordURL { get; set; }

        [RequiredArgument]
        [Input("API Url")]
        public InArgument<string> APIUrl { get; set; }

        [RequiredArgument]
        [Input("IsLive")]
        public InArgument<int> IsLive { get; set; }

        [Input("IsPowerAutomateFlow")]
        public InArgument<bool> IsPowerAutomateFlow { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            String _recordURL = this.RecordURL.Get(executionContext);

            string[] urlParts = _recordURL.Split("?".ToArray());
            string[] urlParams = urlParts[1].Split("&".ToCharArray());
            string PrimaryObjectTypeCode = urlParams[0].Replace("etc=", "");
            string PrimaryentityName = sGetEntityNameFromCode(PrimaryObjectTypeCode, service);
            string PrimaryId = urlParams[1].Replace("id=", "");

            Dictionary<string, string> dictForApiParams = new Dictionary<string, string>();
            dictForApiParams.Add("QuoteId", PrimaryId);
            dictForApiParams.Add("IsLive", this.IsLive.Get(executionContext).ToString());

            tracingService.Trace("{" + string.Join(",", dictForApiParams.Select(kv => kv.Key + "=" + kv.Value).ToArray()) + "}");

            var url = this.APIUrl.Get(executionContext).ToString();
            var client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.BaseAddress = new Uri(url.Trim());

            var request = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress) { Content = new FormUrlEncodedContent(dictForApiParams) };
            if (this.IsPowerAutomateFlow.Get(executionContext) == true)
            {
                request = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress) { Content = new StringContent("{\r\n  \"QuoteId\": \"" + PrimaryId.ToString() + "\", \r\n  \"IsLive\": \"" + this.IsLive.Get(executionContext).ToString() + "\"}", System.Text.Encoding.UTF8, "application/json") };
            }

            var responseString = ProcessWebResponse(client, request, tracingService);
            var response = responseString.Result;
            tracingService.Trace("Response: " + response);
        }

        public static async Task<string> ProcessWebResponse(HttpClient client, HttpRequestMessage request, ITracingService tracingService)
        {
            var reponseContentString = "";
            try
            {
                HttpResponseMessage response = await client.SendAsync(request);
                tracingService.Trace(response.ToString());
                reponseContentString = await response.Content.ReadAsStringAsync();
            }
            catch (HttpRequestException ex)
            {
                tracingService.Trace(ex.Message + Environment.NewLine + ex.InnerException + Environment.NewLine + ex.StackTrace);
            }
            return reponseContentString;
        }

        public string sGetEntityNameFromCode(string ObjectTypeCode, IOrganizationService service)
        {
            MetadataFilterExpression entityFilter = new MetadataFilterExpression(LogicalOperator.And);
            entityFilter.Conditions.Add(new MetadataConditionExpression("ObjectTypeCode", MetadataConditionOperator.Equals, Convert.ToInt32(ObjectTypeCode)));
            EntityQueryExpression entityQueryExpression = new EntityQueryExpression()
            {
                Criteria = entityFilter
            };
            RetrieveMetadataChangesRequest retrieveMetadataChangesRequest = new RetrieveMetadataChangesRequest()
            {
                Query = entityQueryExpression,
                ClientVersionStamp = null
            };
            RetrieveMetadataChangesResponse response = (RetrieveMetadataChangesResponse)service.Execute(retrieveMetadataChangesRequest);

            EntityMetadata entityMetadata = (EntityMetadata)response.EntityMetadata[0];
            return entityMetadata.SchemaName.ToLower();
        }
    }
}