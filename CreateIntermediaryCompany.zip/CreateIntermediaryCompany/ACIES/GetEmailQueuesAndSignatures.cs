﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Xml;

namespace CreateIntermediaryCompany
{
    public class GetEmailQueuesAndSignatures : CodeActivity
    {
        #region "Parameter Definition"
        [Input("ApplicationType")]
        public InArgument<string> ApplicationType { get; set; }

        [Input("Broker")]
        [ReferenceTarget("account")]
        public InArgument<EntityReference> Broker { get; set; }

        [Input("User")]
        [ReferenceTarget("systemuser")]
        public InArgument<EntityReference> User { get; set; }

        [Output("Signature")]
        public OutArgument<string> Signature { get; set; }

        [Output("Queue")]
        [ReferenceTarget("queue")]
        public OutArgument<EntityReference> Queue { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference brokerref = Broker.Get<EntityReference>(executionContext);
            Entity broker = service.Retrieve("account", brokerref.Id, new ColumnSet(true));

            EntityReference userref = User.Get<EntityReference>(executionContext);
            Entity user = service.Retrieve("systemuser", userref.Id, new ColumnSet(true));

            var applntype = ApplicationType.Get<string>(executionContext).ToString();
            tracingService.Trace(applntype);
            var BrokerRegion = broker.Attributes.Contains("lux_region") ? broker.FormattedValues["lux_region"] : "South East";

            var Signaturefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='emailsignature'>
                                    <attribute name='title' />
                                    <attribute name='ownerid' />
                                    <attribute name='isdefault' />
                                    <attribute name='presentationxml' />
                                    <attribute name='emailsignatureid' />
                                    <attribute name='ispersonal' />
                                    <order attribute='title' descending='false' />
                                  </entity>
                                </fetch>";

            var Signatures = service.RetrieveMultiple(new FetchExpression(Signaturefetch)).Entities;

            var Queuefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='queue'>
                                    <attribute name='name' />
                                    <attribute name='emailaddress' />
                                    <attribute name='ownerid' />
                                    <attribute name='statecode' />
                                    <attribute name='numberofitems' />
                                    <attribute name='numberofmembers' />
                                    <attribute name='queueviewtype' />
                                    <attribute name='queueid' />
                                    <order attribute='name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='emailaddress' operator='not-null' />
                                    </filter>
                                  </entity>
                                </fetch>";

            var Queues = service.RetrieveMultiple(new FetchExpression(Queuefetch)).Entities;

            if (BrokerRegion.ToLower() == "south west")
            {
                if (applntype == "Renewal")
                {
                    var SignatureItem = Signatures.FirstOrDefault(x => x.Attributes["title"].ToString().ToLower() == "renewals southwest");
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(Convert.ToString(SignatureItem["presentationxml"]));
                    Signature.Set(executionContext, doc.InnerText);

                    var QueueItem = Queues.FirstOrDefault(x => x.Attributes["emailaddress"].ToString().ToLower() == "renewals.southwest@acies-smeuk.com");
                    Queue.Set(executionContext, QueueItem.ToEntityReference());
                }
                else if (applntype == "MTA" || applntype == "Cancellation")
                {
                    var SignatureItem = Signatures.FirstOrDefault(x => x.Attributes["title"].ToString().ToLower() == "adjustments southwest");
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(Convert.ToString(SignatureItem["presentationxml"]));
                    Signature.Set(executionContext, doc.InnerText);

                    var QueueItem = Queues.FirstOrDefault(x => x.Attributes["emailaddress"].ToString().ToLower() == "adjustments.southwest@acies-smeuk.com");
                    Queue.Set(executionContext, QueueItem.ToEntityReference());
                }
                else
                {
                    var SignatureItem = Signatures.FirstOrDefault(x => x.Attributes["title"].ToString().ToLower() == "quotes southwest");
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(Convert.ToString(SignatureItem["presentationxml"]));
                    Signature.Set(executionContext, doc.InnerText);

                    var QueueItem = Queues.FirstOrDefault(x => x.Attributes["emailaddress"].ToString().ToLower() == "quotes.southwest@acies-smeuk.com");
                    Queue.Set(executionContext, QueueItem.ToEntityReference());
                }
            }
            else if (BrokerRegion.ToLower() == "midlands")
            {
                if (applntype == "Renewal")
                {

                    var SignatureItem = Signatures.FirstOrDefault(x => x.Attributes["title"].ToString().ToLower() == "renewals midlands");
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(Convert.ToString(SignatureItem["presentationxml"]));
                    Signature.Set(executionContext, doc.InnerText);

                    var QueueItem = Queues.FirstOrDefault(x => x.Attributes["emailaddress"].ToString().ToLower() == "renewals.midlands@acies-smeuk.com");
                    Queue.Set(executionContext, QueueItem.ToEntityReference());
                }
                else if (applntype == "MTA" || applntype == "Cancellation")
                {
                    var SignatureItem = Signatures.FirstOrDefault(x => x.Attributes["title"].ToString().ToLower() == "adjustments midlands");
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(Convert.ToString(SignatureItem["presentationxml"]));
                    Signature.Set(executionContext, doc.InnerText);

                    var QueueItem = Queues.FirstOrDefault(x => x.Attributes["emailaddress"].ToString().ToLower() == "adjustments.midlands@acies-smeuk.com");
                    Queue.Set(executionContext, QueueItem.ToEntityReference());
                }
                else
                {
                    var SignatureItem = Signatures.FirstOrDefault(x => x.Attributes["title"].ToString().ToLower() == "quotes midlands");
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(Convert.ToString(SignatureItem["presentationxml"]));
                    Signature.Set(executionContext, doc.InnerText);

                    var QueueItem = Queues.FirstOrDefault(x => x.Attributes["emailaddress"].ToString().ToLower() == "quotes.midlands@acies-smeuk.com");
                    Queue.Set(executionContext, QueueItem.ToEntityReference());
                }
            }
            else
            {
                if (applntype == "Renewal")
                {
                    var SignatureItem = Signatures.FirstOrDefault(x => x.Attributes["title"].ToString().ToLower() == "renewals southeast");
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(Convert.ToString(SignatureItem["presentationxml"]));
                    Signature.Set(executionContext, doc.InnerText);

                    var QueueItem = Queues.FirstOrDefault(x => x.Attributes["emailaddress"].ToString().ToLower() == "renewals@acies-smeuk.com");
                    Queue.Set(executionContext, QueueItem.ToEntityReference());
                }
                else if (applntype == "MTA" || applntype == "Cancellation")
                {
                    //var userSign = user.Attributes.Contains("new_emailsignature") ? user.Attributes["new_emailsignature"].ToString() : "";
                    //Signature.Set(executionContext, userSign);

                    var SignatureItem = Signatures.FirstOrDefault(x => x.Attributes["title"].ToString().ToLower() == "adjustments southeast");
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(Convert.ToString(SignatureItem["presentationxml"]));
                    Signature.Set(executionContext, doc.InnerText);

                    var QueueItem = Queues.FirstOrDefault(x => x.Attributes["emailaddress"].ToString().ToLower() == "adjustments@acies-smeuk.com");
                    Queue.Set(executionContext, QueueItem.ToEntityReference());
                }
                else
                {
                    //var userSign = user.Attributes.Contains("new_emailsignature") ? user.Attributes["new_emailsignature"].ToString() : "";
                    //Signature.Set(executionContext, userSign);

                    var SignatureItem = Signatures.FirstOrDefault(x => x.Attributes["title"].ToString().ToLower() == "quotes southeast");
                    XmlDocument doc = new XmlDocument();
                    doc.LoadXml(Convert.ToString(SignatureItem["presentationxml"]));
                    Signature.Set(executionContext, doc.InnerText);

                    var QueueItem = Queues.FirstOrDefault(x => x.Attributes["emailaddress"].ToString().ToLower() == "quotes@acies-smeuk.com");
                    Queue.Set(executionContext, QueueItem.ToEntityReference());
                }
            }
        }
    }
}