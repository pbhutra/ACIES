﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CreateIntermediaryCompany
{
    public class CreatePhoenixInstalmentTransactions : CodeActivity
    {
        [Input("CPE Quote")]
        [ReferenceTarget("lux_contractorsplantandequipmentquote")]
        public InArgument<EntityReference> ConstructionQuote { get; set; }

        [Input("Construction Policy")]
        [ReferenceTarget("lux_constructionpolicy")]
        public InArgument<EntityReference> ConstructionPolicy { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference quoteref = ConstructionQuote.Get<EntityReference>(executionContext);
            Entity quote = new Entity(quoteref.LogicalName, quoteref.Id);
            quote = service.Retrieve("lux_contractorsplantandequipmentquote", quoteref.Id, new ColumnSet(true));

            EntityReference policyref = ConstructionPolicy.Get<EntityReference>(executionContext);
            Entity policy = new Entity(policyref.LogicalName, policyref.Id);
            policy = service.Retrieve("lux_constructionpolicy", policyref.Id, new ColumnSet(true));

            var applicationType = quote.Attributes.Contains("lux_applicationtype") ? quote.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value : 972970001;

            var Carrier = quote.Attributes.Contains("lux_carrier") ? quote.GetAttributeValue<OptionSetValue>("lux_carrier").Value : 0;
            var IsInstallment = quote.Attributes.Contains("lux_premiumpayablebyinstalments") ? quote.GetAttributeValue<bool>("lux_premiumpayablebyinstalments") : false;
            var SignedShare = quote.Attributes.Contains("lux_signedsharepercentage") ? quote.GetAttributeValue<decimal>("lux_signedsharepercentage") : 100;

            decimal totalExcludingIptFee = quote.GetAttributeValue<Money>("lux_policypremiumbeforetax").Value * SignedShare / 100;

            var brokerCommAmt = quote.GetAttributeValue<Money>("lux_quotedsharebrokercommissionamount").Value;
            var pslCommAmt = quote.GetAttributeValue<Money>("lux_quotedsharemgacommissionamount").Value;
            var totalTaxAmount = quote.GetAttributeValue<Money>("lux_quotedsharetotaltaxamount").Value;

            decimal pslCommPer = quote.GetAttributeValue<decimal>("lux_policymgacommissionpercentage");
            decimal brokerCommPer = quote.GetAttributeValue<decimal>("lux_policybrokercommissionpercentage");

            var totalLineFee = 0M;

            var capacityFetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_phoenixcapacitysplittable'>
                                                    <attribute name='lux_linepercentagecalculated' />
                                                    <attribute name='lux_lineamountcalculated' />
                                                    <attribute name='lux_insurername' />
                                                    <attribute name='lux_capacity' />
                                                    <attribute name='lux_linefee' />
                                                    <attribute name='lux_phoenixcapacitysplittableid' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_contractorsplantandequipmentquote' operator='eq' uiname='' uitype='lux_contractorsplantandequipmentquote' value='{quote.Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

            var capacity1 = service.RetrieveMultiple(new FetchExpression(capacityFetch1)).Entities;
            if (capacity1.Count > 0)
            {
                totalLineFee = capacity1.Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
            }

            //decimal totalAdminFee = quote.Attributes.Contains("lux_policypolicyfee") ? quote.GetAttributeValue<Money>("lux_policypolicyfee").Value : 0;
            decimal adminFee = quote.Attributes.Contains("lux_policypolicyfee") ? quote.GetAttributeValue<Money>("lux_policypolicyfee").Value : 0;
            //adminFee = adminFee - totalLineFee;
            var DueDate = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
            var IPTRate = quote.Attributes.Contains("lux_policytotaltax") ? quote.GetAttributeValue<decimal>("lux_policytotaltax") : 0M;
            var TerrIPTRate = quote.Attributes.Contains("lux_policytotaltax") ? quote.GetAttributeValue<decimal>("lux_policytotaltax") : 0M;

            if (applicationType == 972970002)
            {
                totalExcludingIptFee = quote.GetAttributeValue<Money>("lux_mtapolicypremiumbeforetax").Value * SignedShare / 100;
                pslCommPer = quote.GetAttributeValue<decimal>("lux_mtamgacommission");
                brokerCommPer = quote.GetAttributeValue<decimal>("lux_mtabrokercommission");
                adminFee = quote.Attributes.Contains("lux_mtapolicyfee") ? quote.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0;
                DueDate = quote.GetAttributeValue<DateTime>("lux_effectivedate");
            }

            decimal TerrtotalExcludingIptFee = 0;
            decimal TerrpslCommPer = 0;
            decimal TerrbrokerCommPer = 0;
            decimal TerradminFee = 0;
            decimal TerrbrokerCommAmt = 0;
            decimal TerrpslCommAmt = 0;
            decimal TerrtotalTaxAmt = 0;

            if ((quote.GetAttributeValue<bool>("lux_iscoverrequiredforterrorism") == true && quote.Attributes.Contains("lux_terrorismaddon")) || (quote.Attributes.Contains("lux_terrorismaddon") && applicationType == 972970002))
            {
                var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_contractorsplantandequipmentquotepremui'>
                                    <attribute name='lux_section' />
                                    <attribute name='lux_signedsharepercentage' />
                                    <attribute name='lux_signedsharetotaltaxamount' />
                                    <attribute name='lux_signedsharetotalpolicypremiuminctaxandfee' />
                                    <attribute name='lux_signedsharetotalcommissionamount' />
                                    <attribute name='lux_signedshareretainedincome' />
                                    <attribute name='lux_signedsharepolicypremiuminctax' />
                                    <attribute name='lux_signedsharepolicypremiumbeforetax' />
                                    <attribute name='lux_signedsharebrokercommissionamount' />
                                    <attribute name='lux_signedsharemgacommissionamount' />
                                    <attribute name='lux_signedsharepolicyfee' />
                                    <attribute name='lux_totaltax' />
                                    <attribute name='lux_mgacommission' />
                                    <attribute name='lux_brokercommission' />
                                    <attribute name='lux_rowordercalculated' />
                                    <attribute name='lux_contractorsplantandequipmentquotepremuiid' />
                                    <order attribute='lux_rowordercalculated' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_contractorsplantandequipmentquote' operator='eq' uiname='' uitype='lux_contractorsplantandequipmentquote' value='{quote.Id}' />
                                      <condition attribute='lux_phoenixquoteoption' operator='eq' uiname='' uitype='lux_phoenixquoteoption' value='{quote.GetAttributeValue<EntityReference>("lux_quoteoptionselected").Id}' />
                                      <condition attribute='lux_section' operator='eq' value='972970006' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
                {
                    var TerrData = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.FirstOrDefault();
                    TerrtotalExcludingIptFee = TerrData.Attributes.Contains("lux_signedsharepolicypremiumbeforetax") ? TerrData.GetAttributeValue<Money>("lux_signedsharepolicypremiumbeforetax").Value : 0;
                    TerrpslCommPer = TerrData.Attributes.Contains("lux_mgacommission") ? TerrData.GetAttributeValue<decimal>("lux_mgacommission") : 0;
                    TerrbrokerCommPer = TerrData.Attributes.Contains("lux_brokercommission") ? TerrData.GetAttributeValue<decimal>("lux_brokercommission") : 0;
                    TerradminFee = TerrData.Attributes.Contains("lux_signedsharepolicyfee") ? TerrData.GetAttributeValue<Money>("lux_signedsharepolicyfee").Value : 0;
                    TerrbrokerCommAmt = TerrData.Attributes.Contains("lux_signedsharebrokercommissionamount") ? TerrData.GetAttributeValue<Money>("lux_signedsharebrokercommissionamount").Value : 0;
                    TerrpslCommAmt = TerrData.Attributes.Contains("lux_signedsharemgacommissionamount") ? TerrData.GetAttributeValue<Money>("lux_signedsharemgacommissionamount").Value : 0;
                    TerrIPTRate = TerrData.Attributes.Contains("lux_totaltax") ? TerrData.GetAttributeValue<decimal>("lux_totaltax") : 0;
                    TerrtotalTaxAmt = TerrData.Attributes.Contains("lux_signedsharetotaltaxamount") ? TerrData.GetAttributeValue<Money>("lux_signedsharetotaltaxamount").Value : 0;

                    if (applicationType == 972970002)
                    {
                        TerrtotalExcludingIptFee = TerrData.GetAttributeValue<Money>("lux_addonmtapolicypremiumbeforetax").Value * SignedShare / 100;
                        TerrpslCommPer = TerrData.GetAttributeValue<decimal>("lux_addonmtaphoenixcommission");
                        TerrbrokerCommPer = TerrData.GetAttributeValue<decimal>("lux_addonmtabrokercommission");
                        TerradminFee = TerrData.Attributes.Contains("lux_addonmtapolicyfee") ? TerrData.GetAttributeValue<Money>("lux_addonmtapolicyfee").Value : 0;
                    }

                    brokerCommAmt = brokerCommAmt - TerrbrokerCommAmt;
                    pslCommAmt = pslCommAmt - TerrpslCommAmt;
                    totalExcludingIptFee = totalExcludingIptFee - TerrtotalExcludingIptFee;
                    adminFee = adminFee - TerradminFee;
                    totalTaxAmount = totalTaxAmount - TerrtotalTaxAmt;

                    //totalAdminFee = totalAdminFee - TerradminFee;

                    brokerCommPer = brokerCommAmt * 100 / totalExcludingIptFee;
                    pslCommPer = pslCommAmt * 100 / totalExcludingIptFee;
                    IPTRate = totalTaxAmount * 100 / totalExcludingIptFee;
                }
            }

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_cpeinstalmenttable'>
                                <attribute name='lux_instalmentnumber' />
                                <attribute name='lux_duedate' />
                                <attribute name='lux_instalmentvalue' />
                                <attribute name='lux_instalmentpercentage' />
                                <attribute name='lux_policyadminfee' />
                                <attribute name='lux_taxamount' />
                                <attribute name='lux_cpeinstalmenttableid' />
                                <order attribute='lux_instalmentnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_contractorsplantandequipmentquote' operator='eq' uiname='' uitype='lux_contractorsplantandequipmentquote' value='{quote.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (IsInstallment == true && service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    var instalmentNumber = Convert.ToInt32(item.FormattedValues["lux_instalmentnumber"]);
                    decimal percentage = item.GetAttributeValue<decimal>("lux_instalmentpercentage");
                    var totalExcludingIPTFEE = totalExcludingIptFee * percentage / 100;
                    var terrtotalExcludingIPTFEE = TerrtotalExcludingIptFee * percentage / 100;

                    if (instalmentNumber != 1)
                    {
                        adminFee = 0;
                        TerradminFee = 0;
                    }

                    Entity invoice = new Entity("lux_invoice");
                    invoice["lux_contractorsplantandequipmentquote"] = new EntityReference("lux_contractorsplantandequipmentquote", quote.Id);
                    invoice["lux_constructionpolicy"] = new EntityReference("lux_constructionpolicy", policy.Id);
                    invoice["lux_broker"] = new EntityReference("account", policy.GetAttributeValue<EntityReference>("lux_brokercompany").Id);
                    invoice["transactioncurrencyid"] = new EntityReference("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                    invoice["lux_product"] = new EntityReference("product", quote.GetAttributeValue<EntityReference>("lux_product").Id);

                    if (applicationType == 972970001 || applicationType == 972970003)
                    {
                        invoice["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                        invoice["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("createdon");
                        invoice["lux_transactiontype"] = new OptionSetValue(972970002);
                    }
                    else if (applicationType == 972970002 || applicationType == 972970004)
                    {
                        invoice["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_effectivedate");
                        invoice["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("modifiedon");
                        invoice["lux_transactiontype"] = new OptionSetValue(972970001);
                        if (totalExcludingIPTFEE < 0)
                        {
                            invoice["lux_transactiontype"] = new OptionSetValue(972970003);
                        }
                    }

                    invoice["lux_instalmentpercentage"] = percentage;
                    invoice["lux_insured"] = policy.Attributes["lux_name"].ToString();
                    invoice["lux_policynumber"] = policy.Attributes["lux_policynumber"].ToString();
                    invoice["lux_risktransaction"] = new OptionSetValue(972970001);
                    if (policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
                    {
                        invoice["lux_risktransaction"] = new OptionSetValue(972970002);
                    }

                    invoice["lux_aciescommissionrate"] = pslCommPer.ToString();
                    invoice["lux_commissionrate"] = brokerCommPer.ToString();
                    invoice["lux_aciescommissionamount"] = new Money(totalExcludingIPTFEE * pslCommPer / 100);
                    invoice["lux_commissionamount"] = new Money(totalExcludingIPTFEE * brokerCommPer / 100);

                    invoice["lux_fee"] = new Money(adminFee);
                    invoice["lux_duedate"] = item.GetAttributeValue<DateTime>("lux_duedate");
                    invoice["lux_grosspremiumexciptfee"] = new Money(totalExcludingIPTFEE);

                    if (instalmentNumber == 1)
                    {
                        invoice["lux_isfirstinstalmenttransaction"] = true;
                        invoice["lux_totallinefee"] = new Money(totalLineFee);
                    }

                    invoice["lux_iptrate"] = IPTRate;
                    invoice["lux_ipt"] = new Money(totalExcludingIPTFEE * IPTRate / 100);

                    if (Carrier != 0)
                    {
                        var capacityFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_phoenixcapacitysplittable'>
                                                    <attribute name='lux_linepercentagecalculated' />
                                                    <attribute name='lux_lineamountcalculated' />
                                                    <attribute name='lux_insurername' />
                                                    <attribute name='lux_capacity' />
                                                    <attribute name='lux_linefee' />
                                                    <attribute name='lux_phoenixcapacitysplittableid' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_contractorsplantandequipmentquote' operator='eq' uiname='' uitype='lux_contractorsplantandequipmentquote' value='{quote.Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                        var capacity = service.RetrieveMultiple(new FetchExpression(capacityFetch)).Entities;

                        if (Carrier == 972970001) //Global Binder
                        {
                            if (capacity.Count > 0)
                            {
                                var lancashire = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Lancashire")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                var probitas = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Probitas")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                var cincinatti = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Cincinnati")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                var argenta = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Argenta")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);

                                var lancashireFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Lancashire")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                                var probitasFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Probitas")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                                var cincinattiFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Cincinnati")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                                var argentaFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Argenta")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);

                                invoice["lux_lancashiresplit"] = lancashire;
                                invoice["lux_probitas1492split"] = probitas;
                                invoice["lux_cincinnatiinsurancesplit"] = cincinatti;
                                invoice["lux_argentasplit"] = argenta;
                                if (instalmentNumber == 1)
                                {
                                    invoice["lux_lancashirelinefee"] = new Money(lancashireFee);
                                    invoice["lux_probitas1492linefee"] = new Money(probitasFee);
                                    invoice["lux_cincinnatiinsurancelinefee"] = new Money(cincinattiFee);
                                    invoice["lux_argentalinefee"] = new Money(argentaFee);
                                }
                            }
                            invoice["lux_globalcpesplit"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommPer / 100 - totalExcludingIPTFEE * brokerCommPer / 100);
                        }
                        else if (Carrier == 972970002) //AXA
                        {
                            var axaFee = 0M;
                            if (capacity.Count > 0)
                            {
                                var axa = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("AXA")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                axaFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("AXA")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                                invoice["lux_axasplit"] = axa;
                                if (instalmentNumber == 1)
                                {
                                    invoice["lux_axalinefee"] = new Money(axaFee);
                                }
                            }
                            invoice["lux_duetoaxa"] = new Money(axaFee + totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommPer / 100 - totalExcludingIPTFEE * brokerCommPer / 100);
                        }
                        else if (Carrier == 972970003) // Argenta
                        {
                            if (capacity.Count > 0)
                            {
                                var argenta = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Argenta")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                var argentaFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Argenta")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                                invoice["lux_argentasplit"] = argenta;
                                if (instalmentNumber == 1)
                                {
                                    invoice["lux_argentalinefee"] = new Money(argentaFee);
                                }
                            }
                            invoice["lux_globalcpesplit"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommPer / 100 - totalExcludingIPTFEE * brokerCommPer / 100);
                        }
                        else if (Carrier == 972970004) // Great American
                        {
                            var americaFee = 0M;
                            if (capacity.Count > 0)
                            {
                                var america = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Great American")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                americaFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Great American")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                                invoice["lux_greatamericansplit"] = america;
                                if (instalmentNumber == 1)
                                {
                                    invoice["lux_greatamericanlinefee"] = new Money(americaFee);
                                }
                            }
                            invoice["lux_duetogreatamerican"] = new Money(americaFee + totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommPer / 100 - totalExcludingIPTFEE * brokerCommPer / 100);
                        }
                        else if (Carrier == 972970005) // AXA & Great American
                        {
                            var axa = 50M;
                            var greatamerican = 50M;
                            var axaFee = 0M;
                            var americaFee = 0M;

                            if (capacity.Count > 0)
                            {
                                axa = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("AXA")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                greatamerican = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Great American")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);

                                axaFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("AXA")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                                americaFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Great American")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);

                                invoice["lux_axasplit"] = axa;
                                invoice["lux_greatamericansplit"] = greatamerican;

                                if (instalmentNumber == 1)
                                {
                                    invoice["lux_axalinefee"] = new Money(axaFee);
                                    invoice["lux_greatamericanlinefee"] = new Money(americaFee);
                                }
                            }

                            invoice["lux_duetoaxa"] = new Money(axaFee + (totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommPer / 100 - totalExcludingIPTFEE * brokerCommPer / 100) * axa / 100);
                            invoice["lux_duetogreatamerican"] = new Money(americaFee + (totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommPer / 100 - totalExcludingIPTFEE * brokerCommPer / 100) * greatamerican / 100);
                        }
                    }
                    else
                    {
                        invoice["lux_globalcpesplit"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommPer / 100 - totalExcludingIPTFEE * brokerCommPer / 100);
                    }
                    invoice["lux_totalpremiumincludingiptfee"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 + adminFee);

                    service.Create(invoice);

                    if ((quote.GetAttributeValue<bool>("lux_iscoverrequiredforterrorism") == true && quote.Attributes.Contains("lux_terrorismaddon")) || (quote.Attributes.Contains("lux_terrorismaddon") && applicationType == 972970002))
                    {
                        Entity invoice1 = new Entity("lux_invoice");
                        invoice1["lux_contractorsplantandequipmentquote"] = new EntityReference("lux_contractorsplantandequipmentquote", quote.Id);
                        invoice1["lux_constructionpolicy"] = new EntityReference("lux_constructionpolicy", policy.Id);
                        invoice1["lux_constructionproducttype"] = new OptionSetValue(972970002);
                        invoice1["lux_broker"] = new EntityReference("account", policy.GetAttributeValue<EntityReference>("lux_brokercompany").Id);
                        invoice1["transactioncurrencyid"] = new EntityReference("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                        invoice1["lux_product"] = new EntityReference("product", quote.GetAttributeValue<EntityReference>("lux_product").Id);

                        if (applicationType == 972970001 || applicationType == 972970003)
                        {
                            invoice1["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                            invoice1["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("createdon");
                            invoice1["lux_transactiontype"] = new OptionSetValue(972970002);
                        }
                        else if (applicationType == 972970002 || applicationType == 972970004)
                        {
                            invoice1["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                            invoice1["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("modifiedon");
                            invoice1["lux_transactiontype"] = new OptionSetValue(972970001);
                            if (terrtotalExcludingIPTFEE < 0)
                            {
                                invoice1["lux_transactiontype"] = new OptionSetValue(972970003);
                            }
                        }

                        invoice1["lux_instalmentpercentage"] = percentage;
                        invoice1["lux_insured"] = policy.Attributes["lux_name"].ToString();
                        invoice1["lux_policynumber"] = policy.Attributes["lux_policynumber"].ToString();
                        invoice1["lux_risktransaction"] = new OptionSetValue(972970001);
                        if (policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
                        {
                            invoice1["lux_risktransaction"] = new OptionSetValue(972970002);
                        }

                        invoice1["lux_aciescommissionrate"] = TerrpslCommPer.ToString();
                        invoice1["lux_commissionrate"] = TerrbrokerCommPer.ToString();

                        invoice1["lux_aciescommissionamount"] = new Money(terrtotalExcludingIPTFEE * TerrpslCommPer / 100);
                        invoice1["lux_commissionamount"] = new Money(terrtotalExcludingIPTFEE * TerrbrokerCommPer / 100);

                        invoice1["lux_fee"] = new Money(TerradminFee);
                        invoice1["lux_duedate"] = item.GetAttributeValue<DateTime>("lux_duedate");
                        invoice1["lux_grosspremiumexciptfee"] = new Money(terrtotalExcludingIPTFEE);

                        if (instalmentNumber == 1)
                        {
                            invoice1["lux_isfirstinstalmenttransaction"] = true;
                        }

                        invoice1["lux_isconstructionterrorismtransaction"] = true;
                        invoice1["lux_iptrate"] = TerrIPTRate;
                        invoice1["lux_ipt"] = new Money(terrtotalExcludingIPTFEE * TerrIPTRate / 100);
                        if (Carrier != 0)
                        {
                            var capacityFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_phoenixcapacitysplittable'>
                                                    <attribute name='lux_linepercentagecalculated' />
                                                    <attribute name='lux_lineamountcalculated' />
                                                    <attribute name='lux_insurername' />
                                                    <attribute name='lux_capacity' />
                                                    <attribute name='lux_linefee' />
                                                    <attribute name='lux_phoenixcapacitysplittableid' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_contractorsplantandequipmentquote' operator='eq' uiname='' uitype='lux_contractorsplantandequipmentquote' value='{quote.Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                            var capacity = service.RetrieveMultiple(new FetchExpression(capacityFetch)).Entities;

                            if (Carrier == 972970001) //Global Binder
                            {
                                if (capacity.Count > 0)
                                {
                                    var lancashire = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Lancashire")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                    var probitas = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Probitas")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                    var cincinatti = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Cincinnati")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                    var argenta = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Argenta")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);

                                    invoice1["lux_lancashiresplit"] = lancashire;
                                    invoice1["lux_probitas1492split"] = probitas;
                                    invoice1["lux_cincinnatiinsurancesplit"] = cincinatti;
                                    invoice1["lux_argentasplit"] = argenta;
                                }
                                invoice1["lux_globalcpesplit"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommPer / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommPer / 100);
                            }
                            else if (Carrier == 972970002) //AXA
                            {
                                if (capacity.Count > 0)
                                {
                                    var axa = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("AXA")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                    invoice1["lux_axasplit"] = axa;
                                }
                                invoice1["lux_duetoaxa"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommPer / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommPer / 100);
                            }
                            else if (Carrier == 972970003) // Argenta
                            {
                                if (capacity.Count > 0)
                                {
                                    var argenta = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Argenta")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                    invoice1["lux_argentasplit"] = argenta;
                                }
                                invoice1["lux_globalcpesplit"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommPer / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommPer / 100);
                            }
                            else if (Carrier == 972970004) // Great American
                            {
                                if (capacity.Count > 0)
                                {
                                    var america = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Great American")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                    invoice1["lux_greatamericansplit"] = america;
                                }
                                invoice1["lux_duetogreatamerican"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommPer / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommPer / 100);
                            }
                            else if (Carrier == 972970005) // AXA & Great American
                            {
                                var axa = 50M;
                                var greatamerican = 50M;

                                if (capacity.Count > 0)
                                {
                                    axa = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("AXA")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                    greatamerican = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Great American")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);

                                    invoice1["lux_axasplit"] = axa;
                                    invoice1["lux_greatamericansplit"] = greatamerican;
                                }

                                invoice1["lux_duetoaxa"] = new Money((terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommPer / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommPer / 100) * axa / 100);
                                invoice1["lux_duetogreatamerican"] = new Money((terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommPer / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommPer / 100) * greatamerican / 100);
                            }
                        }
                        else
                        {
                            invoice1["lux_globalcpesplit"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommPer / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommPer / 100);
                        }
                        invoice1["lux_totalpremiumincludingiptfee"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 + TerradminFee);
                        service.Create(invoice1);
                    }
                }
            }
            else
            {
                var totalExcludingIPTFEE = totalExcludingIptFee;
                var terrtotalExcludingIPTFEE = TerrtotalExcludingIptFee;

                Entity invoice = new Entity("lux_invoice");
                invoice["lux_contractorsplantandequipmentquote"] = new EntityReference("lux_contractorsplantandequipmentquote", quote.Id);
                invoice["lux_constructionpolicy"] = new EntityReference("lux_constructionpolicy", policy.Id);
                invoice["lux_broker"] = new EntityReference("account", policy.GetAttributeValue<EntityReference>("lux_brokercompany").Id);
                invoice["transactioncurrencyid"] = new EntityReference("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                invoice["lux_product"] = new EntityReference("product", quote.GetAttributeValue<EntityReference>("lux_product").Id);

                if (applicationType == 972970001 || applicationType == 972970003)
                {
                    invoice["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                    invoice["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("createdon");
                    invoice["lux_transactiontype"] = new OptionSetValue(972970002);
                }
                else if (applicationType == 972970002 || applicationType == 972970004)
                {
                    invoice["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                    invoice["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("modifiedon");
                    invoice["lux_transactiontype"] = new OptionSetValue(972970001);
                    if (totalExcludingIPTFEE < 0)
                    {
                        invoice["lux_transactiontype"] = new OptionSetValue(972970003);
                    }
                }

                invoice["lux_insured"] = policy.Attributes["lux_name"].ToString();
                invoice["lux_policynumber"] = policy.Attributes["lux_policynumber"].ToString();
                invoice["lux_risktransaction"] = new OptionSetValue(972970001);
                if (policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
                {
                    invoice["lux_risktransaction"] = new OptionSetValue(972970002);
                }

                invoice["lux_aciescommissionrate"] = pslCommPer.ToString();
                invoice["lux_commissionrate"] = brokerCommPer.ToString();
                invoice["lux_aciescommissionamount"] = new Money(totalExcludingIPTFEE * pslCommPer / 100);
                invoice["lux_commissionamount"] = new Money(totalExcludingIPTFEE * brokerCommPer / 100);

                invoice["lux_fee"] = new Money(adminFee);
                invoice["lux_duedate"] = new DateTime(DueDate.Year, DueDate.Month, 1).AddMonths(2).AddDays(-1);
                invoice["lux_grosspremiumexciptfee"] = new Money(totalExcludingIPTFEE);

                invoice["lux_iptrate"] = IPTRate;
                invoice["lux_ipt"] = new Money(totalExcludingIPTFEE * IPTRate / 100);

                if (Carrier != 0)
                {
                    var capacityFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_phoenixcapacitysplittable'>
                                                    <attribute name='lux_linepercentagecalculated' />
                                                    <attribute name='lux_lineamountcalculated' />
                                                    <attribute name='lux_insurername' />
                                                    <attribute name='lux_capacity' />
                                                    <attribute name='lux_linefee' />
                                                    <attribute name='lux_phoenixcapacitysplittableid' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_contractorsplantandequipmentquote' operator='eq' uiname='' uitype='lux_contractorsplantandequipmentquote' value='{quote.Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                    var capacity = service.RetrieveMultiple(new FetchExpression(capacityFetch)).Entities;

                    if (Carrier == 972970001) //Global Binder
                    {
                        if (capacity.Count > 0)
                        {
                            var lancashire = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Lancashire")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                            var probitas = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Probitas")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                            var cincinatti = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Cincinnati")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                            var argenta = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Argenta")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);

                            var lancashireFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Lancashire")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                            var probitasFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Probitas")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                            var cincinattiFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Cincinnati")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                            var argentaFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Argenta")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);

                            invoice["lux_lancashiresplit"] = lancashire;
                            invoice["lux_probitas1492split"] = probitas;
                            invoice["lux_cincinnatiinsurancesplit"] = cincinatti;
                            invoice["lux_argentasplit"] = argenta;

                            invoice["lux_lancashirelinefee"] = new Money(lancashireFee);
                            invoice["lux_probitas1492linefee"] = new Money(probitasFee);
                            invoice["lux_cincinnatiinsurancelinefee"] = new Money(cincinattiFee);
                            invoice["lux_argentalinefee"] = new Money(argentaFee);
                        }
                        invoice["lux_globalcpesplit"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommPer / 100 - totalExcludingIPTFEE * brokerCommPer / 100);
                    }
                    else if (Carrier == 972970002) //AXA
                    {
                        var axaFee = 0M;
                        if (capacity.Count > 0)
                        {
                            var axa = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("AXA")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                            axaFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("AXA")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                            invoice["lux_axasplit"] = axa;
                            invoice["lux_axalinefee"] = new Money(axaFee);
                        }
                        invoice["lux_duetoaxa"] = new Money(axaFee + totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommPer / 100 - totalExcludingIPTFEE * brokerCommPer / 100);
                    }
                    else if (Carrier == 972970003) // Argenta
                    {
                        if (capacity.Count > 0)
                        {
                            var argenta = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Argenta")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                            var argentaFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Argenta")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                            invoice["lux_argentasplit"] = argenta;
                            invoice["lux_argentalinefee"] = new Money(argentaFee);
                        }
                        invoice["lux_globalcpesplit"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommPer / 100 - totalExcludingIPTFEE * brokerCommPer / 100);
                    }
                    else if (Carrier == 972970004) // Great American
                    {
                        var americaFee = 0M;
                        if (capacity.Count > 0)
                        {
                            var america = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Great American")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                            americaFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Great American")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                            invoice["lux_greatamericansplit"] = america;
                            invoice["lux_greatamericanlinefee"] = new Money(americaFee);
                        }
                        invoice["lux_duetogreatamerican"] = new Money(americaFee + totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommPer / 100 - totalExcludingIPTFEE * brokerCommPer / 100);
                    }
                    else if (Carrier == 972970005) // AXA & Great American
                    {
                        var axa = 50M;
                        var greatamerican = 50M;
                        var axaFee = 0M;
                        var americaFee = 0M;

                        if (capacity.Count > 0)
                        {
                            axa = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("AXA")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                            greatamerican = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Great American")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);

                            axaFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("AXA")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);
                            americaFee = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Great American")).Sum(x => x.Attributes.Contains("lux_linefee") ? x.GetAttributeValue<Money>("lux_linefee").Value : 0);

                            invoice["lux_axasplit"] = axa;
                            invoice["lux_greatamericansplit"] = greatamerican;

                            invoice["lux_axalinefee"] = new Money(axaFee);
                            invoice["lux_greatamericanlinefee"] = new Money(americaFee);
                        }

                        invoice["lux_duetoaxa"] = new Money(axaFee + (totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommPer / 100 - totalExcludingIPTFEE * brokerCommPer / 100) * axa / 100);
                        invoice["lux_duetogreatamerican"] = new Money(americaFee + (totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommPer / 100 - totalExcludingIPTFEE * brokerCommPer / 100) * greatamerican / 100);
                    }
                }
                else
                {
                    invoice["lux_globalcpesplit"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommPer / 100 - totalExcludingIPTFEE * brokerCommPer / 100);
                }

                invoice["lux_totalpremiumincludingiptfee"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 + adminFee);
                invoice["lux_totallinefee"] = new Money(totalLineFee);
                service.Create(invoice);

                if ((quote.GetAttributeValue<bool>("lux_iscoverrequiredforterrorism") == true && quote.Attributes.Contains("lux_terrorismaddon")) || (quote.Attributes.Contains("lux_terrorismaddon") && applicationType == 972970002))
                {
                    Entity invoice1 = new Entity("lux_invoice");
                    invoice1["lux_contractorsplantandequipmentquote"] = new EntityReference("lux_contractorsplantandequipmentquote", quote.Id);
                    invoice1["lux_constructionpolicy"] = new EntityReference("lux_constructionpolicy", policy.Id);
                    invoice1["lux_constructionproducttype"] = new OptionSetValue(972970002);
                    invoice1["lux_broker"] = new EntityReference("account", policy.GetAttributeValue<EntityReference>("lux_brokercompany").Id);
                    invoice1["transactioncurrencyid"] = new EntityReference("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                    invoice1["lux_product"] = new EntityReference("product", quote.GetAttributeValue<EntityReference>("lux_product").Id);

                    if (applicationType == 972970001 || applicationType == 972970003)
                    {
                        invoice1["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                        invoice1["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("createdon");
                        invoice1["lux_transactiontype"] = new OptionSetValue(972970002);
                    }
                    else if (applicationType == 972970002 || applicationType == 972970004)
                    {
                        invoice1["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                        invoice1["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("modifiedon");
                        invoice1["lux_transactiontype"] = new OptionSetValue(972970001);
                        if (terrtotalExcludingIPTFEE < 0)
                        {
                            invoice1["lux_transactiontype"] = new OptionSetValue(972970003);
                        }
                    }

                    invoice1["lux_insured"] = policy.Attributes["lux_name"].ToString();
                    invoice1["lux_policynumber"] = policy.Attributes["lux_policynumber"].ToString();
                    invoice1["lux_risktransaction"] = new OptionSetValue(972970001);

                    if (policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
                    {
                        invoice1["lux_risktransaction"] = new OptionSetValue(972970002);
                    }

                    invoice1["lux_aciescommissionrate"] = TerrpslCommPer.ToString();
                    invoice1["lux_commissionrate"] = TerrbrokerCommPer.ToString();

                    invoice1["lux_aciescommissionamount"] = new Money(terrtotalExcludingIPTFEE * TerrpslCommPer / 100);
                    invoice1["lux_commissionamount"] = new Money(terrtotalExcludingIPTFEE * TerrbrokerCommPer / 100);

                    invoice1["lux_fee"] = new Money(TerradminFee);
                    invoice1["lux_duedate"] = new DateTime(DueDate.Year, DueDate.Month, 1).AddMonths(2).AddDays(-1);
                    invoice1["lux_grosspremiumexciptfee"] = new Money(terrtotalExcludingIPTFEE);

                    invoice1["lux_isconstructionterrorismtransaction"] = true;
                    invoice1["lux_iptrate"] = TerrIPTRate;
                    invoice1["lux_ipt"] = new Money(terrtotalExcludingIPTFEE * TerrIPTRate / 100);
                    if (Carrier != 0)
                    {
                        var capacityFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_phoenixcapacitysplittable'>
                                                    <attribute name='lux_linepercentagecalculated' />
                                                    <attribute name='lux_lineamountcalculated' />
                                                    <attribute name='lux_insurername' />
                                                    <attribute name='lux_capacity' />
                                                    <attribute name='lux_linefee' />
                                                    <attribute name='lux_phoenixcapacitysplittableid' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_contractorsplantandequipmentquote' operator='eq' uiname='' uitype='lux_contractorsplantandequipmentquote' value='{quote.Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                        var capacity = service.RetrieveMultiple(new FetchExpression(capacityFetch)).Entities;

                        if (Carrier == 972970001) //Global Binder
                        {
                            if (capacity.Count > 0)
                            {
                                var lancashire = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Lancashire")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                var probitas = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Probitas")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                var cincinatti = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Cincinnati")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                var argenta = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Argenta")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);

                                invoice1["lux_lancashiresplit"] = lancashire;
                                invoice1["lux_probitas1492split"] = probitas;
                                invoice1["lux_cincinnatiinsurancesplit"] = cincinatti;
                                invoice1["lux_argentasplit"] = argenta;
                            }
                            invoice1["lux_globalcpesplit"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommPer / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommPer / 100);
                        }
                        else if (Carrier == 972970002) //AXA
                        {
                            if (capacity.Count > 0)
                            {
                                var axa = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("AXA")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                invoice1["lux_axasplit"] = axa;
                            }
                            invoice1["lux_duetoaxa"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommPer / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommPer / 100);
                        }
                        else if (Carrier == 972970003) // Argenta
                        {
                            if (capacity.Count > 0)
                            {
                                var argenta = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Argenta")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                invoice1["lux_argentasplit"] = argenta;
                            }
                            invoice1["lux_globalcpesplit"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommPer / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommPer / 100);
                        }
                        else if (Carrier == 972970004) // Great American
                        {
                            if (capacity.Count > 0)
                            {
                                var america = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Great American")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                invoice1["lux_greatamericansplit"] = america;
                            }
                            invoice1["lux_duetogreatamerican"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommPer / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommPer / 100);
                        }
                        else if (Carrier == 972970005) // AXA & Great American
                        {
                            var axa = 50M;
                            var greatamerican = 50M;

                            if (capacity.Count > 0)
                            {
                                axa = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("AXA")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);
                                greatamerican = capacity.Where(x => x.Attributes["lux_insurername"].ToString().Contains("Great American")).Sum(x => x.Attributes.Contains("lux_linepercentagecalculated") ? x.GetAttributeValue<decimal>("lux_linepercentagecalculated") : 0);

                                invoice1["lux_axasplit"] = axa;
                                invoice1["lux_greatamericansplit"] = greatamerican;
                            }

                            invoice1["lux_duetoaxa"] = new Money((terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommPer / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommPer / 100) * axa / 100);
                            invoice1["lux_duetogreatamerican"] = new Money((terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommPer / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommPer / 100) * greatamerican / 100);
                        }
                    }
                    else
                    {
                        invoice1["lux_globalcpesplit"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommPer / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommPer / 100);
                    }
                    invoice1["lux_totalpremiumincludingiptfee"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * TerrIPTRate / 100 + TerradminFee);
                    service.Create(invoice1);
                }
            }
        }
    }
}