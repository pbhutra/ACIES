﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CreateIntermediaryCompany
{
    public class CreateInstalments : CodeActivity
    {
        [Input("Construction Quote")]
        [ReferenceTarget("lux_constructionquotes")]
        public InArgument<EntityReference> ConstructionQuote { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference quoteref = ConstructionQuote.Get<EntityReference>(executionContext);
            Entity quote = new Entity(quoteref.LogicalName, quoteref.Id);
            quote = service.Retrieve("lux_constructionquotes", quoteref.Id, new ColumnSet(true));
            var DueDate = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
            var IsInstallment = quote.Attributes.Contains("lux_premiumpayablebyinstalments") ? quote.GetAttributeValue<bool>("lux_premiumpayablebyinstalments") : false;
            var Carrier = quote.Attributes.Contains("lux_carrier") ? quote.GetAttributeValue<OptionSetValue>("lux_carrier").Value : 972970001;

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_constructionpremiuminstalment'>
                                <attribute name='lux_instalmentnumber' />
                                <attribute name='lux_duedate' />
                                <attribute name='lux_instalmentvalue' />
                                <attribute name='lux_instalmentpercentage' />
                                <attribute name='lux_constructionpremiuminstalmentid' />
                                <order attribute='lux_instalmentnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_constructionquote' operator='eq' uiname='' uitype='lux_constructionquotes' value='{quote.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (IsInstallment == true && service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
            {
                var NoOfInstallment = Convert.ToInt32(quote.FormattedValues["lux_numberofinstalments"]);
                for (int i = 1; i <= NoOfInstallment; i++)
                {
                    Entity instalment = new Entity("lux_constructionpremiuminstalment");
                    instalment["lux_constructionquote"] = new EntityReference("lux_constructionquotes", quote.Id);
                    instalment["lux_tax"] = 12M;
                    if (Carrier == 972970002)
                    {
                        instalment["lux_tax"] = 5M;
                    }
                    instalment["transactioncurrencyid"] = new EntityReference("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                    instalment["lux_instalmentnumber"] = new OptionSetValue(972970000 + i);
                    if (i == 1)
                    {
                        instalment["lux_duedate"] = new DateTime(DueDate.Year, DueDate.Month, 1).AddMonths(2).AddDays(-1);
                    }
                    service.Create(instalment);
                }
            }
        }
    }
}