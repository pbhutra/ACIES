﻿using CreateIntermediaryCompany.ACIES;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Xml;
//using ColumnSet = Microsoft.Crm.Sdk.Query.ColumnSet;

namespace Send_Email_to_Multiple_Recipients
{
    namespace CreateIntermediaryCompany.ACIES
    {
        public class EmailAddRecipientsFromQuery : CodeActivity
        {
            [RequiredArgument]
            [Input("Email to Update")]
            [ReferenceTarget("email")]
            public InArgument<EntityReference> Email { get; set; }

            [RequiredArgument]
            [Input("Claim")]
            [ReferenceTarget("lux_claim")]
            public InArgument<EntityReference> Claim { get; set; }

            protected override void Execute(CodeActivityContext executionContext)
            {
                ITracingService tracingService = executionContext.GetExtension<ITracingService>();
                tracingService.Trace("Application Started");
                tracingService.Trace(executionContext.ToString());

                if (executionContext == null)
                {
                    throw new ArgumentNullException(nameof(executionContext));
                }

                IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
                IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
                IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

                tracingService.Trace(context.UserId.ToString());


                EntityReference claimref = Claim.Get(executionContext);
                Entity claim = service.Retrieve("lux_claim", claimref.Id, new ColumnSet(true));

                Entity Policy = service.Retrieve("lux_policy", claim.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet(true));
                var InceptionDate = Policy.GetAttributeValue<DateTime>("lux_policystartdate");

                OptionSetValueCollection multiselect = (OptionSetValueCollection)claim.Attributes["lux_claimon"];

                string emailField = "to";
                Entity email = service.Retrieve("email", this.Email.Get(executionContext).Id, new Microsoft.Xrm.Sdk.Query.ColumnSet(emailField, "statuscode"));
                if (email["statuscode"] == null || email.GetAttributeValue<OptionSetValue>("statuscode").Value != 1)
                {
                    throw new ArgumentException("Email must be in Draft status.");
                }

                string fetchXML = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='account'>
                                    <attribute name='name' />
                                    <attribute name='primarycontactid' />
                                    <attribute name='telephone1' />
                                    <attribute name='accountid' />
                                    <order attribute='name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='lux_accounttype' operator='eq' value='972970002' />
                                      <condition attribute = 'lux_claimon' operator= 'contain-values'>";
                foreach (var item1 in multiselect)
                {
                    fetchXML += $@"<value>{item1.Value}</value>";
                }
                fetchXML += $@"</condition>";

                if (multiselect.Contains(new OptionSetValue(972970002)) && InceptionDate >= new DateTime(2024, 01, 01))
                {
                    fetchXML += $@"<condition attribute='accountid' operator='ne' uiname='HCC Liability Claim Handler' uitype='account' value='100B598C-A193-EC11-B400-6045BD0EEC8B' />";
                }
                else if (multiselect.Contains(new OptionSetValue(972970002)) && InceptionDate < new DateTime(2024, 01, 01))
                {
                    fetchXML += $@"<condition attribute='accountid' operator='ne' uiname='Faraday Liability Claim Handler' uitype='account' value='1EA4F329-43E0-EE11-904C-7C1E521E461E' />";
                }

                fetchXML += $@"</filter>
                                  </entity>
                                </fetch>";

                tracingService.Trace(fetchXML.ToString());
                QueryResult result = ExecuteQueryForRecords(executionContext, fetchXML);

                if (result.RecordIds.Any())
                {
                    List<Entity> recipients = new List<Entity>();

                    if (email[emailField] != null && ((Microsoft.Xrm.Sdk.EntityCollection)email[emailField]).Entities != null && ((Microsoft.Xrm.Sdk.EntityCollection)email[emailField]).Entities.Any())
                    {
                        recipients.AddRange(((EntityCollection)email[emailField]).Entities.ToList());
                    }

                    foreach (Guid id in result.RecordIds)
                    {
                        if (!recipients.Any(r => ((EntityReference)(r["partyid"])).Id == id && ((EntityReference)(r["partyid"])).LogicalName == result.EntityName))
                        {
                            Entity party = new Entity("activityparty");
                            party["partyid"] = new EntityReference(result.EntityName, id);
                            recipients.Add(party);
                            //recipientsAdded++;
                        }
                    }
                    email[emailField] = recipients.ToArray();
                }
                service.Update(email);
            }


            public QueryResult ExecuteQueryForRecords(CodeActivityContext context, string fetchXml)
            {
                ITracingService tracingService = context.GetExtension<ITracingService>();
                QueryResult returnValue = new QueryResult() { RecordIds = new List<Guid>() };

                IWorkflowContext workflowContext = context.GetExtension<IWorkflowContext>();
                IOrganizationServiceFactory serviceFactory = context.GetExtension<IOrganizationServiceFactory>();
                IOrganizationService service = serviceFactory.CreateOrganizationService(workflowContext.UserId);


                this.LimitQueryToCurrentRecord(service, ref fetchXml, workflowContext.PrimaryEntityName, workflowContext.PrimaryEntityId);
                EntityCollection ec = null;
                try
                {
                    FetchExpression fe = new FetchExpression(fetchXml);
                    ec = service.RetrieveMultiple(fe);
                }
                catch (System.ServiceModel.FaultException<Microsoft.Xrm.Sdk.OrganizationServiceFault> ex)
                {
                    throw new ArgumentException("There was an error executing the query. Message: " + ex.Message);
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                returnValue.EntityName = ec.EntityName;

                RetrieveEntityRequest entityMetadataRequest = new RetrieveEntityRequest() { LogicalName = returnValue.EntityName };
                var response = service.Execute(entityMetadataRequest) as RetrieveEntityResponse;
                if (response == null || response.EntityMetadata == null)
                {
                    throw new InvalidOperationException($"Entity metadata not found for entity {returnValue.EntityName}");
                }
                returnValue.Metadata = response.EntityMetadata;

                string primaryKeyField = returnValue.Metadata.PrimaryIdAttribute;

                returnValue.RecordIds.AddRange(ec.Entities.Select(e => e.Id).ToList());

                return returnValue;
            }

            protected void LimitQueryToCurrentRecord(IOrganizationService service, ref string fetchXml, string entityName, Guid entityId)
            {
                Microsoft.Xrm.Sdk.Messages.RetrieveEntityRequest metadataRequest = new Microsoft.Xrm.Sdk.Messages.RetrieveEntityRequest() { LogicalName = entityName };
                Microsoft.Xrm.Sdk.Messages.RetrieveEntityResponse metadataResponse = service.Execute(metadataRequest) as Microsoft.Xrm.Sdk.Messages.RetrieveEntityResponse;
                if (metadataResponse == null)
                {
                    return;
                }

                XmlDocument fetchXmlDoc = new XmlDocument();
                fetchXmlDoc.LoadXml(fetchXml);
                this.UpdateConditionRecursively(fetchXmlDoc, fetchXmlDoc.FirstChild, entityId, entityName, metadataResponse.EntityMetadata.PrimaryIdAttribute);
                fetchXml = fetchXmlDoc.OuterXml;
            }

            protected void UpdateConditionRecursively(XmlDocument xmlDoc, XmlNode currentNode, Guid entityId, string entityName, string primaryKeyField)
            {
                if (currentNode.Name == "condition")
                {
                    if (currentNode.Attributes["attribute"] != null && currentNode.Attributes["attribute"].Value == primaryKeyField &&
                        currentNode.Attributes["operator"] != null && currentNode.Attributes["operator"].Value == "not-null" &&
                        currentNode.ParentNode != null && currentNode.ParentNode.Name == "filter" &&
                        currentNode.ParentNode.ParentNode != null && currentNode.ParentNode.ParentNode.Name == "link-entity" &&
                        currentNode.ParentNode.ParentNode.Attributes["name"] != null && currentNode.ParentNode.ParentNode.Attributes["name"].Value == entityName)
                    {
                        XmlAttribute keyAttribute = xmlDoc.CreateAttribute("value");
                        keyAttribute.Value = entityId.ToString();
                        currentNode.Attributes["operator"].Value = "eq";
                        currentNode.Attributes.Append(keyAttribute);
                    }
                }
                foreach (XmlNode child in currentNode.ChildNodes)
                {
                    this.UpdateConditionRecursively(xmlDoc, child, entityId, entityName, primaryKeyField);
                }
            }

            public struct QueryResult
            {
                public string EntityName { get; set; }
                public List<Guid> RecordIds { get; set; }
                public EntityMetadata Metadata { get; set; }
            }
        }
    }
}