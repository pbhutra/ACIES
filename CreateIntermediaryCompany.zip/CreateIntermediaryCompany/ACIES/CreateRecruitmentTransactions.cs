﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CreateIntermediaryCompany
{
    public class CreateRecruitmentTransactions : CodeActivity
    {
        [Input("Recruitment Quote")]
        [ReferenceTarget("lux_recruitmentquotes")]
        public InArgument<EntityReference> RecruitmentQuote { get; set; }

        [Input("Recruitment Policy")]
        [ReferenceTarget("lux_specialistschemespolicy")]
        public InArgument<EntityReference> RecruitmentPolicy { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference quoteref = RecruitmentQuote.Get<EntityReference>(executionContext);
            Entity quote = new Entity(quoteref.LogicalName, quoteref.Id);
            quote = service.Retrieve("lux_recruitmentquotes", quoteref.Id, new ColumnSet(true));

            EntityReference policyref = RecruitmentPolicy.Get<EntityReference>(executionContext);
            Entity policy = new Entity(policyref.LogicalName, policyref.Id);
            policy = service.Retrieve("lux_specialistschemespolicy", policyref.Id, new ColumnSet(true));

            var applicationType = quote.Attributes.Contains("lux_applicationtype") ? quote.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value : 972970001;

            decimal PremexcLegalExcludingIPTFEE = quote.Attributes.Contains("lux_policypremiumbeforetax") ? quote.GetAttributeValue<Money>("lux_policypremiumbeforetax").Value : 0;
            decimal legalExcludingIPTFEE = quote.Attributes.Contains("lux_lepolicypremium") ? quote.GetAttributeValue<Money>("lux_lepolicypremium").Value : 0;
            decimal totalExcludingIPTFEE = PremexcLegalExcludingIPTFEE + legalExcludingIPTFEE;

            decimal brokerComm = quote.GetAttributeValue<decimal>("lux_policybrokercommission");
            decimal aciesComm = quote.GetAttributeValue<decimal>("lux_policyaciescommission");
            decimal adminFee = quote.Attributes.Contains("lux_policypolicyfee") ? quote.GetAttributeValue<Money>("lux_policypolicyfee").Value : 0;

            var Broker = service.Retrieve("account", policy.GetAttributeValue<EntityReference>("lux_brokercompany").Id, new ColumnSet("lux_paymentduedays"));
            var dueDays = 60;
            if (Broker.Attributes.Contains("lux_paymentduedays"))
            {
                if (Broker.FormattedValues["lux_paymentduedays"].Contains("30"))
                {
                    dueDays = 30;
                }
                else if (Broker.FormattedValues["lux_paymentduedays"].Contains("75"))
                {
                    dueDays = 75;
                }
                else if (Broker.FormattedValues["lux_paymentduedays"].Contains("90"))
                {
                    dueDays = 90;
                }
            }

            var DueDate = quote.GetAttributeValue<DateTime>("lux_inceptiondate").AddDays(dueDays);

            if (applicationType == 972970002)
            {
                PremexcLegalExcludingIPTFEE = quote.Attributes.Contains("lux_mtapolicypremiumbeforetax") ? quote.GetAttributeValue<Money>("lux_mtapolicypremiumbeforetax").Value : 0;
                legalExcludingIPTFEE = quote.Attributes.Contains("lux_mtalegalpremiumbeforetax") ? quote.GetAttributeValue<Money>("lux_mtalegalpremiumbeforetax").Value : 0;
                totalExcludingIPTFEE = PremexcLegalExcludingIPTFEE + legalExcludingIPTFEE;

                brokerComm = quote.GetAttributeValue<decimal>("lux_mtabrokercommission");
                aciesComm = quote.GetAttributeValue<decimal>("lux_mtaaciescommission");
                adminFee = quote.Attributes.Contains("lux_mtapolicyfee") ? quote.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0;
                DueDate = quote.GetAttributeValue<DateTime>("lux_effectivedate").AddDays(dueDays);
            }

            Entity invoice = new Entity("lux_invoice");
            invoice["lux_specialistschemesquote"] = new EntityReference("lux_recruitmentquotes", quote.Id);
            invoice["lux_specialistschemespolicy"] = new EntityReference("lux_specialistschemespolicy", policy.Id);
            invoice["lux_broker"] = new EntityReference("account", policy.GetAttributeValue<EntityReference>("lux_brokercompany").Id);
            invoice["transactioncurrencyid"] = new EntityReference("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
            invoice["lux_insured"] = policy.Attributes["lux_insuredname"].ToString();
            invoice["lux_policynumber"] = policy.Attributes["lux_name"].ToString();
            invoice["lux_risktransaction"] = new OptionSetValue(972970001);

            if (applicationType == 972970001 || applicationType == 972970003)
            {
                invoice["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                invoice["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("createdon");
                invoice["lux_transactiontype"] = new OptionSetValue(972970002);
            }
            else if (applicationType == 972970002 || applicationType == 972970004)
            {
                invoice["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_effectivedate");
                invoice["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("modifiedon");
                invoice["lux_transactiontype"] = new OptionSetValue(972970001);
                if (totalExcludingIPTFEE < 0)
                {
                    invoice["lux_transactiontype"] = new OptionSetValue(972970003);
                }
            }

            invoice["lux_product"] = new EntityReference("product", quote.GetAttributeValue<EntityReference>("lux_product").Id);
            if (policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
            {
                invoice["lux_risktransaction"] = new OptionSetValue(972970002);
            }

            invoice["lux_aciescommissionrate"] = aciesComm.ToString("#.00");
            invoice["lux_commissionrate"] = brokerComm.ToString("#.00");
            invoice["lux_aciescommissionamount"] = new Money(totalExcludingIPTFEE * aciesComm / 100);
            invoice["lux_commissionamount"] = new Money(totalExcludingIPTFEE * brokerComm / 100);

            invoice["lux_fee"] = new Money(adminFee);
            invoice["lux_duedate"] = new DateTime(DueDate.Year, DueDate.Month, 1).AddMonths(1).AddDays(-1);
            invoice["lux_grosspremiumexciptfee"] = new Money(totalExcludingIPTFEE);

            var IPTRate = quote.Attributes.Contains("lux_policytax") ? quote.GetAttributeValue<decimal>("lux_policytax") : 0M;

            invoice["lux_iptrate"] = IPTRate;
            invoice["lux_ipt"] = new Money(totalExcludingIPTFEE * IPTRate / 100);

            invoice["lux_duetosompointernational"] = new Money(PremexcLegalExcludingIPTFEE + PremexcLegalExcludingIPTFEE * IPTRate / 100 - PremexcLegalExcludingIPTFEE * aciesComm / 100 - PremexcLegalExcludingIPTFEE * brokerComm / 100);
            invoice["lux_legalexpensessplit"] = new Money(legalExcludingIPTFEE + legalExcludingIPTFEE * IPTRate / 100 - legalExcludingIPTFEE * aciesComm / 100 - legalExcludingIPTFEE * brokerComm / 100);

            invoice["lux_totalpremiumincludingiptfee"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 + adminFee);

            service.Create(invoice);
        }
    }
}