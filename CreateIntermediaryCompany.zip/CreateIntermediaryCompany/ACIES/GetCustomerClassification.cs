﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System.Activities;

namespace CreateIntermediaryCompany
{
    public class GetCustomerClassification : CodeActivity
    {
        [Input("Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        [RequiredArgument]
        public InArgument<EntityReference> Application { get; set; }

        [Input("Tradesman Application")]
        [ReferenceTarget("lux_tradesman")]
        [RequiredArgument]
        public InArgument<EntityReference> TradesmanApplication { get; set; }

        [Input("Product")]
        [ReferenceTarget("product")]
        [RequiredArgument]
        public InArgument<EntityReference> Product { get; set; }

        [Output("IsMicro")]
        public OutArgument<bool> IsMicro { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference prodref = Product.Get<EntityReference>(executionContext);
            Entity product = service.Retrieve("product", prodref.Id, new ColumnSet(true));

            var ProductName = product.Attributes["name"].ToString();
            IsMicro.Set(executionContext, true);

            if (!ProductName.Contains("Tradesman")) //Tradesman
            {
                EntityReference appref = Application.Get<EntityReference>(executionContext);
                Entity appln = service.Retrieve("lux_propertyownersapplications", appref.Id, new ColumnSet(true));

                if (ProductName.Contains("Pubs & Restaurants") || ProductName.Contains("Hotels and Guesthouses"))
                {
                    if (appln.Attributes.Contains("lux_ukturnover") && appln.GetAttributeValue<Money>("lux_ukturnover").Value > 2000000)
                    {
                        IsMicro.Set(executionContext, false);
                    }
                }
                else if (ProductName.Contains("Retail") || ProductName.Contains("Contractors Combined") || ProductName.Contains("Commercial Combined") || ProductName.Contains("Office"))
                {
                    if (appln.Attributes.Contains("lux_turnover") && appln.GetAttributeValue<Money>("lux_turnover").Value > 2000000)
                    {
                        IsMicro.Set(executionContext, false);
                    }
                }
            }
            else
            {
                EntityReference tradesmanref = TradesmanApplication.Get<EntityReference>(executionContext);
                Entity appln = service.Retrieve("lux_tradesman", tradesmanref.Id, new ColumnSet(true));

                if (appln.Attributes.Contains("lux_totalestimatedturnover") && appln.GetAttributeValue<Money>("lux_totalestimatedturnover").Value > 2000000)
                {
                    IsMicro.Set(executionContext, false);
                }
            }
        }
    }
}
