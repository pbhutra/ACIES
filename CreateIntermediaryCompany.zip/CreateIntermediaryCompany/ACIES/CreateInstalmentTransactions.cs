﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CreateIntermediaryCompany
{
    public class CreateInstalmentTransactions : CodeActivity
    {
        [Input("Construction Quote")]
        [ReferenceTarget("lux_constructionquotes")]
        public InArgument<EntityReference> ConstructionQuote { get; set; }

        [Input("Construction Policy")]
        [ReferenceTarget("lux_constructionpolicy")]
        public InArgument<EntityReference> ConstructionPolicy { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference quoteref = ConstructionQuote.Get<EntityReference>(executionContext);
            Entity quote = new Entity(quoteref.LogicalName, quoteref.Id);
            quote = service.Retrieve("lux_constructionquotes", quoteref.Id, new ColumnSet(true));

            EntityReference policyref = ConstructionPolicy.Get<EntityReference>(executionContext);
            Entity policy = new Entity(policyref.LogicalName, policyref.Id);
            policy = service.Retrieve("lux_constructionpolicy", policyref.Id, new ColumnSet(true));

            var IsInstallment = quote.Attributes.Contains("lux_premiumpayablebyinstalments") ? quote.GetAttributeValue<bool>("lux_premiumpayablebyinstalments") : false;
            var Carrier = quote.Attributes.Contains("lux_carrier") ? quote.GetAttributeValue<OptionSetValue>("lux_carrier").Value : 972970001;

            decimal totalExcludingIptFee = quote.GetAttributeValue<Money>("lux_totalpremiumexcludingterrorism").Value;
            decimal pslCommAmt = quote.GetAttributeValue<decimal>("lux_pslcommission");
            decimal brokerCommAmt = quote.GetAttributeValue<decimal>("lux_brokercommission");

            decimal TerrtotalExcludingIptFee = quote.GetAttributeValue<Money>("lux_terrorismsection").Value;
            decimal TerrpslCommAmt = quote.GetAttributeValue<decimal>("lux_terrorismcommission");
            decimal TerrbrokerCommAmt = quote.GetAttributeValue<decimal>("lux_terrorismcommissionpercentage");

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_constructionpremiuminstalment'>
                                <attribute name='lux_instalmentnumber' />
                                <attribute name='lux_duedate' />
                                <attribute name='lux_instalmentvalue' />
                                <attribute name='lux_policyadministrationfee' />
                                <attribute name='lux_instalmentpercentage' />
                                <attribute name='lux_constructionpremiuminstalmentid' />
                                <order attribute='lux_instalmentnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_constructionquote' operator='eq' uiname='' uitype='lux_constructionquotes' value='{quote.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (IsInstallment == true && service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    var instalmentNumber = Convert.ToInt32(item.FormattedValues["lux_instalmentnumber"]);
                    decimal percentage = item.GetAttributeValue<decimal>("lux_instalmentpercentage");
                    var totalExcludingIPTFEE = totalExcludingIptFee * percentage / 100;
                    var terrtotalExcludingIPTFEE = TerrtotalExcludingIptFee;

                    Entity invoice = new Entity("lux_invoice");
                    invoice["lux_constructionapplication"] = new EntityReference("lux_constructionquotes", quote.Id);
                    invoice["lux_constructionpolicy"] = new EntityReference("lux_constructionpolicy", policy.Id);
                    invoice["lux_broker"] = new EntityReference("account", policy.GetAttributeValue<EntityReference>("lux_brokercompany").Id);
                    invoice["transactioncurrencyid"] = new EntityReference("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                    invoice["lux_product"] = new EntityReference("product", quote.GetAttributeValue<EntityReference>("lux_product").Id);
                    invoice["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                    invoice["lux_insured"] = policy.Attributes["lux_name"].ToString();
                    invoice["lux_policynumber"] = policy.Attributes["lux_policynumber"].ToString();
                    invoice["lux_risktransaction"] = new OptionSetValue(972970001);
                    invoice["lux_instalmentpercentage"] = percentage;
                    if (policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
                    {
                        invoice["lux_risktransaction"] = new OptionSetValue(972970002);
                    }

                    invoice["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("createdon");
                    invoice["lux_transactiontype"] = new OptionSetValue(972970002);

                    invoice["lux_aciescommissionrate"] = pslCommAmt.ToString();
                    invoice["lux_commissionrate"] = brokerCommAmt.ToString();
                    invoice["lux_aciescommissionamount"] = new Money(totalExcludingIPTFEE * pslCommAmt / 100);
                    invoice["lux_commissionamount"] = new Money(totalExcludingIPTFEE * brokerCommAmt / 100);

                    invoice["lux_fee"] = item.GetAttributeValue<Money>("lux_policyadministrationfee");
                    invoice["lux_duedate"] = item.GetAttributeValue<DateTime>("lux_duedate");
                    invoice["lux_grosspremiumexciptfee"] = new Money(totalExcludingIPTFEE);

                    if (instalmentNumber == 1)
                    {
                        invoice["lux_isfirstinstalmenttransaction"] = true;
                    }

                    var IPTRate = quote.Attributes.Contains("lux_iptrate") ? quote.GetAttributeValue<decimal>("lux_iptrate") : 0M;

                    invoice["lux_iptrate"] = IPTRate;
                    invoice["lux_ipt"] = new Money(totalExcludingIPTFEE * IPTRate / 100);

                    if (Carrier == 972970002)
                    {
                        IPTRate = 5M;
                        invoice["lux_iptrate"] = IPTRate;
                        invoice["lux_ipt"] = new Money(totalExcludingIPTFEE * IPTRate / 100);
                        invoice["lux_duetoargenta"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommAmt / 100 - totalExcludingIPTFEE * brokerCommAmt / 100);
                    }
                    else
                    {
                        invoice["lux_duetoaxa"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 - totalExcludingIPTFEE * pslCommAmt / 100 - totalExcludingIPTFEE * brokerCommAmt / 100);
                    }
                    invoice["lux_totalpremiumincludingiptfee"] = new Money(totalExcludingIPTFEE + totalExcludingIPTFEE * IPTRate / 100 + item.GetAttributeValue<Money>("lux_policyadministrationfee").Value);

                    service.Create(invoice);

                    if (quote.GetAttributeValue<bool>("lux_isterrorismrequired") == true && instalmentNumber == 1)
                    {
                        Entity invoice1 = new Entity("lux_invoice");
                        invoice1["lux_constructionapplication"] = new EntityReference("lux_constructionquotes", quote.Id);
                        invoice1["lux_constructionpolicy"] = new EntityReference("lux_constructionpolicy", policy.Id);
                        invoice1["lux_broker"] = new EntityReference("account", policy.GetAttributeValue<EntityReference>("lux_brokercompany").Id);
                        invoice1["transactioncurrencyid"] = new EntityReference("transactioncurrency", quote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                        invoice1["lux_product"] = new EntityReference("product", quote.GetAttributeValue<EntityReference>("lux_product").Id);
                        invoice1["lux_inceptioneffectivedate"] = quote.GetAttributeValue<DateTime>("lux_inceptiondate");
                        invoice1["lux_insured"] = policy.Attributes["lux_name"].ToString();
                        invoice1["lux_policynumber"] = policy.Attributes["lux_policynumber"].ToString();
                        invoice1["lux_risktransaction"] = new OptionSetValue(972970001);

                        if (policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
                        {
                            invoice1["lux_risktransaction"] = new OptionSetValue(972970002);
                        }
                        invoice1["lux_transactiondate"] = policy.GetAttributeValue<DateTime>("createdon");
                        invoice1["lux_transactiontype"] = new OptionSetValue(972970002);

                        invoice1["lux_aciescommissionrate"] = TerrpslCommAmt.ToString();
                        invoice1["lux_commissionrate"] = TerrbrokerCommAmt.ToString();

                        invoice1["lux_aciescommissionamount"] = new Money(terrtotalExcludingIPTFEE * TerrpslCommAmt / 100);
                        invoice1["lux_commissionamount"] = new Money(terrtotalExcludingIPTFEE * TerrbrokerCommAmt / 100);

                        invoice1["lux_fee"] = new Money(0);
                        invoice1["lux_duedate"] = item.GetAttributeValue<DateTime>("lux_duedate");
                        invoice1["lux_grosspremiumexciptfee"] = new Money(terrtotalExcludingIPTFEE);
                        invoice1["lux_isconstructionterrorismtransaction"] = true;
                        invoice1["lux_iptrate"] = IPTRate;
                        invoice1["lux_ipt"] = new Money(terrtotalExcludingIPTFEE * IPTRate / 100);
                        invoice1["lux_totalpremiumincludingiptfee"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * IPTRate / 100);
                        invoice1["lux_duetoaxa"] = new Money(terrtotalExcludingIPTFEE + terrtotalExcludingIPTFEE * IPTRate / 100 - terrtotalExcludingIPTFEE * TerrpslCommAmt / 100 - terrtotalExcludingIPTFEE * TerrbrokerCommAmt / 100);

                        service.Create(invoice1);
                    }
                }
            }
        }
    }
}