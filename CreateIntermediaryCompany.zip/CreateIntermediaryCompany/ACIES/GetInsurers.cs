﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CreateIntermediaryCompany
{
    public class GetInsurers : CodeActivity
    {
        #region "Parameter Definition"

        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Output("Insurers")]
        public OutArgument<string> Insurers { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference Application = PropertyOwnersApplication.Get<EntityReference>(executionContext);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_postcode' />
                                <attribute name='lux_insuredtitle' />
                                <attribute name='lux_quotenumber' />
                                <attribute name='statuscode' />
                                <attribute name='lux_inceptiondate' />
                                <attribute name='lux_broker' />
                                <attribute name='lux_quotedpremium' />
                                <attribute name='lux_bindertemplate' />
                                <attribute name='lux_producttype' />
                                <attribute name='lux_trade' />
                                <attribute name='lux_applicationtype' />
                                <attribute name='lux_underwriter' />
                                <attribute name='lux_propertyownersapplicationsid' />
                                <attribute name='lux_iselcoverrequired' />
                                <attribute name='lux_ispublicandproductsliabilitycoverrequired' />
                                <attribute name='lux_materialdamagepolicypremium' />
                                <attribute name='lux_goodsintransitpolicypremium' />
                                <attribute name='lux_employersliabilitypolicypremium' />
                                <attribute name='lux_businessinterruptionpolicypremium' />
                                <attribute name='lux_allriskpolicypremium' />
                                <attribute name='lux_publicproductsliabilitypolicypremium' />
                                <attribute name='lux_isterrorismcoverrequired' />
                                <attribute name='lux_insuranceproductrequired' />
                                <order attribute='lux_inceptiondate' descending='true' />
                                <order attribute='lux_quotenumber' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplicationsid' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{Application.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            var count = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count;
            if (count > 0)
            {
                var appln = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault();
                var BinderTemplate = appln.Attributes.Contains("lux_bindertemplate") ? appln.FormattedValues["lux_bindertemplate"] : "HCC + AXIS";
                var ELCover = appln.Attributes.Contains("lux_iselcoverrequired") ? appln.GetAttributeValue<bool>("lux_iselcoverrequired") : false;
                var PLCover = appln.Attributes.Contains("lux_ispublicandproductsliabilitycoverrequired") ? appln.GetAttributeValue<bool>("lux_ispublicandproductsliabilitycoverrequired") : false;
                var Product = appln.Attributes.Contains("lux_insuranceproductrequired") ? appln.FormattedValues["lux_insuranceproductrequired"] : "";
                var TerrorismCover = appln.Attributes.Contains("lux_isterrorismcoverrequired") ? appln.GetAttributeValue<bool>("lux_isterrorismcoverrequired") : false;
                var InceptionDate = appln.GetAttributeValue<DateTime>("lux_inceptiondate");

                var PropertyInsurer = "Not Covered";
                var PropertyOwnersLiabilityInsurer = "Not Covered";
                var EmployersLiabilityInsurer = "Not Covered";
                var PublicProductLiabilityInsurer = "Not Covered";
                var TerrorismInsurer = "Not Covered";
                var LegalExpensesInsurer = "Not Covered";



                if (Product == "Property Owners" || Product == "Unoccupied")
                {
                    if (BinderTemplate == "HCC")
                    {
                        PropertyInsurer = "HCC";
                    }
                    else if (BinderTemplate == "HCC + AXIS")
                    {
                        PropertyInsurer = "HCC, AXIS";
                    }
                    else if (BinderTemplate == "HCC + Amtrust")
                    {
                        PropertyInsurer = "HCC, Amtrust";
                    }
                    else if (BinderTemplate == "HCC + AXIS + Amtrust")
                    {
                        PropertyInsurer = "HCC, AXIS, Amtrust";
                    }

                    PropertyOwnersLiabilityInsurer = "HCC";
                    LegalExpensesInsurer = "ARAG";
                    if (ELCover == true)
                    {
                        if (InceptionDate >= new DateTime(2024, 01, 01))
                        {
                            EmployersLiabilityInsurer = "Faraday";
                        }
                        else
                        {
                            EmployersLiabilityInsurer = "HCC";
                        }
                    }
                }
                else if (Product == "Retail" || Product == "Office" || Product == "Contractors Combined" || Product == "Commercial Combined" || Product == "Hotels and Guesthouses" || Product == "Pubs & Restaurants")
                {
                    if (Product != "Contractors Combined")
                    {
                        if (BinderTemplate == "HCC")
                        {
                            PropertyInsurer = "HCC";
                        }
                        else if (BinderTemplate == "HCC + AXIS")
                        {
                            PropertyInsurer = "HCC, AXIS";
                        }
                        else if (BinderTemplate == "HCC + Amtrust")
                        {
                            PropertyInsurer = "HCC, Amtrust";
                        }
                        else if (BinderTemplate == "HCC + AXIS + Amtrust")
                        {
                            PropertyInsurer = "HCC, AXIS, Amtrust";
                        }
                    }

                    LegalExpensesInsurer = "ARAG";
                    if (ELCover == true)
                    {
                        if (InceptionDate >= new DateTime(2024, 01, 01))
                        {
                            EmployersLiabilityInsurer = "Faraday";
                        }
                        else
                        {
                            EmployersLiabilityInsurer = "HCC";
                        }
                    }
                    if (PLCover == true)
                    {
                        if (InceptionDate >= new DateTime(2024, 01, 01))
                        {
                            PublicProductLiabilityInsurer = "Faraday";
                        }
                        else
                        {
                            PublicProductLiabilityInsurer = "HCC";
                        }
                    }
                }

                if (TerrorismCover == true)
                {
                    TerrorismInsurer = "Lancashire";
                }

                Insurers.Set(executionContext, "Property Section: " + PropertyInsurer + "\n" + "Property owners liability: " + PropertyOwnersLiabilityInsurer + "\n" + "Employers Liability: " + EmployersLiabilityInsurer
                    + "\n" + "Public and Product liability: " + PublicProductLiabilityInsurer + "\n" + "Terrorism: " + TerrorismInsurer + "\n" + "Legal expense: " + LegalExpensesInsurer);


                //var InceptionDate = appln.GetAttributeValue<DateTime>("lux_inceptiondate");
                //if (InceptionDate >= new DateTime(2024, 01, 01))
                //{
                //if (ELPremium > 0 || PLPremium > 0)
                //{
                //BinderTemplate += ", Faraday";
                //}
                //}

                //if (BinderTemplate == "HCC")
                //{
                //    if (Product == "Property Owners" || Product == "Unoccupied")
                //    {
                //        if (ELCover == true)
                //        {
                //            Insurers.Set(executionContext, "Property Section: HCC" + "\n" + "Property owners liability: HCC" + "\n" + "Employers Liability: HCC" + "\n" + "Public and Product liability: Not Covered");
                //        }
                //        else
                //        {
                //            Insurers.Set(executionContext, "Property Section: HCC" + "\n" + "Property owners liability: HCC" + "\n" + "Employers Liability: Not Covered" + "\n" + "Public and Product liability: Not Covered");
                //        }
                //    }
                //    else
                //    {
                //        Insurers.Set(executionContext, "Property Section: HCC" + "\n" + "Property owners liability: HCC" + "\n" + "Employers Liability: HCC" + "\n" + "Public and Product liability: HCC");
                //    }
                //}
                //else if (BinderTemplate == "HCC, Faraday")
                //{
                //    Insurers.Set(executionContext, "Property Section: HCC" + "\n" + "Property owners liability: HCC" + "\n" + "Employers Liability: Faraday" + "\n" + "Public and Product liability: Faraday");
                //}
                //else if (BinderTemplate == "HCC + AXIS")
                //{
                //    Insurers.Set(executionContext, "Property Section: HCC + AXIS" + "\n" + "Property owners liability: HCC" + "\n" + "Employers Liability: HCC" + "\n" + "Public and Product liability: HCC");
                //}
                //else if (BinderTemplate == "HCC + AXIS, Faraday")
                //{
                //    Insurers.Set(executionContext, "Property Section: HCC + AXIS" + "\n" + "Property owners liability: HCC" + "\n" + "Employers Liability: Faraday" + "\n" + "Public and Product liability: Faraday");
                //}
            }
        }
    }
}