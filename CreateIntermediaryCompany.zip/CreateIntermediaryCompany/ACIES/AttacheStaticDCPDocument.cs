﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Metadata.Query;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace CreateIntermediaryCompany
{
    public class AttacheStaticDCPDocument : CodeActivity
    {
        [Input("Main Record URL")]
        [ReferenceTarget("")]
        public InArgument<String> MainRecordURL { get; set; }

        [Input("RecordId")]
        [ReferenceTarget("")]
        public InArgument<String> RecordId { get; set; }

        [Input("Email")]
        [ReferenceTarget("email")]
        public InArgument<EntityReference> Email { get; set; }

        [Input("IsLive")]
        public InArgument<bool> IsLive { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            // Get parameters
            string recordId = RecordId.Get(executionContext);

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                              <entity name='ptm_mscrmaddons_dcptemplates'>
                                <attribute name='ptm_name' />
                                <attribute name='createdon' />
                                <attribute name='ptm_mscrmaddons_dcptemplatesid' />
                                <order attribute='createdon' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statuscode' operator='eq' value='1' />
                                  <condition attribute='ptm_mscrmaddons_dcptemplatesid' operator='eq' value='{recordId}' />
                                </filter>
                              </entity>
                            </fetch>";

            tracingService.Trace(fetch);
            var data = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
            if (data.Count > 0)
            {
                foreach (var doc in data)
                {
                    var notesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='annotation'>
                                            <attribute name='annotationid' />
                                            <attribute name='subject' />
                                            <attribute name='notetext' />
                                            <attribute name='modifiedby' />
                                            <attribute name='createdon' />
                                            <attribute name='filename' />
                                            <attribute name='documentbody' />
                                            <order attribute='createdon' descending='true' />
                                            <link-entity name='ptm_mscrmaddons_dcptemplates' from='ptm_mscrmaddons_dcptemplatesid' to='objectid' link-type='inner' alias='af'>
                                              <filter type='and'>
                                                <condition attribute='ptm_mscrmaddons_dcptemplatesid' operator='eq' uiname='' uitype='ptm_mscrmaddons_dcptemplates' value='{doc.Id}' />
                                              </filter>
                                            </link-entity>
                                          </entity>
                                        </fetch>";

                    var files = service.RetrieveMultiple(new FetchExpression(notesFetch)).Entities;

                    if (files.Count() > 0)
                    {
                        var file = files.FirstOrDefault();
                        if (recordId != "")
                        {
                            if (Email.Get(executionContext) != null && Email.Get(executionContext).Id != null)
                            {
                                EntityReference email = Email.Get(executionContext);

                                Entity _Attachment = new Entity("activitymimeattachment");
                                _Attachment["objectid"] = new EntityReference("email", email.Id);
                                _Attachment["objecttypecode"] = "email";

                                if (file.Attributes.Contains("subject"))
                                {
                                    _Attachment["subject"] = file.Attributes["subject"].ToString();
                                }
                                if (file.Attributes.Contains("filename"))
                                {
                                    _Attachment["filename"] = file.Attributes["filename"].ToString();
                                }
                                if (file.Attributes.Contains("documentbody"))
                                {
                                    _Attachment["body"] = file.Attributes["documentbody"].ToString();
                                }
                                else if (file.Attributes.Contains("body"))
                                {
                                    _Attachment["body"] = file.Attributes["body"].ToString();
                                }
                                if (file.Attributes.Contains("mimetype"))
                                {
                                    _Attachment["mimetype"] = file.Attributes["mimetype"].ToString();
                                }
                                service.Create(_Attachment);
                            }

                            string mainRecordURL = MainRecordURL.Get(executionContext);


                            // Extract values from URL
                            string[] urlParts = mainRecordURL.Split("?".ToArray());
                            string[] urlParams = urlParts[1].Split("&".ToCharArray());
                            string ObjectTypeCode = urlParams[0].Replace("etc=", "");
                            string EntityName = sGetEntityNameFromCode(ObjectTypeCode, service);
                            string Id = urlParams[1].Replace("id=", "");

                            var client = new HttpClient();
                            client.DefaultRequestHeaders.Accept.Clear();
                            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                            client.BaseAddress = new Uri("https://prod-50.uksouth.logic.azure.com:443/workflows/1185592023794a67b9a71f30dba693cd/triggers/manual/paths/invoke?api-version=2016-06-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=Ov3tpZKncK5-8VJVc72Ou5kxTLRcywrx2_ygnPde6WM");
                            var apiRequest = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress) { Content = new StringContent("{\r\n  \"ApplicationId\": \"" + Id.ToString() + "\", \r\n  \"FileName\": \"" + file.Attributes["filename"].ToString() + "\", \r\n  \"FileContent\": \"" + file.Attributes["documentbody"].ToString() + "\", \r\n  \"EntityName\": \"" + EntityName + "\"}", System.Text.Encoding.UTF8, "application/json") };

                            if (IsLive.Get(executionContext) == true)
                            {
                                client.BaseAddress = new Uri("https://bc67079b6f3e4321944af366558303.53.environment.api.powerplatform.com:443/powerautomate/automations/direct/workflows/e42b320dfa54473390cf48f56c325366/triggers/manual/paths/invoke?api-version=1&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=jjYSw686pN8s0s9_ur17OH5kbGxrW2tXPcYCHp51Tw0");
                                apiRequest = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress) { Content = new StringContent("{\r\n  \"ApplicationId\": \"" + Id.ToString() + "\", \r\n  \"FileName\": \"" + file.Attributes["filename"].ToString() + "\", \r\n  \"FileContent\": \"" + file.Attributes["documentbody"].ToString() + "\", \r\n  \"EntityName\": \"" + EntityName + "\"}", System.Text.Encoding.UTF8, "application/json") };
                            }
                            var apiResponseString = ProcessWebResponse(client, apiRequest, tracingService);
                            var apiResponse = apiResponseString.Result;

                            tracingService.Trace(apiResponse);
                        }
                    }
                }
            }
        }

        public static async Task<string> ProcessWebResponse(HttpClient client, HttpRequestMessage apiRequest, ITracingService tracingService)
        {
            var reponseContentString = "";
            try
            {
                HttpResponseMessage apiResponse = await client.SendAsync(apiRequest);
                reponseContentString = await apiResponse.Content.ReadAsStringAsync();
            }
            catch (HttpRequestException ex)
            {
                tracingService.Trace(ex.Message + Environment.NewLine + ex.StackTrace);
            }
            tracingService.Trace(reponseContentString);
            return reponseContentString;
        }

        public string sGetEntityNameFromCode(string ObjectTypeCode, IOrganizationService service)
        {
            MetadataFilterExpression entityFilter = new MetadataFilterExpression(LogicalOperator.And);
            entityFilter.Conditions.Add(new MetadataConditionExpression("ObjectTypeCode", MetadataConditionOperator.Equals, Convert.ToInt32(ObjectTypeCode)));
            EntityQueryExpression entityQueryExpression = new EntityQueryExpression()
            {
                Criteria = entityFilter
            };
            RetrieveMetadataChangesRequest retrieveMetadataChangesRequest = new RetrieveMetadataChangesRequest()
            {
                Query = entityQueryExpression,
                ClientVersionStamp = null
            };
            RetrieveMetadataChangesResponse response = (RetrieveMetadataChangesResponse)service.Execute(retrieveMetadataChangesRequest);

            EntityMetadata entityMetadata = (EntityMetadata)response.EntityMetadata[0];
            return entityMetadata.SchemaName.ToLower();
        }
    }
}