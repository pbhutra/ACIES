﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CreateIntermediaryCompany
{
    public class SetRateLine : CodeActivity
    {
        //[RequiredArgument]
        //[Input("Excess Amount")]
        //[AttributeTarget("lux_cycleapplications", "lux_excessamount")]
        //public InArgument<OptionSetValue> ExcessAmount { get; set; }

        //[RequiredArgument]
        //[Input("CycleSumInsured")]
        //[AttributeTarget("lux_cycleapplications", "lux_bicyclevalue")]
        //public InArgument<OptionSetValue> CycleSumInsured { get; set; }

        [RequiredArgument]
        [Input("BicycleExactValue")]
        //[AttributeTarget("lux_rates", "lux_paymentfrequency")]
        public InArgument<decimal> BicycleExactValue { get; set; }
        

        [RequiredArgument]
        [Input("PaymentFrequency")]
        //[AttributeTarget("lux_rates", "lux_paymentfrequency")]
        public InArgument<bool> PaymentFrequency { get; set; }

        [RequiredArgument]
        [Input("Requirement")]
        //[AttributeTarget("lux_rates", "lux_requirement")]
        public InArgument<bool> Requirement { get; set; }

        [Output("Rate")]
        [ReferenceTarget("lux_rates")]
        public OutArgument<EntityReference> Rate { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var exactValue = Convert.ToInt32(this.BicycleExactValue.Get(executionContext));

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                      <entity name='lux_rates'>
                        <attribute name='lux_ratesid' />
                        <attribute name='lux_name' />
                        <attribute name='createdon' />
                        <order attribute='lux_name' descending='false' />
                        <filter type='and'>
                          <condition attribute='lux_cyclesuminsuredcurrency' operator='eq' value='{exactValue}' />'
                          <condition attribute='lux_paymentfrequency' operator='eq' value='1' />
                          <condition attribute='lux_requirement' operator='eq' value='{this.Requirement.Get(executionContext)}' />
                          <condition attribute='statecode' operator='eq' value='0' />
                        </filter>
                      </entity>
                    </fetch>";

            tracingService.Trace(fetch);

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var Rates = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                Rate.Set(executionContext, Rates.ToEntityReference());
            }

        }
    }
}