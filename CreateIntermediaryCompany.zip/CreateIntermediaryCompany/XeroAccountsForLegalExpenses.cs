﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Web;

namespace CreateIntermediaryCompany
{
    public class XeroAccountsForLegalExpenses : CodeActivity
    {
        [RequiredArgument]
        [Input("Contact")]
        [ReferenceTarget("contact")]
        public InArgument<EntityReference> Contact { get; set; }

        [RequiredArgument]
        [Input("Policy")]
        [ReferenceTarget("lux_policy")]
        public InArgument<EntityReference> Policy { get; set; }

        [RequiredArgument]
        [Input("LEPolicy")]
        [ReferenceTarget("lux_policy")]
        public InArgument<EntityReference> LEPolicy { get; set; }

        [RequiredArgument]
        [Input("Application")]
        [ReferenceTarget("lux_cycleapplications")]
        public InArgument<EntityReference> Application { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            string contactName = string.Empty;
            string firstName = string.Empty;
            string lastName = string.Empty;
            string emailAddress = string.Empty;
            string addressLine1 = string.Empty;
            string addressLine2 = string.Empty;
            string city = string.Empty;
            string postalCode = string.Empty;
            string phoneNumber = string.Empty;

            EntityReference contactref = Contact.Get(executionContext);
            Entity contact = service.Retrieve("contact", contactref.Id, new ColumnSet(true));

            if (contact.Attributes.Contains("fullname"))
            {
                contactName = contact.Attributes["fullname"].ToString();
            }

            if (contact.Attributes.Contains("firstname"))
            {
                firstName = contact.Attributes["firstname"].ToString();
            }

            if (contact.Attributes.Contains("lastname"))
            {
                lastName = contact.Attributes["lastname"].ToString();
            }

            if (contact.Attributes.Contains("emailaddress1"))
            {
                emailAddress = contact.Attributes["emailaddress1"].ToString();
            }

            if (contact.Attributes.Contains("address1_line1"))
            {
                addressLine1 = contact.Attributes["address1_line1"].ToString();
            }

            if (contact.Attributes.Contains("address1_line2"))
            {
                addressLine2 = contact.Attributes["address1_line2"].ToString();
            }

            if (contact.Attributes.Contains("address1_city"))
            {
                city = contact.Attributes["address1_city"].ToString();
            }

            if (contact.Attributes.Contains("address1_postalcode"))
            {
                postalCode = contact.Attributes["address1_postalcode"].ToString();
            }

            if (contact.Attributes.Contains("mobilephone"))
            {
                phoneNumber = contact.Attributes["mobilephone"].ToString();
            }

            string contactXML = $@"<Contact><Name>{contactName}</Name><FirstName>{firstName}</FirstName><LastName>{lastName}</LastName><EmailAddress>{emailAddress}</EmailAddress><AddressLine1>{addressLine1}</AddressLine1><AddressLine2>{addressLine2}</AddressLine2><City>{city}</City><PostalCode>{postalCode}</PostalCode><PhoneNumber>{phoneNumber}</PhoneNumber></Contact>";

            tracingService.Trace(contactXML);

            //string totalPremiumPayble = string.Empty;
            decimal totalPremiumPayble = 0;

            string veloLifeCommissionAmount = string.Empty;
            string adminFee = string.Empty;
            string payableToMBandG = string.Empty;
            //string paybleToARAG = string.Empty;
            string policyNumber = string.Empty;
            string policyType = string.Empty;
            string paybleARAG = string.Empty;


            // Account Codes
            string accountCode1 = "870";
            string accountCode2 = "BIKES";
            string accountCode3 = "ADMIN FEE";
            string accountCode4 = "ARAG";

            tracingService.Trace(Policy.Get(executionContext).Id.ToString());
            tracingService.Trace(LEPolicy.Get(executionContext).Id.ToString());

            EntityReference policyref = Policy.Get(executionContext);
            Entity policy = service.Retrieve("lux_policy", policyref.Id, new ColumnSet(true));

            EntityReference lepolicyref = LEPolicy.Get(executionContext);
            Entity lepolicy = service.Retrieve("lux_policy", lepolicyref.Id, new ColumnSet(true));

            if (lepolicy.Attributes.Contains("lux_payabletoarag"))
            {
                decimal premiumPayable = lepolicy.GetAttributeValue<Money>("lux_premiumpayable").Value;
                paybleARAG = (premiumPayable - lepolicy.GetAttributeValue<Money>("lux_payabletoarag").Value).ToString();
            }

            EntityReference applicationref = Application.Get(executionContext);
            Entity application = service.Retrieve("lux_cycleapplications", applicationref.Id, new ColumnSet(true));

            if (application.Attributes.Contains("lux_premiumpayable"))
            {
                if (application.GetAttributeValue<bool>("lux_paymentfrequency") == true)//annually
                {
                    totalPremiumPayble = application.GetAttributeValue<Money>("lux_premiumpayable").Value;
                }
                else//monthly
                {
                    totalPremiumPayble = application.GetAttributeValue<Money>("lux_annualvalue").Value;
                }
            }

            if (policy.Attributes.Contains("lux_brokercommission"))
            {
                veloLifeCommissionAmount = policy.GetAttributeValue<Money>("lux_brokercommission").Value.ToString();
            }

            if (application.Attributes.Contains("lux_adminfee"))
            {
                adminFee = application.GetAttributeValue<Money>("lux_adminfee").Value.ToString();
            }

            if (policy.Attributes.Contains("lux_policynumber"))
            {
                policyNumber = policy["lux_policynumber"].ToString();
            }


            tracingService.Trace("totalPremiumPayble " + totalPremiumPayble);
            string invoiceXML = $@"<Invoice><LineItems>
            <LineItem1><Description1>Customer Invoice</Description1><Quantity1>1</Quantity1><UnitAmount1>{totalPremiumPayble}</UnitAmount1><AccountCode1>{accountCode1}</AccountCode1></LineItem1>
            <LineItem2><Description2>VeloLife -  Bike Insurance Commission</Description2><Quantity2>1</Quantity2><UnitAmount2>{veloLifeCommissionAmount}</UnitAmount2><AccountCode2>{accountCode2}</AccountCode2></LineItem2>
            <LineItem3><Description3>VeloLife -  Policy Admin Fee</Description3><Quantity3>1</Quantity3><UnitAmount3>{adminFee}</UnitAmount3><AccountCode3>{accountCode3}</AccountCode3></LineItem3>
            <LineItem4><Description4>VeloLife - ARAG Commission</Description4><Quantity4>1</Quantity4><UnitAmount4>{paybleARAG}</UnitAmount4><AccountCode4>{accountCode4}</AccountCode4></LineItem4>
            <PolicyNumber>{policyNumber}</PolicyNumber>
            </LineItems>            
            </Invoice>";

            var dictForXeroAccount = new Dictionary<string, string>();
            dictForXeroAccount.Add("contactXML", contactXML);
            dictForXeroAccount.Add("invoiceXML", invoiceXML);
            dictForXeroAccount.Add("policyType", policyType);

            tracingService.Trace(contactXML);
            tracingService.Trace(invoiceXML);

            var client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.BaseAddress = new Uri("https://msdynamicswebapi.azurewebsites.net/api/VeloXeroApi/CreateContactInvoice");

            var xeroRequest = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress) { Content = new FormUrlEncodedContent(dictForXeroAccount) };
            var xeroResponseString = ProcessWebResponse(client, xeroRequest, tracingService);
            var xeroResponse = xeroResponseString.Result;

            tracingService.Trace("Response: " + xeroResponse);
        }

        public static async Task<string> ProcessWebResponse(HttpClient client, HttpRequestMessage request, ITracingService tracingService)
        {
            var reponseContentString = "";
            try
            {
                HttpResponseMessage refundResponse = await client.SendAsync(request);
                reponseContentString = await refundResponse.Content.ReadAsStringAsync();
            }
            catch (HttpRequestException ex)
            {
                tracingService.Trace(ex.Message + Environment.NewLine + ex.StackTrace);
            }
            tracingService.Trace(reponseContentString);
            return reponseContentString;
        }

    }
}