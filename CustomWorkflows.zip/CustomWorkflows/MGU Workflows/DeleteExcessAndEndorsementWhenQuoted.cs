﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CustomWorkflows
{
    public class DeleteExcessAndEndorsementWhenQuoted : CodeActivity
    {
        [Input("Application")]
        [ReferenceTarget("lux_application")]
        [RequiredArgument]
        public InArgument<EntityReference> Application { get; set; }

        [Input("Binder")]
        [ReferenceTarget("lux_binder")]
        [RequiredArgument]
        public InArgument<EntityReference> Binder { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);
            var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_applicationendorsements'>
                                <attribute name='lux_applicationendorsementsid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_binder' operator='not-null' />
                                  <condition attribute='lux_application' operator='eq' uiname='MG/3/065' uitype='lux_application' value='{Application.Get(executionContext).Id}' />
                                  <condition attribute='lux_binder' operator='ne' uiname='' uitype='lux_binder' value='{Binder.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            var binderLst = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities;
            if (binderLst.Count > 0)
            {
                foreach (var item in binderLst)
                {
                    service.Delete("lux_applicationendorsements", item.Id);
                }
            }

            var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_applicationexcess'>
                                <attribute name='lux_applicationexcessid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_binder' operator='not-null' />
                                  <condition attribute='lux_application' operator='eq' uiname='MG/3/068' uitype='lux_application' value='{Application.Get(executionContext).Id}' />
                                  <condition attribute='lux_binder' operator='ne' uiname='' uitype='lux_binder' value='{Binder.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            var binderLst1 = service.RetrieveMultiple(new FetchExpression(fetch2)).Entities;
            if (binderLst1.Count > 0)
            {
                foreach (var item in binderLst1)
                {
                    service.Delete("lux_applicationexcess", item.Id);
                }
            }
        }
    }
}