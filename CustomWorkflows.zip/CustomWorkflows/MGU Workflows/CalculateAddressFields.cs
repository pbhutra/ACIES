﻿using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CustomWorkflows
{
    public class CalculateAddressFields : CodeActivity
    {
        [Input("Street")]
        public InArgument<string> Street { get; set; }

        [Input("City")]
        public InArgument<string> City { get; set; }

        [Output("Street1")]
        public OutArgument<string> Street1 { get; set; }

        [Output("Street2")]
        public OutArgument<string> Street2 { get; set; }

        [Output("Street3")]
        public OutArgument<string> Street3 { get; set; }

        [Output("County")]
        public OutArgument<string> County { get; set; }

        [Output("State")]
        public OutArgument<string> State { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            if (context == null)
                throw new ArgumentNullException(nameof(context));

            string street = this.Street.Get(context);
            string city = this.City.Get(context);

            string street1 = "";
            string street2 = "";
            string street3 = "";
            string county = "";
            string state = "";

            if (!string.IsNullOrEmpty(street) && !string.IsNullOrEmpty(city))
            {
                string[] streets = street.Split(',');
                string[] cities = city.Split(',');

                if (streets.Length >= 1)
                {
                    street1 = streets[0].Trim();
                }
                if (streets.Length >= 2)
                {
                    street2 = streets[1].Trim();
                }
                if (streets.Length >= 3)
                {
                    street3 = streets[2].Trim();
                }
                if (cities.Length >= 1)
                {
                    county = cities[0].Trim();
                }
                if (cities.Length >= 2)
                {
                    state = cities[1].Trim();
                }
            }
            this.Street1.Set(context, street1);
            this.Street2.Set(context, street2);
            this.Street3.Set(context, street3);
            this.County.Set(context, county);
            this.State.Set(context, state);
        }
    }
}
