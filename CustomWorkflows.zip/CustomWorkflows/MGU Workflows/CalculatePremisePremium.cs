﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class GetProductAddon : CodeActivity
    {
        [RequiredArgument]
        [Input("Product")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> Product { get; set; }

        [RequiredArgument]
        [Input("AddonName")]
        public InArgument<string> AddonName { get; set; }

        [Output("ProductAddon")]
        [ReferenceTarget("lux_productaddon")]
        public OutArgument<EntityReference> ProductAddon { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                              <entity name='lux_productaddon'>
                                <attribute name='lux_productaddonid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_name' operator='eq' value='{this.AddonName.Get(executionContext)}' />
                                </filter>
                                <link-entity name='product' from='lux_productaddonid' to='lux_productaddonid' link-type='inner' alias='ac'>
                                      <filter type='and'>
                                        <condition attribute='productid' operator='eq' uiname='Liability Only' uitype='product' value='{this.Product.Get(executionContext).Id}' />
                                      </filter>
                                    </link-entity>
                                  </entity>
                                </fetch>";

            tracingService.Trace(this.AddonName.Get(executionContext).ToString());

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var Rates = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                ProductAddon.Set(executionContext, Rates.ToEntityReference());
            }
        }
    }
}
