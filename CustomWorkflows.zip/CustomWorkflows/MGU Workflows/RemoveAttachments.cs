﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using msdyncrmWorkflowTools;
using System;
using System.Activities;
using System.Linq;

namespace CustomWorkflows
{
    public class RemoveAttachments : CodeActivity
    {
        [Input("Main Record URL")]
        [ReferenceTarget("")]
        public InArgument<String> MainRecordURL { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            #region "Load CRM Service from context"

            Common objCommon = new Common(executionContext);
            objCommon.tracingService.Trace("Load CRM Service from context --- OK");

            #endregion

            // Get parameters
            string mainRecordURL = MainRecordURL.Get(executionContext);

            string[] urlParts = mainRecordURL.Split("?".ToArray());
            string[] urlParams = urlParts[1].Split("&".ToCharArray());
            string ParentObjectTypeCode = urlParams[0].Replace("etc=", "");
            string ParentId = urlParams[1].Replace("id=", "");

            var notesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='annotation'>
                                    <attribute name='subject' />
                                    <attribute name='notetext' />
                                    <attribute name='filename' />
                                    <attribute name='annotationid' />
                                    <order attribute='subject' descending='false' />
                                    <link-entity name='lux_application' from='lux_applicationid' to='objectid' link-type='inner' alias='ab'>
                                      <filter type='and'>
                                        <condition attribute='lux_applicationid' operator='eq' uitype='lux_application' value='{ParentId}' />
                                      </filter>
                                    </link-entity>
                                  </entity>
                                </fetch>";

            var file = service.RetrieveMultiple(new FetchExpression(notesFetch)).Entities;
            if (file.Count() > 0)
            {
                foreach (var item in file)
                {
                    service.Delete("annotation", item.Id);
                }
            }
        }
    }
}