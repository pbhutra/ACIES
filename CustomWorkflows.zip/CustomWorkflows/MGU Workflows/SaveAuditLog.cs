﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Net;
using System.ServiceModel.Description;
using System.Linq;

namespace CustomWorkflows
{
    public class SaveAuditLog : CodeActivity
    {
        [Input("Record Dynamic Url")]
        [RequiredArgument]
        public InArgument<string> RecordUrl { get; set; }

        [Input("Portal User")]
        [ReferenceTarget("lux_portalusers")]
        public InArgument<EntityReference> PortalUser { get; set; }

        [Input("Updated Date")]
        [RequiredArgument]
        public InArgument<DateTime> UpdatedDate { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference portalref = PortalUser.Get<EntityReference>(executionContext);
            Entity puser = new Entity(portalref.LogicalName, portalref.Id);
            puser = service.Retrieve("lux_portalusers", portalref.Id, new ColumnSet(true));

            var entityReference = new DynamicUrlParser(RecordUrl.Get<string>(executionContext));
            Guid RecordGuid = entityReference.Id;
            var EntityLogicalName = entityReference.GetEntityLogicalName(service);

            try
            {
                RetrieveRecordChangeHistoryRequest changeRequest = new RetrieveRecordChangeHistoryRequest();
                changeRequest.Target = new EntityReference(EntityLogicalName, RecordGuid);
                RetrieveRecordChangeHistoryResponse changeResponse =
                (RetrieveRecordChangeHistoryResponse)service.Execute(changeRequest);

                AuditDetailCollection auditDetailCollection = changeResponse.AuditDetailCollection;

                foreach (AuditDetail attrAuditDetail in auditDetailCollection.AuditDetails.Where(x => (Convert.ToDateTime(x.AuditRecord.Attributes["createdon"]) - UpdatedDate.Get<DateTime>(executionContext)).Seconds <= 60 && (Convert.ToDateTime(x.AuditRecord.Attributes["createdon"]) - UpdatedDate.Get<DateTime>(executionContext)).Seconds >= -60 && x.AuditRecord.FormattedValues["action"] == "Update"))
                //foreach (AuditDetail attrAuditDetail in auditDetailCollection.AuditDetails.Where(x => x.AuditRecord.FormattedValues["action"] == "Update"))
                {
                    var auditRecord = attrAuditDetail.AuditRecord;
                    //var timedifference = (Convert.ToDateTime(auditRecord.Attributes["createdon"]) - UpdatedDate.Get<DateTime>(executionContext)).Seconds;
                    var detailType = attrAuditDetail.GetType();
                    if (detailType == typeof(AttributeAuditDetail))
                    {
                        AttributeAuditDetail attributeDetail = (AttributeAuditDetail)attrAuditDetail;
                        foreach (KeyValuePair<String, object> attribute in attributeDetail.NewValue.Attributes)
                        {
                            if (!attribute.Key.Contains("_base"))
                            {
                                Entity audit = new Entity("lux_audit");
                                audit["lux_recordguid"] = RecordGuid.ToString();
                                audit["lux_changedby"] = puser["lux_name"];
                                if (EntityLogicalName == "lux_application")
                                {
                                    audit["lux_application"] = new EntityReference(EntityLogicalName, RecordGuid);
                                }
                                else if (EntityLogicalName == "lux_policy")
                                {
                                    audit["lux_policy"] = new EntityReference(EntityLogicalName, RecordGuid);
                                }
                                if (attributeDetail.OldValue.Attributes.Count > 0)
                                {
                                    if (attributeDetail.OldValue.Contains(attribute.Key))
                                    {
                                        audit["lux_changedfieldmachinename"] = attribute.Key;
                                        audit["lux_changedfield"] = RetrieveAttributeDisplayName(EntityLogicalName, attribute.Key, service);
                                        var attType = attributeDetail.OldValue[attribute.Key].GetType();
                                        if (attType == typeof(OptionSetValue) || attType == typeof(EntityReference) || attType == typeof(Boolean))
                                            audit["lux_oldvalue"] = attributeDetail.OldValue.FormattedValues[attribute.Key].ToString();
                                        else if (attType == typeof(Money))
                                            audit["lux_oldvalue"] = ((Money)attributeDetail.OldValue.Attributes[attribute.Key]).Value.ToString();
                                        else
                                            audit["lux_oldvalue"] = attributeDetail.OldValue[attribute.Key].ToString();
                                    }
                                }
                                else
                                {
                                    audit["lux_oldvalue"] = "";
                                }
                                if (attributeDetail.NewValue.Attributes.Count > 0)
                                {
                                    if (attributeDetail.NewValue.Contains(attribute.Key))
                                    {
                                        audit["lux_changedfieldmachinename"] = attribute.Key;
                                        audit["lux_changedfield"] = RetrieveAttributeDisplayName(EntityLogicalName, attribute.Key, service);
                                        var attType = attributeDetail.NewValue[attribute.Key].GetType();
                                        if (attType == typeof(OptionSetValue) || attType == typeof(EntityReference) || attType == typeof(Boolean))
                                            audit["lux_newvalue"] = attributeDetail.NewValue.FormattedValues[attribute.Key].ToString();
                                        else if (attType == typeof(Money))
                                            audit["lux_newvalue"] = ((Money)attributeDetail.NewValue.Attributes[attribute.Key]).Value.ToString();
                                        else
                                            audit["lux_newvalue"] = attributeDetail.NewValue[attribute.Key].ToString();
                                    }
                                }
                                else
                                {
                                    audit["lux_newvalue"] = "";
                                }
                                if (auditRecord.Attributes.Contains("createdon"))
                                {
                                    audit["lux_changeddate"] = Convert.ToDateTime(auditRecord.Attributes["createdon"]);
                                }
                                audit["lux_action"] = auditRecord.FormattedValues["action"];
                                if (audit["lux_oldvalue"].ToString() != audit["lux_newvalue"].ToString())
                                {
                                    var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_audit'>
                                                            <attribute name='lux_auditid' />
                                                            <attribute name='lux_oldvalue' />
                                                            <attribute name='lux_newvalue' />
                                                            <attribute name='lux_changedfield' />
                                                            <attribute name='lux_changeddate' />
                                                            <attribute name='lux_changedby' />
                                                            <attribute name='lux_action' />
                                                            <attribute name='lux_changedfieldmachinename' />
                                                            <order attribute='lux_action' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='lux_changedfieldmachinename' operator='eq' value='{attribute.Key.ToString()}' />
                                                              <condition attribute='lux_oldvalue' operator='eq' value='{audit["lux_oldvalue"].ToString().Replace("'", "&apos;")}' />
                                                              <condition attribute='lux_newvalue' operator='eq' value='{audit["lux_newvalue"].ToString().Replace("'", "&apos;")}' />
                                                              <condition attribute='lux_changedby' operator='eq' value='{audit["lux_changedby"].ToString().Replace("'", "&apos;")}' />
                                                              <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_application' value='{RecordGuid}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";
                                    tracingService.Trace(fetch1);
                                    //tracingService.Trace(audit["lux_oldvalue"].ToString());
                                    //tracingService.Trace(audit["lux_newvalue"].ToString());
                                    //tracingService.Trace(audit["lux_changedby"].ToString());
                                    var count = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count().ToString();
                                    tracingService.Trace(count);
                                    if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count() == 0)
                                    {
                                        service.Create(audit);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }

        public static string RetrieveAttributeDisplayName(string EntitySchemaName, string AttributeSchemaName, IOrganizationService service)
        {
            RetrieveAttributeRequest retrieveAttributeRequest = new RetrieveAttributeRequest
            {
                EntityLogicalName = EntitySchemaName,
                LogicalName = AttributeSchemaName,
                RetrieveAsIfPublished = true
            };
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            AttributeMetadata retrievedAttributeMetadata = (AttributeMetadata)retrieveAttributeResponse.AttributeMetadata;
            return retrievedAttributeMetadata.DisplayName.UserLocalizedLabel.Label;
        }

        public static void ssss()
        {
            ClientCredentials clientCredentials = new ClientCredentials();
            clientCredentials.UserName.UserName = "support@mgucrm.onmicrosoft.com"; //HttpContext.Current.Request.Form["UserName"];
            clientCredentials.UserName.Password = "nPmv88~4"; //HttpContext.Current.Request.Form["Password"];

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            // Copy and Paste Organization Service Endpoint Address URL
            var service = (IOrganizationService)new OrganizationServiceProxy(new Uri("https://mgunderwriting.api.crm11.dynamics.com/XRMServices/2011/Organization.svc"),
             null, clientCredentials, null);

            var portaguid = new Guid("AB61D9F6-F540-EA11-A812-000D3A0BA99A");

            //EntityReference portalref = PortalUser.Get<EntityReference>(executionContext);
            Entity puser = new Entity("lux_portalusers", portaguid);
            puser = service.Retrieve("lux_portalusers", portaguid, new ColumnSet(true));

            //var entityReference = new DynamicUrlParser(RecordUrl.Get<string>(executionContext));
            Guid RecordGuid = new Guid("258697CD-615C-EA11-A811-000D3A0BA99A");
            var EntityLogicalName = "lux_application";

            try
            {
                RetrieveRecordChangeHistoryRequest changeRequest = new RetrieveRecordChangeHistoryRequest();
                changeRequest.Target = new EntityReference(EntityLogicalName, RecordGuid);
                RetrieveRecordChangeHistoryResponse changeResponse =
                (RetrieveRecordChangeHistoryResponse)service.Execute(changeRequest);

                AuditDetailCollection auditDetailCollection = changeResponse.AuditDetailCollection;

                //string fetchquery = @"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                //                          <entity name='lux_audit'>
                //                            <attribute name='lux_auditid' />
                //                            <attribute name='lux_recordguid' />
                //                            <attribute name='lux_oldvalue' />
                //                            <attribute name='lux_newvalue' />
                //                            <attribute name='lux_changedfield' />
                //                            <attribute name='lux_changeddate' />
                //                            <attribute name='lux_action' />
                //                            <order attribute='lux_action' descending='false' />
                //                            <filter type='and'>
                //                              <condition attribute='lux_recordguid' operator='eq' value='##ID##' />
                //                            </filter>
                //                          </entity>
                //                        </fetch>";

                //fetchquery = fetchquery.Replace("##ID##", RecordGuid + "");
                //EntityCollection results = service.RetrieveMultiple(new FetchExpression(fetchquery));

                //foreach (Entity e in results.Entities)
                //{
                //    service.Delete(e.LogicalName, e.Id);
                //}

                var UpdatedDate = Convert.ToDateTime("20/04/2020 08:59:45");

                foreach (AuditDetail attrAuditDetail in auditDetailCollection.AuditDetails)
                {
                    var auditRecord = attrAuditDetail.AuditRecord;
                    if (auditRecord.FormattedValues["action"] == "Update" && Convert.ToDateTime(auditRecord.Attributes["createdon"]) == UpdatedDate)
                    {
                        var detailType = attrAuditDetail.GetType();
                        if (detailType == typeof(AttributeAuditDetail))
                        {
                            AttributeAuditDetail attributeDetail = (AttributeAuditDetail)attrAuditDetail;
                            foreach (KeyValuePair<String, object> attribute in attributeDetail.NewValue.Attributes)
                            {
                                if (attributeDetail.NewValue[attribute.Key].GetType() != typeof(EntityReference) && !attribute.Key.Contains("_base") && !attribute.Key.Contains("lux_numberofindividualcompanycustomerrecords") && !attribute.Key.Contains("lux_originalquotenumber") && !attribute.Key.Contains("lux_quotenumber"))
                                {
                                    Entity audit = new Entity("lux_audit");
                                    audit["lux_recordguid"] = RecordGuid.ToString();
                                    audit["lux_changedby"] = puser["lux_name"];

                                    if (attributeDetail.OldValue.Attributes.Count > 0)
                                    {
                                        if (attributeDetail.OldValue.Contains(attribute.Key))
                                        {
                                            audit["lux_changedfield"] = RetrieveAttributeDisplayName(EntityLogicalName, attribute.Key, service);
                                            var attType = attributeDetail.OldValue[attribute.Key].GetType();
                                            if (attType == typeof(OptionSetValue) || attType == typeof(EntityReference) || attType == typeof(Boolean))
                                                audit["lux_oldvalue"] = attributeDetail.OldValue.FormattedValues[attribute.Key].ToString();
                                            else if (attType == typeof(Money))
                                                audit["lux_oldvalue"] = ((Money)attributeDetail.OldValue.Attributes[attribute.Key]).Value.ToString();
                                            else
                                                audit["lux_oldvalue"] = attributeDetail.OldValue[attribute.Key].ToString();
                                        }
                                    }
                                    else
                                    {
                                        audit["lux_oldvalue"] = "";
                                    }
                                    if (attributeDetail.NewValue.Attributes.Count > 0)
                                    {
                                        if (attributeDetail.NewValue.Contains(attribute.Key))
                                        {
                                            audit["lux_changedfield"] = RetrieveAttributeDisplayName(EntityLogicalName, attribute.Key, service);
                                            var attType = attributeDetail.NewValue[attribute.Key].GetType();
                                            if (attType == typeof(OptionSetValue) || attType == typeof(EntityReference) || attType == typeof(Boolean))
                                                audit["lux_newvalue"] = attributeDetail.NewValue.FormattedValues[attribute.Key].ToString();
                                            else if (attType == typeof(Money))
                                                audit["lux_newvalue"] = ((Money)attributeDetail.NewValue.Attributes[attribute.Key]).Value.ToString();
                                            else
                                                audit["lux_newvalue"] = attributeDetail.NewValue[attribute.Key].ToString();
                                        }
                                    }
                                    else
                                    {
                                        audit["lux_newvalue"] = "";
                                    }
                                    if (auditRecord.Attributes.Contains("createdon"))
                                    {
                                        audit["lux_changeddate"] = Convert.ToDateTime(auditRecord.Attributes["createdon"]);
                                    }
                                    audit["lux_action"] = auditRecord.FormattedValues["action"];
                                    service.Create(audit);
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
    }
}
