﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CheckIfContactExist : CodeActivity
    {
        [RequiredArgument]
        [Input("CustomerName")]
        public InArgument<string> CustomerName { get; set; }

        [Input("Email")]
        public InArgument<string> Email { get; set; }

        [Output("IsExist")]
        public OutArgument<bool> IsExist { get; set; }

        [Output("Contact")]
        [ReferenceTarget("contact")]
        public OutArgument<EntityReference> Contact { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='contact'>
                                <attribute name='fullname' />
                                <attribute name='new_fullname' />
                                <attribute name='parentcustomerid' />
                                <attribute name='telephone1' />
                                <attribute name='emailaddress1' />
                                <attribute name='contactid' />
                                <order attribute='fullname' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_contacttype' operator='eq' value='972970002' />
                                  <condition attribute='new_fullname' operator='eq' value='{CustomerName.Get(executionContext).Replace("&", "&amp;").Replace("'", "&apos;").Replace("\"", "&quot;")}' />";
            if (!string.IsNullOrEmpty(Email.Get(executionContext)))
            {
                fetch += $@"<condition attribute='emailaddress1' operator='eq' value='{Email.Get(executionContext).Replace("&", "&amp;").Replace("'", "&apos;").Replace("\"", "&quot;")}' />";
            }
            fetch += $@"</filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                this.IsExist.Set(executionContext, true);
                var contact = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                Contact.Set(executionContext, contact.ToEntityReference());
            }
            else
            {
                this.IsExist.Set(executionContext, false);
            }
        }

        public static void ssss()
        {
            ClientCredentials clientCredentials = new ClientCredentials();
            clientCredentials.UserName.UserName = "support@mgucrm.onmicrosoft.com"; //HttpContext.Current.Request.Form["UserName"];
            clientCredentials.UserName.Password = "nPmv88~4"; //HttpContext.Current.Request.Form["Password"];

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            // Copy and Paste Organization Service Endpoint Address URL
            var service = (IOrganizationService)new OrganizationServiceProxy(new Uri("https://mgunderwriting.api.crm11.dynamics.com/XRMServices/2011/Organization.svc"),
             null, clientCredentials, null);

            var FirstName = "John";
            var LastName = "Collins";
            var Email = "";

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='contact'>
                                <attribute name='fullname' />
                                <attribute name='parentcustomerid' />
                                <attribute name='telephone1' />
                                <attribute name='emailaddress1' />
                                <attribute name='contactid' />
                                <order attribute='fullname' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='firstname' operator='eq' value='{FirstName}' />
                                  <condition attribute='lastname' operator='eq' value='{LastName}' />";
            if (!string.IsNullOrEmpty(Email))
            {
                fetch += $@"<condition attribute='emailaddress1' operator='eq' value='{Email}' />";
            }
            fetch += $@"</filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
            }
        }
    }
}
