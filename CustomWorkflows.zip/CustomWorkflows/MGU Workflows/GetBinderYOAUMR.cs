﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class GetBinderYOAUMR : CodeActivity
    {
        [Input("Binder")]
        [ReferenceTarget("lux_binder")]
        [RequiredArgument]
        public InArgument<EntityReference> Binder { get; set; }

        [RequiredArgument]
        [Input("Policy Start Date")]
        public InArgument<DateTime> PolicyStartDate { get; set; }

        [Output("UMR")]
        public OutArgument<string> UMR { get; set; }

        [Output("YOA")]
        public OutArgument<string> YOA { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference binderref = Binder.Get<EntityReference>(executionContext);
            Entity binder = service.Retrieve("lux_binder", binderref.Id, new ColumnSet(true));

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_binderhistory'>
                                <attribute name='lux_yoa' />
                                <attribute name='lux_umr' />
                                <attribute name='lux_startdate' />
                                <attribute name='lux_enddate' />
                                <attribute name='lux_binder' />
                                <attribute name='lux_binderhistoryid' />
                                <order attribute='lux_yoa' descending='false' />
                                <filter type='and'>
                                  <condition attribute='lux_startdate' operator='on-or-before' value='{PolicyStartDate.Get(executionContext).ToString("s")}' />
                                  <condition attribute='lux_enddate' operator='on-or-after' value='{PolicyStartDate.Get(executionContext).ToString("s")}' />
                                  <condition attribute='lux_binder' operator='eq' uiname='DTW1991' uitype='lux_binder' value='{binder.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var history = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                YOA.Set(executionContext, history.Attributes["lux_yoa"]);
                UMR.Set(executionContext, history.Attributes["lux_umr"]);
            }
            else
            {
                YOA.Set(executionContext, binder.Attributes["lux_yoa"]);
                UMR.Set(executionContext, binder.Attributes["lux_bindernumber"]);
            }
        }
    }
}
