﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomWorkflows
{
    public class ReverseInstallmentsforMTA : CodeActivity
    {
        [Input("Policy")]
        [ReferenceTarget("lux_policy")]
        public InArgument<EntityReference> Policy { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            #region "Load CRM Service from context"

            Common objCommon = new Common(executionContext);
            objCommon.tracingService.Trace("Load CRM Service from context --- OK");
            #endregion

            var installmentfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='lux_installmentschedule'>
                                        <attribute name='createdon' />
                                        <attribute name='lux_tax' />
                                        <attribute name='lux_netpremium' />
                                        <attribute name='lux_grosspremium' />
                                        <attribute name='lux_customerpayable' />
                                        <attribute name='lux_customer' />
                                        <attribute name='lux_commission' />
                                        <attribute name='statuscode' />
                                        <attribute name='lux_installmentscheduleid' />
                                        <attribute name='lux_fees' />
                                        <attribute name='lux_agentcommission' />
                                        <order attribute='createdon' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='statecode' operator='eq' value='0' />
                                          <condition attribute='lux_installmenttype' operator='eq' value='972970002' />
                                          <condition attribute='lux_policy' operator='eq' uitype='lux_policy' value='{Policy.Get(executionContext).Id}' />
                                        </filter>
                                        <link-entity name='lux_policy' from='lux_policyid' to='lux_policy' visible='false' link-type='outer' alias='pol'>
                                          <attribute name='lux_policynumber' />
                                        </link-entity>
                                      </entity>
                                    </fetch>";

            var InstallmentLst = objCommon.service.RetrieveMultiple(new FetchExpression(installmentfetch)).Entities;
            if (InstallmentLst.Count() > 0)
            {
                foreach (var item in InstallmentLst)
                {
                    var createdGUID = objCommon.CloneRecord("lux_installmentschedule", item.Id.ToString(), "", "");
                    Entity installment = objCommon.service.Retrieve("lux_installmentschedule", createdGUID, new ColumnSet(true));
                    installment["lux_grosspremium"] = new Money(-1 * (installment.Contains("lux_grosspremium") ? installment.GetAttributeValue<Money>("lux_grosspremium").Value : 0));
                    installment["lux_netpremium"] = new Money(-1 * (installment.Contains("lux_netpremium") ? installment.GetAttributeValue<Money>("lux_netpremium").Value : 0));
                    installment["lux_tax"] = new Money(-1 * (installment.Contains("lux_tax") ? installment.GetAttributeValue<Money>("lux_tax").Value : 0));
                    installment["lux_fees"] = new Money(-1 * (installment.Contains("lux_fees") ? installment.GetAttributeValue<Money>("lux_fees").Value : 0));
                    installment["lux_agentcommission"] = new Money(-1 * (installment.Contains("lux_agentcommission") ? installment.GetAttributeValue<Money>("lux_agentcommission").Value : 0));
                    installment["lux_commission"] = new Money(-1 * (installment.Contains("lux_commission") ? installment.GetAttributeValue<Money>("lux_commission").Value : 0));
                    installment["lux_customerpayable"] = new Money(-1 * (installment.Contains("lux_customerpayable") ? installment.GetAttributeValue<Money>("lux_customerpayable").Value : 0));
                    objCommon.service.Update(installment);
                }
            }
        }
    }
}