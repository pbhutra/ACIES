﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using msdyncrmWorkflowTools;
using System;
using System.Activities;
using System.Linq;

namespace CustomWorkflows
{
    public class DocumentAttachmentToEmail : CodeActivity
    {
        [Input("Note")]
        [ReferenceTarget("annotation")]
        public InArgument<EntityReference> Note { get; set; }

        [Input("Email")]
        [ReferenceTarget("email")]
        public InArgument<EntityReference> Email { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference email = Email.Get(executionContext);

            Entity _Attachment = new Entity("activitymimeattachment");
            _Attachment["objectid"] = new EntityReference("email", email.Id);
            _Attachment["objecttypecode"] = "email";

            EntityReference noteref = Note.Get<EntityReference>(executionContext);
            Entity note = service.Retrieve("annotation", noteref.Id, new ColumnSet(true));

            if (note.Attributes.Contains("subject"))
            {
                _Attachment["subject"] = note.Attributes["subject"].ToString();
            }
            if (note.Attributes.Contains("filename"))
            {
                _Attachment["filename"] = note.Attributes["filename"].ToString();
            }
            if (note.Attributes.Contains("documentbody"))
            {
                _Attachment["body"] = note.Attributes["documentbody"].ToString();
            }
            else if (note.Attributes.Contains("body"))
            {
                _Attachment["body"] = note.Attributes["body"].ToString();
            }
            if (note.Attributes.Contains("mimetype"))
            {
                _Attachment["mimetype"] = note.Attributes["mimetype"].ToString();
            }
            service.Create(_Attachment);
        }
    }
}