﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace CustomWorkflows
{
    public class GetLastMonthFirstAndLastDay : CodeActivity
    {
        [RequiredArgument]
        [Output("LastMonth First Day")]
        public OutArgument<DateTime> LastMonthFirstDay { get; set; }

        [RequiredArgument]
        [Output("LastMonth Last Day")]
        public OutArgument<DateTime> LastMonthLastDay { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            DateTime t = DateTime.Now;

            DateTime p = t.PreviousMonthFirstDay();
            LastMonthFirstDay.Set(executionContext, p);

            p = t.PreviousMonthLastDay();
            LastMonthLastDay.Set(executionContext, p);
        }
    }

    public static class Helpers
    {
        public static DateTime PreviousMonthFirstDay(this DateTime currentDate)
        {
            DateTime d = currentDate.PreviousMonthLastDay();
            return new DateTime(d.Year, d.Month, 1);
        }

        public static DateTime PreviousMonthLastDay(this DateTime currentDate)
        {
            return new DateTime(currentDate.Year, currentDate.Month, 1).AddDays(-1);
        }
    }
}
