﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CustomWorkflows
{
    public class AssociateDataFromView : CodeActivity
    {
        [Input("Application")]
        [ReferenceTarget("lux_application")]
        public InArgument<EntityReference> Application { get; set; }

        [Input("Property Owners Premise")]
        [ReferenceTarget("lux_propertyowners")]
        public InArgument<EntityReference> PropertyOwnersPremise { get; set; }

        [Input("Commercial Combined Premise")]
        [ReferenceTarget("lux_commercialcombined")]
        public InArgument<EntityReference> CommercialCombinedPremise { get; set; }

        [Input("View")]
        [ReferenceTarget("savedquery")]
        [RequiredArgument]
        public InArgument<EntityReference> View { get; set; }

        [RequiredArgument]
        [Input("TargetEntityName")]
        public InArgument<string> TargetEntityName { get; set; }

        [Input("Product")]
        public InArgument<string> Product { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference viewref = View.Get<EntityReference>(executionContext);
            Entity view = service.Retrieve("savedquery", viewref.Id, new ColumnSet(true));

            var fetch = view.Attributes["fetchxml"].ToString();
            //tracingService.Trace(Product.Get(executionContext).ToString());

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    if (TargetEntityName.Get(executionContext) == "lux_applicationexcess")
                    {
                        //if (Product.Get(executionContext).ToString() == "Commercial Combined")
                        //{
                        //    var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                        //                  <entity name='lux_applicationexcess'>
                        //                    <attribute name='lux_name' />
                        //                    <attribute name='lux_excessvalue' />
                        //                    <attribute name='lux_applicationexcessid' />
                        //                    <order attribute='lux_name' descending='false' />
                        //                    <filter type='and'>
                        //                      <condition attribute='lux_commercialcombined' operator='eq' uiname='' uitype='lux_commercialcombined' value='{CommercialCombinedPremise.Get(executionContext).Id}' />
                        //                      <condition attribute='lux_excessid' operator='eq' uiname='THIRD PARTY PROPERTY DAMAGE' uitype='lux_excess' value='{item.GetAttributeValue<EntityReference>("lux_excess").Id}' />
                        //                    </filter>
                        //                  </entity>
                        //                </fetch>";
                        //    if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count == 0)
                        //    {
                        //        Entity ent = new Entity(TargetEntityName.Get(executionContext));
                        //        ent["lux_application"] = new EntityReference("lux_application", Application.Get(executionContext).Id);
                        //        ent["lux_commercialcombined"] = new EntityReference("lux_commercialcombined", CommercialCombinedPremise.Get(executionContext).Id);
                        //        ent["lux_excessvalue"] = item.Attributes["lux_excessvalue"];
                        //        ent["lux_name"] = item.GetAttributeValue<AliasedValue>("aa.lux_name").Value.ToString();
                        //        ent["lux_binder"] = new EntityReference("lux_binder", item.GetAttributeValue<EntityReference>("lux_binder").Id);
                        //        ent["lux_excessid"] = new EntityReference("lux_excess", item.GetAttributeValue<EntityReference>("lux_excess").Id);
                        //        service.Create(ent);
                        //    }
                        //}
                        //else if (Product.Get(executionContext).ToString() == "Property Owners")
                        //{
                        //    var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                        //                  <entity name='lux_applicationexcess'>
                        //                    <attribute name='lux_name' />
                        //                    <attribute name='lux_excessvalue' />
                        //                    <attribute name='lux_applicationexcessid' />
                        //                    <order attribute='lux_name' descending='false' />
                        //                    <filter type='and'>
                        //                      <condition attribute='lux_propertyowners' operator='eq' uiname='' uitype='lux_propertyowners' value='{PropertyOwnersPremise.Get(executionContext).Id}' />
                        //                      <condition attribute='lux_excessid' operator='eq' uiname='' uitype='lux_excess' value='{item.GetAttributeValue<EntityReference>("lux_excess").Id}' />
                        //                    </filter>
                        //                  </entity>
                        //                </fetch>";
                        //    if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count == 0)
                        //    {
                        //        Entity ent = new Entity(TargetEntityName.Get(executionContext));
                        //        ent["lux_application"] = new EntityReference("lux_application", Application.Get(executionContext).Id);
                        //        ent["lux_propertyowners"] = new EntityReference("lux_propertyowners", PropertyOwnersPremise.Get(executionContext).Id);
                        //        ent["lux_excessvalue"] = item.Attributes["lux_excessvalue"];
                        //        ent["lux_name"] = item.GetAttributeValue<AliasedValue>("aa.lux_name").Value.ToString();
                        //        ent["lux_binder"] = new EntityReference("lux_binder", item.GetAttributeValue<EntityReference>("lux_binder").Id);
                        //        ent["lux_excessid"] = new EntityReference("lux_excess", item.GetAttributeValue<EntityReference>("lux_excess").Id);
                        //        <condition attribute='lux_excessid' operator='eq' uiname='THIRD PARTY PROPERTY DAMAGE' uitype='lux_excess' value='{item.GetAttributeValue<EntityReference>("lux_excess").Id}' />
                        //        service.Create(ent);
                        //    }
                        //}
                        //else
                        //{
                        var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_applicationexcess'>
                                            <attribute name='lux_name' />
                                            <attribute name='lux_excessvalue' />
                                            <attribute name='lux_applicationexcessid' />
                                            <order attribute='lux_name' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='lux_application' operator='eq' uiname='MG/3/009' uitype='lux_application' value='{Application.Get(executionContext).Id}' />
                                              <condition attribute='lux_binderexcess' operator='eq' uiname='' uitype='lux_binderexcess' value='{item.Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";
                        if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count == 0)
                        {
                            Entity ent = new Entity(TargetEntityName.Get(executionContext));
                            ent["lux_application"] = new EntityReference("lux_application", Application.Get(executionContext).Id);
                            ent["lux_excessvalue"] = item.Attributes["lux_excessvalue"];
                            ent["lux_name"] = item.GetAttributeValue<AliasedValue>("aa.lux_name").Value.ToString();
                            ent["lux_binder"] = new EntityReference("lux_binder", item.GetAttributeValue<EntityReference>("lux_binder").Id);
                            ent["lux_binderexcess"] = new EntityReference("lux_binderexcess", item.Id);
                            service.Create(ent);
                        }
                        //}
                    }
                    else if (TargetEntityName.Get(executionContext) == "lux_applicationendorsements")
                    {
                        var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_applicationendorsements'>
                                            <attribute name='lux_name' />
                                            <attribute name='lux_isstandard' />
                                            <attribute name='lux_isamended' />
                                            <attribute name='lux_endorsement' />
                                            <attribute name='lux_applicationendorsementsid' />
                                            <order attribute='lux_name' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='lux_application' operator='eq' uiname='MG/3/009' uitype='lux_application' value='{Application.Get(executionContext).Id}' />
                                              <condition attribute='lux_endorsementid' operator='eq' uiname='Test 1' uitype='lux_endorsement' value='{item.Attributes["lux_endorsementid"]}' />
                                            </filter>
                                          </entity>
                                        </fetch>";
                        if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count == 0)
                        {
                            var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                              <entity name='lux_binder'>
                                                <attribute name='lux_name' />
                                                <attribute name='createdon' />
                                                <attribute name='lux_amountallocated' />
                                                <attribute name='lux_binderstartdate' />
                                                <attribute name='lux_binderreviewdate' />
                                                <attribute name='lux_binderlimit' />
                                                <attribute name='lux_binderenddate' />
                                                <attribute name='lux_binderid' />
                                                <order attribute='lux_name' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='new_parentbinder' operator='null' />
                                                </filter>
                                                <link-entity name='lux_endorsement_lux_binder' from='lux_binderid' to='lux_binderid' visible='false' intersect='true'>
                                                  <link-entity name='lux_endorsement' from='lux_endorsementid' to='lux_endorsementid' alias='ac'>
                                                    <filter type='and'>
                                                      <condition attribute='lux_endorsementid' operator='eq' uiname='Coronavirus Exclusion' uitype='lux_endorsement' value='{item.Attributes["lux_endorsementid"]}' />
                                                    </filter>
                                                  </link-entity>
                                                </link-entity>
                                              </entity>
                                            </fetch>";
                            tracingService.Trace(fetch2);
                            var binderLst = service.RetrieveMultiple(new FetchExpression(fetch2)).Entities;
                            if (binderLst.Count > 0)
                            {
                                foreach (var item1 in binderLst)
                                {
                                    Entity ent = new Entity(TargetEntityName.Get(executionContext));
                                    ent["lux_application"] = new EntityReference("lux_application", Application.Get(executionContext).Id);
                                    ent["lux_endorsement"] = item.Attributes["lux_endorsement"];
                                    ent["lux_name"] = item.Attributes["lux_name"];
                                    ent["lux_endorsementid"] = new EntityReference("lux_endorsement", new Guid(item.Attributes["lux_endorsementid"].ToString()));
                                    ent["lux_binder"] = new EntityReference("lux_binder", item1.Id);
                                    service.Create(ent);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}