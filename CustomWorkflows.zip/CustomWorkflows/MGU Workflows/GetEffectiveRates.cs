﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class GetEffectiveRates : CodeActivity
    {
        [RequiredArgument]
        [Input("RateName")]
        public InArgument<string> RateName { get; set; }

        [Output("Rate")]
        [ReferenceTarget("lux_taxrates")]
        public OutArgument<EntityReference> Rate { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_taxrates'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_startdate' />
                                <attribute name='lux_rate' />
                                <attribute name='lux_enddate' />
                                <attribute name='lux_taxratesid' />
                                <order attribute='lux_enddate' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", DateTime.UtcNow)}' />
                                  <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", DateTime.UtcNow) }' />
                                  <condition attribute='lux_name' operator='eq' value='{this.RateName.Get(executionContext)}' />
                                </filter>
                              </entity>
                            </fetch>";

            var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_taxrates'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_startdate' />
                                <attribute name='lux_rate' />
                                <attribute name='lux_enddate' />
                                <attribute name='lux_taxratesid' />
                                <order attribute='lux_enddate' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_name' operator='eq' value='{this.RateName.Get(executionContext)}' />
                                </filter>
                              </entity>
                            </fetch>";

            tracingService.Trace(this.RateName.Get(executionContext).ToString());

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var Rates = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                Rate.Set(executionContext, Rates.ToEntityReference());
            }
            else
            {
                var Rates = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities[0];
                Rate.Set(executionContext, Rates.ToEntityReference());
            }
        }
    }
}
