﻿using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CustomWorkflows
{
    public class CalculatePercentAmounts : CodeActivity
    {
        [Input("Premium")]
        public InArgument<decimal> Premium { get; set; }

        [Input("Rate")]
        public InArgument<decimal> Rate { get; set; }

        [Input("DivideBy")]
        public InArgument<decimal> DividedBy { get; set; }

        [RequiredArgument]
        [Input("Round Decimal Places")]
        [Default("-1")]
        public InArgument<int> RoundDecimalPlaces { get; set; }

        [Output("Amount")]
        public OutArgument<decimal> Amount { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            if (context == null)
                throw new ArgumentNullException(nameof(context));

            decimal Number1 = this.Premium.Get(context);
            decimal Number2 = this.Rate.Get(context);
            decimal Number3 = this.DividedBy.Get(context);

            int roundDecimalPlaces = RoundDecimalPlaces.Get(context);

            decimal Amount = Number1 * Number2 / Number3;

            if (roundDecimalPlaces != -1)
                Amount = Math.Round(Amount, roundDecimalPlaces);

            this.Amount.Set(context, Amount);
        }
    }
}
