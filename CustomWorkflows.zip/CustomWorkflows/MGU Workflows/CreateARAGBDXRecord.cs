﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CustomWorkflows
{
    public class CreateARAGBDXRecord : CodeActivity
    {
        [Input("Policy")]
        [ReferenceTarget("lux_policy")]
        [RequiredArgument]
        public InArgument<EntityReference> Policy { get; set; }

        [Input("Application")]
        [ReferenceTarget("lux_application")]
        [RequiredArgument]
        public InArgument<EntityReference> Application { get; set; }

        [Input("Installment")]
        [ReferenceTarget("lux_installmentschedule")]
        [RequiredArgument]
        public InArgument<EntityReference> Installment { get; set; }

        [Input("Binder")]
        [ReferenceTarget("lux_binder")]
        [RequiredArgument]
        public InArgument<EntityReference> Binder { get; set; }

        [RequiredArgument]
        [Input("Product")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> Product { get; set; }

        [RequiredArgument]
        [Input("BDX Type")]
        public InArgument<string> BDXType { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            var ProductName = Product.Get<EntityReference>(executionContext).Id;

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference policyref = Policy.Get<EntityReference>(executionContext);
            Entity policy = service.Retrieve("lux_policy", policyref.Id, new ColumnSet(true));

            EntityReference appref = Application.Get<EntityReference>(executionContext);
            Entity appln = service.Retrieve("lux_application", appref.Id, new ColumnSet(true));

            EntityReference binref = Binder.Get<EntityReference>(executionContext);
            Entity binder = service.Retrieve("lux_binder", binref.Id, new ColumnSet(true));

            EntityReference installref = Installment.Get<EntityReference>(executionContext);
            Entity install = service.Retrieve("lux_installmentschedule", installref.Id, new ColumnSet(true));

            Entity bdx = new Entity("lux_bordereaux");
            bdx["lux_installment"] = new EntityReference("lux_installmentschedule", installref.Id);
            bdx["lux_agent"] = "";
            
            bdx["lux_agentuniquepolicyreference"] = policy.Attributes.Contains("lux_policynumber") == true ? policy.Attributes["lux_policynumber"] : "";

            bdx["lux_policyexpirydateddmmyy"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
            bdx["lux_policyinceptiondateddmmyy"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

            //Liability Only
            if (ProductName == new Guid("9C87AEB1-76D1-EA11-A813-000D3A0BAD7C")) { bdx["lux_aragschemerefno"] = "513762"; bdx["lux_policytype"] = "Essential Business Legal"; }
            //Land Owners Liability
            else if (ProductName == new Guid("bdeea3ef-9483-ea11-a811-000d3a0bad7c")) { bdx["lux_aragschemerefno"] = "513762"; bdx["lux_policytype"] = "Essential Business Legal"; }
            //Commercially Combined
            else if (ProductName == new Guid("258b36d1-9483-ea11-a811-000d3a0bad7c")) { bdx["lux_aragschemerefno"] = "513762"; bdx["lux_policytype"] = "Essential Business Legal"; }
            //Property Owners
            else if (ProductName == new Guid("2f4e1a03-9583-ea11-a811-000d3a0bad7c")) { bdx["lux_aragschemerefno"] = "513781"; bdx["lux_policytype"] = "Commercial Property Owners"; }

            bdx["lux_nameofpolicyholder"] = appln.Attributes.Contains("lux_customername1") ? appln.Attributes["lux_customername1"] : "";

            if (policy.Attributes.Contains("lux_policyholder"))
            {
                Entity customer_detail = service.Retrieve(((EntityReference)policy["lux_policyholder"]).LogicalName, ((EntityReference)policy["lux_policyholder"]).Id, new ColumnSet(true));
                bdx["lux_corraddressline1"] = customer_detail.Attributes.Contains("address1_line1") == true ? customer_detail.Attributes["address1_line1"] : "";
                bdx["lux_corraddressline2"] = customer_detail.Attributes.Contains("address1_city") == true ? customer_detail.Attributes["address1_city"] : "";
                bdx["lux_corraddressline3"] = customer_detail.Attributes.Contains("address1_country") == true ? customer_detail.Attributes["address1_country"] : "";
                bdx["lux_postcode"] = customer_detail.Attributes.Contains("address1_postalcode") == true ? customer_detail.Attributes["address1_postalcode"] : "";
            }
            if (appln.Attributes.Contains("lux_dateofbirth1"))
            {
                bdx["lux_dateofbirth"] = Convert.ToDateTime(appln.FormattedValues["lux_dateofbirth1"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
            }
            bdx["lux_entrytype"] = BDXType.Get(executionContext);
            bdx["lux_cancellationreason"] = policy.Attributes.Contains("lux_cancellationreason") == true ? policy.FormattedValues["lux_cancellationreason"] : "";
            bdx["lux_bordereautype"] = new OptionSetValue(972970001);

            var LEGross = install.Attributes.Contains("lux_customerpayable") == true ? install.GetAttributeValue<Money>("lux_customerpayable").Value : 0;
            var LEIPT = install.Attributes.Contains("lux_tax") == true ? install.GetAttributeValue<Money>("lux_tax").Value : 0;
            var LENet = install.Attributes.Contains("lux_netpremium") == true ? install.GetAttributeValue<Money>("lux_netpremium").Value : 0;
            var Fee = install.Attributes.Contains("lux_fees") == true ? install.GetAttributeValue<Money>("lux_fees").Value : 0;

            bdx["lux_retailpremiumincipt"] = new Money(LEGross);
            bdx["lux_netpremiumtobdis"] = new Money(LENet);
            bdx["lux_otherfeeamount"] = new Money(Fee);
            bdx["lux_ipt"] = new Money(LEIPT);
            bdx["lux_totalnetpremiumtobdis"] = new Money(LENet + LEIPT);

            service.Create(bdx);
        }
    }
}