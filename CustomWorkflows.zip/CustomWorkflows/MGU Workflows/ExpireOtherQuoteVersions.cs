﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System.Activities;

namespace CustomWorkflows
{
    public class ExpireOtherQuoteVersions : CodeActivity
    {
        #region "Parameter Definition"

        [Input("Application")]
        [ReferenceTarget("lux_application")]
        public InArgument<EntityReference> Application { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference appref = Application.Get<EntityReference>(executionContext);
            Entity appln = service.Retrieve("lux_application", appref.Id, new ColumnSet(true));

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_application'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_applicationid' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='lux_applicationid' operator='ne' uitype='lux_application' value='{appln.Id}' />
                                  <condition attribute='lux_originalquotenumber' operator='eq' value='{appln["lux_originalquotenumber"]}' />
                                  <condition attribute='statuscode' operator='ne' value='972970009' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    service.Execute(new SetStateRequest
                    {
                        EntityMoniker = new EntityReference("lux_application", item.Id),
                        State = new OptionSetValue(0),
                        Status = new OptionSetValue(972970001)
                    });
                }
            }
        }
    }
}
