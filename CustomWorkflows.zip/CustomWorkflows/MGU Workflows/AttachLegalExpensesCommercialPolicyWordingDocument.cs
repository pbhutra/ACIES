﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using msdyncrmWorkflowTools;
using System;
using System.Activities;
using System.Linq;

namespace CustomWorkflows
{
    public class AttachLegalExpensesCommercialPolicyWordingDocument : CodeActivity
    {
        [Input("Entity Name")]
        [ReferenceTarget("")]
        public InArgument<String> EntityName { get; set; }

        [Input("Main Record URL")]
        [ReferenceTarget("")]
        public InArgument<String> MainRecordURL { get; set; }

        [Input("Email")]
        [ReferenceTarget("email")]
        public InArgument<EntityReference> Email { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            #region "Load CRM Service from context"

            Common objCommon = new Common(executionContext);
            objCommon.tracingService.Trace("Load CRM Service from context --- OK");

            #endregion

            // Get parameters
            string mainRecordURL = MainRecordURL.Get(executionContext);

            var notesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='annotation'>
                                    <attribute name='subject' />
                                    <attribute name='notetext' />
                                    <attribute name='filename' />
                                    <attribute name='documentbody' />
                                    <attribute name='annotationid' />
                                    <order attribute='subject' descending='false' />
                                    <link-entity name='ptm_mscrmaddons_dcptemplates' from='ptm_mscrmaddons_dcptemplatesid' to='objectid' link-type='inner' alias='ab'>
                                      <filter type='and'>
                                        <condition attribute='ptm_name' operator='eq' value='Legal Expenses Commercial Policy Wording' />
                                      </filter>
                                    </link-entity>
                                  </entity>
                                </fetch>";

            var file = service.RetrieveMultiple(new FetchExpression(notesFetch)).Entities.FirstOrDefault();
            if (!string.IsNullOrEmpty(mainRecordURL))
            {
                // Extract values from URL
                string[] urlParts = mainRecordURL.Split("?".ToArray());
                string[] urlParams = urlParts[1].Split("&".ToCharArray());
                string ParentObjectTypeCode = urlParams[0].Replace("etc=", "");
                string ParentId = urlParams[1].Replace("id=", "");

                Entity Note = new Entity("annotation");
                Note["objectid"] = new Microsoft.Xrm.Sdk.EntityReference(EntityName.Get(executionContext), new Guid(ParentId));
                Note["objecttypecode"] = EntityName.Get(executionContext);
                Note["filename"] = file.Attributes["filename"].ToString();
                Note["subject"] = file.Attributes["subject"].ToString();
                Note["documentbody"] = file.Attributes["documentbody"].ToString();
                service.Create(Note);
            }
            else
            {
                EntityReference email = Email.Get(executionContext);

                Entity _Attachment = new Entity("activitymimeattachment");
                _Attachment["objectid"] = new EntityReference("email", email.Id);
                _Attachment["objecttypecode"] = "email";

                if (file.Attributes.Contains("subject"))
                {
                    _Attachment["subject"] = file.Attributes["subject"].ToString();
                }
                if (file.Attributes.Contains("filename"))
                {
                    _Attachment["filename"] = file.Attributes["filename"].ToString();
                }
                if (file.Attributes.Contains("documentbody"))
                {
                    _Attachment["body"] = file.Attributes["documentbody"].ToString();
                }
                else if (file.Attributes.Contains("body"))
                {
                    _Attachment["body"] = file.Attributes["body"].ToString();
                }
                if (file.Attributes.Contains("mimetype"))
                {
                    _Attachment["mimetype"] = file.Attributes["mimetype"].ToString();
                }
                service.Create(_Attachment);
            }
        }
    }
}