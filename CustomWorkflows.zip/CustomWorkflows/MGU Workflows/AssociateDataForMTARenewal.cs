﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class AssociateDataForMTARenewal : CodeActivity
    {
        [Input("Application")]
        [ReferenceTarget("lux_application")]
        [RequiredArgument]
        public InArgument<EntityReference> Application { get; set; }

        [Input("Old Application")]
        [ReferenceTarget("lux_application")]
        [RequiredArgument]
        public InArgument<EntityReference> OldApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            Common objCommon = new Common(executionContext);

            EntityReference appref = Application.Get<EntityReference>(executionContext);
            Entity appln = service.Retrieve("lux_application", appref.Id, new ColumnSet(true));

            var oldApplnId = OldApplication.Get<EntityReference>(executionContext).Id;

            var excessFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_applicationexcess'>
                                            <attribute name='lux_name' />
                                            <attribute name='lux_excessvalue' />
                                            <attribute name='lux_binderexcess' />
                                            <attribute name='lux_binder' />
                                            <attribute name='lux_excessid' />
                                            <attribute name='lux_applicationexcessid' />
                                            <order attribute='lux_name' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='lux_application' operator='eq' uitype='lux_application' value='{oldApplnId}' />
                                            </filter>
                                          </entity>
                                        </fetch>";

            var excess = service.RetrieveMultiple(new FetchExpression(excessFetch)).Entities;
            if (excess.Count > 0)
            {
                foreach (var item in excess)
                {
                    Entity ent = new Entity("lux_applicationexcess");
                    ent["lux_application"] = new EntityReference("lux_application", Application.Get(executionContext).Id);
                    ent["lux_excessvalue"] = item.Attributes["lux_excessvalue"];
                    ent["lux_name"] = item.Attributes["lux_name"];
                    if (item.Attributes.Contains("lux_binder"))
                    {
                        ent["lux_binder"] = new EntityReference("lux_binder", item.GetAttributeValue<EntityReference>("lux_binder").Id);
                    }
                    if (item.Attributes.Contains("lux_binderexcess"))
                    {
                        ent["lux_binderexcess"] = new EntityReference("lux_binderexcess", item.GetAttributeValue<EntityReference>("lux_binderexcess").Id);
                    }
                    service.Create(ent);
                }
            }

            var endorsementFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_applicationendorsements'>
                                            <attribute name='lux_name' />
                                            <attribute name='lux_isstandard' />
                                            <attribute name='lux_isamended' />    
                                            <attribute name='lux_binder' />
                                            <attribute name='lux_endorsement' />
                                            <attribute name='lux_endorsementid' />
                                            <attribute name='lux_applicationendorsementsid' />
                                            <order attribute='lux_name' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='lux_application' operator='eq' uitype='lux_application' value='{oldApplnId}' />/>
                                            </filter>
                                          </entity>
                                        </fetch>";

            var endorsement = service.RetrieveMultiple(new FetchExpression(endorsementFetch)).Entities;
            if (endorsement.Count > 0)
            {
                foreach (var item in endorsement)
                {
                    Entity ent = new Entity("lux_applicationendorsements");
                    ent["lux_application"] = new EntityReference("lux_application", Application.Get(executionContext).Id);
                    ent["lux_endorsement"] = item.Attributes["lux_endorsement"];
                    ent["lux_name"] = item.Attributes["lux_name"];
                    if (item.Attributes.Contains("lux_endorsementid"))
                    {
                        ent["lux_endorsementid"] = new EntityReference("lux_endorsement", item.GetAttributeValue<EntityReference>("lux_endorsementid").Id);
                    }
                    if (item.Attributes.Contains("lux_binder"))
                    {
                        ent["lux_binder"] = new EntityReference("lux_binder", item.GetAttributeValue<EntityReference>("lux_binder").Id);
                    }
                    ent["lux_isstandard"] = item.GetAttributeValue<bool>("lux_isstandard");
                    ent["lux_isamended"] = item.GetAttributeValue<bool>("lux_isamended");
                    service.Create(ent);
                }
            }

            if (appln.Attributes.Contains("lux_applicationtype") && appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value != 972970002)
            {
                var notesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_note'>
                                    <attribute name='createdon' />
                                    <attribute name='lux_subject' />
                                    <attribute name='lux_regardingapplication' />
                                    <attribute name='lux_notescreatedby' />
                                    <attribute name='lux_notetext' />
                                    <attribute name='lux_filename' />
                                    <attribute name='lux_noteid' />
                                    <attribute name='lux_requiredocument' />
                                    <attribute name='lux_isread' />
                                    <attribute name='lux_name' />
                                    <order attribute='createdon' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_showonbrokerside' operator='eq' value='0' />
                                      <condition attribute='lux_regardingapplication' operator='eq' uitype='lux_application' value='{oldApplnId}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                var notes = service.RetrieveMultiple(new FetchExpression(notesFetch)).Entities;
                if (notes.Count > 0)
                {
                    foreach (var item in notes)
                    {
                        Entity ent = new Entity("lux_note");
                        ent["lux_regardingapplication"] = new EntityReference("lux_application", Application.Get(executionContext).Id);
                        ent["lux_notetext"] = item.Attributes.Contains("lux_notetext") ? item.Attributes["lux_notetext"] : "";
                        ent["lux_filename"] = item.Attributes.Contains("lux_filename") ? item.Attributes["lux_filename"] : "";
                        ent["lux_subject"] = item.Attributes.Contains("lux_subject") ? item.Attributes["lux_subject"] : "";
                        ent["lux_showonbrokerside"] = false;
                        ent["overriddencreatedon"] = Convert.ToDateTime(item.FormattedValues["createdon"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        if (item.Attributes.Contains("lux_notescreatedby"))
                            ent["lux_notescreatedby"] = new EntityReference("lux_portalusers", item.GetAttributeValue<EntityReference>("lux_notescreatedby").Id);
                        service.Create(ent);
                    }
                }
            }

            var lanownersPremiseFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_landownersliability'>
                                                <attribute name='lux_landownersliabilityid' />
                                                <attribute name='lux_name' />
                                                <attribute name='createdon' />
                                                <attribute name='lux_premisenumber' />
                                                <order attribute='lux_name' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_application' operator='eq' uitype='lux_application' value='{oldApplnId}' />
                                                </filter>
                                              </entity>
                                            </fetch>";
            var lanownersPremise = service.RetrieveMultiple(new FetchExpression(lanownersPremiseFetch)).Entities;
            if (lanownersPremise.Count > 0)
            {
                foreach (var item in lanownersPremise)
                {
                    var createdGUID = objCommon.CloneRecord("lux_landownersliability", item.Id.ToString(), "", "");
                    if (createdGUID != null)
                    {
                        Entity landowners = service.Retrieve("lux_landownersliability", createdGUID, new ColumnSet(true));
                        landowners["lux_application"] = new EntityReference("lux_application", Application.Get(executionContext).Id);
                        landowners["lux_previouspremise"] = new EntityReference("lux_landownersliability", item.Id);
                        landowners["lux_premisenumber"] = item.Attributes.Contains("lux_premisenumber") == true ? item.GetAttributeValue<int>("lux_premisenumber") : 0;
                        service.Update(landowners);
                    }
                }
            }

            var propertyownersPremiseFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_propertyowners'>
                                                    <attribute name='lux_propertyownersid' />
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_premisenumber' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_application' operator='eq' uitype='lux_application' value='{oldApplnId}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";
            var propertyownersPremise = service.RetrieveMultiple(new FetchExpression(propertyownersPremiseFetch)).Entities;
            if (propertyownersPremise.Count > 0)
            {
                foreach (var item in propertyownersPremise)
                {
                    var createdGUID = objCommon.CloneRecord("lux_propertyowners", item.Id.ToString(), "", "");
                    if (createdGUID != null)
                    {
                        Entity propertyowners = service.Retrieve("lux_propertyowners", createdGUID, new ColumnSet(true));
                        propertyowners["lux_application"] = new EntityReference("lux_application", Application.Get(executionContext).Id);
                        propertyowners["lux_previouspremise"] = new EntityReference("lux_propertyowners", item.Id);
                        propertyowners["lux_premisenumber"] = item.Attributes.Contains("lux_premisenumber") == true ? item.GetAttributeValue<int>("lux_premisenumber") : 0;
                        service.Update(propertyowners);

                        var perilFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_premiseperil'>
                                            <attribute name='lux_premiseperilid' />
                                            <attribute name='lux_name' />
                                            <attribute name='createdon' />
                                            <attribute name='lux_peril' />
                                            <attribute name='lux_isincluded' />
                                            <order attribute='lux_name' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_propertyownerpremise' operator='eq' uitype='lux_propertyowners' value='{item.Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";
                        var peril = service.RetrieveMultiple(new FetchExpression(perilFetch)).Entities;
                        if (peril.Count > 0)
                        {
                            foreach (var item1 in peril)
                            {
                                Entity ent = new Entity("lux_premiseperil");
                                ent["lux_propertyownerpremise"] = new EntityReference("lux_propertyowners", createdGUID);
                                ent["lux_name"] = item1.Attributes["lux_name"];
                                ent["lux_isincluded"] = item1.GetAttributeValue<bool>("lux_isincluded");
                                ent["lux_peril"] = new EntityReference("lux_peril", item1.GetAttributeValue<EntityReference>("lux_peril").Id);
                                service.Create(ent);
                            }
                        }
                    }
                }
            }

            var commercialCombinedPremiseFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_commercialcombined'>
                                                    <attribute name='lux_commercialcombinedid' />
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_premisenumber' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_application' operator='eq' uitype='lux_application' value='{oldApplnId}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";
            var commercialCombinedPremise = service.RetrieveMultiple(new FetchExpression(commercialCombinedPremiseFetch)).Entities;
            if (commercialCombinedPremise.Count > 0)
            {
                foreach (var item in commercialCombinedPremise)
                {
                    var createdGUID = objCommon.CloneRecord("lux_commercialcombined", item.Id.ToString(), "", "");
                    if (createdGUID != null)
                    {
                        Entity propertyowners = service.Retrieve("lux_commercialcombined", createdGUID, new ColumnSet(true));
                        propertyowners["lux_application"] = new EntityReference("lux_application", Application.Get(executionContext).Id);
                        propertyowners["lux_previouspremise"] = new EntityReference("lux_commercialcombined", item.Id);
                        propertyowners["lux_premisenumber"] = item.Attributes.Contains("lux_premisenumber") == true ? item.GetAttributeValue<int>("lux_premisenumber") : 0;
                        service.Update(propertyowners);

                        var perilFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_premiseperil'>
                                            <attribute name='lux_premiseperilid' />
                                            <attribute name='lux_name' />
                                            <attribute name='createdon' />
                                            <attribute name='lux_peril' />
                                            <attribute name='lux_isincluded' />
                                            <order attribute='lux_name' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_commercialcombinedpremise' operator='eq' uitype='lux_commercialcombined' value='{item.Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";
                        var peril = service.RetrieveMultiple(new FetchExpression(perilFetch)).Entities;
                        if (peril.Count > 0)
                        {
                            foreach (var item1 in peril)
                            {
                                Entity ent = new Entity("lux_premiseperil");
                                ent["lux_commercialcombinedpremise"] = new EntityReference("lux_commercialcombined", createdGUID);
                                ent["lux_name"] = item1.Attributes["lux_name"];
                                ent["lux_isincluded"] = item1.GetAttributeValue<bool>("lux_isincluded");
                                ent["lux_peril"] = new EntityReference("lux_peril", item1.GetAttributeValue<EntityReference>("lux_peril").Id);
                                service.Create(ent);
                            }
                        }
                    }
                }
            }

        }
    }
}