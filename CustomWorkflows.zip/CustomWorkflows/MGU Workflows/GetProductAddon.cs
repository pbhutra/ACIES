﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class GetProductAddon : CodeActivity
    {
        [RequiredArgument]
        [Input("Application")]
        [ReferenceTarget("lux_application")]
        public InArgument<EntityReference> Application { get; set; }

        [RequiredArgument]
        [Input("Product")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> Product { get; set; }

        [RequiredArgument]
        [Input("AddonName")]
        public InArgument<string> AddonName { get; set; }

        [Output("ProductAddon")]
        [ReferenceTarget("lux_productaddon")]
        public OutArgument<EntityReference> ProductAddon { get; set; }

        [Output("GrossRate")]
        public OutArgument<decimal> GrossRate { get; set; }

        [Output("NetRate")]
        public OutArgument<decimal> NetRate { get; set; }

        [Output("GrossCommissionRate")]
        public OutArgument<decimal> GrossCommissionRate { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                              <entity name='lux_productaddon'>
                                <attribute name='lux_productaddonid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_name' operator='eq' value='{this.AddonName.Get(executionContext)}' />
                                </filter>
                                <link-entity name='product' from='productid' to='lux_product' link-type='inner' alias='ac'>
                                      <filter type='and'>
                                        <condition attribute='productid' operator='eq' uiname='' uitype='product' value='{this.Product.Get(executionContext).Id}' />
                                      </filter>
                                    </link-entity>
                                  </entity>
                                </fetch>";



            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var Rates = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                ProductAddon.Set(executionContext, Rates.ToEntityReference());

                EntityReference appref = Application.Get<EntityReference>(executionContext);
                Entity appln = service.Retrieve("lux_application", appref.Id, new ColumnSet(true));

                bool ELCover = appln.GetAttributeValue<bool>("lux_employersliability");

                //If product not in PO
                if (Product.Get<EntityReference>(executionContext).Id != new Guid("2f4e1a03-9583-ea11-a811-000d3a0bad7c"))
                {
                    decimal TotalWageroll = 0;
                    if (ELCover == true)
                    {
                        var WagesClerical = appln.Attributes.Contains("lux_wagesclerical") == true ? appln.GetAttributeValue<Money>("lux_wagesclerical").Value : 0;
                        var ManualPrincipal = appln.Attributes.Contains("lux_manualprincipal") == true ? appln.GetAttributeValue<Money>("lux_manualprincipal").Value : 0;
                        var Manual = appln.Attributes.Contains("lux_manual") == true ? appln.GetAttributeValue<Money>("lux_manual").Value : 0;
                        var ManualWorkAway = appln.Attributes.Contains("lux_manualworkaway") == true ? appln.GetAttributeValue<Money>("lux_manualworkaway").Value : 0;
                        var ManualWorkAwayHeat = appln.Attributes.Contains("lux_manualworkawayheat") == true ? appln.GetAttributeValue<Money>("lux_manualworkawayheat").Value : 0;
                        var Woodworking = appln.Attributes.Contains("lux_woodworking") == true ? appln.GetAttributeValue<Money>("lux_woodworking").Value : 0;
                        var WareHouse = appln.Attributes.Contains("lux_warehousedrivers") == true ? appln.GetAttributeValue<Money>("lux_warehousedrivers").Value : 0;
                        var Engineering = appln.Attributes.Contains("lux_engineeringcuttingguillotine") == true ? appln.GetAttributeValue<Money>("lux_engineeringcuttingguillotine").Value : 0;

                        TotalWageroll = WagesClerical + ManualPrincipal + Manual + ManualWorkAway + ManualWorkAwayHeat + Woodworking + WareHouse + Engineering;
                    }
                    else
                    {
                        TotalWageroll = 0;
                    }

                    var ratesfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='lux_productaddonrates'>
                                        <attribute name='createdon' />
                                        <attribute name='lux_wagerollto' />
                                        <attribute name='lux_wagerollfrom' />
                                        <attribute name='lux_productaddon' />
                                        <attribute name='lux_netrate' />
                                        <attribute name='lux_grossrate' />
                                        <attribute name='lux_grosscommission' />
                                        <attribute name='lux_productaddonratesid' />
                                        <order attribute='lux_grosscommission' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='statecode' operator='eq' value='0' />
                                          <condition attribute='lux_productaddon' operator='eq' uiname='Legal Expenses' uitype='lux_productaddon' value='{Rates.Id}' />
                                          <condition attribute='lux_wagerollfrom' operator='le' value='{TotalWageroll}' />
                                          <condition attribute='lux_wagerollto' operator='ge' value='{TotalWageroll}' />
                                        </filter>
                                      </entity>
                                    </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(ratesfetch)).Entities.Count > 0)
                    {
                        var LegalRates = service.RetrieveMultiple(new FetchExpression(ratesfetch)).Entities[0];
                        var Gross = LegalRates.GetAttributeValue<Money>("lux_grossrate").Value;
                        var Net = LegalRates.GetAttributeValue<Money>("lux_netrate").Value;
                        var GrossCommission = LegalRates.GetAttributeValue<Money>("lux_grosscommission").Value;
                        GrossRate.Set(executionContext, Gross);
                        NetRate.Set(executionContext, Net);
                        GrossCommissionRate.Set(executionContext, GrossCommission);
                    }
                }
                else
                {
                    var propfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_propertyowners'>
                                            <attribute name='lux_propertyownersid' />
                                            <attribute name='lux_name' />
                                            <attribute name='createdon' />
                                            <order attribute='lux_name' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_application' value='{appln.Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                    //var propCount = service.RetrieveMultiple(new FetchExpression(propfetch)).Entities.Count != 0 ? service.RetrieveMultiple(new FetchExpression(propfetch)).Entities.Count : 1;

                    var ratesfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_productaddonrates'>
                                            <attribute name='createdon' />
                                            <attribute name='lux_wagerollto' />
                                            <attribute name='lux_wagerollfrom' />
                                            <attribute name='lux_productaddon' />
                                            <attribute name='lux_netrate' />
                                            <attribute name='lux_grossrate' />
                                            <attribute name='lux_grosscommission' />
                                            <attribute name='lux_productaddonratesid' />
                                            <order attribute='lux_grosscommission' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_productaddon' operator='eq' uiname='Legal Expenses' uitype='lux_productaddon' value='{Rates.Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(ratesfetch)).Entities.Count > 0)
                    {
                        var LegalRates = service.RetrieveMultiple(new FetchExpression(ratesfetch)).Entities[0];
                        var Gross = LegalRates.GetAttributeValue<Money>("lux_grossrate").Value;
                        var Net = LegalRates.GetAttributeValue<Money>("lux_netrate").Value;
                        var GrossCommission = LegalRates.GetAttributeValue<Money>("lux_grosscommission").Value;
                        GrossRate.Set(executionContext, Gross);
                        NetRate.Set(executionContext, Net);
                        GrossCommissionRate.Set(executionContext, GrossCommission);
                    }
                }
            }
        }
    }
}
