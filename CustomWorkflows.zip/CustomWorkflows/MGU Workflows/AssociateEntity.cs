﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata.Query;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using msdyncrmWorkflowTools;
using System.ServiceModel;

namespace CustomWorkflows
{
    public class AssociateEntity : CodeActivity
    {
        #region "Parameter Definition"
        [RequiredArgument]
        [Input("Relationship Name")]
        [Default("")]
        public InArgument<String> RelationshipName { get; set; }

        [RequiredArgument]
        [Input("Relationship Entity Name")]
        [Default("")]
        public InArgument<String> RelationshipEntityName { get; set; }

        [RequiredArgument]
        [Input("Record URL")]
        [ReferenceTarget("")]
        public InArgument<String> RecordURL { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            #region "Load CRM Service from context"

            Common objCommon = new Common(executionContext);
            objCommon.tracingService.Trace("Load CRM Service from context --- OK");
            #endregion

            #region "Read Parameters"
            String _relationshipName = this.RelationshipName.Get(executionContext);
            String _relationshipEntityName = this.RelationshipEntityName.Get(executionContext);
            String _recordURL = this.RecordURL.Get(executionContext);
            if (_recordURL == null || _recordURL == "")
            {
                return;
            }
            string[] urlParts = _recordURL.Split("?".ToArray());
            string[] urlParams = urlParts[1].Split("&".ToCharArray());
            string ParentObjectTypeCode = urlParams[0].Replace("etc=", "");
            string entityName = objCommon.sGetEntityNameFromCode(ParentObjectTypeCode, objCommon.service);
            string ParentId = urlParams[1].Replace("id=", "");
            objCommon.tracingService.Trace("ParentObjectTypeCode=" + ParentObjectTypeCode + "--ParentId=" + ParentId);
            #endregion

            #region "Associate Execution"

            try
            {
                //msdyncrmWorkflowTools_Class commonClass = new msdyncrmWorkflowTools_Class(objCommon.service);
                //commonClass.AssociateEntity(objCommon.context.PrimaryEntityName, objCommon.context.PrimaryEntityId, _relationshipName, _relationshipEntityName, entityName, ParentId);
                EntityReferenceCollection relatedEntities = new EntityReferenceCollection();

                bool isExist = RelationshipExists(service, _relationshipName, objCommon.context.PrimaryEntityId, objCommon.context.PrimaryEntityName, new Guid(ParentId), entityName);
                if (isExist == false)
                {
                    relatedEntities.Add(new EntityReference(entityName, new Guid(ParentId)));
                }
                   
                //Relationship relationship = new Relationship(_relationshipName);
                //service.Associate(objCommon.context.PrimaryEntityName, objCommon.context.PrimaryEntityId, relationship, relatedEntities);

                AssociateRequest assreq = new AssociateRequest();
                assreq.Target = new EntityReference(objCommon.context.PrimaryEntityName, objCommon.context.PrimaryEntityId);
                assreq.RelatedEntities = relatedEntities;
                assreq.Relationship = new Relationship(_relationshipName);
                AssociateResponse response = (AssociateResponse)service.Execute(assreq);

                objCommon.tracingService.Trace("Error : {0}", response);

            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                objCommon.tracingService.Trace("Error : {0} - {1}", ex.Message, ex.StackTrace);
                //throw ex;
                // if (ex.Detail.ErrorCode != 2147220937)//ignore if the error is a duplicate insert
                //{
                // throw ex;
                //}
            }
            catch (System.Exception ex)
            {
                objCommon.tracingService.Trace("Error : {0} - {1}", ex.Message, ex.StackTrace);
                //throw ex;
            }
            #endregion

        }

        public static bool RelationshipExists(IOrganizationService service, string relationshipname, Guid entity1Id, string entity1Name, Guid entity2Id, string entity2Name)
        {
            string relationship1EtityName = string.Format("{0}id", entity1Name);
            string relationship2EntityName = string.Format("{0}id", entity2Name);

            //This check is added for self-referenced relationships
            if (entity1Name.Equals(entity2Name, StringComparison.InvariantCultureIgnoreCase))
            {
                relationship1EtityName = string.Format("{0}idone", entity1Name);
                relationship1EtityName = string.Format("{0}idtwo", entity1Name);
            }

            QueryExpression query = new QueryExpression(entity1Name)
            {
                ColumnSet = new ColumnSet(false)
            };

            LinkEntity link = query.AddLink(relationshipname,
                string.Format("{0}id", entity1Name), relationship1EtityName);
            link.LinkCriteria.AddCondition(relationship1EtityName,
                ConditionOperator.Equal, new object[] { entity1Id });
            link.LinkCriteria.AddCondition(relationship2EntityName,
                ConditionOperator.Equal, new object[] { entity2Id });

            return service.RetrieveMultiple(query).Entities.Count != 0;
        }
    }
}
