﻿using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CustomWorkflows
{
    public class CalculateSectionSubtotal : CodeActivity
    {
        [Input("Sum Insured")]
        public InArgument<decimal> SumInsured { get; set; }

        [Input("Base Rate")]
        public InArgument<decimal> BaseRate { get; set; }

        [Input("Loading")]
        public InArgument<decimal> Loading { get; set; }

        [Input("Discount")]
        public InArgument<decimal> Discount { get; set; }

        [RequiredArgument]
        [Input("Round Decimal Places")]
        [Default("-1")]
        public InArgument<int> RoundDecimalPlaces { get; set; }

        [Output("Subtotal")]
        public OutArgument<decimal> Subtotal { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            if (context == null)
                throw new ArgumentNullException(nameof(context));

            decimal SumInsured = this.SumInsured.Get(context);
            decimal BaseRate = this.BaseRate.Get(context);
            decimal Loading = this.Loading.Get(context);
            decimal Discount = this.Discount.Get(context);

            int roundDecimalPlaces = RoundDecimalPlaces.Get(context);

            decimal Subtotal = SumInsured * (BaseRate + BaseRate * (Loading + Discount) / 100) / 100;

            if (roundDecimalPlaces != -1)
                Subtotal = Math.Round(Subtotal, roundDecimalPlaces);

            this.Subtotal.Set(context, Subtotal);
        }
    }
}
