﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class SetBrokersOnQuotes : CodeActivity
    {
        [RequiredArgument]
        [Input("BrokerOid")]
        public InArgument<string> BrokerOid { get; set; }

        [RequiredArgument]
        [Input("BrokerCompanyOid")]
        public InArgument<string> BrokerCompanyOid { get; set; }

        [Output("Contact")]
        [ReferenceTarget("contact")]
        public OutArgument<EntityReference> Broker { get; set; }

        [Output("Account")]
        [ReferenceTarget("account")]
        public OutArgument<EntityReference> BrokerAccount { get; set; }

        [Output("IsContactExist")]
        public OutArgument<bool> IsContactExist { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            if (BrokerOid.Get(executionContext).ToString().Replace(",", "") == "10001001")
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='contact'>
                                <attribute name='new_fullname' />
                                <attribute name='emailaddress1' />
                                <attribute name='address1_composite' />
                                <attribute name='parentcustomerid' />
                                <attribute name='telephone1' />
                                <attribute name='contactid' />
                                <attribute name='lux_brokeroid' />
                                <order attribute='new_fullname' descending='false' />
                                <filter type='and'>
                                  <condition attribute='lux_contacttype' operator='eq' value='972970001' />
                                  <condition attribute='lux_brokeroid' operator='eq' value='{BrokerOid.Get(executionContext).ToString().Replace(",", "")}' />
                                </filter>
                              </entity>
                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    this.IsContactExist.Set(executionContext, true);
                    var contact = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                    Broker.Set(executionContext, contact.ToEntityReference());

                    var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='account'>
                                        <attribute name='name' />
                                        <attribute name='emailaddress1' />
                                        <attribute name='address1_composite' />
                                        <attribute name='lux_maincontactname' />
                                        <attribute name='accountid' />
                                        <attribute name='lux_brokeroid' />
                                        <attribute name='lux_uniquieid' />
                                        <order attribute='name' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='lux_accounttype' operator='eq' value='972970001' />
                                          <condition attribute='lux_brokeroid' operator='eq' value='{BrokerCompanyOid.Get(executionContext).Replace(",", "")}' />
                                        </filter>
                                      </entity>
                                    </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
                    {
                        var contact1 = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities[0];
                        BrokerAccount.Set(executionContext, contact1.ToEntityReference());
                    }
                }
                else
                {
                    this.IsContactExist.Set(executionContext, false);
                }
            }
            else
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='contact'>
                                <attribute name='new_fullname' />
                                <attribute name='emailaddress1' />
                                <attribute name='address1_composite' />
                                <attribute name='parentcustomerid' />
                                <attribute name='telephone1' />
                                <attribute name='contactid' />
                                <attribute name='lux_brokeroid' />
                                <order attribute='new_fullname' descending='false' />
                                <filter type='and'>
                                  <condition attribute='lux_contacttype' operator='eq' value='972970001' />
                                  <condition attribute='lux_brokeroid' operator='eq' value='{BrokerOid.Get(executionContext).ToString().Replace(",", "")}' />
                                </filter>
                                <link-entity name='account' from='accountid' to='parentcustomerid' link-type='inner' alias='ac'>
                                  <filter type='and'>
                                    <condition attribute='lux_brokeroid' operator='eq' value='{BrokerCompanyOid.Get(executionContext).Replace(",", "")}' />
                                  </filter>
                                </link-entity>
                              </entity>
                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    this.IsContactExist.Set(executionContext, true);
                    var contact = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                    Broker.Set(executionContext, contact.ToEntityReference());
                    BrokerAccount.Set(executionContext, new EntityReference("account", contact.GetAttributeValue<EntityReference>("parentcustomerid").Id));
                }
                else
                {
                    this.IsContactExist.Set(executionContext, false);
                }
            }
        }
    }
}
