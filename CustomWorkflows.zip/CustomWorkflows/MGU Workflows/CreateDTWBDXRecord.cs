﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CustomWorkflows
{
    public class CreateDTWBDXRecord : CodeActivity
    {
        [Input("Policy")]
        [ReferenceTarget("lux_policy")]
        [RequiredArgument]
        public InArgument<EntityReference> Policy { get; set; }

        [Input("Application")]
        [ReferenceTarget("lux_application")]
        [RequiredArgument]
        public InArgument<EntityReference> Application { get; set; }

        [Input("Parent Application")]
        [ReferenceTarget("lux_application")]
        public InArgument<EntityReference> ParentApplication { get; set; }

        [Input("Installment")]
        [ReferenceTarget("lux_installmentschedule")]
        [RequiredArgument]
        public InArgument<EntityReference> Installment { get; set; }

        [Input("Binder")]
        [ReferenceTarget("lux_binder")]
        [RequiredArgument]
        public InArgument<EntityReference> Binder { get; set; }

        [RequiredArgument]
        [Input("Product")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> Product { get; set; }

        [RequiredArgument]
        [Input("BDX Type")]
        public InArgument<string> BDXType { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            var ProductName = Product.Get<EntityReference>(executionContext).Id;

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference policyref = Policy.Get<EntityReference>(executionContext);
            Entity policy = service.Retrieve("lux_policy", policyref.Id, new ColumnSet(true));

            EntityReference appref = Application.Get<EntityReference>(executionContext);
            Entity appln = service.Retrieve("lux_application", appref.Id, new ColumnSet(true));

            EntityReference binref = Binder.Get<EntityReference>(executionContext);
            Entity binder = service.Retrieve("lux_binder", binref.Id, new ColumnSet(true));

            EntityReference installref = Installment.Get<EntityReference>(executionContext);
            Entity installment = service.Retrieve("lux_installmentschedule", installref.Id, new ColumnSet(true));

            //Liability Only
            if (ProductName == new Guid("9C87AEB1-76D1-EA11-A813-000D3A0BAD7C"))
            {
                Entity bdx = new Entity("lux_bordereaux");

                bdx["lux_installment"] = new EntityReference("lux_installmentschedule", installref.Id);
                bdx["lux_bindernumberumr"] = policy.Attributes.Contains("lux_umr") == true ? policy.Attributes["lux_umr"] : "";
                bdx["lux_producername"] = policy.Attributes.Contains("lux_broker") == true ? policy.FormattedValues["lux_broker"] : "";
                bdx["lux_policynumber"] = appln.Attributes.Contains("lux_originalquotenumber") == true ? appln.Attributes["lux_originalquotenumber"] : "";
                bdx["lux_insuredname"] = appln.Attributes.Contains("lux_customername1") ? appln.Attributes["lux_customername1"] : "";

                bdx["lux_tradecode"] = appln.Attributes.Contains("lux_bdxcode") ? appln.Attributes["lux_bdxcode"].ToString() : "";
                if (policy.Attributes.Contains("lux_ernexempt") && policy.FormattedValues["lux_ernexempt"] == "Yes")
                {
                    bdx["lux_ernexempt"] = true;
                }
                else
                {
                    bdx["lux_ernexempt"] = false;
                }

                bdx["lux_ernnumber"] = policy.Attributes.Contains("lux_employersreferencenumber") == true ? policy.Attributes["lux_employersreferencenumber"] : "";


                if (BDXType.Get(executionContext) == "Mta")
                {
                    bdx["lux_effectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_mtadate") ? policy.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                }
                else if (BDXType.Get(executionContext) == "Cancelation")
                {
                    bdx["lux_effectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_cancellationdate") ? policy.FormattedValues["lux_cancellationdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                }
                else
                {
                    bdx["lux_effectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                }
                bdx["lux_policyexpirydateddmmyy"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                bdx["lux_policyinceptiondateddmmyy"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "MTA")
                {
                    bdx["lux_policyissuedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_mtadate") == true ? policy.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                }
                else
                {
                    bdx["lux_policyissuedate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                }
                if (policy.Attributes.Contains("lux_cancellationdate") == true)
                {
                    bdx["lux_dateofcancellation"] = Convert.ToDateTime(policy.FormattedValues["lux_cancellationdate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                }
                bdx["lux_cancellationreason"] = policy.Attributes.Contains("lux_cancellationreason") == true ? policy.FormattedValues["lux_cancellationreason"] : "";

                bdx["lux_riskaddress"] = appln.Attributes["lux_riskstreet"] + ", " + appln.Attributes["lux_riskcitycounty"];
                bdx["lux_riskpostcode"] = appln.Attributes["lux_riskpostcode"];
                bdx["lux_locationnumber"] = 1;
                bdx["lux_businesstype"] = (appln.Attributes.Contains("lux_businesssector") ? appln.FormattedValues["lux_businesssector"] : "") + ", " + (appln.Attributes.Contains("lux_businesstype1") ? appln.FormattedValues["lux_businesstype1"] : "") + ", " + (appln.Attributes.Contains("lux_fullbusinessdescription") ? appln.Attributes["lux_fullbusinessdescription"] : "");
                bdx["lux_covershare"] = Convert.ToDecimal(100.00);
                bdx["lux_mdbuildingssi"] = 0;
                bdx["lux_bisuminsured"] = 0;
                bdx["lux_mdcontentssi"] = 0;
                bdx["lux_stocksi"] = 0;
                bdx["lux_allriskssi"] = 0;
                bdx["lux_moneysi"] = 0;
                bdx["lux_gitsi"] = 0;
                bdx["lux_dossi"] = 0;
                bdx["lux_totalmdsi"] = 0;

                var iptRate = Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.Attributes["lux_iptrate"] : 12);
                var grossCommRate = Convert.ToDecimal(policy.Attributes.Contains("lux_grosscommissionrate") == true ? policy.Attributes["lux_grosscommissionrate"] : 0);
                var brokerCommRate = Convert.ToDecimal(policy.Attributes.Contains("lux_brokercommissionrate") == true ? policy.Attributes["lux_brokercommissionrate"] : 0);

                if (BDXType.Get(executionContext) == "New" || BDXType.Get(executionContext) == "Renewal")
                {
                    var totalPremium = new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value + new Money(policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value;

                    bdx["lux_combinedpremium"] = totalPremium;
                    bdx["lux_elpremium"] = policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0;
                    bdx["lux_plpremium"] = policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0;
                    bdx["lux_liabsipt"] = totalPremium * Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.GetAttributeValue<decimal>("lux_iptrate") : 12) / 100;
                    bdx["lux_elbrokerage"] = new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value * grossCommRate / 100;
                    bdx["lux_plbrokerage"] = new Money(policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value * grossCommRate / 100;
                    bdx["lux_netpremiumtounderwritersinctax"] = totalPremium + totalPremium * iptRate / 100 - totalPremium * grossCommRate / 100;
                    bdx["lux_grosspremiumexclterrorism"] = totalPremium;

                    if (BDXType.Get(executionContext) == "Renewal")
                    {
                        bdx["lux_newrenewalaprp"] = new OptionSetValue(972970002);
                        if (policy.Attributes.Contains("lux_previouspolicy"))
                        {
                            var previousPolicyID = policy.GetAttributeValue<EntityReference>("lux_previouspolicy").Id;
                            var previousPolicy = service.Retrieve("lux_policy", previousPolicyID, new ColumnSet(true));
                            var totalPreviousPremium = new Money(previousPolicy.Attributes.Contains("lux_elgross") == true ? previousPolicy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value + new Money(previousPolicy.Attributes.Contains("lux_plgross") == true ? previousPolicy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value;
                            bdx["lux_expiringpremium"] = totalPreviousPremium;
                        }
                    }
                    else
                    {
                        bdx["lux_newrenewalaprp"] = new OptionSetValue(972970001);
                    }
                }
                else if (BDXType.Get(executionContext) == "Mta")
                {
                    EntityReference parentappref = ParentApplication.Get<EntityReference>(executionContext);
                    Entity parentappln = service.Retrieve("lux_application", parentappref.Id, new ColumnSet(true));

                    DateTime startingDate = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                    DateTime endingDate = Convert.ToDateTime(DateTime.Now, System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                    TimeSpan difference = startingDate - endingDate;
                    int LengthofCovertillnow = Math.Abs(Convert.ToInt32(difference.TotalDays));
                    int remainingDays = 365 - LengthofCovertillnow;

                    decimal ELMTAPremium = policy.Attributes.Contains("lux_elmtapremium") == true ? policy.GetAttributeValue<Money>("lux_elmtapremium").Value : 0;
                    decimal PLMTAPremium = policy.Attributes.Contains("lux_plmtapremium") == true ? policy.GetAttributeValue<Money>("lux_plmtapremium").Value : 0;

                    var MTAPremium = ELMTAPremium + PLMTAPremium;

                    bdx["lux_combinedpremium"] = MTAPremium;
                    bdx["lux_elpremium"] = ELMTAPremium;
                    bdx["lux_plpremium"] = PLMTAPremium;
                    bdx["lux_liabsipt"] = MTAPremium * Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.GetAttributeValue<decimal>("lux_iptrate") : 12) / 100;
                    bdx["lux_elbrokerage"] = ELMTAPremium * grossCommRate / 100;
                    bdx["lux_plbrokerage"] = PLMTAPremium * grossCommRate / 100;
                    bdx["lux_netpremiumtounderwritersinctax"] = MTAPremium + MTAPremium * iptRate / 100 - MTAPremium * grossCommRate / 100;
                    bdx["lux_grosspremiumexclterrorism"] = MTAPremium;

                    bdx["lux_newrenewalaprp"] = new OptionSetValue(972970003);
                }
                else if (BDXType.Get(executionContext) == "Cancelation")
                {
                    var cancellationDate = DateTime.Now;
                    if (policy.Contains("lux_cancellationdate"))
                    {
                        cancellationDate = Convert.ToDateTime(policy.FormattedValues["lux_cancellationdate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                    }
                    if (policy.Contains("lux_typeofcancellation") && policy.GetAttributeValue<OptionSetValue>("lux_typeofcancellation").Value == 972970001) //Mid Term
                    {
                        var refundELGross = policy.Attributes.Contains("lux_elrefundamount") == true ? policy.GetAttributeValue<Money>("lux_elrefundamount").Value : 0;
                        var refundPLGross = policy.Attributes.Contains("lux_plrefundamount") == true ? policy.GetAttributeValue<Money>("lux_plrefundamount").Value : 0;

                        var totalRefundPremium = refundELGross + refundPLGross;

                        bdx["lux_combinedpremium"] = -totalRefundPremium;
                        bdx["lux_elpremium"] = -refundELGross;
                        bdx["lux_plpremium"] = -refundPLGross;
                        bdx["lux_liabsipt"] = -(totalRefundPremium * Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.GetAttributeValue<decimal>("lux_iptrate") : 12) / 100);
                        bdx["lux_elbrokerage"] = -(refundELGross * grossCommRate / 100);
                        bdx["lux_plbrokerage"] = -(refundPLGross * grossCommRate / 100);
                        bdx["lux_netpremiumtounderwritersinctax"] = -(totalRefundPremium + totalRefundPremium * iptRate / 100 - totalRefundPremium * grossCommRate / 100);
                        bdx["lux_grosspremiumexclterrorism"] = -totalRefundPremium;
                    }
                    else if (policy.Contains("lux_typeofcancellation") && policy.GetAttributeValue<OptionSetValue>("lux_typeofcancellation").Value == 972970002) //Full
                    {
                        var refundELGross = policy.Attributes.Contains("lux_elrefundamount") == true ? policy.GetAttributeValue<Money>("lux_elrefundamount").Value : 0;
                        var refundPLGross = policy.Attributes.Contains("lux_plrefundamount") == true ? policy.GetAttributeValue<Money>("lux_plrefundamount").Value : 0;

                        var totalRefundPremium = refundELGross + refundPLGross;
                        bdx["lux_combinedpremium"] = -totalRefundPremium;
                        bdx["lux_elpremium"] = -(refundELGross);
                        bdx["lux_plpremium"] = -(refundPLGross);
                        bdx["lux_liabsipt"] = -(totalRefundPremium * Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.GetAttributeValue<decimal>("lux_iptrate") : 12) / 100);
                        bdx["lux_elbrokerage"] = -(refundELGross * grossCommRate / 100);
                        bdx["lux_plbrokerage"] = -(refundPLGross * grossCommRate / 100);
                        bdx["lux_netpremiumtounderwritersinctax"] = -(totalRefundPremium + totalRefundPremium * iptRate / 100 - totalRefundPremium * grossCommRate / 100);
                        bdx["lux_grosspremiumexclterrorism"] = -totalRefundPremium;
                    }

                    bdx["lux_newrenewalaprp"] = new OptionSetValue(972970004);
                }

                bdx["lux_mdpremium"] = Convert.ToDecimal(0);
                bdx["lux_mdipt"] = Convert.ToDecimal(0);

                bdx["lux_iptrate"] = iptRate;
                bdx["lux_mdbrokerage"] = Convert.ToDecimal(0);
                bdx["lux_mdbrokeragefigure"] = Convert.ToDecimal(0);

                bdx["lux_elplbrokerage"] = grossCommRate;
                bdx["lux_turnover"] = Convert.ToInt32(appln.Contains("lux_totalestimatedturnover") == true ? appln.GetAttributeValue<Money>("lux_totalestimatedturnover").Value : 0);
                bdx["lux_wages"] = Convert.ToInt32(appln.Contains("lux_wagesclerical") == true ? appln.GetAttributeValue<Money>("lux_wagesclerical").Value : 0);
                bdx["lux_ellimitofindemnity"] = appln.Contains("lux_employersliabilityindemityamount") == true ? Convert.ToInt32(appln.FormattedValues["lux_employersliabilityindemityamount"].ToString().Replace(",", "").Replace("£", "").Replace(".00", "")) : 0;
                bdx["lux_pllimitofindemnity"] = appln.Contains("lux_publicliabilityindemnityamount") == true ? Convert.ToInt32(appln.FormattedValues["lux_publicliabilityindemnityamount"].ToString().Replace(",", "").Replace("£", "")) : 0;

                var excessFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_applicationexcess'>
                                                <attribute name='lux_name' />
                                                <attribute name='lux_excessvalue' />
                                                <attribute name='lux_applicationexcessid' />
                                                <order attribute='lux_name' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='lux_application' operator='eq' uitype='lux_application' value='{appln.Id}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                var Excess = service.RetrieveMultiple(new FetchExpression(excessFetch)).Entities;
                var FireExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Fire, Lightning, Explosion, Aircraft");
                var SubsidenceExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Subsidence, Landslip & Heave");
                var EOWExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Escape of Water");
                var TheftExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Theft");
                var LiabilityExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Third Party Property Damage");

                bdx["lux_fireexcess"] = FireExcess != null ? Convert.ToInt32(FireExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                bdx["lux_subsidenceexcess"] = SubsidenceExcess != null ? Convert.ToInt32(SubsidenceExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                bdx["lux_eowexcess"] = EOWExcess != null ? Convert.ToInt32(EOWExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                bdx["lux_theftexcess"] = TheftExcess != null ? Convert.ToInt32(TheftExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                bdx["lux_liabilityexcess"] = LiabilityExcess != null ? Convert.ToInt32(LiabilityExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;

                bdx["lux_constructionclass"] = "";
                //bdx["lux_squarefootage"] = "";
                //bdx["lux_numberofstories"] = "";
                //bdx["lux_yearbuilt"] = "";
                bdx["lux_terrorismyn"] = "N";
                //bdx["lux_grossterrorismpremiummd"] = "";
                //bdx["lux_grossterrorismpremiumbi"] = "";
                //bdx["lux_terrorismipt"] = "";
                //bdx["lux_terrorismiptrate"] = "";
                //bdx["lux_brokerageterrorismpercent"] = "";
                //bdx["lux_brokerageterrorism"] = "";
                //bdx["lux_terrorismzone"] = "";
                //bdx["lux_surveyfees"] = "";

                bdx["lux_referraltosyndicate"] = false;
                bdx["lux_information"] = appln.Attributes.Contains("new_additionalinformationappearondocument") ? appln.Attributes["new_additionalinformationappearondocument"].ToString() : "";

                bdx["lux_bordereautype"] = new OptionSetValue(972970003);
                if (appln.Attributes.Contains("lux_wasthisriskreferredtoinsurers") && appln.FormattedValues["lux_wasthisriskreferredtoinsurers"] == "Yes")
                {
                    bdx["lux_wastheriskreferredtoinsurers"] = true;
                }
                else
                {
                    bdx["lux_wastheriskreferredtoinsurers"] = false;
                }

                service.Create(bdx);
            }
            //Land Owners Liability
            else if (ProductName == new Guid("bdeea3ef-9483-ea11-a811-000d3a0bad7c"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_landownersliability'>
                                    <attribute name='lux_landownersliabilityid' />
                                    <attribute name='lux_name' />
                                    <attribute name='createdon' />
                                    <attribute name='lux_application' />
                                    <order attribute='lux_premisenumber' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_isdeleted' operator='ne' value='1' />
                                      <condition attribute='lux_application' operator='eq' uitype='lux_application' value='{appln.Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        var item = service.Retrieve("lux_landownersliability", item1.Id, new ColumnSet(true));

                        Entity bdx = new Entity("lux_bordereaux");
                        bdx["lux_installment"] = new EntityReference("lux_installmentschedule", installref.Id);
                        bdx["lux_bindernumberumr"] = policy.Attributes.Contains("lux_umr") == true ? policy.Attributes["lux_umr"] : "";
                        bdx["lux_producername"] = policy.Attributes.Contains("lux_broker") == true ? policy.FormattedValues["lux_broker"] : "";
                        bdx["lux_policynumber"] = appln.Attributes.Contains("lux_originalquotenumber") == true ? appln.Attributes["lux_originalquotenumber"] : "";

                        //string title = appln.Attributes.Contains("lux_title") ? appln.Attributes["lux_title"].ToString() : "";
                        bdx["lux_insuredname"] = appln.Attributes.Contains("lux_customername1") ? appln.Attributes["lux_customername1"] : "";

                        bdx["lux_tradecode"] = appln.Attributes.Contains("lux_bdxcode") ? appln.Attributes["lux_bdxcode"].ToString() : "";
                        if (policy.Attributes.Contains("lux_ernexempt") && policy.FormattedValues["lux_ernexempt"] == "Yes")
                        {
                            bdx["lux_ernexempt"] = true;
                        }
                        else
                        {
                            bdx["lux_ernexempt"] = false;
                        }

                        bdx["lux_ernnumber"] = policy.Attributes.Contains("lux_employersreferencenumber") == true ? policy.Attributes["lux_employersreferencenumber"] : "";


                        if (BDXType.Get(executionContext) == "Mta")
                        {
                            bdx["lux_effectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_mtadate") ? policy.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        else if (BDXType.Get(executionContext) == "Cancelation")
                        {
                            bdx["lux_effectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_cancellationdate") ? policy.FormattedValues["lux_cancellationdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        else
                        {
                            bdx["lux_effectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        bdx["lux_policyexpirydateddmmyy"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_policyinceptiondateddmmyy"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                        if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "Cancelation")
                        {
                            bdx["lux_policyissuedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_cancellationdate") == true ? policy.FormattedValues["lux_cancellationdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        else
                        {
                            bdx["lux_policyissuedate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        if (policy.Attributes.Contains("lux_cancellationdate") == true)
                        {
                            bdx["lux_dateofcancellation"] = Convert.ToDateTime(policy.FormattedValues["lux_cancellationdate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }

                        bdx["lux_buildingname"] = "";
                        bdx["lux_buildingnumber"] = "";
                        bdx["lux_riskaddress"] = item.Attributes.Contains("lux_riskstreet") == true ? item.Attributes["lux_riskstreet"] : "" + ", " + item.Attributes["lux_riskcitycounty"];
                        bdx["lux_riskpostcode"] = item.Attributes.Contains("lux_riskpostcode") == true ? item.Attributes["lux_riskpostcode"] : "";
                        bdx["lux_locationnumber"] = item.Attributes.Contains("lux_premisenumber") == true ? item.Attributes["lux_premisenumber"] : "";

                        bdx["lux_businesstype"] = appln.Attributes.Contains("lux_fullbusinessdescription") ? appln.Attributes["lux_fullbusinessdescription"] : "";
                        bdx["lux_covershare"] = Convert.ToDecimal(100.00);
                        bdx["lux_mdbuildingssi"] = 0;
                        bdx["lux_bisuminsured"] = 0;
                        bdx["lux_mdcontentssi"] = 0;
                        bdx["lux_stocksi"] = 0;
                        bdx["lux_allriskssi"] = 0;
                        bdx["lux_moneysi"] = 0;
                        bdx["lux_gitsi"] = 0;
                        bdx["lux_dossi"] = 0;
                        bdx["lux_totalmdsi"] = 0;

                        var iptRate = Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.Attributes["lux_iptrate"] : 12);
                        var grossCommRate = Convert.ToDecimal(policy.Attributes.Contains("lux_grosscommissionrate") == true ? policy.Attributes["lux_grosscommissionrate"] : 0);

                        if (BDXType.Get(executionContext) == "New" || BDXType.Get(executionContext) == "Renewal")
                        {
                            var totalPremium = new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value + new Money(policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value;

                            bdx["lux_combinedpremium"] = totalPremium;
                            bdx["lux_elpremium"] = policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0;
                            bdx["lux_plpremium"] = policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0;
                            bdx["lux_liabsipt"] = totalPremium * Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.GetAttributeValue<decimal>("lux_iptrate") : 12) / 100;
                            bdx["lux_elbrokerage"] = new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value * grossCommRate / 100;
                            bdx["lux_plbrokerage"] = new Money(policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value * grossCommRate / 100;
                            bdx["lux_netpremiumtounderwritersinctax"] = totalPremium + totalPremium * iptRate / 100 - totalPremium * grossCommRate / 100;
                            bdx["lux_grosspremiumexclterrorism"] = totalPremium;

                            if (BDXType.Get(executionContext) == "Renewal")
                            {
                                bdx["lux_newrenewalaprp"] = new OptionSetValue(972970002);
                                if (policy.Attributes.Contains("lux_previouspolicy"))
                                {
                                    var previousPolicyID = policy.GetAttributeValue<EntityReference>("lux_previouspolicy").Id;
                                    var previousPolicy = service.Retrieve("lux_policy", previousPolicyID, new ColumnSet(true));
                                    var totalPreviousPremium = new Money(previousPolicy.Attributes.Contains("lux_elgross") == true ? previousPolicy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value + new Money(previousPolicy.Attributes.Contains("lux_plgross") == true ? previousPolicy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value;
                                    bdx["lux_expiringpremium"] = totalPreviousPremium;
                                }
                            }
                            else
                            {
                                bdx["lux_newrenewalaprp"] = new OptionSetValue(972970001);
                            }
                        }
                        else if (BDXType.Get(executionContext) == "Mta")
                        {
                            EntityReference parentappref = ParentApplication.Get<EntityReference>(executionContext);
                            Entity parentappln = service.Retrieve("lux_application", parentappref.Id, new ColumnSet(true));

                            DateTime startingDate = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            DateTime endingDate = Convert.ToDateTime(DateTime.Now, System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            TimeSpan difference = startingDate - endingDate;
                            int LengthofCovertillnow = Math.Abs(Convert.ToInt32(difference.TotalDays));
                            int remainingDays = 365 - LengthofCovertillnow;

                            var ParentApplnELPremium = new Money(parentappln.Attributes.Contains("lux_elgross") == true ? parentappln.GetAttributeValue<Money>("lux_elgross").Value : 0);
                            var CurrentApplnELPremium = new Money(appln.Attributes.Contains("lux_elgross") == true ? appln.GetAttributeValue<Money>("lux_elgross").Value : 0);

                            var ParentApplnPLPremium = new Money(parentappln.Attributes.Contains("lux_plgross") == true ? parentappln.GetAttributeValue<Money>("lux_plgross").Value : 0);
                            var CurrentApplnPLPremium = new Money(appln.Attributes.Contains("lux_plgross") == true ? appln.GetAttributeValue<Money>("lux_plgross").Value : 0);

                            decimal ELMTAPremium = 0;
                            decimal PLMTAPremium = 0;

                            if (CurrentApplnELPremium.Value - ParentApplnELPremium.Value > 0)
                            {
                                ELMTAPremium = (CurrentApplnELPremium.Value - ParentApplnELPremium.Value) * remainingDays / 365;
                            }
                            else
                            {
                                ELMTAPremium = (CurrentApplnELPremium.Value - ParentApplnELPremium.Value) - (CurrentApplnELPremium.Value - ParentApplnELPremium.Value) * LengthofCovertillnow;
                            }

                            if (CurrentApplnPLPremium.Value - ParentApplnPLPremium.Value > 0)
                            {
                                PLMTAPremium = (CurrentApplnPLPremium.Value - ParentApplnPLPremium.Value) * remainingDays / 365;
                            }
                            else
                            {
                                PLMTAPremium = (CurrentApplnPLPremium.Value - ParentApplnPLPremium.Value) - (CurrentApplnPLPremium.Value - ParentApplnPLPremium.Value) * LengthofCovertillnow;
                            }

                            var MTAPremium = ELMTAPremium + PLMTAPremium;

                            bdx["lux_combinedpremium"] = MTAPremium;
                            bdx["lux_elpremium"] = ELMTAPremium;
                            bdx["lux_plpremium"] = PLMTAPremium;
                            bdx["lux_liabsipt"] = MTAPremium * Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.GetAttributeValue<decimal>("lux_iptrate") : 12) / 100;
                            bdx["lux_elbrokerage"] = ELMTAPremium * grossCommRate / 100;
                            bdx["lux_plbrokerage"] = PLMTAPremium * grossCommRate / 100;
                            bdx["lux_netpremiumtounderwritersinctax"] = MTAPremium + MTAPremium * iptRate / 100 - MTAPremium * grossCommRate / 100;
                            bdx["lux_grosspremiumexclterrorism"] = MTAPremium;

                            bdx["lux_newrenewalaprp"] = new OptionSetValue(972970003);
                        }
                        else if (BDXType.Get(executionContext) == "Cancelation")
                        {
                            var cancellationDate = DateTime.Now;
                            if (policy.Contains("lux_cancellationdate"))
                            {
                                cancellationDate = Convert.ToDateTime(policy.FormattedValues["lux_cancellationdate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            }
                            bdx["lux_cancellationreason"] = policy.Attributes.Contains("lux_cancellationreason") == true ? policy.FormattedValues["lux_cancellationreason"] : "";
                            if (policy.Contains("lux_typeofcancellation") && policy.GetAttributeValue<OptionSetValue>("lux_typeofcancellation").Value == 972970001) //Mid Term
                            {
                                var dateDiff = Convert.ToDateTime(policy.FormattedValues["lux_cancellationdate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat) - Convert.ToDateTime(policy.FormattedValues["lux_policystartdate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                                var usedELGross = new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value * dateDiff.Days / 365;
                                var refundELGross = new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value - usedELGross : 0).Value;

                                var usedPLGross = new Money(policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value * dateDiff.Days / 365;
                                var refundPLGross = new Money(policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value - usedPLGross : 0).Value;

                                var totalRefundPremium = refundELGross + refundPLGross;

                                bdx["lux_combinedpremium"] = -totalRefundPremium;
                                bdx["lux_elpremium"] = -refundELGross;
                                bdx["lux_plpremium"] = -refundPLGross;
                                bdx["lux_liabsipt"] = -(totalRefundPremium * Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.GetAttributeValue<decimal>("lux_iptrate") : 12) / 100);
                                bdx["lux_elbrokerage"] = -(refundELGross * grossCommRate / 100);
                                bdx["lux_plbrokerage"] = -(refundPLGross * grossCommRate / 100);
                                bdx["lux_netpremiumtounderwritersinctax"] = -(totalRefundPremium + totalRefundPremium * iptRate / 100 - totalRefundPremium * grossCommRate / 100);
                                bdx["lux_grosspremiumexclterrorism"] = -totalRefundPremium;
                            }
                            else if (policy.Contains("lux_typeofcancellation") && policy.GetAttributeValue<OptionSetValue>("lux_typeofcancellation").Value == 972970002) //Full
                            {
                                var totalRefundPremium = new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value + new Money(policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value;

                                bdx["lux_combinedpremium"] = -totalRefundPremium;
                                bdx["lux_elpremium"] = -(new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value);
                                bdx["lux_plpremium"] = -(new Money(policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value);
                                bdx["lux_liabsipt"] = -(totalRefundPremium * Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.GetAttributeValue<decimal>("lux_iptrate") : 12) / 100);
                                bdx["lux_elbrokerage"] = -(new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value * grossCommRate / 100);
                                bdx["lux_plbrokerage"] = -(new Money(policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value * grossCommRate / 100);
                                bdx["lux_netpremiumtounderwritersinctax"] = -(totalRefundPremium + totalRefundPremium * iptRate / 100 - totalRefundPremium * grossCommRate / 100);
                                bdx["lux_grosspremiumexclterrorism"] = -totalRefundPremium;
                            }

                            bdx["lux_newrenewalaprp"] = new OptionSetValue(972970004);
                        }

                        bdx["lux_mdpremium"] = Convert.ToDecimal(0);
                        bdx["lux_mdipt"] = Convert.ToDecimal(0);

                        bdx["lux_iptrate"] = iptRate;
                        //bdx["lux_expiringpremium"] = 0;
                        bdx["lux_mdbrokerage"] = Convert.ToDecimal(0);
                        bdx["lux_mdbrokeragefigure"] = Convert.ToDecimal(0);

                        bdx["lux_elplbrokerage"] = grossCommRate;
                        bdx["lux_turnover"] = Convert.ToInt32(appln.Contains("lux_totalestimatedturnover") == true ? appln.GetAttributeValue<Money>("lux_totalestimatedturnover").Value : 0);
                        bdx["lux_wages"] = Convert.ToInt32(appln.Contains("lux_wagesclerical") == true ? appln.GetAttributeValue<Money>("lux_wagesclerical").Value : 0);
                        bdx["lux_ellimitofindemnity"] = appln.Contains("lux_employersliabilityindemityamount") == true ? Convert.ToInt32(appln.FormattedValues["lux_employersliabilityindemityamount"].ToString().Replace(",", "").Replace("£", "").Replace(".00", "")) : 0;
                        bdx["lux_pllimitofindemnity"] = appln.Contains("lux_publicliabilityindemnityamount") == true ? Convert.ToInt32(appln.FormattedValues["lux_publicliabilityindemnityamount"].ToString().Replace(",", "").Replace("£", "")) : 0;

                        var excessFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_applicationexcess'>
                                                <attribute name='lux_name' />
                                                <attribute name='lux_excessvalue' />
                                                <attribute name='lux_applicationexcessid' />
                                                <order attribute='lux_name' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='lux_application' operator='eq' uitype='lux_application' value='{appln.Id}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                        var Excess = service.RetrieveMultiple(new FetchExpression(excessFetch)).Entities;
                        var FireExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Fire, Lightning, Explosion, Aircraft");
                        var SubsidenceExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Subsidence, Landslip & Heave");
                        var EOWExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Escape of Water");
                        var TheftExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Theft");
                        var LiabilityExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Third Party Property Damage");

                        bdx["lux_fireexcess"] = FireExcess != null ? Convert.ToInt32(FireExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                        bdx["lux_subsidenceexcess"] = SubsidenceExcess != null ? Convert.ToInt32(SubsidenceExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                        bdx["lux_eowexcess"] = EOWExcess != null ? Convert.ToInt32(EOWExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                        bdx["lux_theftexcess"] = TheftExcess != null ? Convert.ToInt32(TheftExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                        bdx["lux_liabilityexcess"] = LiabilityExcess != null ? Convert.ToInt32(LiabilityExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;

                        bdx["lux_constructionclass"] = "";
                        //bdx["lux_squarefootage"] = "";
                        if (item.Attributes.Contains("lux_numberofstoreys"))
                        {
                            bdx["lux_numberofstories"] = item.GetAttributeValue<int>("lux_numberofstoreys");
                        }
                        bdx["lux_yearbuilt"] = item.Contains("lux_yearofconstruction") ? item.GetAttributeValue<int>("lux_yearofconstruction").ToString().Replace(",", "") : "";

                        bdx["lux_terrorismyn"] = "N";
                        //bdx["lux_grossterrorismpremiummd"] = "";
                        //bdx["lux_grossterrorismpremiumbi"] = "";
                        //bdx["lux_terrorismipt"] = "";
                        //bdx["lux_terrorismiptrate"] = "";
                        //bdx["lux_brokerageterrorismpercent"] = "";
                        //bdx["lux_brokerageterrorism"] = "";
                        //bdx["lux_terrorismzone"] = "";
                        //bdx["lux_surveyfees"] = "";

                        bdx["lux_referraltosyndicate"] = false;
                        bdx["lux_information"] = appln.Attributes.Contains("new_additionalinformationappearondocument") ? appln.Attributes["new_additionalinformationappearondocument"].ToString() : "";

                        bdx["lux_bordereautype"] = new OptionSetValue(972970003);
                        if (appln.Attributes.Contains("lux_wasthisriskreferredtoinsurers") && appln.FormattedValues["lux_wasthisriskreferredtoinsurers"] == "Yes")
                        {
                            bdx["lux_wastheriskreferredtoinsurers"] = true;
                        }
                        else
                        {
                            bdx["lux_wastheriskreferredtoinsurers"] = false;
                        }
                        service.Create(bdx);
                    }
                }
            }
            //Commercially Combined
            else if (ProductName == new Guid("258b36d1-9483-ea11-a811-000d3a0bad7c"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_commercialcombined'>
                                    <attribute name='lux_commercialcombinedid' />
                                    <attribute name='lux_name' />
                                    <attribute name='createdon' />
                                    <order attribute='lux_name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_isdeleted' operator='ne' value='1' />
                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_application' value='{appln.Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        var item = service.Retrieve("lux_commercialcombined", item1.Id, new ColumnSet(true));

                        Entity bdx = new Entity("lux_bordereaux");
                        bdx["lux_installment"] = new EntityReference("lux_installmentschedule", installref.Id);
                        bdx["lux_bindernumberumr"] = policy.Attributes.Contains("lux_umr") == true ? policy.Attributes["lux_umr"] : "";
                        bdx["lux_producername"] = policy.Attributes.Contains("lux_broker") == true ? policy.FormattedValues["lux_broker"] : "";
                        bdx["lux_policynumber"] = appln.Attributes.Contains("lux_originalquotenumber") == true ? appln.Attributes["lux_originalquotenumber"] : "";

                        //string title = appln.Attributes.Contains("lux_title") ? appln.Attributes["lux_title"].ToString() : "";
                        bdx["lux_insuredname"] = appln.Attributes.Contains("lux_customername1") ? appln.Attributes["lux_customername1"] : "";

                        bdx["lux_tradecode"] = appln.Attributes.Contains("lux_bdxcode") ? appln.Attributes["lux_bdxcode"].ToString() : "";
                        if (policy.Attributes.Contains("lux_ernexempt") && policy.FormattedValues["lux_ernexempt"] == "Yes")
                        {
                            bdx["lux_ernexempt"] = true;
                        }
                        else
                        {
                            bdx["lux_ernexempt"] = false;
                        }

                        bdx["lux_ernnumber"] = policy.Attributes.Contains("lux_employersreferencenumber") == true ? policy.Attributes["lux_employersreferencenumber"] : "";

                        if (BDXType.Get(executionContext) == "Mta")
                        {
                            bdx["lux_effectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_mtadate") ? policy.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        else if (BDXType.Get(executionContext) == "Cancelation")
                        {
                            bdx["lux_effectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_cancellationdate") ? policy.FormattedValues["lux_cancellationdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        else
                        {
                            bdx["lux_effectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        bdx["lux_policyexpirydateddmmyy"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_policyinceptiondateddmmyy"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                        if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "Cancelation")
                        {
                            bdx["lux_policyissuedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_cancellationdate") == true ? policy.FormattedValues["lux_cancellationdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        else
                        {
                            bdx["lux_policyissuedate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        if (policy.Attributes.Contains("lux_cancellationdate") == true)
                        {
                            bdx["lux_dateofcancellation"] = Convert.ToDateTime(policy.FormattedValues["lux_cancellationdate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        var PremiseNumber = Convert.ToInt32(item.Attributes.Contains("lux_premisenumber") == true ? item.Attributes["lux_premisenumber"] : 1);
                        bdx["lux_buildingname"] = "";
                        bdx["lux_buildingnumber"] = "";
                        bdx["lux_riskaddress"] = item.Attributes.Contains("lux_riskstreet") == true ? item.Attributes["lux_riskstreet"] : "" + ", " + item.Attributes["lux_riskcitycounty"];
                        bdx["lux_riskpostcode"] = item.Attributes.Contains("lux_riskpostcode") == true ? item.Attributes["lux_riskpostcode"] : "";
                        bdx["lux_locationnumber"] = PremiseNumber;

                        bdx["lux_businesstype"] = (appln.Attributes.Contains("lux_businesssector") ? appln.FormattedValues["lux_businesssector"] : "") + ", " + (appln.Attributes.Contains("lux_businesstype1") ? appln.FormattedValues["lux_businesstype1"] : "") + ", " + (appln.Attributes.Contains("lux_fullbusinessdescription") ? appln.Attributes["lux_fullbusinessdescription"] : "");
                        bdx["lux_covershare"] = Convert.ToDecimal(100.00);

                        var GrossProfit = Convert.ToInt32(item.Attributes.Contains("lux_estimatedgrossprofit") == true ? item.GetAttributeValue<Money>("lux_estimatedgrossprofit").Value : 0);
                        var GrossRevenue = Convert.ToInt32(item.Attributes.Contains("lux_estimatedgrossrevenue") == true ? item.GetAttributeValue<Money>("lux_estimatedgrossrevenue").Value : 0);
                        var GrossRental = Convert.ToInt32(item.Attributes.Contains("lux_grossrentals") == true ? item.GetAttributeValue<Money>("lux_grossrentals").Value : 0);
                        var CostofWorking = Convert.ToInt32(item.Attributes.Contains("lux_increaseincostofworking") == true ? item.GetAttributeValue<Money>("lux_increaseincostofworking").Value : 0);

                        var BISI = 0;

                        if (item.Attributes.Contains("lux_basisofcover") && item.FormattedValues["lux_basisofcover"] == "972970001")
                        {
                            BISI = GrossRevenue;
                        }
                        else if (item.Attributes.Contains("lux_basisofcover") && item.FormattedValues["lux_basisofcover"] == "972970002")
                        {
                            BISI = GrossProfit;
                        }
                        else if (item.Attributes.Contains("lux_basisofcover") && item.FormattedValues["lux_basisofcover"] == "972970003")
                        {
                            BISI = GrossRental;
                        }
                        else if (item.Attributes.Contains("lux_basisofcover") && item.FormattedValues["lux_basisofcover"] == "972970004")
                        {
                            BISI = CostofWorking;
                        }

                        var BuildingSI = Convert.ToInt32(item.Attributes.Contains("lux_buildingssuminsured") == true ? item.GetAttributeValue<Money>("lux_buildingssuminsured").Value : 0);
                        var LandlordSI = Convert.ToInt32(item.Attributes.Contains("lux_landlordsfixturesandfittings") == true ? item.GetAttributeValue<Money>("lux_landlordsfixturesandfittings").Value : 0);
                        var FixedGlassSI = Convert.ToInt32(item.Attributes.Contains("lux_fixedglasssignsandcanopies") == true ? item.GetAttributeValue<Money>("lux_fixedglasssignsandcanopies").Value : 0);

                        var TenantsSI = Convert.ToInt32(item.Attributes.Contains("lux_tenantsimprovements") == true ? item.GetAttributeValue<Money>("lux_tenantsimprovements").Value : 0);
                        var TradeSI = Convert.ToInt32(item.Attributes.Contains("lux_tradecontentsplantandmachinery") == true ? item.GetAttributeValue<Money>("lux_tradecontentsplantandmachinery").Value : 0);
                        var ElectronicSI = Convert.ToInt32(item.Attributes.Contains("lux_electronicbusinessequipmentcomputers") == true ? item.GetAttributeValue<Money>("lux_electronicbusinessequipmentcomputers").Value : 0);
                        var OtherBESI = Convert.ToInt32(item.Attributes.Contains("lux_otherbusinessequipment") == true ? item.GetAttributeValue<Money>("lux_otherbusinessequipment").Value : 0);
                        var GeneralStockSI = Convert.ToInt32(item.Attributes.Contains("lux_generalstock") == true ? item.GetAttributeValue<Money>("lux_generalstock").Value : 0);
                        var OtherstockSI = Convert.ToInt32(item.Attributes.Contains("lux_othertargetstock") == true ? item.GetAttributeValue<Money>("lux_othertargetstock").Value : 0);
                        var GoodsSI = Convert.ToInt32(item.Attributes.Contains("lux_goodsintrust") == true ? item.GetAttributeValue<Money>("lux_goodsintrust").Value : 0);
                        var CiggeratesSI = Convert.ToInt32(item.Attributes.Contains("lux_cigarettestobacco") == true ? item.GetAttributeValue<Money>("lux_cigarettestobacco").Value : 0);
                        var WinesSI = Convert.ToInt32(item.Attributes.Contains("lux_winesspirits") == true ? item.GetAttributeValue<Money>("lux_winesspirits").Value : 0);
                        var OtherGoodsSI = Convert.ToInt32(item.Attributes.Contains("lux_otherspecificgoods") == true ? item.GetAttributeValue<Money>("lux_otherspecificgoods").Value : 0);
                        var StockSI = Convert.ToInt32(item.Attributes.Contains("lux_stocknonferrousmetals") == true ? item.GetAttributeValue<Money>("lux_stocknonferrousmetals").Value : 0);

                        var MDContentSI = TenantsSI + TradeSI + ElectronicSI + OtherBESI + GeneralStockSI + OtherstockSI + GoodsSI + CiggeratesSI + WinesSI + OtherGoodsSI + StockSI;
                        var MDBuildingSI = BuildingSI + LandlordSI + FixedGlassSI;

                        bdx["lux_mdbuildingssi"] = MDBuildingSI;
                        bdx["lux_bisuminsured"] = BISI;
                        bdx["lux_mdcontentssi"] = MDContentSI;
                        bdx["lux_stocksi"] = StockSI;

                        var LaptopsSI = Convert.ToInt32(appln.Attributes.Contains("lux_laptopsmobiles") == true ? appln.GetAttributeValue<Money>("lux_laptopsmobiles").Value : 0);
                        var AudioSI = Convert.ToInt32(appln.Attributes.Contains("lux_audiovisualphotographic") == true ? appln.GetAttributeValue<Money>("lux_audiovisualphotographic").Value : 0);
                        var SpecificSurveySI = Convert.ToInt32(appln.Attributes.Contains("lux_scientificsurvey") == true ? appln.GetAttributeValue<Money>("lux_scientificsurvey").Value : 0);
                        var PortableToolSI = Convert.ToInt32(appln.Attributes.Contains("lux_portabletoolsequipment") == true ? appln.GetAttributeValue<Money>("lux_portabletoolsequipment").Value : 0);
                        var OtherSI = Convert.ToInt32(appln.Attributes.Contains("lux_other") == true ? appln.GetAttributeValue<Money>("lux_other").Value : 0);
                        var AllRiskSI = LaptopsSI + AudioSI + SpecificSurveySI + PortableToolSI + OtherSI;
                        if (PremiseNumber == 1)
                        {
                            bdx["lux_allriskssi"] = AllRiskSI;
                        }
                        else
                        {
                            AllRiskSI = 0;
                        }

                        var BusinessHoursSI = Convert.ToInt32(item.Attributes.Contains("lux_moneyinthepremisesduringbusinesshours") == true ? item.GetAttributeValue<Money>("lux_moneyinthepremisesduringbusinesshours").Value : 0);
                        var OutsideBusinessHoursSI = Convert.ToInt32(item.Attributes.Contains("lux_moneyinthepremisesoutsidebusinesshours") == true ? item.GetAttributeValue<Money>("lux_moneyinthepremisesoutsidebusinesshours").Value : 0);
                        var MoneySI = BusinessHoursSI + OutsideBusinessHoursSI;
                        bdx["lux_moneysi"] = MoneySI;

                        var InsuredVehicleSI = Convert.ToInt32(appln.Attributes.Contains("lux_propertyintransitbyinsuredsvehicles") == true ? appln.GetAttributeValue<Money>("lux_propertyintransitbyinsuredsvehicles").Value : 0);
                        var RoadHauliersSI = Convert.ToInt32(appln.Attributes.Contains("lux_propertyintransitbyroadhauliers") == true ? appln.GetAttributeValue<Money>("lux_propertyintransitbyroadhauliers").Value : 0);
                        var PostParcelSI = Convert.ToInt32(appln.Attributes.Contains("lux_propertyintransitbypostandorparcel") == true ? appln.GetAttributeValue<Money>("lux_propertyintransitbypostandorparcel").Value : 0);

                        var GITSI = InsuredVehicleSI + RoadHauliersSI + PostParcelSI;
                        bdx["lux_gitsi"] = GITSI;

                        var DOSSI = Convert.ToInt32(item.Attributes.Contains("lux_deteriorationofstocksuminsured") == true ? item.GetAttributeValue<Money>("lux_deteriorationofstocksuminsured").Value : 0);
                        bdx["lux_dossi"] = DOSSI;

                        bdx["lux_totalmdsi"] = MDBuildingSI + BISI + MDContentSI + StockSI + AllRiskSI + MoneySI + GITSI + DOSSI;

                        var iptRate = Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.Attributes["lux_iptrate"] : 12);
                        var grossCommRate = Convert.ToDecimal(policy.Attributes.Contains("lux_grosscommissionrate") == true ? policy.Attributes["lux_grosscommissionrate"] : 0);

                        if (BDXType.Get(executionContext) == "New" || BDXType.Get(executionContext) == "Renewal")
                        {
                            var totalPremium = new Money(appln.Attributes.Contains("lux_commerciallycombinedpremisesubtotal") == true ? appln.GetAttributeValue<Money>("lux_commerciallycombinedpremisesubtotal").Value : 0).Value + new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value + new Money(policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value;

                            var MDPremium = new Money(appln.Attributes.Contains("lux_commerciallycombinedpremisesubtotal") == true ? appln.GetAttributeValue<Money>("lux_commerciallycombinedpremisesubtotal").Value : 0).Value;
                            var MDIPT = new Money(appln.Attributes.Contains("lux_ccriskiptsubtotal") == true ? appln.GetAttributeValue<Money>("lux_ccriskiptsubtotal").Value : 0).Value;

                            bdx["lux_mdpremium"] = MDPremium;
                            bdx["lux_mdipt"] = MDIPT;

                            bdx["lux_combinedpremium"] = totalPremium;
                            bdx["lux_elpremium"] = policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0;
                            bdx["lux_plpremium"] = policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0;
                            bdx["lux_liabsipt"] = (policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0 + (policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0)) * iptRate / 100;
                            bdx["lux_elbrokerage"] = new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value * grossCommRate / 100;
                            bdx["lux_plbrokerage"] = new Money(policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value * grossCommRate / 100;
                            bdx["lux_netpremiumtounderwritersinctax"] = totalPremium + totalPremium * iptRate / 100 - totalPremium * grossCommRate / 100;
                            bdx["lux_grosspremiumexclterrorism"] = totalPremium;

                            if (BDXType.Get(executionContext) == "Renewal")
                            {
                                bdx["lux_newrenewalaprp"] = new OptionSetValue(972970002);
                                if (policy.Attributes.Contains("lux_previouspolicy"))
                                {
                                    var previousPolicyID = policy.GetAttributeValue<EntityReference>("lux_previouspolicy").Id;
                                    var previousPolicy = service.Retrieve("lux_policy", previousPolicyID, new ColumnSet(true));
                                    var totalPreviousPremium = new Money(previousPolicy.Attributes.Contains("lux_elgross") == true ? previousPolicy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value + new Money(previousPolicy.Attributes.Contains("lux_plgross") == true ? previousPolicy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value;
                                    bdx["lux_expiringpremium"] = totalPreviousPremium;
                                }
                            }
                            else
                            {
                                bdx["lux_newrenewalaprp"] = new OptionSetValue(972970001);
                            }
                        }
                        else if (BDXType.Get(executionContext) == "Mta")
                        {
                            EntityReference parentappref = ParentApplication.Get<EntityReference>(executionContext);
                            Entity parentappln = service.Retrieve("lux_application", parentappref.Id, new ColumnSet(true));

                            DateTime startingDate = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            DateTime endingDate = Convert.ToDateTime(DateTime.Now, System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            TimeSpan difference = startingDate - endingDate;
                            int LengthofCovertillnow = Math.Abs(Convert.ToInt32(difference.TotalDays));
                            int remainingDays = 365 - LengthofCovertillnow;

                            var ParentApplnELPremium = new Money(parentappln.Attributes.Contains("lux_elgross") == true ? parentappln.GetAttributeValue<Money>("lux_elgross").Value : 0);
                            var CurrentApplnELPremium = new Money(appln.Attributes.Contains("lux_elgross") == true ? appln.GetAttributeValue<Money>("lux_elgross").Value : 0);

                            var ParentApplnPLPremium = new Money(parentappln.Attributes.Contains("lux_plgross") == true ? parentappln.GetAttributeValue<Money>("lux_plgross").Value : 0);
                            var CurrentApplnPLPremium = new Money(appln.Attributes.Contains("lux_plgross") == true ? appln.GetAttributeValue<Money>("lux_plgross").Value : 0);

                            decimal ELMTAPremium = 0;
                            decimal PLMTAPremium = 0;

                            if (CurrentApplnELPremium.Value - ParentApplnELPremium.Value > 0)
                            {
                                ELMTAPremium = (CurrentApplnELPremium.Value - ParentApplnELPremium.Value) * remainingDays / 365;
                            }
                            else
                            {
                                ELMTAPremium = (CurrentApplnELPremium.Value - ParentApplnELPremium.Value) - (CurrentApplnELPremium.Value - ParentApplnELPremium.Value) * LengthofCovertillnow;
                            }

                            if (CurrentApplnPLPremium.Value - ParentApplnPLPremium.Value > 0)
                            {
                                PLMTAPremium = (CurrentApplnPLPremium.Value - ParentApplnPLPremium.Value) * remainingDays / 365;
                            }
                            else
                            {
                                PLMTAPremium = (CurrentApplnPLPremium.Value - ParentApplnPLPremium.Value) - (CurrentApplnPLPremium.Value - ParentApplnPLPremium.Value) * LengthofCovertillnow;
                            }

                            var MTAPremium = ELMTAPremium + PLMTAPremium;

                            bdx["lux_combinedpremium"] = MTAPremium;
                            bdx["lux_elpremium"] = ELMTAPremium;
                            bdx["lux_plpremium"] = PLMTAPremium;
                            bdx["lux_liabsipt"] = MTAPremium * Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.GetAttributeValue<decimal>("lux_iptrate") : 12) / 100;
                            bdx["lux_elbrokerage"] = ELMTAPremium * grossCommRate / 100;
                            bdx["lux_plbrokerage"] = PLMTAPremium * grossCommRate / 100;
                            bdx["lux_netpremiumtounderwritersinctax"] = MTAPremium + MTAPremium * iptRate / 100 - MTAPremium * grossCommRate / 100;
                            bdx["lux_grosspremiumexclterrorism"] = MTAPremium;

                            bdx["lux_newrenewalaprp"] = new OptionSetValue(972970003);
                        }
                        else if (BDXType.Get(executionContext) == "Cancelation")
                        {
                            var cancellationDate = DateTime.Now;
                            bdx["lux_cancellationreason"] = policy.Attributes.Contains("lux_cancellationreason") == true ? policy.FormattedValues["lux_cancellationreason"] : "";
                            if (policy.Contains("lux_cancellationdate"))
                            {
                                cancellationDate = Convert.ToDateTime(policy.FormattedValues["lux_cancellationdate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            }

                            if (policy.Contains("lux_typeofcancellation") && policy.GetAttributeValue<OptionSetValue>("lux_typeofcancellation").Value == 972970001) //Mid Term
                            {
                                var dateDiff = Convert.ToDateTime(policy.FormattedValues["lux_cancellationdate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat) - Convert.ToDateTime(policy.FormattedValues["lux_policystartdate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                                var usedELGross = new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value * dateDiff.Days / 365;
                                var refundELGross = new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value - usedELGross : 0).Value;

                                var usedPLGross = new Money(policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value * dateDiff.Days / 365;
                                var refundPLGross = new Money(policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value - usedPLGross : 0).Value;

                                var totalRefundPremium = refundELGross + refundPLGross;

                                bdx["lux_combinedpremium"] = -totalRefundPremium;
                                bdx["lux_elpremium"] = -refundELGross;
                                bdx["lux_plpremium"] = -refundPLGross;
                                bdx["lux_liabsipt"] = -(totalRefundPremium * Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.GetAttributeValue<decimal>("lux_iptrate") : 12) / 100);
                                bdx["lux_elbrokerage"] = -(refundELGross * grossCommRate / 100);
                                bdx["lux_plbrokerage"] = -(refundPLGross * grossCommRate / 100);
                                bdx["lux_netpremiumtounderwritersinctax"] = -(totalRefundPremium + totalRefundPremium * iptRate / 100 - totalRefundPremium * grossCommRate / 100);
                                bdx["lux_grosspremiumexclterrorism"] = -totalRefundPremium;
                            }
                            else if (policy.Contains("lux_typeofcancellation") && policy.GetAttributeValue<OptionSetValue>("lux_typeofcancellation").Value == 972970002) //Full
                            {
                                var totalRefundPremium = new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value + new Money(policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value;

                                bdx["lux_combinedpremium"] = -totalRefundPremium;
                                bdx["lux_elpremium"] = -(new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value);
                                bdx["lux_plpremium"] = -(new Money(policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value);
                                bdx["lux_liabsipt"] = -(totalRefundPremium * Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.GetAttributeValue<decimal>("lux_iptrate") : 12) / 100);
                                bdx["lux_elbrokerage"] = -(new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value * grossCommRate / 100);
                                bdx["lux_plbrokerage"] = -(new Money(policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value * grossCommRate / 100);
                                bdx["lux_netpremiumtounderwritersinctax"] = -(totalRefundPremium + totalRefundPremium * iptRate / 100 - totalRefundPremium * grossCommRate / 100);
                                bdx["lux_grosspremiumexclterrorism"] = -totalRefundPremium;
                            }

                            bdx["lux_newrenewalaprp"] = new OptionSetValue(972970004);
                        }



                        bdx["lux_iptrate"] = iptRate;
                        //bdx["lux_expiringpremium"] = 0;
                        bdx["lux_mdbrokerage"] = Convert.ToDecimal(0);
                        bdx["lux_mdbrokeragefigure"] = Convert.ToDecimal(0);

                        bdx["lux_elplbrokerage"] = grossCommRate;
                        bdx["lux_turnover"] = Convert.ToInt32(appln.Contains("lux_totalestimatedturnover") == true ? appln.GetAttributeValue<Money>("lux_totalestimatedturnover").Value : 0);
                        bdx["lux_wages"] = Convert.ToInt32(appln.Contains("lux_wagesclerical") == true ? appln.GetAttributeValue<Money>("lux_wagesclerical").Value : 0);
                        bdx["lux_ellimitofindemnity"] = appln.Contains("lux_employersliabilityindemityamount") == true ? Convert.ToInt32(appln.FormattedValues["lux_employersliabilityindemityamount"].ToString().Replace(",", "").Replace("£", "").Replace(".00", "")) : 0;
                        bdx["lux_pllimitofindemnity"] = appln.Contains("lux_publicliabilityindemnityamount") == true ? Convert.ToInt32(appln.FormattedValues["lux_publicliabilityindemnityamount"].ToString().Replace(",", "").Replace("£", "")) : 0;

                        var excessFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_applicationexcess'>
                                                <attribute name='lux_name' />
                                                <attribute name='lux_excessvalue' />
                                                <attribute name='lux_applicationexcessid' />
                                                <order attribute='lux_name' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='lux_application' operator='eq' uitype='lux_application' value='{appln.Id}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                        var Excess = service.RetrieveMultiple(new FetchExpression(excessFetch)).Entities;
                        var FireExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Fire, Lightning, Explosion, Aircraft");
                        var SubsidenceExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Subsidence, Landslip & Heave");
                        var EOWExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Escape of Water");
                        var TheftExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Theft");
                        var LiabilityExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Third Party Property Damage");

                        bdx["lux_fireexcess"] = FireExcess != null ? Convert.ToInt32(FireExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                        bdx["lux_subsidenceexcess"] = SubsidenceExcess != null ? Convert.ToInt32(SubsidenceExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                        bdx["lux_eowexcess"] = EOWExcess != null ? Convert.ToInt32(EOWExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                        bdx["lux_theftexcess"] = TheftExcess != null ? Convert.ToInt32(TheftExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                        bdx["lux_liabilityexcess"] = LiabilityExcess != null ? Convert.ToInt32(LiabilityExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;

                        bdx["lux_constructionclass"] = "";
                        //bdx["lux_squarefootage"] = "";
                        if (item.Attributes.Contains("lux_numberofstoreys"))
                        {
                            bdx["lux_numberofstories"] = item.GetAttributeValue<int>("lux_numberofstoreys");
                        }
                        bdx["lux_yearbuilt"] = item.Contains("lux_yearofconstruction") ? item.GetAttributeValue<int>("lux_yearofconstruction").ToString().Replace(",", "") : "";

                        bdx["lux_terrorismyn"] = "N";
                        //bdx["lux_grossterrorismpremiummd"] = "";
                        //bdx["lux_grossterrorismpremiumbi"] = "";
                        //bdx["lux_terrorismipt"] = "";
                        //bdx["lux_terrorismiptrate"] = "";
                        //bdx["lux_brokerageterrorismpercent"] = "";
                        //bdx["lux_brokerageterrorism"] = "";
                        //bdx["lux_terrorismzone"] = "";
                        //bdx["lux_surveyfees"] = "";

                        bdx["lux_referraltosyndicate"] = false;
                        bdx["lux_information"] = appln.Attributes.Contains("new_additionalinformationappearondocument") ? appln.Attributes["new_additionalinformationappearondocument"].ToString() : "";

                        bdx["lux_bordereautype"] = new OptionSetValue(972970003);
                        if (appln.Attributes.Contains("lux_wasthisriskreferredtoinsurers") && appln.FormattedValues["lux_wasthisriskreferredtoinsurers"] == "Yes")
                        {
                            bdx["lux_wastheriskreferredtoinsurers"] = true;
                        }
                        else
                        {
                            bdx["lux_wastheriskreferredtoinsurers"] = false;
                        }
                        bdx["lux_floodperil"] = false;
                        bdx["lux_subsidenceperil"] = false;
                        service.Create(bdx);
                    }
                }
            }
            //Property Owners
            else if (ProductName == new Guid("2f4e1a03-9583-ea11-a811-000d3a0bad7c"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_propertyowners'>
                                    <attribute name='lux_propertyownersid' />
                                    <attribute name='lux_premisestreet' />
                                    <attribute name='lux_premisepostcode' />
                                    <attribute name='lux_premisenumber' />
                                    <order attribute='lux_premisenumber' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='lux_isdeleted' operator='ne' value='1' />
                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_application' value='{appln.Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        var item = service.Retrieve("lux_propertyowners", item1.Id, new ColumnSet(true));

                        Entity bdx = new Entity("lux_bordereaux");
                        bdx["lux_installment"] = new EntityReference("lux_installmentschedule", installref.Id);
                        bdx["lux_bindernumberumr"] = policy.Attributes.Contains("lux_umr") == true ? policy.Attributes["lux_umr"] : "";
                        bdx["lux_producername"] = policy.Attributes.Contains("lux_broker") == true ? policy.FormattedValues["lux_broker"] : "";
                        bdx["lux_policynumber"] = appln.Attributes.Contains("lux_originalquotenumber") == true ? appln.Attributes["lux_originalquotenumber"] : "";

                        //string title = appln.Attributes.Contains("lux_title") ? appln.Attributes["lux_title"].ToString() : "";
                        bdx["lux_insuredname"] = appln.Attributes.Contains("lux_customername1") ? appln.Attributes["lux_customername1"] : "";

                        bdx["lux_tradecode"] = appln.Attributes.Contains("lux_bdxcode") ? appln.Attributes["lux_bdxcode"].ToString() : "";
                        if (policy.Attributes.Contains("lux_ernexempt") && policy.FormattedValues["lux_ernexempt"] == "Yes")
                        {
                            bdx["lux_ernexempt"] = true;
                        }
                        else
                        {
                            bdx["lux_ernexempt"] = false;
                        }

                        bdx["lux_ernnumber"] = policy.Attributes.Contains("lux_employersreferencenumber") == true ? policy.Attributes["lux_employersreferencenumber"] : "";

                        if (BDXType.Get(executionContext) == "Mta")
                        {
                            bdx["lux_effectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_mtadate") ? policy.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        else if (BDXType.Get(executionContext) == "Cancelation")
                        {
                            bdx["lux_effectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_cancellationdate") ? policy.FormattedValues["lux_cancellationdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        else
                        {
                            bdx["lux_effectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }

                        bdx["lux_policyexpirydateddmmyy"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_policyinceptiondateddmmyy"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                        if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "Cancelation")
                        {
                            bdx["lux_policyissuedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_cancellationdate") == true ? policy.FormattedValues["lux_cancellationdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        else
                        {
                            bdx["lux_policyissuedate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        if (policy.Attributes.Contains("lux_cancellationdate") == true)
                        {
                            bdx["lux_dateofcancellation"] = Convert.ToDateTime(policy.FormattedValues["lux_cancellationdate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        var PremiseNumber = Convert.ToInt32(item.Attributes.Contains("lux_premisenumber") == true ? item.Attributes["lux_premisenumber"] : 1);
                        bdx["lux_buildingname"] = "";
                        bdx["lux_buildingnumber"] = "";
                        bdx["lux_riskaddress"] = item.Attributes.Contains("lux_premisestreet") == true ? item.Attributes["lux_premisestreet"] : "";
                        bdx["lux_riskpostcode"] = item.Attributes.Contains("lux_premisepostcode") == true ? item.Attributes["lux_premisepostcode"] : "";
                        bdx["lux_locationnumber"] = PremiseNumber;

                        bdx["lux_businesstype"] = item.Attributes.Contains("lux_businesstype") ? item.FormattedValues["lux_businesstype"] : "";
                        bdx["lux_covershare"] = Convert.ToDecimal(100.00);

                        var GrossProfit = Convert.ToInt32(item.Attributes.Contains("lux_estimatedgrossprofit") == true ? item.GetAttributeValue<Money>("lux_estimatedgrossprofit").Value : 0);
                        var GrossRevenue = Convert.ToInt32(item.Attributes.Contains("lux_estimatedgrossrevenue") == true ? item.GetAttributeValue<Money>("lux_estimatedgrossrevenue").Value : 0);
                        var GrossRental = Convert.ToInt32(item.Attributes.Contains("lux_grossrentals") == true ? item.GetAttributeValue<Money>("lux_grossrentals").Value : 0);
                        var CostofWorking = Convert.ToInt32(item.Attributes.Contains("lux_increaseincostofworking") == true ? item.GetAttributeValue<Money>("lux_increaseincostofworking").Value : 0);



                        var BuildingSI = Convert.ToInt32(item.Attributes.Contains("lux_buildingsuminsured") == true ? item.GetAttributeValue<Money>("lux_buildingsuminsured").Value : 0);
                        var LORSI = Convert.ToInt32(item.Attributes.Contains("lux_lossofrentreceivable") == true ? item.GetAttributeValue<Money>("lux_lossofrentreceivable").Value : 0);
                        var LandlordSI = Convert.ToInt32(item.Attributes.Contains("lux_landlordscontentsuminsured") == true ? item.GetAttributeValue<Money>("lux_landlordscontentsuminsured").Value : 0);


                        var FixedGlassSI = Convert.ToInt32(item.Attributes.Contains("lux_fixedglasssignsandcanopies") == true ? item.GetAttributeValue<Money>("lux_fixedglasssignsandcanopies").Value : 0);
                        var TenantsSI = Convert.ToInt32(item.Attributes.Contains("lux_tenantsimprovements") == true ? item.GetAttributeValue<Money>("lux_tenantsimprovements").Value : 0);
                        var TradeSI = Convert.ToInt32(item.Attributes.Contains("lux_tradecontentsplantandmachinery") == true ? item.GetAttributeValue<Money>("lux_tradecontentsplantandmachinery").Value : 0);
                        var ElectronicSI = Convert.ToInt32(item.Attributes.Contains("lux_electronicbusinessequipmentcomputers") == true ? item.GetAttributeValue<Money>("lux_electronicbusinessequipmentcomputers").Value : 0);
                        var OtherBESI = Convert.ToInt32(item.Attributes.Contains("lux_otherbusinessequipment") == true ? item.GetAttributeValue<Money>("lux_otherbusinessequipment").Value : 0);
                        var GeneralStockSI = Convert.ToInt32(item.Attributes.Contains("lux_generalstock") == true ? item.GetAttributeValue<Money>("lux_generalstock").Value : 0);
                        var OtherstockSI = Convert.ToInt32(item.Attributes.Contains("lux_othertargetstock") == true ? item.GetAttributeValue<Money>("lux_othertargetstock").Value : 0);
                        var GoodsSI = Convert.ToInt32(item.Attributes.Contains("lux_goodsintrust") == true ? item.GetAttributeValue<Money>("lux_goodsintrust").Value : 0);
                        var CiggeratesSI = Convert.ToInt32(item.Attributes.Contains("lux_cigarettestobacco") == true ? item.GetAttributeValue<Money>("lux_cigarettestobacco").Value : 0);
                        var WinesSI = Convert.ToInt32(item.Attributes.Contains("lux_winesspirits") == true ? item.GetAttributeValue<Money>("lux_winesspirits").Value : 0);
                        var OtherGoodsSI = Convert.ToInt32(item.Attributes.Contains("lux_otherspecificgoods") == true ? item.GetAttributeValue<Money>("lux_otherspecificgoods").Value : 0);
                        var StockSI = Convert.ToInt32(item.Attributes.Contains("lux_stocknonferrousmetals") == true ? item.GetAttributeValue<Money>("lux_stocknonferrousmetals").Value : 0);

                        var MDContentSI = TenantsSI + TradeSI + ElectronicSI + OtherBESI + GeneralStockSI + OtherstockSI + GoodsSI + CiggeratesSI + WinesSI + OtherGoodsSI + StockSI;
                        var MDBuildingSI = BuildingSI + LandlordSI + FixedGlassSI;

                        bdx["lux_mdbuildingssi"] = BuildingSI;
                        bdx["lux_bisuminsured"] = LORSI;
                        bdx["lux_mdcontentssi"] = LandlordSI;
                        bdx["lux_totalmdsi"] = BuildingSI + LORSI + LandlordSI;
                        bdx["lux_allriskssi"] = 0;
                        bdx["lux_moneysi"] = 0;
                        bdx["lux_gitsi"] = 0;
                        bdx["lux_stocksi"] = StockSI;


                        if (PremiseNumber == 1)
                        {
                            var clerical = Convert.ToInt32(appln.Contains("lux_wagesclerical") == true ? appln.GetAttributeValue<Money>("lux_wagesclerical").Value : 0);
                            var caretakers = Convert.ToInt32(appln.Contains("lux_caretakersandportersannualpayroll") == true ? appln.GetAttributeValue<Money>("lux_caretakersandportersannualpayroll").Value : 0);
                            var gardeners = Convert.ToInt32(appln.Contains("lux_gardenersannualpayroll") == true ? appln.GetAttributeValue<Money>("lux_gardenersannualpayroll").Value : 0);
                            var cleaners = Convert.ToInt32(appln.Contains("lux_cleanersannualpayroll") == true ? appln.GetAttributeValue<Money>("lux_cleanersannualpayroll").Value : 0);

                            bdx["lux_wages"] = clerical + caretakers + gardeners + cleaners;

                            bdx["lux_ellimitofindemnity"] = appln.GetAttributeValue<bool>("lux_employersliability") == true ? Convert.ToInt32(appln.FormattedValues["lux_employersliabilityindemityamount"].ToString().Replace(",", "").Replace("£", "").Replace(".00", "")) : 0;

                        }

                        bdx["lux_pllimitofindemnity"] = appln.Contains("lux_propertyownersliability") == true ? Convert.ToInt32(appln.FormattedValues["lux_propertyownersliability"].ToString().Replace(",", "").Replace("£", "")) : 0;

                        bdx["lux_dossi"] = 0;

                        var iptRate = Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.Attributes["lux_iptrate"] : 12);
                        var grossCommRate = Convert.ToDecimal(policy.Attributes.Contains("lux_grosscommissionrate") == true ? policy.Attributes["lux_grosscommissionrate"] : 0);

                        if (BDXType.Get(executionContext) == "New" || BDXType.Get(executionContext) == "Renewal")
                        {
                            var totalPremium = new Money(appln.Attributes.Contains("lux_totalgross") == true ? appln.GetAttributeValue<Money>("lux_totalgross").Value : 0).Value;

                            var MDPremium = new Money(appln.Attributes.Contains("lux_propertyownerspremisessubtotal") == true ? appln.GetAttributeValue<Money>("lux_propertyownerspremisessubtotal").Value : 0).Value;
                            var MDIPT = new Money(appln.Attributes.Contains("lux_poriskipt") == true ? appln.GetAttributeValue<Money>("lux_poriskipt").Value : 0).Value;
                            if (PremiseNumber == 1)
                            {
                                var ELPremium = Convert.ToDecimal(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0);
                                var PLPremium = Convert.ToDecimal(policy.Attributes.Contains("lux_polgross") == true ? policy.GetAttributeValue<Money>("lux_polgross").Value : 0);

                                bdx["lux_mdpremium"] = MDPremium;
                                bdx["lux_mdipt"] = MDIPT;
                                bdx["lux_combinedpremium"] = totalPremium;

                                bdx["lux_elpremium"] = ELPremium;
                                bdx["lux_plpremium"] = PLPremium;
                                bdx["lux_liabsipt"] = (ELPremium + PLPremium) * 12 / 100;

                                bdx["lux_mdbrokerage"] = grossCommRate;
                                bdx["lux_mdbrokeragefigure"] = MDPremium * grossCommRate / 100;

                                bdx["lux_elplbrokerage"] = grossCommRate;
                                bdx["lux_elbrokerage"] = ELPremium * grossCommRate / 100;
                                bdx["lux_plbrokerage"] = PLPremium * grossCommRate / 100;

                                bdx["lux_netpremiumtounderwritersinctax"] = totalPremium + totalPremium * iptRate / 100 - totalPremium * grossCommRate / 100;
                                bdx["lux_grosspremiumexclterrorism"] = totalPremium;
                            }
                            else
                            {
                                bdx["lux_elpremium"] = Convert.ToDecimal(0);
                                bdx["lux_plpremium"] = Convert.ToDecimal(0);
                            }

                            bdx["lux_turnover"] = Convert.ToInt32(appln.Contains("lux_totalestimatedturnover") == true ? appln.GetAttributeValue<Money>("lux_totalestimatedturnover").Value : 0);

                            if (BDXType.Get(executionContext) == "Renewal")
                            {
                                if (PremiseNumber == 1)
                                {
                                    bdx["lux_newrenewalaprp"] = new OptionSetValue(972970002);
                                    if (policy.Attributes.Contains("lux_previouspolicy"))
                                    {
                                        var previousPolicyID = policy.GetAttributeValue<EntityReference>("lux_previouspolicy").Id;
                                        var previousPolicy = service.Retrieve("lux_policy", previousPolicyID, new ColumnSet(true));
                                        var totalPreviousPremium = new Money(previousPolicy.Attributes.Contains("lux_grosspremium") == true ? previousPolicy.GetAttributeValue<Money>("lux_grosspremium").Value : 0).Value;
                                        bdx["lux_expiringpremium"] = totalPreviousPremium;
                                    }
                                }
                            }
                            else
                            {
                                bdx["lux_newrenewalaprp"] = new OptionSetValue(972970001);
                            }
                        }
                        else if (BDXType.Get(executionContext) == "Mta")
                        {
                            //EntityReference parentappref = ParentApplication.Get<EntityReference>(executionContext);
                            //Entity parentappln = service.Retrieve("lux_application", parentappref.Id, new ColumnSet(true));

                            //DateTime startingDate = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            //DateTime endingDate = Convert.ToDateTime(DateTime.Now, System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            //TimeSpan difference = startingDate - endingDate;
                            //int LengthofCovertillnow = Math.Abs(Convert.ToInt32(difference.TotalDays));
                            //int remainingDays = 365 - LengthofCovertillnow;

                            //var ParentApplnELPremium = new Money(parentappln.Attributes.Contains("lux_elgross") == true ? parentappln.GetAttributeValue<Money>("lux_elgross").Value : 0);
                            //var CurrentApplnELPremium = new Money(appln.Attributes.Contains("lux_elgross") == true ? appln.GetAttributeValue<Money>("lux_elgross").Value : 0);

                            //var ParentApplnPLPremium = new Money(parentappln.Attributes.Contains("lux_polgross") == true ? parentappln.GetAttributeValue<Money>("lux_polgross").Value : 0);
                            //var CurrentApplnPLPremium = new Money(appln.Attributes.Contains("lux_polgross") == true ? appln.GetAttributeValue<Money>("lux_polgross").Value : 0);

                            decimal ELMTAPremium = policy.Attributes.Contains("lux_elmtapremium") == true ? policy.GetAttributeValue<Money>("lux_elmtapremium").Value : 0;
                            decimal PLMTAPremium = policy.Attributes.Contains("lux_polmtapremium") == true ? policy.GetAttributeValue<Money>("lux_polmtapremium").Value : 0;
                            decimal MTAPremium = policy.Attributes.Contains("lux_mtapremium") == true ? policy.GetAttributeValue<Money>("lux_mtapremium").Value : 0;
                            decimal MDPremium = policy.Attributes.Contains("lux_pomtapremium") == true ? policy.GetAttributeValue<Money>("lux_pomtapremium").Value : 0;

                            //if (CurrentApplnELPremium.Value - ParentApplnELPremium.Value > 0)
                            //{
                            //    ELMTAPremium = (CurrentApplnELPremium.Value - ParentApplnELPremium.Value) * remainingDays / 365;
                            //}
                            //else
                            //{
                            //    ELMTAPremium = (CurrentApplnELPremium.Value - ParentApplnELPremium.Value) - (CurrentApplnELPremium.Value - ParentApplnELPremium.Value) * LengthofCovertillnow;
                            //}

                            //if (CurrentApplnPLPremium.Value - ParentApplnPLPremium.Value > 0)
                            //{
                            //    PLMTAPremium = (CurrentApplnPLPremium.Value - ParentApplnPLPremium.Value) * remainingDays / 365;
                            //}
                            //else
                            //{
                            //    PLMTAPremium = (CurrentApplnPLPremium.Value - ParentApplnPLPremium.Value) - (CurrentApplnPLPremium.Value - ParentApplnPLPremium.Value) * LengthofCovertillnow;
                            //}

                            if (PremiseNumber == 1)
                            {
                                bdx["lux_mdpremium"] = MDPremium;
                                bdx["lux_mdipt"] = MDPremium * Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.GetAttributeValue<decimal>("lux_iptrate") : 12) / 100;

                                bdx["lux_combinedpremium"] = MTAPremium;
                                bdx["lux_elpremium"] = ELMTAPremium;
                                bdx["lux_plpremium"] = PLMTAPremium;
                                bdx["lux_liabsipt"] = (ELMTAPremium + PLMTAPremium) * Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.GetAttributeValue<decimal>("lux_iptrate") : 12) / 100;

                                bdx["lux_mdbrokerage"] = grossCommRate;
                                bdx["lux_mdbrokeragefigure"] = MDPremium * grossCommRate / 100;

                                bdx["lux_elplbrokerage"] = grossCommRate;
                                bdx["lux_elbrokerage"] = ELMTAPremium * grossCommRate / 100;
                                bdx["lux_plbrokerage"] = PLMTAPremium * grossCommRate / 100;
                                bdx["lux_netpremiumtounderwritersinctax"] = MTAPremium + MTAPremium * iptRate / 100 - MTAPremium * grossCommRate / 100;
                                bdx["lux_grosspremiumexclterrorism"] = MTAPremium;
                            }
                            else
                            {
                                bdx["lux_elpremium"] = Convert.ToDecimal(0);
                                bdx["lux_plpremium"] = Convert.ToDecimal(0);
                            }
                            bdx["lux_newrenewalaprp"] = new OptionSetValue(972970003);
                        }
                        else if (BDXType.Get(executionContext) == "Cancelation")
                        {
                            var cancellationDate = DateTime.Now;
                            bdx["lux_cancellationreason"] = policy.Attributes.Contains("lux_cancellationreason") == true ? policy.FormattedValues["lux_cancellationreason"] : "";
                            if (policy.Contains("lux_cancellationdate"))
                            {
                                cancellationDate = Convert.ToDateTime(policy.FormattedValues["lux_cancellationdate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            }

                            if (policy.Contains("lux_typeofcancellation")) //Mid Term
                            {
                                decimal ELRefundPremium = policy.Attributes.Contains("lux_elrefundamount") == true ? policy.GetAttributeValue<Money>("lux_elrefundamount").Value : 0;
                                decimal PLRefundPremium = policy.Attributes.Contains("lux_polrefundamount") == true ? policy.GetAttributeValue<Money>("lux_polrefundamount").Value : 0;
                                decimal RefundPremium = policy.Attributes.Contains("lux_refundamount") == true ? policy.GetAttributeValue<Money>("lux_refundamount").Value : 0;
                                decimal MDRefundPremium = policy.Attributes.Contains("lux_porefundamount") == true ? policy.GetAttributeValue<Money>("lux_porefundamount").Value : 0;

                                //var dateDiff = Convert.ToDateTime(policy.FormattedValues["lux_cancellationdate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat) - Convert.ToDateTime(policy.FormattedValues["lux_policystartdate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                                //var usedELGross = new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value * dateDiff.Days / 365;
                                //var refundELGross = new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value - usedELGross : 0).Value;

                                //var usedPLGross = new Money(policy.Attributes.Contains("lux_polgross") == true ? policy.GetAttributeValue<Money>("lux_polgross").Value : 0).Value * dateDiff.Days / 365;
                                //var refundPLGross = new Money(policy.Attributes.Contains("lux_polgross") == true ? policy.GetAttributeValue<Money>("lux_polgross").Value - usedPLGross : 0).Value;

                                if (PremiseNumber == 1)
                                {
                                    bdx["lux_mdpremium"] = -MDRefundPremium;
                                    bdx["lux_mdipt"] = -MDRefundPremium * Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.GetAttributeValue<decimal>("lux_iptrate") : 12) / 100;

                                    bdx["lux_combinedpremium"] = -RefundPremium;
                                    bdx["lux_elpremium"] = -ELRefundPremium;
                                    bdx["lux_plpremium"] = -PLRefundPremium;
                                    bdx["lux_liabsipt"] = -(ELRefundPremium + PLRefundPremium) * Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.GetAttributeValue<decimal>("lux_iptrate") : 12) / 100;

                                    bdx["lux_mdbrokerage"] = grossCommRate;
                                    bdx["lux_mdbrokeragefigure"] = -MDRefundPremium * grossCommRate / 100;

                                    bdx["lux_elplbrokerage"] = grossCommRate;
                                    bdx["lux_elbrokerage"] = -(ELRefundPremium * grossCommRate / 100);
                                    bdx["lux_plbrokerage"] = -(PLRefundPremium * grossCommRate / 100);

                                    bdx["lux_netpremiumtounderwritersinctax"] = -(RefundPremium + RefundPremium * iptRate / 100 - RefundPremium * grossCommRate / 100);
                                    bdx["lux_grosspremiumexclterrorism"] = -RefundPremium;
                                }
                                else
                                {
                                    bdx["lux_elpremium"] = Convert.ToDecimal(0);
                                    bdx["lux_plpremium"] = Convert.ToDecimal(0);
                                }
                            }
                            //else if (policy.Contains("lux_typeofcancellation") && policy.GetAttributeValue<OptionSetValue>("lux_typeofcancellation").Value == 972970002) //Full
                            //{
                            //    var totalRefundPremium = new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value + new Money(policy.Attributes.Contains("lux_plgross") == true ? policy.GetAttributeValue<Money>("lux_plgross").Value : 0).Value;
                            //    if (PremiseNumber == 1)
                            //    {
                            //        bdx["lux_combinedpremium"] = -totalRefundPremium;
                            //        bdx["lux_elpremium"] = -(new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value);
                            //        bdx["lux_plpremium"] = -(new Money(policy.Attributes.Contains("lux_polgross") == true ? policy.GetAttributeValue<Money>("lux_polgross").Value : 0).Value);
                            //        bdx["lux_liabsipt"] = -(totalRefundPremium * Convert.ToDecimal(policy.Attributes.Contains("lux_iptrate") == true ? policy.GetAttributeValue<decimal>("lux_iptrate") : 12) / 100);
                            //        bdx["lux_elbrokerage"] = -(new Money(policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0).Value * grossCommRate / 100);
                            //        bdx["lux_plbrokerage"] = -(new Money(policy.Attributes.Contains("lux_polgross") == true ? policy.GetAttributeValue<Money>("lux_polgross").Value : 0).Value * grossCommRate / 100);
                            //        bdx["lux_netpremiumtounderwritersinctax"] = -(totalRefundPremium + totalRefundPremium * iptRate / 100 - totalRefundPremium * grossCommRate / 100);
                            //        bdx["lux_grosspremiumexclterrorism"] = -totalRefundPremium;
                            //    }
                            //    else
                            //    {
                            //        bdx["lux_elpremium"] = Convert.ToDecimal(0);
                            //        bdx["lux_plpremium"] = Convert.ToDecimal(0);
                            //    }
                            //}

                            bdx["lux_newrenewalaprp"] = new OptionSetValue(972970004);
                        }

                        bdx["lux_iptrate"] = iptRate;

                        var excessFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_applicationexcess'>
                                                <attribute name='lux_name' />
                                                <attribute name='lux_excessvalue' />
                                                <attribute name='lux_applicationexcessid' />
                                                <order attribute='lux_name' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='lux_application' operator='eq' uitype='lux_application' value='{appln.Id}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                        var Excess = service.RetrieveMultiple(new FetchExpression(excessFetch)).Entities;
                        var FireExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Fire, Lightning, Explosion, Aircraft");
                        var SubsidenceExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Subsidence, Landslip & Heave");
                        var EOWExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Escape of Water");
                        var TheftExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Theft");
                        var LiabilityExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Third Party Property Damage");

                        bdx["lux_fireexcess"] = FireExcess != null ? Convert.ToInt32(FireExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                        bdx["lux_subsidenceexcess"] = SubsidenceExcess != null ? Convert.ToInt32(SubsidenceExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                        bdx["lux_eowexcess"] = EOWExcess != null ? Convert.ToInt32(EOWExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                        bdx["lux_theftexcess"] = TheftExcess != null ? Convert.ToInt32(TheftExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                        bdx["lux_liabilityexcess"] = LiabilityExcess != null ? Convert.ToInt32(LiabilityExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;

                        bdx["lux_constructionclass"] = "";

                        if (item.Attributes.Contains("lux_numberofstoreys"))
                        {
                            bdx["lux_numberofstories"] = Convert.ToInt32(item.Attributes["lux_numberofstoreys"]);
                        }
                        bdx["lux_yearbuilt"] = item.Contains("lux_yearofconstruction") ? item.GetAttributeValue<int>("lux_yearofconstruction").ToString().Replace(",", "") : "";

                        bdx["lux_terrorismyn"] = "N";

                        bdx["lux_information"] = appln.Attributes.Contains("new_additionalinformationappearondocument") ? appln.Attributes["new_additionalinformationappearondocument"].ToString() : "";

                        bdx["lux_bordereautype"] = new OptionSetValue(972970003);
                        if (appln.Attributes.Contains("lux_wasthisriskreferredtoinsurers") && appln.FormattedValues["lux_wasthisriskreferredtoinsurers"] == "Yes")
                        {
                            bdx["lux_wastheriskreferredtoinsurers"] = true;
                            bdx["lux_referraltosyndicate"] = true;
                        }
                        else
                        {
                            bdx["lux_wastheriskreferredtoinsurers"] = false;
                            bdx["lux_referraltosyndicate"] = false;
                        }
                        bdx["lux_floodperil"] = false;
                        bdx["lux_subsidenceperil"] = false;
                        service.Create(bdx);
                    }
                }
            }
        }
    }
}