﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CustomWorkflows
{
    public class SetPremiseNumbers : CodeActivity
    {
        #region "Parameter Definition"

        [Input("Application")]
        [ReferenceTarget("lux_application")]
        public InArgument<EntityReference> Application { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference appref = Application.Get<EntityReference>(executionContext);
            Entity application = service.Retrieve("lux_application", appref.Id, new ColumnSet(true));

            var productId = application.GetAttributeValue<EntityReference>("lux_product").Id;

            if (productId == new Guid("bdeea3ef-9483-ea11-a811-000d3a0bad7c"))
            {
                var landownersFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_landownersliability'>
                                            <attribute name='lux_landownersliabilityid' />
                                            <attribute name='lux_name' />
                                            <attribute name='createdon' />
                                            <attribute name='lux_premisenumber' />
                                            <order attribute='createdon' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_application' operator='eq' uitype='lux_application' value='{Application.Get(executionContext).Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                var landowners = service.RetrieveMultiple(new FetchExpression(landownersFetch)).Entities;
                if (landowners.Count > 0)
                {
                    int premiseCount = 1;
                    foreach (var item in landowners)
                    {
                        Entity land = service.Retrieve("lux_landownersliability", item.Id, new ColumnSet(true));
                        land["lux_premisenumber"] = premiseCount;
                        service.Update(land);
                        premiseCount++;
                    }
                }
            }
            else if (productId == new Guid("2f4e1a03-9583-ea11-a811-000d3a0bad7c"))
            {
                var propertyownersFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyowners'>
                                                <attribute name='lux_propertyownersid' />
                                                <attribute name='lux_name' />
                                                <attribute name='createdon' />
                                                <attribute name='lux_premisenumber' />
                                                <order attribute='createdon' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_application' operator='eq' uitype='lux_application' value='{Application.Get(executionContext).Id}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                var propertyowners = service.RetrieveMultiple(new FetchExpression(propertyownersFetch)).Entities;
                if (propertyowners.Count > 0)
                {
                    int premiseCount = 1;
                    foreach (var item in propertyowners)
                    {
                        Entity property = service.Retrieve("lux_propertyowners", item.Id, new ColumnSet(true));
                        property["lux_premisenumber"] = premiseCount;
                        service.Update(property);
                        premiseCount++;
                    }
                }
            }
            else if (productId == new Guid("258b36d1-9483-ea11-a811-000d3a0bad7c"))
            {
                var commercialCombinedFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_commercialcombined'>
                                                <attribute name='lux_commercialcombinedid' />
                                                <attribute name='lux_name' />
                                                <attribute name='createdon' />
                                                <order attribute='createdon' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_application' operator='eq' uiname='MG/3/077/1' uitype='lux_application' value='{Application.Get(executionContext).Id}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                var commercialCombined = service.RetrieveMultiple(new FetchExpression(commercialCombinedFetch)).Entities;
                if (commercialCombined.Count > 0)
                {
                    int premiseCount = 1;
                    foreach (var item in commercialCombined)
                    {
                        Entity commercial = service.Retrieve("lux_commercialcombined", item.Id, new ColumnSet(true));
                        commercial["lux_premisenumber"] = premiseCount;
                        service.Update(commercial);
                        premiseCount++;
                    }
                }
            }
        }
    }
}

