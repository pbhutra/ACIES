﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Globalization;

namespace CustomWorkflows
{
    public class CheckDayLightSavingTime : CodeActivity
    {
        [Input("PolicyStartDate")]
        public InArgument<DateTime> PolicyStartDate { get; set; }

        [Input("PolicyEndDate")]
        public InArgument<DateTime> PolicyEndDate { get; set; }

        [Output("IsDayLightSavingTimePolicyStartDate")]
        public OutArgument<bool> IsDayLightSavingTimePolicyStartDate { get; set; }

        [Output("IsDayLightSavingTimePolicyEndDate")]
        public OutArgument<bool> IsDayLightSavingTimePolicyEndDate { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            TimeZoneInfo tst = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");

            TimeZoneInfo gmtZone = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");
            TimeZoneInfo utcZone = TimeZoneInfo.FindSystemTimeZoneById("UTC");

            var gmtStDT = TimeZoneInfo.ConvertTime(PolicyStartDate.Get(executionContext), utcZone, gmtZone);
            var gmtEndDT = TimeZoneInfo.ConvertTime(PolicyEndDate.Get(executionContext), utcZone, gmtZone);

            IsDayLightSavingTimePolicyStartDate.Set(executionContext, tst.IsDaylightSavingTime(gmtStDT));
            IsDayLightSavingTimePolicyEndDate.Set(executionContext, tst.IsDaylightSavingTime(gmtEndDT));
        }

        public static void ssss()
        {
            TimeZoneInfo tst = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");
            DateTime PolicyStartDate = DateTime.Parse("10/01/2020 00:01", CultureInfo.GetCultureInfo("en-gb"));
            bool sds = tst.IsDaylightSavingTime(PolicyStartDate);
        }
    }
}