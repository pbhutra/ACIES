﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class UpdateInstallments : CodeActivity
    {
        [Input("Installment")]
        [ReferenceTarget("lux_installmentschedule")]
        public InArgument<EntityReference> Installment { get; set; }

        [Input("Policy")]
        [ReferenceTarget("lux_policy")]
        public InArgument<EntityReference> Policy { get; set; }

        [Input("Created On")]
        public InArgument<DateTime> CreatedOn { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_installmentschedule'>
                                <attribute name='createdon' />
                                <attribute name='lux_tax' />
                                <attribute name='lux_name' />
                                <attribute name='lux_netpremium' />
                                <attribute name='lux_grosspremium' />
                                <attribute name='lux_customerpayable' />
                                <attribute name='lux_customer' />
                                <attribute name='lux_commission' />
                                <attribute name='statuscode' />
                                <attribute name='lux_installmentscheduleid' />
                                <attribute name='lux_policyinstallmenttypeinsly' />
                                <order attribute='createdon' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='createdon' operator='on' value='{this.CreatedOn.Get(executionContext)}' />
                                  <condition attribute='lux_policyinstallmenttypeinsly' operator='eq' value='972970002' />
                                </filter>
                                <link-entity name='lux_policy' from='lux_policyid' to='lux_policy' link-type='inner' alias='pol'>
                                  <attribute name='lux_policynumber' />
                                  <filter type='and'>
                                    <condition attribute='lux_policyid' operator='eq' uiname='10651744' uitype='lux_policy' value='{this.Policy.Get(executionContext).Id}' />
                                  </filter>
                                </link-entity>
                              </entity>
                            </fetch>";

            tracingService.Trace(fetch);

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var installment = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];//FirstOrDefault(x => Convert.ToDateTime(x.Attributes["createdon"]) == this.CreatedOn.Get(executionContext));
                if (installment != null)
                {
                    Entity feeInst = service.Retrieve("lux_installmentschedule", installment.Id, new ColumnSet(true));
                    tracingService.Trace(feeInst["lux_name"].ToString());
                    Entity mainInst = service.Retrieve("lux_installmentschedule", Installment.Get(executionContext).Id, new ColumnSet(true));
                    mainInst["lux_fees"] = feeInst.Contains("lux_grosspremium") == true ? feeInst.GetAttributeValue<Money>("lux_grosspremium") : new Money(0);
                    service.Update(mainInst);
                    feeInst["lux_isdeleted"] = true;
                    service.Update(feeInst);
                }
            }
        }
    }
}
