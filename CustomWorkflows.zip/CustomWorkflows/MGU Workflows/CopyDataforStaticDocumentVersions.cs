﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CopyDataforStaticDocumentVersions : CodeActivity
    {
        [Input("Old Document")]
        [ReferenceTarget("ptm_mscrmaddons_dcptemplates")]
        [RequiredArgument]
        public InArgument<EntityReference> OldDocument { get; set; }

        [Input("New Document")]
        [ReferenceTarget("ptm_mscrmaddons_dcptemplates")]
        [RequiredArgument]
        public InArgument<EntityReference> NewDocument { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference olddocref = OldDocument.Get<EntityReference>(executionContext);
            Entity doc = service.Retrieve("ptm_mscrmaddons_dcptemplates", olddocref.Id, new ColumnSet(true));

            EntityReference newdocref = NewDocument.Get<EntityReference>(executionContext);
            Entity newdoc = service.Retrieve("ptm_mscrmaddons_dcptemplates", newdocref.Id, new ColumnSet(true));

            var binderFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                  <entity name='lux_binder'>
                                    <attribute name='lux_name' />
                                    <attribute name='createdon' />
                                    <attribute name='lux_binderid' />
                                    <order attribute='lux_name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                    </filter>
                                    <link-entity name='lux_ptm_mscrmaddons_dcptemplates_lux_binder' from='lux_binderid' to='lux_binderid' visible='false' intersect='true'>
                                      <link-entity name='ptm_mscrmaddons_dcptemplates' from='ptm_mscrmaddons_dcptemplatesid' to='ptm_mscrmaddons_dcptemplatesid' alias='ab'>
                                        <filter type='and'>
                                          <condition attribute='ptm_mscrmaddons_dcptemplatesid' operator='eq' uitype='ptm_mscrmaddons_dcptemplates' value='{doc.Id}' />
                                        </filter>
                                      </link-entity>
                                    </link-entity>
                                  </entity>
                                </fetch>";

            var binder = service.RetrieveMultiple(new FetchExpression(binderFetch)).Entities;
            if (binder.Count > 0)
            {
                EntityReferenceCollection relatedEntities = new EntityReferenceCollection();
                foreach (var item in binder)
                {
                    relatedEntities.Add(new EntityReference("lux_binder", item.Id));
                }
                AssociateRequest assreq = new AssociateRequest();
                assreq.Target = new EntityReference("ptm_mscrmaddons_dcptemplates", newdoc.Id);
                assreq.RelatedEntities = relatedEntities;
                assreq.Relationship = new Relationship("lux_ptm_mscrmaddons_dcptemplates_lux_binder");
                AssociateResponse response = (AssociateResponse)service.Execute(assreq);
            }

            var productFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                      <entity name='product'>
                                        <attribute name='name' />
                                        <attribute name='productid' />
                                        <attribute name='productnumber' />
                                        <attribute name='description' />
                                        <attribute name='statecode' />
                                        <attribute name='productstructure' />
                                        <order attribute='productnumber' descending='false' />
                                        <link-entity name='lux_ptm_mscrmaddons_dcptemplates_product' from='productid' to='productid' visible='false' intersect='true'>
                                          <link-entity name='ptm_mscrmaddons_dcptemplates' from='ptm_mscrmaddons_dcptemplatesid' to='ptm_mscrmaddons_dcptemplatesid' alias='ad'>
                                            <filter type='and'>
                                              <condition attribute='ptm_mscrmaddons_dcptemplatesid' operator='eq' uitype='ptm_mscrmaddons_dcptemplates' value='{doc.Id}' />
                                            </filter>
                                          </link-entity>
                                        </link-entity>
                                      </entity>
                                    </fetch>";

            var product = service.RetrieveMultiple(new FetchExpression(productFetch)).Entities;
            if (product.Count > 0)
            {
                EntityReferenceCollection relatedEntities = new EntityReferenceCollection();
                foreach (var item in product)
                {
                    relatedEntities.Add(new EntityReference("product", item.Id));
                }
                AssociateRequest assreq = new AssociateRequest();
                assreq.Target = new EntityReference("ptm_mscrmaddons_dcptemplates", newdoc.Id);
                assreq.RelatedEntities = relatedEntities;
                assreq.Relationship = new Relationship("lux_ptm_mscrmaddons_dcptemplates_product");
                AssociateResponse response = (AssociateResponse)service.Execute(assreq);
            }
        }
    }
}