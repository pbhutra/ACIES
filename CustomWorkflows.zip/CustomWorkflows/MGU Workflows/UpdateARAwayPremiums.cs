﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class UpdateARAwayPremiums : CodeActivity
    {
        [Input("Application")]
        [ReferenceTarget("lux_application")]
        public InArgument<EntityReference> Application { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_commercialcombined'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_application' />
                                <attribute name='lux_commercialcombinedid' />
                                <attribute name='lux_scientificsurveyterritory' />
                                <attribute name='lux_scientificsurveyrate' />
                                <attribute name='lux_scientificsurveypremium' />
                                <attribute name='lux_scientificsurveyloading' />
                                <attribute name='lux_scientificsurvey' />
                                <attribute name='lux_portabletoolsequipmentterritory' />
                                <attribute name='lux_portabletoolsequipmentrate' />
                                <attribute name='lux_portabletoolsequipmentpremium' />
                                <attribute name='lux_portabletoolsequipmentloading' />
                                <attribute name='lux_portabletoolsequipment' />
                                <attribute name='lux_otherterritory' />
                                <attribute name='lux_otherrate' />
                                <attribute name='lux_otherpremium' />
                                <attribute name='lux_otherloading' />
                                <attribute name='lux_other' />
                                <attribute name='lux_laptopsmobilesterritory' />
                                <attribute name='lux_laptopsmobilesrate' />
                                <attribute name='lux_laptopsmobilespremium' />
                                <attribute name='lux_laptopsmobilesloading' />
                                <attribute name='lux_laptopsmobiles' />
                                <attribute name='lux_audiovisualphotographicterritory' />
                                <attribute name='lux_audiovisualphotographicrate' />
                                <attribute name='lux_audiovisualphotographicpremium' />
                                <attribute name='lux_audiovisualphotographicloading' />
                                <attribute name='lux_audiovisualphotographic' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_application' operator='eq' uiname='MGI/14/081/1' uitype='lux_application' value='{Application.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            tracingService.Trace(fetch);

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                decimal Laptops = 0;
                decimal LaptopsRate = 0;
                decimal LaptopsPremium = 0;
                decimal LaptopsLoading = 0;
                var LaptopsTerritory = 0;

                decimal Audio = 0;
                decimal AudioRate = 0;
                decimal AudioPremium = 0;
                decimal AudioLoading = 0;
                var AudioTerritory = 0;

                decimal Scientific = 0;
                decimal ScientificRate = 0;
                decimal ScientificPremium = 0;
                decimal ScientificLoading = 0;
                var ScientificTerritory = 0;

                decimal Portable = 0;
                decimal PortableRate = 0;
                decimal PortablePremium = 0;
                decimal PortableLoading = 0;
                var PortableTerritory = 0;

                decimal Other = 0;
                decimal OtherRate = 0;
                decimal OtherPremium = 0;
                decimal OtherLoading = 0;
                var OtherTerritory = 0;
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    Laptops += item.Contains("lux_laptopsmobiles") == true ? item.GetAttributeValue<Money>("lux_laptopsmobiles").Value : 0;
                    Audio += item.Contains("lux_audiovisualphotographic") == true ? item.GetAttributeValue<Money>("lux_audiovisualphotographic").Value : 0;
                    Scientific += item.Contains("lux_scientificsurvey") == true ? item.GetAttributeValue<Money>("lux_scientificsurvey").Value : 0;
                    Portable += item.Contains("lux_portabletoolsequipment") == true ? item.GetAttributeValue<Money>("lux_portabletoolsequipment").Value : 0;
                    Other += item.Contains("lux_other") == true ? item.GetAttributeValue<Money>("lux_other").Value : 0;

                    LaptopsRate += item.Contains("lux_laptopsmobilesrate") == true ? item.GetAttributeValue<decimal>("lux_laptopsmobilesrate") : 0;
                    AudioRate += item.Contains("lux_audiovisualphotographicrate") == true ? item.GetAttributeValue<decimal>("lux_audiovisualphotographicrate") : 0;
                    ScientificRate += item.Contains("lux_scientificsurveyrate") == true ? item.GetAttributeValue<decimal>("lux_scientificsurveyrate") : 0;
                    PortableRate += item.Contains("lux_portabletoolsequipmentrate") == true ? item.GetAttributeValue<decimal>("lux_portabletoolsequipmentrate") : 0;
                    OtherRate += item.Contains("lux_otherrate") == true ? item.GetAttributeValue<decimal>("lux_otherrate") : 0;

                    //LaptopsPremium += item.Contains("lux_laptopsmobilespremium") == true ? item.GetAttributeValue<Money>("lux_laptopsmobilespremium").Value : 0;
                    //AudioPremium += item.Contains("lux_audiovisualphotographicpremium") == true ? item.GetAttributeValue<Money>("lux_audiovisualphotographicpremium").Value : 0;
                    //ScientificPremium += item.Contains("lux_scientificsurveypremium") == true ? item.GetAttributeValue<Money>("lux_scientificsurveypremium").Value : 0;
                    //PortablePremium += item.Contains("lux_portabletoolsequipmentpremium") == true ? item.GetAttributeValue<Money>("lux_portabletoolsequipmentpremium").Value : 0;
                    //OtherPremium += item.Contains("lux_otherpremium") == true ? item.GetAttributeValue<Money>("lux_otherpremium").Value : 0;

                    LaptopsLoading += item.Contains("lux_laptopsmobilesloading") == true ? item.GetAttributeValue<decimal>("lux_laptopsmobilesloadingloading") : 0;
                    AudioLoading += item.Contains("lux_audiovisualphotographicloading") == true ? item.GetAttributeValue<decimal>("lux_audiovisualphotographicloading") : 0;
                    ScientificLoading += item.Contains("lux_scientificsurveyloading") == true ? item.GetAttributeValue<decimal>("lux_scientificsurveyloading") : 0;
                    PortableLoading += item.Contains("lux_portabletoolsequipmentloading") == true ? item.GetAttributeValue<decimal>("lux_portabletoolsequipmentloading") : 0;
                    OtherLoading += item.Contains("lux_otherloading") == true ? item.GetAttributeValue<decimal>("lux_otherloading") : 0;

                    if (LaptopsTerritory == 0)
                        LaptopsTerritory = item.Contains("lux_laptopsmobilesterritory") == true ? item.GetAttributeValue<OptionSetValue>("lux_laptopsmobilesterritory").Value : 0;
                    if (AudioTerritory == 0)
                        AudioTerritory = item.Contains("lux_audiovisualphotographicterritory") == true ? item.GetAttributeValue<OptionSetValue>("lux_audiovisualphotographicterritory").Value : 0;
                    if (ScientificTerritory == 0)
                        ScientificTerritory = item.Contains("lux_scientificsurveyterritory") == true ? item.GetAttributeValue<OptionSetValue>("lux_scientificsurveyterritory").Value : 0;
                    if (PortableTerritory == 0)
                        PortableTerritory = item.Contains("lux_portabletoolsequipmentterritory") == true ? item.GetAttributeValue<OptionSetValue>("lux_portabletoolsequipmentterritory").Value : 0;
                    if (OtherTerritory == 0)
                        OtherTerritory = item.Contains("lux_otherterritory") == true ? item.GetAttributeValue<OptionSetValue>("lux_otherterritory").Value : 0;
                }

                Entity appln = service.Retrieve("lux_application", Application.Get(executionContext).Id, new ColumnSet(true));
                appln["lux_laptopsmobiles"] = new Money(Laptops);
                appln["lux_laptopsmobilesbaserate"] = LaptopsRate;
                appln["lux_laptopsmobilesloading"] = LaptopsLoading;
                if (LaptopsTerritory != 0)
                    appln["lux_laptopsmobilesterritory"] = new OptionSetValue(LaptopsTerritory);

                appln["lux_audiovisualphotographic"] = new Money(Audio);
                appln["lux_audiovisualphotographicbaserate"] = AudioRate;
                appln["lux_audiovisualphotographicloading"] = AudioLoading;
                if (AudioTerritory != 0)
                    appln["lux_audiovisualphotographicterritory"] = new OptionSetValue(AudioTerritory);

                appln["lux_scientificsurvey"] = new Money(Scientific);
                appln["lux_scientificsurveybaserate"] = ScientificRate;
                appln["lux_scientificsurveyloading"] = ScientificLoading;
                if (ScientificTerritory != 0)
                    appln["lux_scientificsurveyterritory"] = new OptionSetValue(ScientificTerritory);

                appln["lux_portabletoolsequipment"] = new Money(Portable);
                appln["lux_portabletoolsequipmentbaserate"] = PortableRate;
                appln["lux_portabletoolsequipmentloading"] = PortableLoading;
                if (PortableTerritory != 0)
                    appln["lux_portabletoolsequipmentterritory"] = new OptionSetValue(PortableTerritory);

                appln["lux_other"] = new Money(Other);
                appln["lux_otherbaserate"] = OtherRate;
                appln["lux_otherloading"] = OtherLoading;
                if (OtherTerritory != 0)
                    appln["lux_otherterritory"] = new OptionSetValue(OtherTerritory);

                service.Update(appln);
            }
        }
    }
}
