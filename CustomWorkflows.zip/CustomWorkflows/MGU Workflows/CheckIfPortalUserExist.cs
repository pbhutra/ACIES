﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CheckIfPortalUserExist : CodeActivity
    {
        [RequiredArgument]
        [Input("BrokerName")]
        public InArgument<string> BrokerName { get; set; }

        [RequiredArgument]
        [Input("BrokerEmail")]
        public InArgument<string> BrokerEmail { get; set; }

        [Output("IsExist")]
        public OutArgument<bool> IsExist { get; set; }

        [Output("Portal User")]
        [ReferenceTarget("lux_portalusers")]
        public OutArgument<EntityReference> PortalUser { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_portalusers'>
                                <attribute name='lux_portalusersid' />
                                <attribute name='lux_name' />
                                <attribute name='lux_email' />
                                <attribute name='createdon' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='lux_name' operator='eq' value='{BrokerName.Get(executionContext).ToString().Trim()}' />
                                  <condition attribute='lux_email' operator='eq' value='{BrokerEmail.Get(executionContext).ToString().Trim()}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                this.IsExist.Set(executionContext, true);
                var user = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                PortalUser.Set(executionContext, user.ToEntityReference());
            }
            else
            {
                this.IsExist.Set(executionContext, false);
            }
        }
    }
}
