﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata.Query;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using msdyncrmWorkflowTools;
using System.ServiceModel;

namespace CustomWorkflows
{
    public class UpdateUnderwriter : CodeActivity
    {
        [Input("Application")]
        [ReferenceTarget("lux_application")]
        [RequiredArgument]
        public InArgument<EntityReference> Application { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            RetrieveRecordChangeHistoryRequest changeRequest = new RetrieveRecordChangeHistoryRequest();
            changeRequest.Target = new EntityReference("lux_application", Application.Get(executionContext).Id);
            RetrieveRecordChangeHistoryResponse changeResponse =
            (RetrieveRecordChangeHistoryResponse)service.Execute(changeRequest);

            AuditDetailCollection auditDetailCollection = changeResponse.AuditDetailCollection;

            foreach (AuditDetail attrAuditDetail in auditDetailCollection.AuditDetails.Where(x => Convert.ToDateTime(x.AuditRecord.Attributes["createdon"]).ToShortDateString() == DateTime.Now.AddDays(-19).ToShortDateString() && x.AuditRecord.FormattedValues["action"] == "Delete"))
            {
                var auditRecord = attrAuditDetail.AuditRecord;
                var detailType = attrAuditDetail.GetType();
                if (detailType == typeof(AttributeAuditDetail))
                {
                    AttributeAuditDetail attributeDetail = (AttributeAuditDetail)attrAuditDetail;
                    foreach (KeyValuePair<String, object> attribute in attributeDetail.OldValue.Attributes)
                    {
                        if (attributeDetail.OldValue.Attributes.Contains("lux_mgunderwriter"))
                        {
                            if (attributeDetail.OldValue.GetAttributeValue<EntityReference>("lux_mgunderwriter").Id == new Guid("11f2f85a-f661-eb11-89f5-0022483f12ba"))
                            {
                                var appln = new Entity("lux_application", Application.Get(executionContext).Id);
                                appln["lux_mgunderwriter"] = new EntityReference("lux_portalusers", new Guid("89513f5d-49c7-ea11-a812-000d3a0ba99a"));
                                service.Update(appln);
                            }
                        }
                    }
                }
            }
        }
    }
}
