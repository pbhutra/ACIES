﻿using CustomWorkflows.Model;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System.Activities;
using System.Collections.Generic;
using System.Linq;

namespace CustomWorkflows
{
    public class ConcatenateCustomersNameforDocument : CodeActivity
    {
        [Input("Application")]
        [ReferenceTarget("lux_application")]
        [RequiredArgument]
        public InArgument<EntityReference> Application { get; set; }

        [Output("Concatenated Name")]
        public OutArgument<string> ConcatenatedName { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference appref = Application.Get<EntityReference>(executionContext);
            Entity appln = service.Retrieve("lux_application", appref.Id, new ColumnSet(true));

            List<CustomerModel> customers = new List<CustomerModel>();
            for (int i = 1; i <= 10; i++)
            {
                CustomerModel model = new CustomerModel();
                if (i == 1)
                {
                    if (appln.Attributes.Contains("lux_customertype") == true && (appln.Attributes.Contains("lux_customername1") == true))
                    {
                        model.CustomerType = appln.Attributes.Contains("lux_customertype") ? appln.FormattedValues["lux_customertype"].ToString() : "";
                        model.CustomerName = appln.Attributes.Contains("lux_customername1") ? appln.Attributes["lux_customername1"].ToString() : "";
                        model.CustomerNumber = i;
                        customers.Add(model);
                    }
                }
                else
                {
                    if (appln.Attributes.Contains("lux_customertype" + i) == true && (appln.Attributes.Contains("lux_customername" + i) == true))
                    {
                        model.CustomerType = appln.Attributes.Contains("lux_customertype" + i) ? appln.FormattedValues["lux_customertype" + i].ToString() : "";
                        model.CustomerName = appln.Attributes.Contains("lux_customername" + i) ? appln.Attributes["lux_customername" + i].ToString() : "";
                        model.CustomerNumber = i;
                        customers.Add(model);
                    }
                }
            }
            string ConcatenatedName = "";
            foreach (var item in customers.Where(x => x.CustomerType == "Individual").OrderBy(x => x.CustomerNumber))
            {
                var Name = ConcatenatedName == "" ? item.CustomerName : ", " + item.CustomerName;
                Name = Name.Trim().Replace("  ", " ");
                ConcatenatedName += Name;
            }
            foreach (var item in customers.Where(x => x.CustomerType == "Company").OrderBy(x => x.CustomerNumber))
            {
                if (item.CustomerName != "")
                {
                    if (ConcatenatedName == "")
                    {
                        ConcatenatedName += item.CustomerName;
                    }
                    else
                    {
                        ConcatenatedName += ", " + item.CustomerName;
                    }
                }
            }
            this.ConcatenatedName.Set(executionContext, ConcatenatedName);
        }
    }
}