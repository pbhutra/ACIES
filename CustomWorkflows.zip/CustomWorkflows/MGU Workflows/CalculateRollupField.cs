﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Crm.Sdk.Messages;
using System.ServiceModel.Description;
using System.Net;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;

namespace CustomWorkflows
{
    public class CalculateRollupField : CodeActivity
    {
        #region "Parameter Definition"
        [RequiredArgument]
        [Input("FieldName")]
        [Default("")]
        public InArgument<String> FieldName { get; set; }

        [RequiredArgument]
        [Input("Parent Record URL")]
        [ReferenceTarget("")]
        public InArgument<String> ParentRecordURL { get; set; }

        [Output("CalculatedAmount")]
        public OutArgument<Money> CalculatedAmount { get; set; }
        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {

            #region "Load CRM Service from context"

            Common objCommon = new Common(executionContext);
            objCommon.tracingService.Trace("Load CRM Service from context --- OK");
            #endregion

            #region "Read Parameters"
            String _FieldName = this.FieldName.Get(executionContext);
            objCommon.tracingService.Trace("_FieldName=" + _FieldName);
            String _ParentRecordURL = this.ParentRecordURL.Get(executionContext);

            if (_ParentRecordURL == null || _ParentRecordURL == "")
            {
                return;
            }
            objCommon.tracingService.Trace("_ParentRecordURL=" + _ParentRecordURL);
            string[] urlParts = _ParentRecordURL.Split("?".ToArray());
            string[] urlParams = urlParts[1].Split("&".ToCharArray());

            string ParentObjectTypeCode = urlParams[0].Replace("etc=", "");
            string ParentId = urlParams[1].Replace("id=", "");
            objCommon.tracingService.Trace("ParentObjectTypeCode=" + ParentObjectTypeCode + "--ParentId=" + ParentId);
            #endregion


            #region "CalculateRollupField Execution"
            string ParentEntityName = objCommon.sGetEntityNameFromCode(ParentObjectTypeCode, objCommon.service);
            CalculateRollupFieldRequest calculateRollup = new CalculateRollupFieldRequest();
            calculateRollup.FieldName = _FieldName;
            calculateRollup.Target = new EntityReference(ParentEntityName, new Guid(ParentId));
            CalculateRollupFieldResponse resp = (CalculateRollupFieldResponse)objCommon.service.Execute(calculateRollup);
            Entity QuoteEntity = resp.Entity;
            var pre = ((Money)QuoteEntity.Attributes[_FieldName]);
            this.CalculatedAmount.Set(executionContext, pre);
            #endregion
        }

        public static void adasds()
        {
            ClientCredentials clientCredentials = new ClientCredentials();
            clientCredentials.UserName.UserName = "support@mgucrm.onmicrosoft.com"; //HttpContext.Current.Request.Form["UserName"];
            clientCredentials.UserName.Password = "nPmv88~4"; //HttpContext.Current.Request.Form["Password"];

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            // Copy and Paste Organization Service Endpoint Address URL
            var service = (IOrganizationService)new OrganizationServiceProxy(new Uri("https://mgunderwriting.api.crm11.dynamics.com/XRMServices/2011/Organization.svc"),
             null, clientCredentials, null);

            var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_application'>
                                <attribute name='lux_quotenumber' />
                                <attribute name='statuscode' />
                                <attribute name='lux_applicationtype' />
                                <attribute name='lux_product' />
                                <attribute name='lux_mgunderwriter' />
                                <attribute name='createdon' />
                                <attribute name='lux_proposedinceptiondate' />
                                <attribute name='lux_broker' />
                                <attribute name='lux_customername1' />
                                <attribute name='lux_applicationid' />
                                <order attribute='lux_quotenumber' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_mgunderwriter' operator='null' />
                                  <condition attribute='statuscode' operator='in'>
                                    <value>972970009</value>
                                    <value>972970000</value>
                                  </condition>
                                  <condition attribute='lux_proposedinceptiondate' operator='on-or-after' value='2019-01-01' />
                                </filter>
                              </entity>
                            </fetch>";
            var count = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count().ToString();
            var rowno = 1;
            if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count() > 0)
            {
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch1)).Entities)
                {
                    RetrieveRecordChangeHistoryRequest changeRequest = new RetrieveRecordChangeHistoryRequest();
                    changeRequest.Target = new EntityReference("lux_application", item.Id);
                    RetrieveRecordChangeHistoryResponse changeResponse =
                    (RetrieveRecordChangeHistoryResponse)service.Execute(changeRequest);

                    AuditDetailCollection auditDetailCollection = changeResponse.AuditDetailCollection;

                    foreach (AuditDetail attrAuditDetail in auditDetailCollection.AuditDetails.Where(x => Convert.ToDateTime(x.AuditRecord.Attributes["createdon"]).ToShortDateString() == DateTime.Now.AddDays(-71).ToShortDateString() && x.AuditRecord.FormattedValues["action"] == "Delete"))
                    //foreach (AuditDetail attrAuditDetail in auditDetailCollection.AuditDetails.Where(x => x.AuditRecord.FormattedValues["action"] == "Update"))
                    {
                        var auditRecord = attrAuditDetail.AuditRecord;
                        var detailType = attrAuditDetail.GetType();
                        if (detailType == typeof(AttributeAuditDetail))
                        {
                            AttributeAuditDetail attributeDetail = (AttributeAuditDetail)attrAuditDetail;
                            foreach (KeyValuePair<String, object> attribute in attributeDetail.OldValue.Attributes)
                            {
                                if (attributeDetail.OldValue.Attributes.Contains("lux_mgunderwriter"))
                                {
                                    if (attributeDetail.OldValue.GetAttributeValue<EntityReference>("lux_mgunderwriter").Id == new Guid("01f2f85a-f661-eb11-89f5-0022483f12ba"))
                                    {
                                        var appln = new Entity("lux_application", item.Id);
                                        appln["lux_mgunderwriter"] = new EntityReference("lux_portalusers", new Guid("89513f5d-49c7-ea11-a812-000d3a0ba99a"));
                                        service.Update(appln);
                                    }
                                    if (attributeDetail.OldValue.GetAttributeValue<EntityReference>("lux_mgunderwriter").Id == new Guid("fff1f85a-f661-eb11-89f5-0022483f12ba"))
                                    {
                                        var appln = new Entity("lux_application", item.Id);
                                        appln["lux_mgunderwriter"] = new EntityReference("lux_portalusers", new Guid("1a86a1ec-56aa-eb11-9442-002248015a49"));
                                        service.Update(appln);
                                    }
                                }
                            }
                        }
                    }
                    rowno++;
                }
            }
            //Entity entity = new Entity("lux_portalusers");
            //entity.Attributes["lux_portalusersid"] = new Guid("11f2f85a-f661-eb11-89f5-0022483f12ba");
            //entity.Attributes["lux_name"] = "AAAAA";
            //service.Create(entity);

            //String _FieldName = "lux_lolrisksubtotal";

            //CalculateRollupFieldRequest calculateRollup = new CalculateRollupFieldRequest();
            //calculateRollup.FieldName = _FieldName;
            //calculateRollup.Target = new EntityReference("lux_application", new Guid("A1333B58-397C-EB11-A812-002248405303"));
            //CalculateRollupFieldResponse resp = (CalculateRollupFieldResponse)service.Execute(calculateRollup);
            //Entity QuoteEntity = resp.Entity;
            //var pre = ((Money)QuoteEntity.Attributes[_FieldName]).Value;
        }

        public static string RetrieveAttributeDisplayName(string EntitySchemaName, string AttributeSchemaName, IOrganizationService service)
        {
            RetrieveAttributeRequest retrieveAttributeRequest = new RetrieveAttributeRequest
            {
                EntityLogicalName = EntitySchemaName,
                LogicalName = AttributeSchemaName,
                RetrieveAsIfPublished = true
            };
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            AttributeMetadata retrievedAttributeMetadata = (AttributeMetadata)retrieveAttributeResponse.AttributeMetadata;
            return retrievedAttributeMetadata.DisplayName.UserLocalizedLabel.Label;
        }
    }
}
