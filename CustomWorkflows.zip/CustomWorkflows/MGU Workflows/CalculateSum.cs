﻿using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CustomWorkflows
{
    public class CalculateSum : CodeActivity
    {
        [Input("Number1")]
        public InArgument<decimal> Number1 { get; set; }

        [Input("Number2")]
        public InArgument<decimal> Number2 { get; set; }

        [Input("Number3")]
        public InArgument<decimal> Number3 { get; set; }

        [Input("Number4")]
        public InArgument<decimal> Number4 { get; set; }

        [Input("Number5")]
        public InArgument<decimal> Number5 { get; set; }
        
        [Input("Number6")]
        public InArgument<decimal> Number6 { get; set; }

        [Input("Number7")]
        public InArgument<decimal> Number7 { get; set; }

        [Input("Number8")]
        public InArgument<decimal> Number8 { get; set; }

        [Input("Number9")]
        public InArgument<decimal> Number9 { get; set; }

        [Input("Number10")]
        public InArgument<decimal> Number10 { get; set; }

        [RequiredArgument]
        [Input("Round Decimal Places")]
        [Default("-1")]
        public InArgument<int> RoundDecimalPlaces { get; set; }

        [Output("Subtotal")]
        public OutArgument<decimal> Subtotal { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            if (context == null)
                throw new ArgumentNullException(nameof(context));

            decimal Number1 = this.Number1.Get(context);
            decimal Number2 = this.Number2.Get(context);
            decimal Number3 = this.Number3.Get(context);
            decimal Number4 = this.Number4.Get(context);
            decimal Number5 = this.Number5.Get(context);
            decimal Number6 = this.Number6.Get(context);
            decimal Number7 = this.Number7.Get(context);
            decimal Number8 = this.Number8.Get(context);
            decimal Number9 = this.Number9.Get(context);
            decimal Number10 = this.Number10.Get(context);

            int roundDecimalPlaces = RoundDecimalPlaces.Get(context);

            decimal Subtotal = Number1 + Number2 + Number3 + Number4 + Number5 + Number6 + Number7 + Number8 + Number9 + Number10;

            if (roundDecimalPlaces != -1)
                Subtotal = Math.Round(Subtotal, roundDecimalPlaces);

            this.Subtotal.Set(context, Subtotal);
        }
    }
}
