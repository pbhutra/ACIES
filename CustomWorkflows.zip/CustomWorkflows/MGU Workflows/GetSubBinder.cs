﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CustomWorkflows
{
    public class GetSubBinder : CodeActivity
    {
        [Input("Binder")]
        [ReferenceTarget("lux_binder")]
        [RequiredArgument]
        public InArgument<EntityReference> Binder { get; set; }

        [Input("Product")]
        [ReferenceTarget("product")]
        [RequiredArgument]
        public InArgument<EntityReference> Product { get; set; }

        [Output("Sub Binder")]
        [ReferenceTarget("lux_binder")]
        public OutArgument<EntityReference> SubBinder { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            var ProductName = Product.Get(executionContext);

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_binder'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_amountallocated' />
                                <attribute name='lux_binderstartdate' />
                                <attribute name='lux_binderreviewdate' />
                                <attribute name='lux_binderlimit' />
                                <attribute name='lux_binderenddate' />
                                <attribute name='lux_binderid' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='new_parentbinder' operator='eq' uiname='DTW' uitype='lux_binder' value='{Binder.Get(executionContext).Id}' />
                                  <condition attribute='lux_product' operator='eq' uiname='Liability Only' uitype='product' value='{Product.Get(executionContext).Id}' />
                                  <condition attribute='lux_binderstartdate' operator='on-or-before' value='{DateTime.UtcNow}' />
                                  <condition attribute='lux_binderenddate' operator='on-or-after' value='{DateTime.UtcNow}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var binder = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                SubBinder.Set(executionContext, binder.ToEntityReference());
            }
        }
    }
}