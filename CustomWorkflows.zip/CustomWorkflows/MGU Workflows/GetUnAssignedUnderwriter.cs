﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class GetUnAssignedUnderwriter : CodeActivity
    {
        [Input("Application")]
        [ReferenceTarget("lux_application")]
        public InArgument<EntityReference> Application { get; set; }

        [Output("PortalUsers")]
        [ReferenceTarget("lux_portalusers")]
        public OutArgument<EntityReference> PortalUsers { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                              <entity name='lux_portalusers'>
                                <attribute name='lux_portalusersid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_userrole' operator='in'>
                                    <value>972970002</value>
                                    <value>972970001</value>
                                  </condition>
                                  <condition attribute='lux_portalrole' operator='eq' value='100000003' />
                                </filter>
                                <link-entity name='lux_application' from='lux_mgunderwriter' to='lux_portalusersid' link-type='outer' alias='ae' />
                                <filter type='and'>
                                  <condition entityname='ae' attribute='lux_mgunderwriter' operator='null' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var portalUser = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                PortalUsers.Set(executionContext, portalUser.ToEntityReference());
            }
            else
            {
                var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                              <entity name='lux_portalusers'>
                                <attribute name='lux_portalusersid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_userrole' operator='in'>
                                    <value>972970002</value>
                                    <value>972970001</value>
                                  </condition>
                                  <condition attribute='lux_portalrole' operator='eq' value='100000003' />
                                </filter>
                                <link-entity name='lux_application' from='lux_mgunderwriter' to='lux_portalusersid' link-type='inner' alias='ae' />
                              </entity>
                            </fetch>";
                if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
                {
                    var count = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count;
                    tracingService.Trace(count.ToString());
                    Random r = new Random();
                    int x = r.Next(0, count);

                    var portalUser = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities[x];
                    PortalUsers.Set(executionContext, portalUser.ToEntityReference());
                }
            }
        }
    }
}
