﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CheckIfApplicationExist : CodeActivity
    {
        [RequiredArgument]
        [Input("Name")]
        public InArgument<string> Name { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_application'>
                                <attribute name='lux_quotenumber' />
                                <attribute name='statuscode' />
                                <attribute name='lux_applicationtype' />
                                <attribute name='lux_product' />
                                <attribute name='lux_mgunderwriter' />
                                <attribute name='createdon' />
                                <attribute name='lux_proposedinceptiondate' />
                                <attribute name='lux_broker' />
                                <attribute name='lux_customername1' />
                                <attribute name='lux_applicationid' />
                                <order attribute='lux_quotenumber' descending='true' />
                                <filter type='and'>
                                  <condition attribute='lux_name' operator='eq' value='{Name.Get(executionContext).ToString()}' />
                                  <condition attribute='overriddencreatedon' operator='on-or-before' value='{DateTime.Now.AddDays(-4)}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var application = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                service.Delete("lux_application", application.Id);
            }
        }
    }
}
