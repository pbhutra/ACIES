﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CustomWorkflows
{
    public class GetDCPDocumentVersion : CodeActivity
    {
        [RequiredArgument]
        [Input("Document Type")]
        public InArgument<string> DocumentType { get; set; }

        [Input("InceptionDate")]
        public InArgument<DateTime> InceptionDate { get; set; }

        [Input("Product")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> Product { get; set; }

        [Input("Binder")]
        [ReferenceTarget("lux_binder")]
        public InArgument<EntityReference> Binder { get; set; }

        [Input("Entity Name")]
        [ReferenceTarget("")]
        public InArgument<String> EntityName { get; set; }

        [Input("Main Record URL")]
        [ReferenceTarget("")]
        public InArgument<String> MainRecordURL { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            #region "Load CRM Service from context"

            Common objCommon = new Common(executionContext);
            objCommon.tracingService.Trace("Load CRM Service from context --- OK");

            #endregion

            // Get parameters
            string mainRecordURL = MainRecordURL.Get(executionContext);

            var DocName = DocumentType.Get(executionContext);
            var DocValue = 972970001;
            if (DocName == "Policy Wording")
            {
                DocValue = 972970001;
            }
            else if (DocName == "Key Fact")
            {
                DocValue = 972970002;
            }
            else if (DocName == "Legal Expenses Policy Wording")
            {
                DocValue = 972970003;
            }

            TimeZoneInfo tst = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");

            TimeZoneInfo gmtZone = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");
            TimeZoneInfo utcZone = TimeZoneInfo.FindSystemTimeZoneById("UTC");

            var gmtStDT = TimeZoneInfo.ConvertTime(InceptionDate.Get(executionContext), utcZone, gmtZone);

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference proref = Product.Get<EntityReference>(executionContext);
            Entity product = service.Retrieve("product", proref.Id, new ColumnSet(true));

            EntityReference binref = Binder.Get<EntityReference>(executionContext);
            Entity binder = service.Retrieve("lux_binder", binref.Id, new ColumnSet(true));

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                              <entity name='ptm_mscrmaddons_dcptemplates'>
                                <attribute name='ptm_name' />
                                <attribute name='lux_validto' />
                                <attribute name='lux_validfrom' />
                                <attribute name='createdon' />
                                <attribute name='lux_documenttype' />
                                <attribute name='ptm_mscrmaddons_dcptemplatesid' />
                                <order attribute='createdon' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statuscode' operator='eq' value='1' />
                                  <condition attribute='ptm_entitytype' operator='null' />
                                  <condition attribute='lux_documenttype' operator='eq' value='{DocValue}' />
                                  <condition attribute='lux_validfrom' operator='on-or-before' value='{gmtStDT}' />
                                  <filter type='or'>
                                      <condition attribute='lux_validto' operator='on-or-after' value='{gmtStDT}' />
                                      <condition attribute='lux_validto' operator='null' />
                                  </filter>
                                </filter>
                                <link-entity name='lux_ptm_mscrmaddons_dcptemplates_lux_binder' from='ptm_mscrmaddons_dcptemplatesid' to='ptm_mscrmaddons_dcptemplatesid' visible='false' intersect='true'>
                                  <link-entity name='lux_binder' from='lux_binderid' to='lux_binderid' alias='ae'>
                                    <filter type='and'>
                                      <condition attribute='lux_binderid' operator='eq' uiname='' uitype='lux_binder' value='{binder.Id}' />
                                    </filter>
                                  </link-entity>
                                </link-entity>
                                <link-entity name='lux_ptm_mscrmaddons_dcptemplates_product' from='ptm_mscrmaddons_dcptemplatesid' to='ptm_mscrmaddons_dcptemplatesid' visible='false' intersect='true'>
                                  <link-entity name='product' from='productid' to='productid' alias='af'>
                                    <filter type='and'>
                                      <condition attribute='productid' operator='eq' uiname='' uitype='product' value='{product.Id}' />
                                    </filter>
                                  </link-entity>
                                </link-entity>
                              </entity>
                            </fetch>";

            tracingService.Trace(fetch);

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var doc = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                var notesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='annotation'>
                                            <attribute name='annotationid' />
                                            <attribute name='subject' />
                                            <attribute name='notetext' />
                                            <attribute name='modifiedby' />
                                            <attribute name='createdon' />
                                            <attribute name='filename' />
                                            <attribute name='documentbody' />
                                            <order attribute='createdon' descending='true' />
                                            <link-entity name='ptm_mscrmaddons_dcptemplates' from='ptm_mscrmaddons_dcptemplatesid' to='objectid' link-type='inner' alias='af'>
                                              <filter type='and'>
                                                <condition attribute='ptm_mscrmaddons_dcptemplatesid' operator='eq' uiname='' uitype='ptm_mscrmaddons_dcptemplates' value='{doc.Id}' />
                                              </filter>
                                            </link-entity>
                                          </entity>
                                        </fetch>";

                var files = service.RetrieveMultiple(new FetchExpression(notesFetch)).Entities;

                if (files.Count() > 0)
                {
                    var file = service.RetrieveMultiple(new FetchExpression(notesFetch)).Entities.FirstOrDefault();
                    if (mainRecordURL != "")
                    {
                        // Extract values from URL
                        string[] urlParts = mainRecordURL.Split("?".ToArray());
                        string[] urlParams = urlParts[1].Split("&".ToCharArray());
                        string ParentObjectTypeCode = urlParams[0].Replace("etc=", "");
                        string ParentId = urlParams[1].Replace("id=", "");

                        Entity Note = new Entity("annotation");
                        Note["objectid"] = new Microsoft.Xrm.Sdk.EntityReference(EntityName.Get(executionContext), new Guid(ParentId));
                        Note["objecttypecode"] = EntityName.Get(executionContext);
                        Note["filename"] = file.Attributes["filename"].ToString();
                        Note["subject"] = file.Attributes["subject"].ToString();
                        Note["documentbody"] = file.Attributes["documentbody"].ToString();
                        service.Create(Note);
                    }
                }
            }
            //else
            //{
            //    var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
            //                      <entity name='ptm_mscrmaddons_dcptemplates'>
            //                        <attribute name='ptm_name' />
            //                        <attribute name='lux_validto' />
            //                        <attribute name='lux_validfrom' />
            //                        <attribute name='createdon' />
            //                        <attribute name='lux_documenttype' />
            //                        <attribute name='ptm_mscrmaddons_dcptemplatesid' />
            //                        <order attribute='createdon' descending='true' />
            //                        <filter type='and'>
            //                          <condition attribute='statuscode' operator='eq' value='1' />
            //                          <condition attribute='ptm_entitytype' operator='null' />
            //                          <condition attribute='lux_documenttype' operator='eq' value='{DocValue}' />
            //                        </filter>
            //                        <link-entity name='lux_ptm_mscrmaddons_dcptemplates_lux_binder' from='ptm_mscrmaddons_dcptemplatesid' to='ptm_mscrmaddons_dcptemplatesid' visible='false' intersect='true'>
            //                          <link-entity name='lux_binder' from='lux_binderid' to='lux_binderid' alias='ae'>
            //                            <filter type='and'>
            //                              <condition attribute='lux_binderid' operator='eq' uiname='' uitype='lux_binder' value='{binder.Id}' />
            //                            </filter>
            //                          </link-entity>
            //                        </link-entity>
            //                        <link-entity name='lux_ptm_mscrmaddons_dcptemplates_product' from='ptm_mscrmaddons_dcptemplatesid' to='ptm_mscrmaddons_dcptemplatesid' visible='false' intersect='true'>
            //                          <link-entity name='product' from='productid' to='productid' alias='af'>
            //                            <filter type='and'>
            //                              <condition attribute='productid' operator='eq' uiname='' uitype='product' value='{product.Id}' />
            //                            </filter>
            //                          </link-entity>
            //                        </link-entity>
            //                      </entity>
            //                    </fetch>";
            //    if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
            //    {
            //        var doc = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities[0];

            //        var notesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            //                              <entity name='annotation'>
            //                                <attribute name='annotationid' />
            //                                <attribute name='subject' />
            //                                <attribute name='notetext' />
            //                                <attribute name='modifiedby' />
            //                                <attribute name='createdon' />
            //                                <attribute name='filename' />
            //                                <attribute name='documentbody' />
            //                                <order attribute='createdon' descending='true' />
            //                                <link-entity name='ptm_mscrmaddons_dcptemplates' from='ptm_mscrmaddons_dcptemplatesid' to='objectid' link-type='inner' alias='af'>
            //                                  <filter type='and'>
            //                                    <condition attribute='ptm_mscrmaddons_dcptemplatesid' operator='eq' uiname='' uitype='ptm_mscrmaddons_dcptemplates' value='{doc.Id}' />
            //                                  </filter>
            //                                </link-entity>
            //                              </entity>
            //                            </fetch>";

            //        var files = service.RetrieveMultiple(new FetchExpression(notesFetch)).Entities;

            //        if (files.Count() > 0)
            //        {
            //            tracingService.Trace("Step2");
            //            var file = service.RetrieveMultiple(new FetchExpression(notesFetch)).Entities.FirstOrDefault();
            //            if (mainRecordURL != "")
            //            {
            //                // Extract values from URL
            //                string[] urlParts = mainRecordURL.Split("?".ToArray());
            //                string[] urlParams = urlParts[1].Split("&".ToCharArray());
            //                string ParentObjectTypeCode = urlParams[0].Replace("etc=", "");
            //                string ParentId = urlParams[1].Replace("id=", "");
            //                tracingService.Trace("Step3");
            //                Entity Note = new Entity("annotation");
            //                Note["objectid"] = new Microsoft.Xrm.Sdk.EntityReference(EntityName.Get(executionContext), new Guid(ParentId));
            //                Note["objecttypecode"] = EntityName.Get(executionContext);
            //                Note["filename"] = file.Attributes["filename"].ToString();
            //                Note["subject"] = file.Attributes["subject"].ToString();
            //                Note["documentbody"] = file.Attributes["documentbody"].ToString();
            //                service.Create(Note);
            //            }
            //        }
            //    }
            //}
        }
    }
}