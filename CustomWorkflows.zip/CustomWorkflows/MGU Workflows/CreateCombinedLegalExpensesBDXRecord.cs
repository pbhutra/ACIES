﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CustomWorkflows
{
    public class CreateCombinedLegalExpensesBDXRecord : CodeActivity
    {
        [Input("Policy")]
        [ReferenceTarget("lux_policy")]
        [RequiredArgument]
        public InArgument<EntityReference> Policy { get; set; }

        [Input("Application")]
        [ReferenceTarget("lux_application")]
        [RequiredArgument]
        public InArgument<EntityReference> Application { get; set; }

        [Input("Installment")]
        [ReferenceTarget("lux_installmentschedule")]
        [RequiredArgument]
        public InArgument<EntityReference> Installment { get; set; }

        [Input("Binder")]
        [ReferenceTarget("lux_binder")]
        [RequiredArgument]
        public InArgument<EntityReference> Binder { get; set; }

        [RequiredArgument]
        [Input("Product")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> Product { get; set; }

        [RequiredArgument]
        [Input("BDX Type")]
        public InArgument<string> BDXType { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            var ProductName = Product.Get<EntityReference>(executionContext).Id;

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference policyref = Policy.Get<EntityReference>(executionContext);
            Entity policy = service.Retrieve("lux_policy", policyref.Id, new ColumnSet(true));

            EntityReference appref = Application.Get<EntityReference>(executionContext);
            Entity appln = service.Retrieve("lux_application", appref.Id, new ColumnSet(true));

            EntityReference binref = Binder.Get<EntityReference>(executionContext);
            Entity binder = service.Retrieve("lux_binder", binref.Id, new ColumnSet(true));

            EntityReference installref = Installment.Get<EntityReference>(executionContext);
            Entity install = service.Retrieve("lux_installmentschedule", installref.Id, new ColumnSet(true));

            Entity bdx = new Entity("lux_bordereaux");
            bdx["lux_policynumber"] = policy.Attributes.Contains("lux_policynumber") == true ? policy.Attributes["lux_policynumber"] : "";
            bdx["lux_policycode"] = binder.Attributes.Contains("lux_policycode") == true ? binder.Attributes["lux_policycode"] : "";
            bdx["lux_policytype"] = binder.Attributes.Contains("lux_policytype") == true ? binder.Attributes["lux_policytype"] : "";
            bdx["lux_policysubtype"] = binder.Attributes.Contains("lux_policysubtype") == true ? binder.Attributes["lux_policysubtype"] : "";
            bdx["lux_installment"] = new EntityReference("lux_installmentschedule", installref.Id);
            bdx["lux_insuredname"] = appln.Attributes.Contains("lux_concatenatedcustomernamefordocuments") == true ? appln.Attributes["lux_concatenatedcustomernamefordocuments"] : "";
            bdx["lux_clienttitle"] = appln.Attributes.Contains("lux_title1") ==true ? appln.Attributes["lux_title1"] : "";
            bdx["lux_clientfirstname"] = appln.Attributes.Contains("lux_firstname1") == true ? appln.Attributes["lux_firstname1"] : "";
            bdx["lux_clientsurname"] = appln.Attributes.Contains("lux_surname1") == true ? appln.Attributes["lux_surname1"] : "";

            if (policy.Attributes.Contains("lux_policyholder"))
            {
                Entity customer_detail = service.Retrieve(((EntityReference)policy["lux_policyholder"]).LogicalName, ((EntityReference)policy["lux_policyholder"]).Id, new ColumnSet(true));
                bdx["lux_corraddressline1"] = customer_detail.Attributes.Contains("address1_line1") == true ? customer_detail.Attributes["address1_line1"] : "";
                bdx["lux_corraddressline2"] = customer_detail.Attributes.Contains("address1_city") == true ? customer_detail.Attributes["address1_city"] : "";
                bdx["lux_corraddressline3"] = "";
                bdx["lux_postcode"] = customer_detail.Attributes.Contains("address1_postalcode") == true ? customer_detail.Attributes["address1_postalcode"] : "";
            }

            if (binder.Attributes.Contains("lux_policycode") && (binder.Attributes["lux_policycode"].ToString() == "comlexlei" || binder.Attributes["lux_policycode"].ToString() == "comlexsm1" || binder.Attributes["lux_policycode"].ToString() == "comlex04m" || binder.Attributes["lux_policycode"].ToString() == "comlex05m"))
            {
                bdx["lux_smallbusinessstandardorpremierpolicy"] = "Standard";
            }

            bdx["lux_entrytype"] = BDXType.Get(executionContext);
            bdx["lux_policyinceptiondateddmmyy"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
            bdx["lux_policyexpirydateddmmyy"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
            bdx["lux_cancellationreason"] = policy.Attributes.Contains("lux_cancellationreason") == true ? policy.FormattedValues["lux_cancellationreason"] : "";
            bdx["lux_insuredpropertyaddressline1landlordsonly"] = appln.Attributes.Contains("lux_riskstreet") == true ? appln.Attributes["lux_riskstreet"] : "";
            bdx["lux_insuredpropertypostcodelandlordsonly"] = appln.Attributes.Contains("lux_riskpostcode") == true ? appln.Attributes["lux_riskpostcode"] : "";
            bdx["lux_bordereautype"] = new OptionSetValue(972970001);

            var LEGross = install.Attributes.Contains("lux_customerpayable") == true ? install.GetAttributeValue<Money>("lux_customerpayable").Value : 0;
            var LEIPT = install.Attributes.Contains("lux_tax") == true ? install.GetAttributeValue<Money>("lux_tax").Value : 0;
            var LENet = install.Attributes.Contains("lux_netpremium") == true ? install.GetAttributeValue<Money>("lux_netpremium").Value : 0;

            bdx["lux_retailpremiumincipt"] = new Money(LEGross);
            bdx["lux_ipt"] = new Money(LEIPT);
            bdx["lux_totalnetpremiumtobdis"] = new Money(LENet);


            //if (BDXType.Get(executionContext) == "N/B" || BDXType.Get(executionContext) == "RNL")
            //{
            //    var LEGross = policy.Attributes.Contains("lux_legross") == true ? policy.GetAttributeValue<Money>("lux_legross").Value : 0;
            //    var LEIPT = policy.Attributes.Contains("lux_leipt") == true ? policy.GetAttributeValue<Money>("lux_leipt").Value : 0;
            //    var LEGrossComm = policy.Attributes.Contains("lux_legrosscommission") == true ? policy.GetAttributeValue<decimal>("lux_legrosscommission") : 0;

            //    bdx["lux_retailpremiumincipt"] = new Money(LEGross + LEIPT);
            //    bdx["lux_ipt"] = new Money(LEIPT);
            //    bdx["lux_totalnetpremiumtobdis"] = new Money(LEGross - LEGrossComm);
            //}
            //else if (BDXType.Get(executionContext) == "MTA")
            //{
            //    var LEGross = policy.Attributes.Contains("lux_lemtapremium") == true ? policy.GetAttributeValue<Money>("lux_lemtapremium").Value : 0;
            //    var LEIPTRate = policy.Attributes.Contains("lux_iptrate") == true ? policy.GetAttributeValue<Money>("lux_iptrate").Value : 0;
            //    var LEIPT = LEGross * LEIPTRate / 100;
            //    var LEGrossComm = policy.Attributes.Contains("lux_lemtagrosscommission") == true ? policy.GetAttributeValue<decimal>("lux_lemtagrosscommission") : 0;

            //    bdx["lux_retailpremiumincipt"] = new Money(LEGross + LEIPT);
            //    bdx["lux_ipt"] = new Money(LEIPT);
            //    bdx["lux_totalnetpremiumtobdis"] = new Money(LEGross - LEGrossComm);
            //}
            //else if (BDXType.Get(executionContext) == "Cancel")
            //{
            //    var LEGross = -1 * (policy.Attributes.Contains("lux_refundleamount") == true ? policy.GetAttributeValue<Money>("lux_refundleamount").Value : 0);
            //    var LEIPT = -1 * (policy.Attributes.Contains("lux_refundleipt") == true ? policy.GetAttributeValue<Money>("lux_refundleipt").Value : 0);
            //    var LEGrossComm = -1 * (policy.Attributes.Contains("lux_refundlegrosscommission") == true ? policy.GetAttributeValue<decimal>("lux_refundlegrosscommission") : 0);

            //    bdx["lux_retailpremiumincipt"] = new Money(LEGross + LEIPT);
            //    bdx["lux_ipt"] = new Money(LEIPT);
            //    bdx["lux_totalnetpremiumtobdis"] = new Money(LEGross - LEGrossComm);
            //}
            service.Create(bdx);
        }
    }
}