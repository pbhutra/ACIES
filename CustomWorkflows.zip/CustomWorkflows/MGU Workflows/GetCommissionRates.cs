﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CustomWorkflows
{
    public class GetCommissionRates : CodeActivity
    {
        #region "Parameter Definition"

        [Input("Application")]
        [ReferenceTarget("lux_application")]
        [RequiredArgument]
        public InArgument<EntityReference> Application { get; set; }

        [Input("Binder")]
        [ReferenceTarget("lux_binder")]
        [RequiredArgument]
        public InArgument<EntityReference> Binder { get; set; }

        [Input("SubBinder")]
        [ReferenceTarget("lux_binder")]
        [RequiredArgument]
        public InArgument<EntityReference> SubBinder { get; set; }

        [Input("Broker")]
        [ReferenceTarget("account")]
        [RequiredArgument]
        public InArgument<EntityReference> Broker { get; set; }

        [Output("GrossCommissionRate")]
        public OutArgument<decimal> GrossCommissionRate { get; set; }

        [Output("BrokerCommissionRate")]
        public OutArgument<decimal> BrokerCommissionRate { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference appref = Application.Get<EntityReference>(executionContext);
            Entity appln = service.Retrieve("lux_application", appref.Id, new ColumnSet(true));

            if (appln.Attributes.Contains("lux_brokercommissionoverride"))
            {
                BrokerCommissionRate.Set(executionContext, appln.Attributes["lux_brokercommissionoverride"]);
            }
            else
            {
                EntityReference binref = Binder.Get<EntityReference>(executionContext);
                Entity binder = service.Retrieve("lux_binder", binref.Id, new ColumnSet(true));

                EntityReference subbinref = SubBinder.Get<EntityReference>(executionContext);
                Entity item1 = service.Retrieve("lux_binder", subbinref.Id, new ColumnSet(true));

                EntityReference brokerref = Broker.Get<EntityReference>(executionContext);
                Entity account = service.Retrieve("account", brokerref.Id, new ColumnSet(true));

                if (binder.Attributes["lux_name"].ToString().ToLower().Contains("brit"))
                {
                    if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("9C87AEB1-76D1-EA11-A813-000D3A0BAD7C"))
                    {
                        BrokerCommissionRate.Set(executionContext, account["lux_britliabilityonlycommission"]);
                    }
                    else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("bdeea3ef-9483-ea11-a811-000d3a0bad7c"))
                    {
                        BrokerCommissionRate.Set(executionContext, account["lux_britlandownersliabilitycommission"]);
                    }
                    else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("258b36d1-9483-ea11-a811-000d3a0bad7c"))
                    {
                        BrokerCommissionRate.Set(executionContext, account["lux_britcommercialcombinedcommission"]);
                    }
                    else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("2f4e1a03-9583-ea11-a811-000d3a0bad7c"))
                    {
                        BrokerCommissionRate.Set(executionContext, account["lux_britpropertyownerscommission"]);
                    }
                }
                else if (binder.Attributes["lux_name"].ToString().ToLower().Contains("dtw"))
                {
                    tracingService.Trace("DTW");
                    if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("9C87AEB1-76D1-EA11-A813-000D3A0BAD7C"))
                    {
                        BrokerCommissionRate.Set(executionContext, account["lux_dtwliabilityonlycommission"]);
                    }
                    else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("bdeea3ef-9483-ea11-a811-000d3a0bad7c"))
                    {
                        BrokerCommissionRate.Set(executionContext, account["lux_dtwlandownersliabilitycommission"]);
                    }
                    else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("258b36d1-9483-ea11-a811-000d3a0bad7c"))
                    {
                        BrokerCommissionRate.Set(executionContext, account["lux_dtwcommercialcombinedcommission"]);
                    }
                    else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("2f4e1a03-9583-ea11-a811-000d3a0bad7c"))
                    {
                        BrokerCommissionRate.Set(executionContext, account["lux_dtwpropertyownerscommission"]);
                    }
                }
                else if (binder.Attributes["lux_name"].ToString().ToLower().Contains("argenta"))
                {
                    if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("9C87AEB1-76D1-EA11-A813-000D3A0BAD7C"))
                    {
                        BrokerCommissionRate.Set(executionContext, account["lux_argentaliabilityonlycommission"]);
                    }
                    else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("bdeea3ef-9483-ea11-a811-000d3a0bad7c"))
                    {
                        BrokerCommissionRate.Set(executionContext, account["lux_argentalandownersliabilitycommission"]);
                    }
                    else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("258b36d1-9483-ea11-a811-000d3a0bad7c"))
                    {
                        BrokerCommissionRate.Set(executionContext, account["lux_argentacommercialcombinedcommission"]);
                    }
                    else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("2f4e1a03-9583-ea11-a811-000d3a0bad7c"))
                    {
                        BrokerCommissionRate.Set(executionContext, account["lux_argentapropertyownerscommission"]);
                    }
                }
                else if (binder.Attributes["lux_name"].ToString().ToLower().Contains("ascot"))
                {
                    if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("9C87AEB1-76D1-EA11-A813-000D3A0BAD7C"))
                    {
                        BrokerCommissionRate.Set(executionContext, account["lux_ascotliabilityonlycommission"]);
                    }
                    else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("bdeea3ef-9483-ea11-a811-000d3a0bad7c"))
                    {
                        BrokerCommissionRate.Set(executionContext, account["lux_ascotlandownersliabilitycommission"]);
                    }
                    else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("258b36d1-9483-ea11-a811-000d3a0bad7c"))
                    {
                        BrokerCommissionRate.Set(executionContext, account["lux_ascotcommercialcombinedcommission"]);
                    }
                    else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("2f4e1a03-9583-ea11-a811-000d3a0bad7c"))
                    {
                        BrokerCommissionRate.Set(executionContext, account["lux_ascotpropertyownerscommission"]);
                    }
                }
            }

            if (appln.Attributes.Contains("lux_grosscommissionoverride"))
            {
                GrossCommissionRate.Set(executionContext, appln.Attributes["lux_grosscommissionoverride"]);
            }
            else
            {
                EntityReference binref = SubBinder.Get<EntityReference>(executionContext);
                Entity binder = service.Retrieve("lux_binder", binref.Id, new ColumnSet(true));
                GrossCommissionRate.Set(executionContext, binder.Attributes["lux_mgcommission"]);
            }
        }
    }
}
