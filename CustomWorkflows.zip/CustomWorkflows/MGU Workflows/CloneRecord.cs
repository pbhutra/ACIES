﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomWorkflows
{
    public class CloneRecord : CodeActivity
    {
        #region "Parameter Definition"

        [RequiredArgument]
        [Input("Clonning Record URL")]
        [ReferenceTarget("")]
        public InArgument<String> ClonningRecordURL { get; set; }

        [Input("Prefix")]
        [Default("")]
        public InArgument<String> Prefix { get; set; }

        [Input("Fields to Ignore")]
        [Default("")]
        public InArgument<String> FieldstoIgnore { get; set; }

        [Output("Cloned Guid")]
        public OutArgument<String> ClonedGuid { get; set; }

        [Output("Application")]
        [ReferenceTarget("lux_application")]
        public OutArgument<EntityReference> Application { get; set; }

        [Output("Record Count")]
        public OutArgument<int> RecordCount { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            #region "Load CRM Service from context"

            Common objCommon = new Common(executionContext);
            objCommon.tracingService.Trace("Load CRM Service from context --- OK");
            #endregion

            #region "Read Parameters"
            String _ClonningRecordURL = this.ClonningRecordURL.Get(executionContext);
            if (_ClonningRecordURL == null || _ClonningRecordURL == "")
            {
                return;
            }
            string[] urlParts = _ClonningRecordURL.Split("?".ToArray());
            string[] urlParams = urlParts[1].Split("&".ToCharArray());
            string objectTypeCode = urlParams[0].Replace("etc=", "");
            string entityName = objCommon.sGetEntityNameFromCode(objectTypeCode, objCommon.service);
            string objectId = urlParams[1].Replace("id=", "");
            objCommon.tracingService.Trace("ObjectTypeCode=" + objectTypeCode + "--ParentId=" + objectId);

            string prefix = this.Prefix.Get(executionContext);
            string fieldstoIgnore = this.FieldstoIgnore.Get(executionContext);
            #endregion

            #region "Clone Execution"

            var createdGUID = objCommon.CloneRecord(entityName, objectId, fieldstoIgnore, prefix);
            ClonedGuid.Set(executionContext, createdGUID.ToString());

            Entity appln = new Entity("lux_application", createdGUID);
            appln = objCommon.service.Retrieve("lux_application", createdGUID, new ColumnSet(true));

            Application.Set(executionContext, appln.ToEntityReference());

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_application'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_applicationid' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_originalquotenumber' operator='eq' value='{appln["lux_originalquotenumber"]}' />
                                </filter>
                              </entity>
                            </fetch>";
            var count = objCommon.service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count;
            RecordCount.Set(executionContext, count);

            objCommon.tracingService.Trace("cloned object OK");

            #endregion

        }
    }
}
