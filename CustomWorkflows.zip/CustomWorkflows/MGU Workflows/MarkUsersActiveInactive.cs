﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class MarkUsersActiveInactive : CodeActivity
    {
        [Input("Account")]
        [ReferenceTarget("account")]
        public InArgument<EntityReference> Account { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference accountref = Account.Get<EntityReference>(executionContext);
            Entity account = service.Retrieve("account", accountref.Id, new ColumnSet(true));

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_portalusers'>
                                <attribute name='lux_portalusersid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='lux_company' operator='eq' uitype='account' value='{account.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='contact'>
                                <attribute name='new_fullname' />
                                <attribute name='emailaddress1' />
                                <attribute name='address1_composite' />
                                <attribute name='parentcustomerid' />
                                <attribute name='telephone1' />
                                <attribute name='contactid' />
                                <order attribute='new_fullname' descending='false' />
                                <filter type='and'>
                                  <condition attribute='lux_contacttype' operator='eq' value='972970001' />
                                  <condition attribute='parentcustomerid' operator='eq' uitype='account' value='{account.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var PortalUsers = service.RetrieveMultiple(new FetchExpression(fetch));
                foreach (var item in PortalUsers.Entities)
                {
                    if (account.FormattedValues["statecode"] == "Active")
                    {
                        service.Execute(new SetStateRequest
                        {
                            EntityMoniker = new EntityReference("lux_portalusers", item.Id),
                            State = new OptionSetValue(0),
                            Status = new OptionSetValue(1)
                        });
                    }
                    else
                    {
                        service.Execute(new SetStateRequest
                        {
                            EntityMoniker = new EntityReference("lux_portalusers", item.Id),
                            State = new OptionSetValue(1),
                            Status = new OptionSetValue(2)
                        });
                    }
                }
            }
            if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
            {
                var Contacts = service.RetrieveMultiple(new FetchExpression(fetch1));
                foreach (var item in Contacts.Entities)
                {
                    if (account.FormattedValues["statecode"] == "Active")
                    {
                        service.Execute(new SetStateRequest
                        {
                            EntityMoniker = new EntityReference("contact", item.Id),
                            State = new OptionSetValue(0),
                            Status = new OptionSetValue(1)
                        });
                    }
                    else
                    {
                        service.Execute(new SetStateRequest
                        {
                            EntityMoniker = new EntityReference("contact", item.Id),
                            State = new OptionSetValue(1),
                            Status = new OptionSetValue(2)
                        });
                    }
                }
            }
        }
    }
}
