﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CheckIfAccountExist : CodeActivity
    {
        [RequiredArgument]
        [Input("CustomerName")]
        public InArgument<string> CustomerName { get; set; }

        [Input("Email")]
        public InArgument<string> Email { get; set; }

        [Output("IsExist")]
        public OutArgument<bool> IsExist { get; set; }

        [Output("Account")]
        [ReferenceTarget("account")]
        public OutArgument<EntityReference> Account { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='account'>
                                <attribute name='name' />
                                <attribute name='address1_city' />
                                <attribute name='primarycontactid' />
                                <attribute name='telephone1' />
                                <attribute name='accountid' />
                                <order attribute='name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_accounttype' operator='eq' value='972970002' />
                                  <condition attribute='name' operator='eq' value='{CustomerName.Get(executionContext).Replace("&", "&amp;").Replace("'", "&apos;").Replace("\"", "&quot;")}' />";
            if (!string.IsNullOrEmpty(Email.Get(executionContext)))
            {
                fetch += $@"<condition attribute='emailaddress1' operator='eq' value='{Email.Get(executionContext).Replace("&", "&amp;").Replace("'", "&apos;").Replace("\"", "&quot;")}' />";
            }
            fetch += $@"</filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                this.IsExist.Set(executionContext, true);
                var contact = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                Account.Set(executionContext, contact.ToEntityReference());
            }
            else
            {
                this.IsExist.Set(executionContext, false);
            }
        }
    }
}
