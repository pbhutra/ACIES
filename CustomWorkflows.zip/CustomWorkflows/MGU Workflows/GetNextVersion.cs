﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class GetNextVersion : CodeActivity
    {
        [Input("Application")]
        [RequiredArgument]
        [ReferenceTarget("lux_application")]
        public InArgument<EntityReference> Application { get; set; }

        [Output("NextApplication")]
        [ReferenceTarget("lux_application")]
        public OutArgument<EntityReference> NextApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference appRef = Application.Get<EntityReference>(executionContext);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_application'>
                                <attribute name='lux_applicationid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='lux_previousversionquoteid' operator='eq' uiname='' uitype='lux_application' value='{appRef.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var appln = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                NextApplication.Set(executionContext, appln.ToEntityReference());
            }
        }
    }
}
