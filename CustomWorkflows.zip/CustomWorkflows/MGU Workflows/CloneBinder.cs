﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomWorkflows
{
    public class CloneBinder : CodeActivity
    {
        #region "Parameter Definition"

        [RequiredArgument]
        [Input("Clonning Record URL")]
        [ReferenceTarget("")]
        public InArgument<String> ClonningRecordURL { get; set; }

        [Input("Prefix")]
        [Default("")]
        public InArgument<String> Prefix { get; set; }

        [Input("Fields to Ignore")]
        [Default("")]
        public InArgument<String> FieldstoIgnore { get; set; }

        [Output("Cloned Guid")]
        public OutArgument<String> ClonedGuid { get; set; }

        [Output("New Binder")]
        [ReferenceTarget("lux_binder")]
        public OutArgument<EntityReference> NewBinder { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            #region "Load CRM Service from context"

            Common objCommon = new Common(executionContext);
            objCommon.tracingService.Trace("Load CRM Service from context --- OK");
            #endregion

            #region "Read Parameters"
            String _ClonningRecordURL = this.ClonningRecordURL.Get(executionContext);
            if (_ClonningRecordURL == null || _ClonningRecordURL == "")
            {
                return;
            }
            string[] urlParts = _ClonningRecordURL.Split("?".ToArray());
            string[] urlParams = urlParts[1].Split("&".ToCharArray());
            string objectTypeCode = urlParams[0].Replace("etc=", "");
            string entityName = objCommon.sGetEntityNameFromCode(objectTypeCode, objCommon.service);
            string objectId = urlParams[1].Replace("id=", "");
            objCommon.tracingService.Trace("ObjectTypeCode=" + objectTypeCode + "--ParentId=" + objectId);

            string prefix = this.Prefix.Get(executionContext);
            string fieldstoIgnore = this.FieldstoIgnore.Get(executionContext);
            #endregion

            #region "Clone Execution"

            var createdGUID = objCommon.CloneRecord(entityName, objectId, fieldstoIgnore, prefix);
            Entity binder = objCommon.service.Retrieve("lux_binder", createdGUID, new ColumnSet(true));

            NewBinder.Set(executionContext, binder.ToEntityReference());

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_binder'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_amountallocated' />
                                <attribute name='lux_binderstartdate' />
                                <attribute name='lux_binderreviewdate' />
                                <attribute name='lux_binderlimit' />
                                <attribute name='lux_binderenddate' />
                                <attribute name='lux_binderid' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='new_parentbinder' operator='not-null' />
                                  <condition attribute='new_parentbinder' operator='eq' uiname='Brit' uitype='lux_binder' value='{new Guid(objectId)}' />
                                </filter>
                              </entity>
                            </fetch>";

            var subBinder = objCommon.service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
            if (subBinder.Count() > 0)
            {
                foreach (var item in subBinder)
                {
                    var GUID = objCommon.CloneRecord(entityName, item.Id.ToString(), fieldstoIgnore, prefix);
                    Entity subbinder = objCommon.service.Retrieve("lux_binder", GUID, new ColumnSet(true));
                    subbinder["new_parentbinder"] = new EntityReference("lux_binder", binder.Id);
                    if (subbinder.Attributes.Contains("lux_binderenddate"))
                    {
                        subbinder["lux_binderstartdate"] = Convert.ToDateTime(subbinder.GetAttributeValue<DateTime>("lux_binderenddate").ToString()).AddDays(1);
                    }
                    if (subbinder.Attributes.Contains("lux_binderenddate"))
                    {
                        subbinder["lux_binderenddate"] = Convert.ToDateTime(subbinder.GetAttributeValue<DateTime>("lux_binderenddate")).AddYears(1);
                    }
                    if (subbinder.Attributes.Contains("lux_binderreviewdate"))
                    {
                        subbinder["lux_binderreviewdate"] = Convert.ToDateTime(subbinder.GetAttributeValue<DateTime>("lux_binderreviewdate")).AddYears(1);
                    }
                    objCommon.service.Update(subbinder);

                    objCommon.service.Execute(new SetStateRequest
                    {
                        EntityMoniker = new EntityReference("lux_binder", item.Id),
                        State = new OptionSetValue(1),
                        Status = new OptionSetValue(2)
                    });
                }
            }

            var historyfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='lux_binderhistory'>
                                        <attribute name='lux_binderhistoryid' />
                                        <attribute name='lux_name' />
                                        <attribute name='createdon' />
                                        <order attribute='lux_name' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='lux_binder' operator='eq' uitype='lux_binder' value='{new Guid(objectId)}' />
                                        </filter>
                                      </entity>
                                    </fetch>";

            var history = objCommon.service.RetrieveMultiple(new FetchExpression(historyfetch)).Entities;
            if (history.Count() > 0)
            {
                foreach (var item in history)
                {
                    Entity excess1 = objCommon.service.Retrieve("lux_binderhistory", item.Id, new ColumnSet(true));
                    excess1["lux_binder"] = new EntityReference("lux_binder", binder.Id);
                    objCommon.service.Update(excess1);
                }
            }

            var Excessfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_binderexcess'>
                                    <attribute name='lux_excessvalue' />
                                    <attribute name='lux_binder' />
                                    <attribute name='lux_binderexcessid' />
                                    <order attribute='lux_excessvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_binder' operator='eq' uitype='lux_binder' value='{new Guid(objectId)}' />
                                    </filter>
                                  </entity>
                                </fetch>";

            var excess = objCommon.service.RetrieveMultiple(new FetchExpression(Excessfetch)).Entities;
            if (excess.Count() > 0)
            {
                foreach (var item in excess)
                {
                    Entity excess1 = objCommon.service.Retrieve("lux_binderexcess", item.Id, new ColumnSet(true));
                    excess1["lux_binder"] = new EntityReference("lux_binder", binder.Id);
                    objCommon.service.Update(excess1);
                }
            }

            var Endorsefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                      <entity name='lux_endorsement'>
                                        <attribute name='lux_endorsementid' />
                                        <attribute name='lux_name' />
                                        <attribute name='createdon' />
                                        <order attribute='lux_name' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='statecode' operator='eq' value='0' />
                                        </filter>
                                        <link-entity name='lux_endorsement_lux_binder' from='lux_endorsementid' to='lux_endorsementid' visible='false' intersect='true'>
                                          <link-entity name='lux_binder' from='lux_binderid' to='lux_binderid' alias='ab'>
                                            <filter type='and'>
                                              <condition attribute='lux_binderid' operator='eq' uitype='lux_binder' value='{new Guid(objectId)}' />
                                            </filter>
                                          </link-entity>
                                        </link-entity>
                                      </entity>
                                    </fetch>";

            var endorsement = objCommon.service.RetrieveMultiple(new FetchExpression(Endorsefetch)).Entities;
            if (endorsement.Count() > 0)
            {
                EntityReferenceCollection relatedEntities = new EntityReferenceCollection();
                foreach (var item in endorsement)
                {
                    relatedEntities.Add(new EntityReference("lux_endorsement", item.Id));
                }
                AssociateRequest assreq = new AssociateRequest();
                assreq.Target = new EntityReference("lux_binder", binder.Id);
                assreq.RelatedEntities = relatedEntities;
                assreq.Relationship = new Relationship("lux_endorsement_lux_binder");
                AssociateResponse response = (AssociateResponse)objCommon.service.Execute(assreq);
            }

            objCommon.tracingService.Trace("cloned object OK");

            #endregion
        }
    }
}
