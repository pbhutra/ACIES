﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class UpdateCommissionRatesFromBinder : CodeActivity
    {
        [Input("Account")]
        [ReferenceTarget("account")]
        [RequiredArgument]
        public InArgument<EntityReference> Account { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference accountref = Account.Get<EntityReference>(executionContext);
            Entity account = service.Retrieve("account", accountref.Id, new ColumnSet(true));

            account["lux_britliabilityonlycommission"] = 0.00;
            account["lux_britlandownersliabilitycommission"] = 0.00;
            account["lux_britcommercialcombinedcommission"] = 0.00;
            account["lux_britpropertyownerscommission"] = 0.00;

            account["lux_dtwliabilityonlycommission"] = 0.00;
            account["lux_dtwlandownersliabilitycommission"] = 0.00;
            account["lux_dtwcommercialcombinedcommission"] = 0.00;
            account["lux_dtwpropertyownerscommission"] = 0.00;

            account["lux_argentaliabilityonlycommission"] = 0.00;
            account["lux_argentalandownersliabilitycommission"] = 0.00;
            account["lux_argentacommercialcombinedcommission"] = 0.00;
            account["lux_argentapropertyownerscommission"] = 0.00;

            account["lux_ascotliabilityonlycommission"] = 0.00;
            account["lux_ascotlandownersliabilitycommission"] = 0.00;
            account["lux_ascotcommercialcombinedcommission"] = 0.00;
            account["lux_ascotpropertyownerscommission"] = 0.00;

            var binderfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_binder'>
                                    <attribute name='lux_name' />
                                    <attribute name='createdon' />
                                    <attribute name='lux_amountallocated' />
                                    <attribute name='lux_binderstartdate' />
                                    <attribute name='lux_binderreviewdate' />
                                    <attribute name='lux_binderlimit' />
                                    <attribute name='lux_binderenddate' />
                                    <attribute name='lux_binderid' />
                                    <order attribute='lux_name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='new_parentbinder' operator='null' />
                                      <condition attribute='lux_binderstartdate' operator='not-null' />
                                      <condition attribute='lux_binderenddate' operator='not-null' />
                                    </filter>
                                  </entity>
                                </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(binderfetch)).Entities.Count > 0)
            {
                var result = service.RetrieveMultiple(new FetchExpression(binderfetch));
                foreach (var item in result.Entities)
                {
                    var RecordGuid = item.Id;
                    var retrievedBinder = service.Retrieve("lux_binder", RecordGuid, new ColumnSet(true));

                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_binder'>
                                            <attribute name='lux_name' />
                                            <attribute name='lux_product' />
                                            <attribute name='lux_mgcommission' />
                                            <attribute name='lux_defaultbrokercommission' />
                                            <attribute name='lux_binderid' />
                                            <order attribute='lux_name' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='new_parentbinder' operator='eq' uitype='lux_binder' value='{RecordGuid}' />
                                              <condition attribute='lux_binderstartdate' operator='on-or-before' value='{DateTime.UtcNow.ToString("s")}' />
                                              <condition attribute='lux_binderenddate' operator='on-or-after' value='{DateTime.UtcNow.ToString("s")}' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                    {
                        var subBinder = service.RetrieveMultiple(new FetchExpression(fetch));
                        foreach (var item1 in subBinder.Entities)
                        {
                            if (retrievedBinder.Attributes["lux_name"].ToString().ToLower().Contains("brit"))
                            {
                                if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("9C87AEB1-76D1-EA11-A813-000D3A0BAD7C"))
                                {
                                    account["lux_britliabilityonlycommission"] = item1.Attributes.Contains("lux_defaultbrokercommission") == true ? item1.Attributes["lux_defaultbrokercommission"] : 0;
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("bdeea3ef-9483-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_britlandownersliabilitycommission"] = item1.Attributes.Contains("lux_defaultbrokercommission") == true ? item1.Attributes["lux_defaultbrokercommission"] : 0;
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("258b36d1-9483-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_britcommercialcombinedcommission"] = item1.Attributes.Contains("lux_defaultbrokercommission") == true ? item1.Attributes["lux_defaultbrokercommission"] : 0;
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("2f4e1a03-9583-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_britpropertyownerscommission"] = item1.Attributes.Contains("lux_defaultbrokercommission") == true ? item1.Attributes["lux_defaultbrokercommission"] : 0;
                                }
                            }
                            else if (retrievedBinder.Attributes["lux_name"].ToString().ToLower().Contains("dtw"))
                            {
                                if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("9C87AEB1-76D1-EA11-A813-000D3A0BAD7C"))
                                {
                                    account["lux_dtwliabilityonlycommission"] = item1.Attributes.Contains("lux_defaultbrokercommission") == true ? item1.Attributes["lux_defaultbrokercommission"] : 0;
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("bdeea3ef-9483-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_dtwlandownersliabilitycommission"] = item1.Attributes.Contains("lux_defaultbrokercommission") == true ? item1.Attributes["lux_defaultbrokercommission"] : 0;
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("258b36d1-9483-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_dtwcommercialcombinedcommission"] = item1.Attributes.Contains("lux_defaultbrokercommission") == true ? item1.Attributes["lux_defaultbrokercommission"] : 0;
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("2f4e1a03-9583-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_dtwpropertyownerscommission"] = item1.Attributes.Contains("lux_defaultbrokercommission") == true ? item1.Attributes["lux_defaultbrokercommission"] : 0;
                                }
                            }
                            else if (retrievedBinder.Attributes["lux_name"].ToString().ToLower().Contains("argenta"))
                            {
                                if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("9C87AEB1-76D1-EA11-A813-000D3A0BAD7C"))
                                {
                                    account["lux_argentaliabilityonlycommission"] = item1.Attributes.Contains("lux_defaultbrokercommission") == true ? item1.Attributes["lux_defaultbrokercommission"] : 0;
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("bdeea3ef-9483-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_argentalandownersliabilitycommission"] = item1.Attributes.Contains("lux_defaultbrokercommission") == true ? item1.Attributes["lux_defaultbrokercommission"] : 0;
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("258b36d1-9483-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_argentacommercialcombinedcommission"] = item1.Attributes.Contains("lux_defaultbrokercommission") == true ? item1.Attributes["lux_defaultbrokercommission"] : 0;
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("2f4e1a03-9583-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_argentapropertyownerscommission"] = item1.Attributes.Contains("lux_defaultbrokercommission") == true ? item1.Attributes["lux_defaultbrokercommission"] : 0;
                                }
                            }
                            else if (retrievedBinder.Attributes["lux_name"].ToString().ToLower().Contains("ascot"))
                            {
                                if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("9C87AEB1-76D1-EA11-A813-000D3A0BAD7C"))
                                {
                                    account["lux_ascotliabilityonlycommission"] = item1.Attributes.Contains("lux_defaultbrokercommission") == true ? item1.Attributes["lux_defaultbrokercommission"] : 0;
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("bdeea3ef-9483-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_ascotlandownersliabilitycommission"] = item1.Attributes.Contains("lux_defaultbrokercommission") == true ? item1.Attributes["lux_defaultbrokercommission"] : 0;
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("258b36d1-9483-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_ascotcommercialcombinedcommission"] = item1.Attributes.Contains("lux_defaultbrokercommission") == true ? item1.Attributes["lux_defaultbrokercommission"] : 0;
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("2f4e1a03-9583-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_ascotpropertyownerscommission"] = item1.Attributes.Contains("lux_defaultbrokercommission") == true ? item1.Attributes["lux_defaultbrokercommission"] : 0;
                                }
                            }
                        }
                    }
                }
                service.Update(account);
            }
        }

        public static void ssss()
        {
            ClientCredentials clientCredentials = new ClientCredentials();
            clientCredentials.UserName.UserName = "support@mgucrm.onmicrosoft.com";
            clientCredentials.UserName.Password = "nPmv88~4";

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            // Copy and Paste Organization Service Endpoint Address URL
            var service = (IOrganizationService)new OrganizationServiceProxy(new Uri("https://mgunderwriting.api.crm11.dynamics.com//XRMServices/2011/Organization.svc"),
             null, clientCredentials, null);

            Entity account = service.Retrieve("account", new Guid("451B2B00-504E-EA11-A812-000D3A0BAD7C"), new ColumnSet(true));

            account["lux_britliabilityonlycommission"] = 0.00;
            account["lux_britlandownersliabilitycommission"] = 0.00;
            account["lux_britcommercialcombinedcommission"] = 0.00;
            account["lux_britpropertyownerscommission"] = 0.00;

            account["lux_dtwliabilityonlycommission"] = 0.00;
            account["lux_dtwlandownersliabilitycommission"] = 0.00;
            account["lux_dtwcommercialcombinedcommission"] = 0.00;
            account["lux_dtwpropertyownerscommission"] = 0.00;

            account["lux_argentaliabilityonlycommission"] = 0.00;
            account["lux_argentalandownersliabilitycommission"] = 0.00;
            account["lux_argentacommercialcombinedcommission"] = 0.00;
            account["lux_argentapropertyownerscommission"] = 0.00;

            var binderfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_binder'>
                                    <attribute name='lux_name' />
                                    <attribute name='createdon' />
                                    <attribute name='lux_amountallocated' />
                                    <attribute name='lux_binderstartdate' />
                                    <attribute name='lux_binderreviewdate' />
                                    <attribute name='lux_binderlimit' />
                                    <attribute name='lux_binderenddate' />
                                    <attribute name='lux_binderid' />
                                    <order attribute='lux_name' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='new_parentbinder' operator='null' />
                                      <condition attribute='lux_binderstartdate' operator='not-null' />
                                      <condition attribute='lux_binderenddate' operator='not-null' />
                                    </filter>
                                  </entity>
                                </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(binderfetch)).Entities.Count > 0)
            {
                var result = service.RetrieveMultiple(new FetchExpression(binderfetch));
                foreach (var item in result.Entities)
                {
                    var RecordGuid = item.Id;
                    var retrievedBinder = service.Retrieve("lux_binder", RecordGuid, new ColumnSet(true));

                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_binder'>
                                            <attribute name='lux_name' />
                                            <attribute name='lux_product' />
                                            <attribute name='lux_mgcommission' />
                                            <attribute name='lux_defaultbrokercommission' />
                                            <attribute name='lux_binderid' />
                                            <order attribute='lux_name' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='new_parentbinder' operator='eq' uitype='lux_binder' value='{RecordGuid}' />
                                              <condition attribute='lux_binderstartdate' operator='on-or-before' value='{DateTime.UtcNow.ToString("s")}' />
                                              <condition attribute='lux_binderenddate' operator='on-or-after' value='{DateTime.UtcNow.ToString("s")}' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                    {
                        var subBinder = service.RetrieveMultiple(new FetchExpression(fetch));
                        foreach (var item1 in subBinder.Entities)
                        {
                            if (RecordGuid == new Guid("0F1BE913-A978-EA11-A811-000D3A0BAD7C"))
                            {
                                if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("9C87AEB1-76D1-EA11-A813-000D3A0BAD7C"))
                                {
                                    account["lux_britliabilityonlycommission"] = item1.Attributes["lux_defaultbrokercommission"];
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("bdeea3ef-9483-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_britlandownersliabilitycommission"] = item1.Attributes["lux_defaultbrokercommission"];
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("258b36d1-9483-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_britcommercialcombinedcommission"] = item1.Attributes["lux_defaultbrokercommission"];
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("2f4e1a03-9583-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_britpropertyownerscommission"] = item1.Attributes.Contains("lux_defaultbrokercommission") == true ? item1.Attributes["lux_defaultbrokercommission"] : 0;
                                }
                            }
                            else if (RecordGuid == new Guid("A9937307-439F-EA11-A812-000D3A0BAD7C"))
                            {
                                if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("9C87AEB1-76D1-EA11-A813-000D3A0BAD7C"))
                                {
                                    account["lux_dtwliabilityonlycommission"] = item1.Attributes["lux_defaultbrokercommission"];
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("bdeea3ef-9483-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_dtwlandownersliabilitycommission"] = item1.Attributes["lux_defaultbrokercommission"];
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("258b36d1-9483-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_dtwcommercialcombinedcommission"] = item1.Attributes["lux_defaultbrokercommission"];
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("2f4e1a03-9583-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_dtwpropertyownerscommission"] = item1.Attributes["lux_defaultbrokercommission"];
                                }
                            }
                            else if (RecordGuid == new Guid("28265B09-F99F-EA11-A812-000D3A0BAD7C"))
                            {
                                if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("9C87AEB1-76D1-EA11-A813-000D3A0BAD7C"))
                                {
                                    account["lux_argentaliabilityonlycommission"] = item1.Attributes["lux_defaultbrokercommission"];
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("bdeea3ef-9483-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_argentalandownersliabilitycommission"] = item1.Attributes["lux_defaultbrokercommission"];
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("258b36d1-9483-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_argentacommercialcombinedcommission"] = item1.Attributes["lux_defaultbrokercommission"];
                                }
                                else if (((EntityReference)item1.Attributes["lux_product"]).Id == new Guid("2f4e1a03-9583-ea11-a811-000d3a0bad7c"))
                                {
                                    account["lux_argentapropertyownerscommission"] = item1.Attributes["lux_defaultbrokercommission"];
                                }
                            }
                        }
                    }
                }
            }
            service.Update(account);
        }
    }
}
