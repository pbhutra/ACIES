﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class SetBrokersOnCustomers : CodeActivity
    {
        [RequiredArgument]
        [Input("CompanyName")]
        public InArgument<string> CompanyName { get; set; }

        [Output("IsAccountExist")]
        public OutArgument<bool> IsAccountExist { get; set; }

        [Output("Account")]
        [ReferenceTarget("account")]
        public OutArgument<EntityReference> Account { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='account'>
                                <attribute name='name' />
                                <attribute name='emailaddress1' />
                                <attribute name='address1_composite' />
                                <attribute name='lux_maincontactname' />
                                <attribute name='accountid' />
                                <order attribute='name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='lux_accounttype' operator='eq' value='972970001' />
                                  <condition attribute='name' operator='like' value='%{CompanyName.Get(executionContext).Replace("&", "&amp;").Replace("'", "&apos;").Replace("\"", "&quot;")}%' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                this.IsAccountExist.Set(executionContext, true);
                var contact = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                Account.Set(executionContext, contact.ToEntityReference());
            }
            else
            {
                var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='contact'>
                                <attribute name='new_fullname' />
                                <attribute name='emailaddress1' />
                                <attribute name='address1_composite' />
                                <attribute name='parentcustomerid' />
                                <attribute name='telephone1' />
                                <attribute name='contactid' />
                                <order attribute='new_fullname' descending='false' />
                                <filter type='and'>
                                  <condition attribute='lux_contacttype' operator='eq' value='972970001' />
                                  <condition attribute='statuscode' operator='eq' value='1' />
                                  <condition attribute='new_fullname' operator='like' value='%{CompanyName.Get(executionContext).Replace("&", "&amp;").Replace("'", "&apos;").Replace("\"", "&quot;")}%' />
                                </filter>
                              </entity>
                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
                {
                    var contact = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities[0];
                    if (contact.Contains("parentcustomerid"))
                    {
                        this.IsAccountExist.Set(executionContext, true);
                        Account.Set(executionContext, new EntityReference("account", contact.GetAttributeValue<EntityReference>("parentcustomerid").Id));
                    }
                }
            }
        }
    }
}
