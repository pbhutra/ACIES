﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Globalization;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class GetPolicyEndDate : CodeActivity
    {
        //[Input("Policy")]
        //[ReferenceTarget("lux_policy")]
        //[RequiredArgument]
        //public InArgument<EntityReference> Policy { get; set; }

        [RequiredArgument]
        [Input("Policy End Date")]
        public InArgument<DateTime> PolicyEndDate { get; set; }

        [Output("Updated Policy End Date")]
        public OutArgument<DateTime> UpdatedPolicyEndDate { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var date = PolicyEndDate.Get<DateTime>(executionContext);
            tracingService.Trace(date.ToString());
            TimeZoneInfo gmtZone = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");
            TimeZoneInfo utcZone = TimeZoneInfo.FindSystemTimeZoneById("UTC");

            var gmtDT = TimeZoneInfo.ConvertTime(date, utcZone, gmtZone);

            UpdatedPolicyEndDate.Set(executionContext, gmtDT.Date);
            tracingService.Trace(gmtDT.Date.ToString());

            //tracingService.Trace(gmtDT.ToString());
            //bool sds = gmtZone.IsDaylightSavingTime(gmtDT);
            //if (sds)
            //{
            //    var date3 = gmtDT.Date;
            //    UpdatedPolicyEndDate.Set(executionContext, date3.AddHours(-1));
            //    tracingService.Trace("BST: " + date3.ToString());
            //}
            //else
            //{
            //    var date3 = gmtDT.Add(new TimeSpan(0, 0, 0));
            //    UpdatedPolicyEndDate.Set(executionContext, date3);
            //    tracingService.Trace("UTC: " + date3.ToString());
            //}


            //TimeZoneInfo tst = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");
            //var date1 = DateTime.Parse(date.ToLongDateString());
            //tracingService.Trace(date1.ToString());
            //var date2 = TimeZoneInfo.ConvertTimeFromUtc(date1, tst);
            //tracingService.Trace(date2.ToString());
            //var ssd = tst.IsDaylightSavingTime(date2);
            //if (ssd)
            //{
            //    tracingService.Trace("BST");
            //    tracingService.Trace(date2.ToString());
            //    var date3 = date2.Add(new TimeSpan(0, 0, 0));

            //    //policy["lux_policyenddate"] = date;
            //    //service.Update(policy);

            //    tracingService.Trace(date3.AddHours(-1).ToString());
            //    UpdatedPolicyEndDate.Set(executionContext, date3.AddHours(-1));
            //}
            //else
            //{
            //    tracingService.Trace("GMT");
            //    tracingService.Trace(date2.ToString());
            //    var date3 = date2.Add(new TimeSpan(0, 0, 0));

            //    //policy["lux_policyenddate"] = date;
            //    //service.Update(policy);

            //    tracingService.Trace(date3.ToString());
            //    UpdatedPolicyEndDate.Set(executionContext, date3);
            //}
        }


        public static void ssss()
        {
            ClientCredentials clientCredentials = new ClientCredentials();
            clientCredentials.UserName.UserName = "support@mgucrm.onmicrosoft.com";
            clientCredentials.UserName.Password = "nPmv88~4";

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            // Copy and Paste Organization Service Endpoint Address URL
            var service = (IOrganizationService)new OrganizationServiceProxy(new Uri("https://mgunderwriting.api.crm11.dynamics.com//XRMServices/2011/Organization.svc"),
             null, clientCredentials, null);

            Entity pol = service.Retrieve("lux_policy", new Guid("24788609-E5F7-EA11-A815-000D3A0BA3B3"), new ColumnSet(true));
            var PolicyEndDate = pol.GetAttributeValue<DateTime>("lux_policyenddate");

            TimeZoneInfo gmtZone = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");
            TimeZoneInfo utcZone = TimeZoneInfo.FindSystemTimeZoneById("UTC");

            var gmtDT = TimeZoneInfo.ConvertTime(PolicyEndDate, utcZone, gmtZone);

            bool sds = gmtZone.IsDaylightSavingTime(gmtDT);
            if (sds)
            {
                var date3 = gmtDT.Date.AddHours(-1);
            }
            else
            {
                var date3 = gmtDT.Add(new TimeSpan(0, 0, 0));
            }
        }
    }
}
