﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Text.RegularExpressions;

namespace CustomWorkflows
{
    public class CreateBritBDXRecord : CodeActivity
    {
        [Input("Policy")]
        [ReferenceTarget("lux_policy")]
        [RequiredArgument]
        public InArgument<EntityReference> Policy { get; set; }

        [Input("Application")]
        [ReferenceTarget("lux_application")]
        [RequiredArgument]
        public InArgument<EntityReference> Application { get; set; }

        [Input("Installment")]
        [ReferenceTarget("lux_installmentschedule")]
        [RequiredArgument]
        public InArgument<EntityReference> Installment { get; set; }

        [Input("Binder")]
        [ReferenceTarget("lux_binder")]
        [RequiredArgument]
        public InArgument<EntityReference> Binder { get; set; }

        [RequiredArgument]
        [Input("Product")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> Product { get; set; }

        [RequiredArgument]
        [Input("BDX Type")]
        public InArgument<string> BDXType { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            var ProductName = Product.Get<EntityReference>(executionContext).Id;

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference policyref = Policy.Get<EntityReference>(executionContext);
            Entity policy = service.Retrieve("lux_policy", policyref.Id, new ColumnSet(true));

            EntityReference appref = Application.Get<EntityReference>(executionContext);
            Entity appln = service.Retrieve("lux_application", appref.Id, new ColumnSet(true));

            EntityReference binref = Binder.Get<EntityReference>(executionContext);
            Entity binder = service.Retrieve("lux_binder", binref.Id, new ColumnSet(true));

            EntityReference installref = Installment.Get<EntityReference>(executionContext);
            Entity installment = service.Retrieve("lux_installmentschedule", installref.Id, new ColumnSet(true));

            //Property Owners
            if (ProductName == new Guid("2f4e1a03-9583-ea11-a811-000d3a0bad7c"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_propertyowners'>
                                    <attribute name='lux_propertyownersid' />
                                    <attribute name='lux_premisestreet' />
                                    <attribute name='lux_premisepostcode' />
                                    <attribute name='lux_premisenumber' />
                                    <order attribute='lux_premisenumber' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='lux_isdeleted' operator='ne' value='1' />
                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_application' value='{appln.Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    var LocationNo = 1;
                    foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        var item = service.Retrieve("lux_propertyowners", item1.Id, new ColumnSet(true));

                        Entity bdx = new Entity("lux_bordereaux");
                        bdx["lux_installment"] = new EntityReference("lux_installmentschedule", installref.Id);
                        if (policy.Attributes.Contains("lux_yoa"))
                        {
                            bdx["lux_yoa"] = Convert.ToInt32(policy.Attributes["lux_yoa"]);
                        }
                        bdx["lux_coverholderumrpolicyreference"] = policy.Attributes.Contains("lux_policynumber") ? policy.Attributes["lux_policynumber"] : "";
                        bdx["lux_underwriterinitials"] = policy.Attributes.Contains("lux_mgunderwriter") ? Regex.Replace(policy.FormattedValues["lux_mgunderwriter"], @"(?i)(?:^|\s|-)+([^\s-])[^\s-]*(?:(?:\s+)(?:the\s+)?(?:jr|sr|II|2nd|III|3rd|IV|4th)\.?$)?", "$1").ToUpper() : "";
                        bdx["lux_referralreference"] = "";
                        bdx["lux_transactiontype"] = BDXType.Get(executionContext);
                        bdx["lux_reason"] = policy.Attributes.Contains("lux_cancellationreason") ? policy.FormattedValues["lux_cancellationreason"] : "";

                        bdx["lux_nameofpolicyholder"] = appln.Attributes.Contains("lux_customername1") ? appln.Attributes["lux_customername1"] : "";
                        bdx["lux_subsidiarycompany"] = "";

                        bdx["lux_correspondenceaddress"] = appln.Attributes.Contains("lux_street1") ? appln.Attributes["lux_street1"] : "" + ", " + (appln.Attributes.Contains("lux_citycounty1") ? appln.Attributes["lux_citycounty1"] : "");
                        bdx["lux_correspondencepostcode"] = appln.Attributes.Contains("lux_postcode1") ? appln.Attributes["lux_postcode1"] : "";

                        //if (policy.Attributes.Contains("lux_policyholder"))
                        //{
                        //    Entity customer_detail = service.Retrieve(((EntityReference)policy["lux_policyholder"]).LogicalName, ((EntityReference)policy["lux_policyholder"]).Id, new ColumnSet(true));
                        //    bdx["lux_correspondenceaddress"] = customer_detail.Attributes.Contains("address1_line1") == true ? customer_detail.Attributes["address1_line1"] : "" + ", " + (customer_detail.Attributes.Contains("address1_city") == true ? customer_detail.Attributes["address1_city"] : "");
                        //    bdx["lux_correspondencepostcode"] = customer_detail.Attributes.Contains("address1_postalcode") == true ? customer_detail.Attributes["address1_postalcode"] : "";
                        //}

                        if (item1.GetAttributeValue<OptionSetValue>("lux_natureofproperty").Value != 972970000)
                        {
                            bdx["lux_policytype"] = "CPO";
                        }
                        else
                        {
                            bdx["lux_policytype"] = "RPO";
                        }

                        bdx["lux_policyexpirydateddmmyy"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_policyinceptiondateddmmyy"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                        if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "MTA")
                        {
                            bdx["lux_policyissuedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_mtadate") == true ? policy.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        else
                        {
                            bdx["lux_policyissuedate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        bdx["lux_locationnumber"] = item.Attributes.Contains("lux_premisenumber") == true ? item.Attributes["lux_premisenumber"] : 1;
                        bdx["lux_buildingname"] = "";
                        bdx["lux_buildingnumber"] = "";
                        bdx["lux_riskaddress"] = item.Attributes.Contains("lux_premisestreet") == true ? item.Attributes["lux_premisestreet"] : "";
                        bdx["lux_riskpostcode"] = item.Attributes.Contains("lux_premisepostcode") == true ? item.Attributes["lux_premisepostcode"] : "";
                        bdx["lux_terrorismyn"] = item.FormattedValues["lux_doyouwanttoaddterrorismcover"] == "Yes" ? "Y" : "N";
                        bdx["lux_terrorismzone"] = item.Attributes.Contains("lux_terrorismzone") == true ? item.Attributes["lux_terrorismzone"] : "";
                        bdx["lux_countrycode"] = "GB";
                        bdx["lux_currency"] = "GBP";
                        bdx["lux_constructionclass"] = "";
                        bdx["lux_numberofstories"] = item.Attributes.Contains("lux_numberofstoreys") == true ? Convert.ToInt32(item.Attributes["lux_numberofstoreys"]) : 0;
                        if (item.Attributes.Contains("lux_yearofconstruction"))
                        {
                            bdx["lux_yearbuilt"] = item.Attributes.Contains("lux_yearofconstruction") ? item.Attributes["lux_yearofconstruction"].ToString() : "";
                        }
                        bdx["lux_squarefootage"] = "";
                        bdx["lux_flatroofyn"] = item.FormattedValues["lux_doesthepropertyhaveaflatroof"] == "Yes" ? "Y" : "N";
                        bdx["lux_flatroofmaterial"] = item.Attributes.Contains("lux_whatmaterialistheflatroofcovering") == true ? item.FormattedValues["lux_whatmaterialistheflatroofcovering"] : "";
                        bdx["lux_flatroof"] = item.Attributes.Contains("lux_asapercentageoftheroofareahowmuchisflat") == true ? item.FormattedValues["lux_asapercentageoftheroofareahowmuchisflat"] : "";
                        bdx["lux_occupationtradedescriptionfreeformat"] = (item.Attributes.Contains("lux_natureofproperty") ? item.FormattedValues["lux_natureofproperty"] + ", " : "") + (item.Attributes.Contains("lux_residentialtypeofdwelling") ? item.FormattedValues["lux_residentialtypeofdwelling"] + ", " : "") + (item.Attributes.Contains("lux_residentialoccupancytype") ? item.FormattedValues["lux_residentialoccupancytype"] : "");
                        bdx["lux_generictradecode"] = "";
                        var buildingRebuildValue = item.Attributes.Contains("lux_buildingsrebuildvalue") == true ? item.GetAttributeValue<Money>("lux_buildingsrebuildvalue").Value : 0;
                        var landloredValue = item.Attributes.Contains("lux_landlordscontentsuminsured") == true ? item.GetAttributeValue<Money>("lux_landlordscontentsuminsured").Value : 0;
                        var lossofRentValue = item.Attributes.Contains("lux_lossofrentreceivable") == true ? item.GetAttributeValue<Money>("lux_lossofrentreceivable").Value : 0;
                        bdx["lux_buildingsdeclaredvalue"] = Convert.ToInt32(buildingRebuildValue);
                        bdx["lux_landlordscontentsvalue"] = Convert.ToInt32(landloredValue);
                        //bdx["lux_tenantsimprovementsvalue"] = "";
                        //bdx["lux_contentsofcommonpartsvalue"] = "";
                        bdx["lux_lossofrentvalue"] = Convert.ToInt32(lossofRentValue);
                        tracingService.Trace(item.FormattedValues["lux_indemnityperiod"]);
                        //bdx["lux_indemnityperiodmonths"] = item.Attributes.Contains("lux_indemnityperiod") == true ? item.FormattedValues["lux_indemnityperiod"] : "";
                        bdx["lux_alternativeaccommodation"] = "";
                        bdx["lux_totalsuminsured"] = Convert.ToInt32(buildingRebuildValue + landloredValue + lossofRentValue);
                        tracingService.Trace(appln.FormattedValues["lux_propertyownersliability"]);
                        //bdx["lux_propertyownerslimitofindemnity"] = appln.Attributes.Contains("lux_propertyownersliability") == true ? appln.FormattedValues["lux_propertyownersliability"] : "";
                        //bdx["lux_employerslimitofindemnity"] = "";
                        bdx["lux_wageroll"] = 0;
                        bdx["lux_ernnumber"] = "";

                        decimal buildingPremium = 0;
                        decimal lossofrentpremium = 0;
                        decimal lossofservicechargepremium = 0;
                        decimal POLPremium = 0;
                        decimal ELPremium = 0;
                        decimal LEPremium = 0;
                        decimal PremiseTaxAmount = 0;
                        decimal TotalIPT = 0;

                        if (BDXType.Get(executionContext) == "MTA")
                        {
                            bdx["lux_effectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_mtadate") == true ? policy.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                            buildingPremium = item.Attributes.Contains("lux_buildingsrebuildmtasubtotal") == true ? item.GetAttributeValue<Money>("lux_buildingsrebuildmtasubtotal").Value : 0;
                            lossofrentpremium = item.Attributes.Contains("lux_lossofrentmtasubtotal") == true ? item.GetAttributeValue<Money>("lux_lossofrentmtasubtotal").Value : 0;
                            lossofservicechargepremium = item.Attributes.Contains("lux_landlordscontentmtasubtotal") == true ? item.GetAttributeValue<Money>("lux_landlordscontentmtasubtotal").Value : 0;
                            POLPremium = policy.Attributes.Contains("lux_polmtapremium") == true ? policy.GetAttributeValue<Money>("lux_polmtapremium").Value : 0;
                            ELPremium = policy.Attributes.Contains("lux_elmtapremium") == true ? policy.GetAttributeValue<Money>("lux_elmtapremium").Value : 0;
                            LEPremium = policy.Attributes.Contains("lux_lemtapremium") == true ? policy.GetAttributeValue<Money>("lux_lemtapremium").Value : 0;
                            PremiseTaxAmount = item.Attributes.Contains("lux_premisemtaipt") == true ? item.GetAttributeValue<Money>("lux_premisemtaipt").Value : 0;
                            TotalIPT = policy.Attributes.Contains("lux_mtaipt") == true ? policy.GetAttributeValue<Money>("lux_mtaipt").Value : 0;
                        }
                        else if (BDXType.Get(executionContext) == "Cancellation")
                        {
                            bdx["lux_effectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_cancellationdate") == true ? policy.FormattedValues["lux_cancellationdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                            buildingPremium = -1 * (item.Attributes.Contains("lux_buildingrebuildrefundsubtotal") == true ? item.GetAttributeValue<Money>("lux_buildingrebuildrefundsubtotal").Value : 0);
                            lossofrentpremium = -1 * (item.Attributes.Contains("lux_lossofrentrefundamount") == true ? item.GetAttributeValue<Money>("lux_lossofrentrefundamount").Value : 0);
                            lossofservicechargepremium = -1 * (item.Attributes.Contains("lux_landlordscontentrefundsubtotal") == true ? item.GetAttributeValue<Money>("lux_landlordscontentrefundsubtotal").Value : 0);
                            POLPremium = -1 * (policy.Attributes.Contains("lux_polrefundamount") == true ? policy.GetAttributeValue<Money>("lux_polrefundamount").Value : 0);
                            ELPremium = -1 * (policy.Attributes.Contains("lux_elrefundamount") == true ? policy.GetAttributeValue<Money>("lux_elrefundamount").Value : 0);
                            LEPremium = -1 * (policy.Attributes.Contains("lux_refundleamount") == true ? policy.GetAttributeValue<Money>("lux_refundleamount").Value : 0);
                            PremiseTaxAmount = -1 * (item.Attributes.Contains("lux_premiserefundipt") == true ? item.GetAttributeValue<Money>("lux_premiserefundipt").Value : 0);
                            TotalIPT = -1 * (policy.Attributes.Contains("lux_totalrefundipt") == true ? policy.GetAttributeValue<Money>("lux_totalrefundipt").Value : 0);
                        }
                        else
                        {
                            bdx["lux_effectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                            buildingPremium = item.Attributes.Contains("lux_buildingsrebuildvaluesubtotal") == true ? item.GetAttributeValue<Money>("lux_buildingsrebuildvaluesubtotal").Value : 0;
                            lossofrentpremium = item.Attributes.Contains("lux_lossofrentsubtotal") == true ? item.GetAttributeValue<Money>("lux_lossofrentsubtotal").Value : 0;
                            lossofservicechargepremium = item.Attributes.Contains("lux_landlordscontentssubtotal") == true ? item.GetAttributeValue<Money>("lux_landlordscontentssubtotal").Value : 0;
                            POLPremium = policy.Attributes.Contains("lux_polgross") == true ? policy.GetAttributeValue<Money>("lux_polgross").Value : 0;
                            ELPremium = policy.Attributes.Contains("lux_elgross") == true ? policy.GetAttributeValue<Money>("lux_elgross").Value : 0;
                            LEPremium = policy.Attributes.Contains("lux_legross") == true ? policy.GetAttributeValue<Money>("lux_legross").Value : 0;
                            PremiseTaxAmount = item.Attributes.Contains("lux_riskipt") == true ? item.GetAttributeValue<Money>("lux_riskipt").Value : 0;
                            TotalIPT = policy.Attributes.Contains("lux_insurancepremiumtax") == true ? policy.GetAttributeValue<Money>("lux_insurancepremiumtax").Value : 0;
                        }

                        bdx["lux_buildingcontentpremium"] = buildingPremium;
                        bdx["lux_lossofrentpremium"] = lossofrentpremium;
                        bdx["lux_lossofservicechargepremium"] = lossofservicechargepremium;
                        bdx["lux_totalpdbipremium"] = buildingPremium + lossofrentpremium + lossofservicechargepremium;

                        var GrossCommissionRate = policy.Attributes.Contains("lux_grosscommissionrate") == true ? policy.GetAttributeValue<decimal>("lux_grosscommissionrate") : 0;

                        if (LocationNo == 1)
                        {
                            bdx["lux_polpremium"] = POLPremium;
                            bdx["lux_elpremium"] = ELPremium;
                            bdx["lux_totalliabilitiespremium"] = POLPremium + ELPremium;
                            bdx["lux_legalexpensespremium"] = LEPremium;
                            //bdx["lux_terrorismpremium"] = "";
                            bdx["lux_coverholderfee"] = policy.Attributes.Contains("lux_adminfee") == true ? policy.GetAttributeValue<Money>("lux_adminfee").Value : 0;
                            bdx["lux_anyotherfeeincproducingbroker"] = Convert.ToDecimal(0);
                            bdx["lux_taxamt"] = TotalIPT;
                            bdx["lux_totalpremiumpayablebypolicyholderinctax"] = buildingPremium + lossofrentpremium + lossofservicechargepremium + POLPremium + ELPremium + LEPremium + TotalIPT;

                            bdx["lux_totalpremiumexterrorismextax"] = buildingPremium + lossofrentpremium + lossofservicechargepremium + POLPremium + ELPremium + LEPremium;
                            bdx["lux_totalpremiumincterrorismextax"] = buildingPremium + lossofrentpremium + lossofservicechargepremium + POLPremium + ELPremium + LEPremium;

                            var GrossComm = (buildingPremium + lossofrentpremium + lossofservicechargepremium + POLPremium + ELPremium + LEPremium) * GrossCommissionRate / 100;
                            var NetAmtIncIPT = buildingPremium + lossofrentpremium + lossofservicechargepremium + POLPremium + ELPremium + LEPremium - GrossComm + TotalIPT;
                            bdx["lux_netpremiumtounderwritersinctax"] = NetAmtIncIPT;

                        }
                        else
                        {
                            bdx["lux_taxamt"] = PremiseTaxAmount;
                            bdx["lux_totalpremiumpayablebypolicyholderinctax"] = buildingPremium + lossofrentpremium + lossofservicechargepremium + PremiseTaxAmount;

                            bdx["lux_totalpremiumexterrorismextax"] = buildingPremium + lossofrentpremium + lossofservicechargepremium + PremiseTaxAmount;
                            bdx["lux_totalpremiumincterrorismextax"] = buildingPremium + lossofrentpremium + lossofservicechargepremium + PremiseTaxAmount;

                            var GrossComm = (buildingPremium + lossofrentpremium + lossofservicechargepremium + PremiseTaxAmount) * GrossCommissionRate / 100;
                            var NetAmtIncIPT = buildingPremium + lossofrentpremium + lossofservicechargepremium + PremiseTaxAmount - GrossComm + TotalIPT;
                            bdx["lux_netpremiumtounderwritersinctax"] = NetAmtIncIPT;
                        }

                        bdx["lux_tax"] = item.Attributes.Contains("lux_iptrate") == true ? item.GetAttributeValue<decimal>("lux_iptrate") : Convert.ToDecimal(0);
                        bdx["lux_coverholdercommission"] = GrossCommissionRate;
                        //bdx["lux_terrorismcommission"] = "";
                        bdx["lux_lloydsbrokercommission"] = policy.Attributes.Contains("lux_brokercommissionrate") == true ? policy.GetAttributeValue<decimal>("lux_brokercommissionrate") : 0;
                        tracingService.Trace("Test5");
                        if (appln.Attributes.Contains("lux_surveyrequired"))
                        {
                            bdx["lux_surveyrequiredyn"] = appln.FormattedValues["lux_surveyrequired"] == "Yes" ? "yes" : "no";
                        }
                        //bdx["lux_technicalpriceexleexterrorismextax"] = "";
                        //bdx["lux_discretiondiscountloading"] = "";

                        var excessFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_applicationexcess'>
                                                <attribute name='lux_name' />
                                                <attribute name='lux_excessvalue' />
                                                <attribute name='lux_applicationexcessid' />
                                                <order attribute='lux_name' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='lux_application' operator='eq' uitype='lux_application' value='{appln.Id}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                        var Excess = service.RetrieveMultiple(new FetchExpression(excessFetch)).Entities;
                        if (Excess.Count > 0)
                        {
                            var FloodExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Flood Excess");
                            var SubsidenceExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Subsidence Excess");
                            var EOWExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "EOW Excess");
                            var TheftExcess = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "Theft Excess");
                            var AllOthersExcessExFLEA = Excess.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == "All Others Excess Ex FLEA");

                            bdx["lux_floodexcess"] = FloodExcess != null ? Convert.ToInt32(FloodExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                            bdx["lux_subsidenceexcess"] = SubsidenceExcess != null ? Convert.ToInt32(SubsidenceExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                            bdx["lux_eowexcess"] = EOWExcess != null ? Convert.ToInt32(EOWExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                            bdx["lux_theftexcess"] = TheftExcess != null ? Convert.ToInt32(TheftExcess.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                            bdx["lux_allothersexcessexflea"] = AllOthersExcessExFLEA != null ? Convert.ToInt32(AllOthersExcessExFLEA.GetAttributeValue<Money>("lux_excessvalue").Value) : 0;
                            bdx["lux_coverexcludesfloodyn"] = "";
                        }
                        tracingService.Trace("Test6");
                        //var endorsementFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                        //                             <entity name='lux_applicationendorsements'>
                        //                                <attribute name='lux_name' />
                        //                                <attribute name='lux_isstandard' />
                        //                                <attribute name='lux_isamended' />
                        //                                <attribute name='lux_endorsement' />
                        //                                <attribute name='lux_endorsementtext' />
                        //                                <attribute name='lux_applicationendorsementsid' />
                        //                                <order attribute='lux_name' descending='false' />
                        //                                <filter type='and'>
                        //                                  <condition attribute='lux_application' operator='eq' uitype='lux_application' value='{appln.Id}' />
                        //                                </filter>
                        //                              </entity>
                        //                            </fetch>";
                        //var Endorsement = service.RetrieveMultiple(new FetchExpression(endorsementFetch)).Entities;
                        //if (Endorsement.Count > 0)
                        //{
                        //    var end = Endorsement.Select(x => x.Attributes["lux_endorsementtext"]);
                        //    var Endorse = "";
                        //    foreach (var iend in end)
                        //    {
                        //        Endorse += iend.ToString() + "\r\n";
                        //    }
                        //    bdx["lux_notesadditionaltermsinformartionandexclusionsetc"] = Endorse;
                        //}
                        bdx["lux_writtenline"] = 100;
                        bdx["lux_bordereautype"] = new OptionSetValue(972970002);
                        tracingService.Trace("Test7");
                        if (appln.Attributes.Contains("lux_wasthisriskreferredtoinsurers") && appln.FormattedValues["lux_wasthisriskreferredtoinsurers"] == "Yes")
                        {
                            bdx["lux_wastheriskreferredtoinsurers"] = true;
                        }
                        else
                        {
                            bdx["lux_wastheriskreferredtoinsurers"] = false;
                        }
                        tracingService.Trace("Test8");
                        bdx["lux_floodperil"] = false;
                        bdx["lux_subsidenceperil"] = false;
                        service.Create(bdx);
                        LocationNo++;
                    }
                }
            }
        }
    }
}