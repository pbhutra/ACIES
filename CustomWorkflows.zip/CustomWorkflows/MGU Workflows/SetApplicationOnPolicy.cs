﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class SetApplicationOnPolicy : CodeActivity
    {
        [RequiredArgument]
        [Input("PolicyNumber")]
        public InArgument<string> PolicyNumber { get; set; }

        [Output("Application")]
        [ReferenceTarget("lux_application")]
        public OutArgument<EntityReference> Application { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_application'>
                                <attribute name='lux_quotenumber' />
                                <attribute name='statuscode' />
                                <attribute name='lux_applicationtype' />
                                <attribute name='lux_product' />
                                <attribute name='lux_mgunderwriter' />
                                <attribute name='createdon' />
                                <attribute name='lux_proposedinceptiondate' />
                                <attribute name='lux_broker' />
                                <attribute name='lux_customername1' />
                                <attribute name='lux_applicationid' />
                                <order attribute='lux_quotenumber' descending='true' />
                                <filter type='and'>
                                  <condition attribute='lux_quotenumber' operator='eq' value='{this.PolicyNumber.Get(executionContext).Trim().Replace(" ", "")}' />
                                </filter>
                              </entity>
                            </fetch>";

            tracingService.Trace(fetch);

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var applin = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                Application.Set(executionContext, applin.ToEntityReference());
            }
        }
    }
}
