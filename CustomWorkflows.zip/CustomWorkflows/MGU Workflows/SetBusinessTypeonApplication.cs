﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class SetBusinessTypeonApplication : CodeActivity
    {
        [RequiredArgument]
        [Input("BusinessTypeText")]
        public InArgument<string> BusinessTypeText { get; set; }

        [RequiredArgument]
        [Input("BusinessSector")]
        [AttributeTarget("lux_application", "lux_businesssector")]
        public InArgument<OptionSetValue> BusinessSector { get; set; }

        [Output("BusinessType")]
        [ReferenceTarget("lux_businesstype")]
        public OutArgument<EntityReference> BusinessType { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_businesstype'>
                                <attribute name='lux_businesstypeid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='new_slug' />
                                <attribute name='new_businesssector' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='new_slug' operator='eq' value='{BusinessTypeText.Get(executionContext).Trim().Replace("--","-").Replace("retreaders", "re-treaders").Replace("prepackaged", "pre-packaged")}' />
                                  <condition attribute='new_businesssector' operator='eq' value='{BusinessSector.Get<OptionSetValue>(executionContext).Value}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var applin = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                BusinessType.Set(executionContext, applin.ToEntityReference());
            }
        }
    }
}
