﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System.Activities;

namespace CustomWorkflows
{
    public class CheckIfPolicyExist : CodeActivity
    {
        [Input("Bordereau")]
        [ReferenceTarget("crb82_bordereau")]
        public InArgument<EntityReference> Bordereau { get; set; }

        [Output("IsExist")]
        public OutArgument<bool> IsExist { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference bdxRef = Bordereau.Get<EntityReference>(executionContext);
            Entity bdx = new Entity(bdxRef.LogicalName, bdxRef.Id);
            bdx = service.Retrieve("crb82_bordereau", bdxRef.Id, new ColumnSet(true));

            var bdxPolicyId = bdx["crb82_policyid"].ToString().Trim();

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'><entity name='contract'><attribute name='title' /><attribute name='contractid' /><attribute name='statuscode' /><order attribute='activeon' descending='true' /><filter type='and'><condition attribute='statuscode' operator='not-in'><value>933140002</value><value>5</value><value>933140003</value></condition><condition attribute='title' operator='eq' value='{bdxPolicyId}' /></filter></entity></fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                this.IsExist.Set(executionContext, true);
            }
            else
            {
                this.IsExist.Set(executionContext, false);
            }
        }

        //public static void ssss()
        //{
        //    ClientCredentials clientCredentials = new ClientCredentials();
        //    clientCredentials.UserName.UserName = "crm@lucidtestbed.onmicrosoft.com"; //HttpContext.Current.Request.Form["UserName"];
        //    clientCredentials.UserName.Password = "$5i2t0Vo"; //HttpContext.Current.Request.Form["Password"];

        //    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        //    // Copy and Paste Organization Service Endpoint Address URL
        //    var organizationService = (IOrganizationService)new OrganizationServiceProxy(new Uri("https://insurxchange.api.crm11.dynamics.com/XRMServices/2011/Organization.svc"),
        //     null, clientCredentials, null);

        //    Entity application = new Entity("crb82_bordereau", new Guid("bfe339ce-840b-ea11-a811-000d3a7ed2f2"));
        //    application = organizationService.Retrieve("crb82_bordereau", new Guid("bfe339ce-840b-ea11-a811-000d3a7ed2f2"), new ColumnSet(true));
        //    string bdxPolicyId = application["crb82_policyid"].ToString();

        //    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'><entity name='contract'><attribute name='title' /><attribute name='contractid' /><attribute name='statuscode' /><order attribute='activeon' descending='true' /><filter type='and'><condition attribute='statuscode' operator='not-in'><value>933140002</value><value>5</value><value>933140003</value></condition><condition attribute='title' operator='eq' value='{bdxPolicyId}' /></filter></entity></fetch>";

        //    if (organizationService.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
        //    {

        //    }
        //}
    }
}
