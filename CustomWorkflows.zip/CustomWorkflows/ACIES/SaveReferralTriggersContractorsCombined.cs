﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Net;
using System.ServiceModel.Description;
using System.Linq;

namespace CustomWorkflows
{
    public class SaveReferralTriggersContractorsCombined : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference applnref = PropertyOwnersApplication.Get<EntityReference>(executionContext);
            Entity appln = new Entity(applnref.LogicalName, applnref.Id);
            appln = service.Retrieve("lux_propertyownersapplications", applnref.Id, new ColumnSet(true));
            var InceptionDate = appln.GetAttributeValue<DateTime>("lux_inceptiondate");
            var RenewalDate = appln.GetAttributeValue<DateTime>("lux_renewaldate");

            //if (InceptionDate >= new DateTime(2024, 01, 01))
            //{
            //    if (appln.Attributes.Contains("lux_doyourequirecoverforcontractwork"))
            //    {
            //        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            //                      <entity name='lux_referral'>
            //                        <attribute name='lux_suppliedvalue' />
            //                        <attribute name='lux_fieldname' />
            //                        <attribute name='lux_approve' />
            //                        <attribute name='lux_additionalinfo' />
            //                        <attribute name='lux_referralid' />
            //                        <order attribute='lux_suppliedvalue' descending='false' />
            //                        <filter type='and'>
            //                          <condition attribute='statecode' operator='eq' value='0' />
            //                          <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
            //                          <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyourequirecoverforcontractwork' />
            //                        </filter>
            //                      </entity>
            //                    </fetch>";

            //        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
            //        {
            //            if (appln.GetAttributeValue<bool>("lux_doyourequirecoverforcontractwork") == true)
            //            {
            //                var FieldName1 = "CAR Cover";

            //                Entity refer = new Entity("lux_referral");
            //                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", appln.Id);
            //                refer["lux_fieldname"] = FieldName1;
            //                refer["lux_fieldschemaname"] = "lux_doyourequirecoverforcontractwork";
            //                refer["lux_suppliedvalue"] = "Yes";
            //                refer["lux_declined"] = true;
            //                refer["lux_additionalinfo"] = "CAR Risk Not Covered";
            //                service.Create(refer);
            //            }
            //        }
            //        else
            //        {
            //            if (appln.GetAttributeValue<bool>("lux_doyourequirecoverforcontractwork") == false)
            //            {
            //                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
            //                foreach (var item in reff)
            //                {
            //                    if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
            //                }
            //            }
            //        }
            //    }
            //}

            if (appln.Attributes.Contains("lux_postcode"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_postcode' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<string>("lux_postcode").StartsWith("BT"))
                    {
                        var FieldName1 = "Postcode";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_postcode";
                        refer["lux_additionalinfo"] = "Northern Ireland Postcode";
                        refer["lux_suppliedvalue"] = appln.Attributes.Contains("lux_postcode") ? appln.Attributes["lux_postcode"] : ""; ;
                        service.Create(refer);
                    }
                }
                else
                {
                    if (!appln.GetAttributeValue<string>("lux_postcode").StartsWith("BT"))
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_declarationsquestion1"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_declarationsquestion1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion1") == false)
                    {
                        var FieldName1 = "The Proposers any Director or Partner in the company:";
                        FieldName1 += "a. Has never been convicted";
                        FieldName1 += "b. Has never been charged(but not yet tried)";
                        FieldName1 += "c. Has never been given an official police caution in respect of any criminal offence other than a than a(road traffic) motoring offence";
                        FieldName1 += "d. Has never been given an official police caution in respect of any criminal offence other than an offence that is now considered 'spent' under the Rehabilitation of Offenders Act 1974";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_declarationsquestion1";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_declarationanswer1") ? appln.Attributes["lux_declarationanswer1"] : "";
                        refer["lux_suppliedvalue"] = "Disagree";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion1") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_declarationsquestion2"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_declarationsquestion2' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion2") == false)
                    {
                        var FieldName1 = "The Proposers, any Director or Partner in the company:";
                        FieldName1 += "a. Has never been declared bankrupt (other than a bankruptcy that has been discharged) or insolvent";
                        FieldName1 += "b. Is not subject to any current bankruptcy or insolvency proceedings";
                        FieldName1 += "c. Has no outstanding County Court Judgement(s) or Sheriff Court Decree(s)";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_declarationsquestion2";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_declarationanswer2") ? appln.Attributes["lux_declarationanswer2"] : "";
                        refer["lux_suppliedvalue"] = "Disagree";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion2") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_declarationsquestion3"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_declarationsquestion3' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion3") == false)
                    {
                        var FieldName1 = "The Proposers any Director or Partner in the company have never been prosecuted or received notice of intended prosecution under:";
                        FieldName1 += "a. The Consumer Protection Act 1987";
                        FieldName1 += "b. The Food Safety Act 1990";
                        FieldName1 += "c. The Health & Safety Act 1974";
                        FieldName1 += "d. Any welfare or environmental protection legislation";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_declarationsquestion3";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_declarationanswer3") ? appln.Attributes["lux_declarationanswer3"] : "";
                        refer["lux_suppliedvalue"] = "Disagree";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion3") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_declarationsquestion4"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_declarationsquestion4' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion4") == false)
                    {
                        var FieldName1 = "The Proposers any Director or Partner in the company have not had:";
                        FieldName1 += "a. an insurance application refused or declined";
                        FieldName1 += "b. an insurance cancelled or renewal refused";
                        FieldName1 += "c. any increased or specific terms applied to any business insurance";
                        FieldName1 += "d. avioided any of your insurance policies for non-disclosure or misrepresentation of any material fact";
                        FieldName1 += "e. refused to pay a claim or restricted cover as a result of a policy terms or condition or risk improvement requirements.";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_declarationsquestion4";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_declarationanswer4") ? appln.Attributes["lux_declarationanswer4"] : "";
                        refer["lux_suppliedvalue"] = "Disagree";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion4") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_claimmadewithinthelast5years") && appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value != 972970003)
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_claimmadewithinthelast5years' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == true)
                    {
                        var FieldName1 = "Has your business been involved in any losses, claims or incidents that may result in a claim within the last 5 years";

                        CalculateRollupFieldRequest calculateRollup = new CalculateRollupFieldRequest();
                        calculateRollup.FieldName = "lux_totalclaimamountpaidoutstanding";
                        calculateRollup.Target = new EntityReference("lux_propertyownersapplications", appln.Id);
                        CalculateRollupFieldResponse resp = (CalculateRollupFieldResponse)service.Execute(calculateRollup);

                        CalculateRollupFieldRequest calculateRollup1 = new CalculateRollupFieldRequest();
                        calculateRollup1.FieldName = "lux_totalnumberofclaims";
                        calculateRollup1.Target = new EntityReference("lux_propertyownersapplications", appln.Id);
                        CalculateRollupFieldResponse resp1 = (CalculateRollupFieldResponse)service.Execute(calculateRollup1);

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_claimmadewithinthelast5years";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_additionalinfo"] = "Total Claim Amount: " + appln.FormattedValues["lux_totalclaimamountpaidoutstanding"] + ", " + "Total Number of Claims: " + appln.GetAttributeValue<Int32>("lux_totalnumberofclaims");
                        service.Create(refer);
                    }
                }
                else
                {
                    var refer1 = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault();
                    if (refer1.GetAttributeValue<bool>("lux_approve") != true)
                    {
                        if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == false)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                            foreach (var item in reff)
                            {
                                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                            }
                        }
                        else if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == true)
                        {
                            var FieldName1 = "Has your business been involved in any losses, claims or incidents that may result in a claim within the last 5 years";

                            CalculateRollupFieldRequest calculateRollup = new CalculateRollupFieldRequest();
                            calculateRollup.FieldName = "lux_totalclaimamountpaidoutstanding";
                            calculateRollup.Target = new EntityReference("lux_propertyownersapplications", appln.Id);
                            CalculateRollupFieldResponse resp = (CalculateRollupFieldResponse)service.Execute(calculateRollup);

                            CalculateRollupFieldRequest calculateRollup1 = new CalculateRollupFieldRequest();
                            calculateRollup1.FieldName = "lux_totalnumberofclaims";
                            calculateRollup1.Target = new EntityReference("lux_propertyownersapplications", appln.Id);
                            CalculateRollupFieldResponse resp1 = (CalculateRollupFieldResponse)service.Execute(calculateRollup1);

                            Entity refer = new Entity("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Id);
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_claimmadewithinthelast5years";
                            refer["lux_suppliedvalue"] = "Yes";
                            refer["lux_additionalinfo"] = "Total Claim Amount: " + appln.FormattedValues["lux_totalclaimamountpaidoutstanding"] + ", " + "Total Number of Claims: " + appln.GetAttributeValue<Int32>("lux_totalnumberofclaims");
                            service.Update(refer);
                        }
                    }
                    else
                    {
                        if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == true)
                        {
                            var FieldName1 = "Has your business been involved in any losses, claims or incidents that may result in a claim within the last 5 years";

                            CalculateRollupFieldRequest calculateRollup = new CalculateRollupFieldRequest();
                            calculateRollup.FieldName = "lux_totalclaimamountpaidoutstanding";
                            calculateRollup.Target = new EntityReference("lux_propertyownersapplications", appln.Id);
                            CalculateRollupFieldResponse resp = (CalculateRollupFieldResponse)service.Execute(calculateRollup);

                            CalculateRollupFieldRequest calculateRollup1 = new CalculateRollupFieldRequest();
                            calculateRollup1.FieldName = "lux_totalnumberofclaims";
                            calculateRollup1.Target = new EntityReference("lux_propertyownersapplications", appln.Id);
                            CalculateRollupFieldResponse resp1 = (CalculateRollupFieldResponse)service.Execute(calculateRollup1);

                            Entity refer = service.Retrieve("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Id, new ColumnSet(true));
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_claimmadewithinthelast5years";
                            refer["lux_suppliedvalue"] = "Yes";
                            if (!refer["lux_additionalinfo"].ToString().Contains(appln.FormattedValues["lux_totalclaimamountpaidoutstanding"]))
                            {
                                refer["lux_approve"] = false;
                                refer["lux_approvaldate"] = null;
                                refer["lux_userapproval"] = null;
                                refer["lux_additionalinfo"] = "Total Claim Amount: " + appln.FormattedValues["lux_totalclaimamountpaidoutstanding"] + ", " + "Total Number of Claims: " + appln.GetAttributeValue<Int32>("lux_totalnumberofclaims");
                            }
                            else
                            {
                                refer["lux_additionalinfo"] = "Total Claim Amount: " + appln.FormattedValues["lux_totalclaimamountpaidoutstanding"] + ", " + "Total Number of Claims: " + appln.GetAttributeValue<Int32>("lux_totalnumberofclaims");
                            }
                            service.Update(refer);
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_claimmadewithinthelast5years") && appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value != 972970003)
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_claimmadewithinthelast5years1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='lux_subsidarycompanypreviousclaim'>
                                        <attribute name='lux_descriptionofclaim' />
                                        <attribute name='lux_dateofclaim' />
                                        <attribute name='lux_causeofclaim' />
                                        <attribute name='lux_amountpaid' />
                                        <attribute name='lux_amountoutstanding' />
                                        <attribute name='lux_totalclaimamount' />
                                        <attribute name='lux_subsidarycompanypreviousclaimid' />
                                        <order attribute='lux_causeofclaim' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='statecode' operator='eq' value='0' />
                                          <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                          <condition attribute='lux_causeofclaim' operator='eq' value='972970015' />
                                        </filter>
                                      </entity>
                                    </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == true && service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
                    {
                        var Claim = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities;
                        var claimCount = Claim.Count;
                        if (claimCount == 1 && Claim.Sum(x => x.GetAttributeValue<Money>("lux_totalclaimamount").Value) > 10000)
                        {
                            var FieldName1 = "ARAG Claims Referral";

                            Entity refer = new Entity("lux_referral");
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_claimmadewithinthelast5years1";
                            refer["lux_suppliedvalue"] = "Total Number of Claims: " + claimCount + ", Total Claim Amount: " + Claim.Sum(x => x.GetAttributeValue<Money>("lux_totalclaimamount").Value);
                            refer["lux_additionalinfo"] = "Refer to ARAG";
                            service.Create(refer);
                        }
                        else if (claimCount >= 2)
                        {
                            var FieldName1 = "ARAG Claims Referral";

                            Entity refer = new Entity("lux_referral");
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_claimmadewithinthelast5years1";
                            refer["lux_suppliedvalue"] = "Total Number of Claims: " + claimCount + ", Total Claim Amount: " + Claim.Sum(x => x.GetAttributeValue<Money>("lux_totalclaimamount").Value);
                            refer["lux_additionalinfo"] = "Refer to ARAG";
                            service.Create(refer);
                        }
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == false || service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count == 0)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                    else if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == true && service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
                    {
                        var Claim = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities;
                        var claimCount = Claim.Count;
                        if (claimCount == 1 && Claim.Sum(x => x.GetAttributeValue<Money>("lux_totalclaimamount").Value) > 10000)
                        {
                            var FieldName1 = "ARAG Claims Referral";

                            Entity refer = new Entity("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Id);
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_claimmadewithinthelast5years1";
                            refer["lux_suppliedvalue"] = "Total Number of Claims: " + claimCount + ", Total Claim Amount: " + Claim.Sum(x => x.GetAttributeValue<Money>("lux_totalclaimamount").Value);
                            refer["lux_additionalinfo"] = "Refer to ARAG";
                            service.Update(refer);
                        }
                        else if (claimCount >= 2)
                        {
                            var FieldName1 = "ARAG Claims Referral";

                            Entity refer = new Entity("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Id);
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_claimmadewithinthelast5years1";
                            refer["lux_suppliedvalue"] = "Total Number of Claims: " + claimCount + ", Total Claim Amount: " + Claim.Sum(x => x.GetAttributeValue<Money>("lux_totalclaimamount").Value);
                            refer["lux_additionalinfo"] = "Refer to ARAG";
                            service.Update(refer);
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_datethebusinessstarted"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_datethebusinessstarted' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if ((DateTime.Now.Year - 1) <= appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").Year)
                    {
                        var FieldName1 = "Date the business started";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_datethebusinessstarted";
                        refer["lux_additionalinfo"] = "Trading less than 12 months";
                        refer["lux_suppliedvalue"] = appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").ToShortDateString();
                        service.Create(refer);
                    }
                }
                else
                {
                    if ((DateTime.Now.Year - 1) > appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").Year)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                    else if ((DateTime.Now.Year - 1) <= appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").Year)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").ToShortDateString();
                        reff["lux_additionalinfo"] = "Trading less than 12 months";
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_anyheatworkawayundertaken"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_anyheatworkawayundertaken' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_anyheatworkawayundertaken") == true)
                    {
                        var FieldName1 = "Any heat work away undertaken";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_anyheatworkawayundertaken";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_anyheatworkawayundertaken") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }
            if (InceptionDate >= new DateTime(2024, 01, 01))
            {
                if (appln.Attributes.Contains("lux_turnover"))
                {
                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_turnover' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                    {
                        if (appln.GetAttributeValue<Money>("lux_turnover").Value > 5000000)
                        {
                            var FieldName1 = "Maximum Turnover";
                            Entity refer = new Entity("lux_referral");
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_turnover";
                            refer["lux_suppliedvalue"] = appln.FormattedValues["lux_turnover"];
                            refer["lux_additionalinfo"] = "Turnover exceeds authority - refer to Liability Carrier";
                            service.Create(refer);
                        }
                    }
                    else
                    {
                        if (appln.GetAttributeValue<Money>("lux_turnover").Value <= 5000000)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                        }
                        else if (appln.GetAttributeValue<Money>("lux_turnover").Value > 5000000)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            reff["lux_suppliedvalue"] = appln.FormattedValues["lux_turnover"];
                            reff["lux_additionalinfo"] = "Turnover exceeds authority - refer to Liability Carrier";
                            service.Update(reff);
                        }
                    }
                }
            }
            else
            {
                if (appln.Attributes.Contains("lux_turnover"))
                {
                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_turnover' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                    {
                        if (appln.GetAttributeValue<Money>("lux_turnover").Value > 10000000)
                        {
                            var FieldName1 = "Maximum Turnover";
                            Entity refer = new Entity("lux_referral");
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_turnover";
                            refer["lux_suppliedvalue"] = appln.FormattedValues["lux_turnover"];
                            refer["lux_additionalinfo"] = "Turnover exceeds authority - refer to Liability Carrier";
                            service.Create(refer);
                        }
                    }
                    else
                    {
                        if (appln.GetAttributeValue<Money>("lux_turnover").Value <= 10000000)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                        }
                        else if (appln.GetAttributeValue<Money>("lux_turnover").Value > 10000000)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            reff["lux_suppliedvalue"] = appln.FormattedValues["lux_turnover"];
                            reff["lux_additionalinfo"] = "Turnover exceeds authority - refer to Liability Carrier";
                            service.Update(reff);
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_turnover"))
            {
                var Turnover = appln.GetAttributeValue<Money>("lux_turnover").Value;
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_referral'>
                                            <attribute name='lux_suppliedvalue' />
                                            <attribute name='lux_fieldname' />
                                            <attribute name='lux_approve' />
                                            <attribute name='lux_additionalinfo' />
                                            <attribute name='lux_referralid' />
                                            <order attribute='lux_suppliedvalue' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                              <condition attribute='lux_fieldschemaname' operator='eq' value='lux_turnover1' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (Turnover >= 10000000)
                    {
                        var FieldName1 = "Total Turnover";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_turnover1";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_turnover"];
                        refer["lux_additionalinfo"] = "ARAG: TOTAL TURNOVER: LIMIT EXCEEDED";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (Turnover < 10000000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_totalwageroll"))
            {
                var bonafideWageroll = appln.Attributes.Contains("lux_bonafidesubcontractorswageroll") ? appln.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value : 0;

                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_totalwageroll' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_totalwageroll").Value + bonafideWageroll > 5000000)
                    {
                        var FieldName1 = "Maximum Wageroll";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_totalwageroll";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_totalwageroll"];
                        refer["lux_additionalinfo"] = "Wageroll exceeds authority - refer to Liability Carrier";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_totalwageroll").Value + bonafideWageroll <= 5000000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<Money>("lux_totalwageroll").Value + bonafideWageroll > 5000000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_totalwageroll"];
                        reff["lux_additionalinfo"] = "Wageroll exceeds authority - refer to Liability Carrier";
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_bonafidesubcontractorswageroll"))
            {
                var TotalTurnover = appln.Attributes.Contains("lux_turnover") ? appln.GetAttributeValue<Money>("lux_turnover").Value : 0;
                var bonafideWageroll = appln.Attributes.Contains("lux_bonafidesubcontractorswageroll") ? appln.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value : 0;

                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_bonafidesubcontractorswageroll' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (TotalTurnover * 80 / 100 < bonafideWageroll)
                    {
                        var FieldName1 = "Bonafide Subcontractors Wageroll";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_bonafidesubcontractorswageroll";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_bonafidesubcontractorswageroll"];
                        refer["lux_additionalinfo"] = "BFSC wageroll exceeds authority - refer to Liability Carrier";
                        refer["lux_refertohcc"] = true;
                        service.Create(refer);
                    }
                }
                else
                {
                    if (TotalTurnover * 80 / 100 >= appln.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (TotalTurnover * 80 / 100 < appln.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_bonafidesubcontractorswageroll"];
                        reff["lux_additionalinfo"] = (bonafideWageroll * 100 / TotalTurnover).ToString("#.##") + "%";
                        reff["lux_refertohcc"] = true;
                        reff["lux_additionalinfo"] = "BFSC wageroll exceeds authority - refer to Liability Carrier";
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_maximumplantsuminsured"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_maximumplantsuminsured' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_maximumplantsuminsured").Value > 100000)
                    {
                        var FieldName1 = "Maximum Single Plant Sum Insured";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_maximumplantsuminsured";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_maximumplantsuminsured"];
                        refer["lux_additionalinfo"] = "Maximum Single Plant limit exceeds authority - refer to Liability Carrier";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_maximumplantsuminsured").Value <= 100000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<Money>("lux_maximumplantsuminsured").Value > 100000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_maximumplantsuminsured"];
                        reff["lux_additionalinfo"] = "Maximum Single Plant limit exceeds authority - refer to Liability Carrier";
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_maximumcontractvalue"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_maximumcontractvalue' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_maximumcontractvalue").Value > 1500000)
                    {
                        var FieldName1 = "Maximum Contract Value";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_maximumcontractvalue";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_maximumcontractvalue"];
                        refer["lux_additionalinfo"] = "Contract Value exceeds Authority - refer to Liability Carrier";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_maximumcontractvalue").Value <= 1500000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<Money>("lux_maximumcontractvalue").Value > 1500000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_maximumcontractvalue"];
                        reff["lux_additionalinfo"] = "Contract Value exceeds Authority - refer to Liability Carrier";
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_employersliabilitypolicypremium"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_employersliabilitypolicypremium' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    var ELPremium = appln.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value;
                    if (ELPremium > 15000)
                    {
                        var FieldName1 = "Employer's Liability Premium";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_employersliabilitypolicypremium";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_employersliabilitypolicypremium"];
                        refer["lux_additionalinfo"] = "Liability Survey Required";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value <= 15000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_publicproductsliabilitypremium"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_publicproductsliabilitypremium' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    var PLPremium = appln.GetAttributeValue<Money>("lux_publicproductsliabilitypremium").Value;
                    if (PLPremium > 15000)
                    {
                        var FieldName1 = "PL/Products Premium";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_publicproductsliabilitypremium";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_publicproductsliabilitypremium"];
                        refer["lux_additionalinfo"] = "Liability Survey Required";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_publicproductsliabilitypremium").Value <= 15000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_moneyonpremisesduringhours"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_moneyonpremisesduringhours' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<OptionSetValue>("lux_moneyonpremisesduringhours").Value > 972970003)
                    {
                        var FieldName1 = "Money on Premises during business hours";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_moneyonpremisesduringhours";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_moneyonpremisesduringhours"];
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<OptionSetValue>("lux_moneyonpremisesduringhours").Value <= 972970003)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<OptionSetValue>("lux_moneyonpremisesduringhours").Value > 972970003)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_moneyonpremisesduringhours"];
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_moneyinspecifiedsafe1"))
            {
                var Money1 = appln.GetAttributeValue<Money>("lux_moneyinspecifiedsafe1").Value;
                var Money2 = appln.Attributes.Contains("lux_moneyinspecifiedsafe2") ? appln.GetAttributeValue<Money>("lux_moneyinspecifiedsafe2").Value : 0;
                var Money3 = appln.Attributes.Contains("lux_moneyinspecifiedsafe3") ? appln.GetAttributeValue<Money>("lux_moneyinspecifiedsafe3").Value : 0;
                var Money4 = appln.Attributes.Contains("lux_moneyinspecifiedsafe4") ? appln.GetAttributeValue<Money>("lux_moneyinspecifiedsafe4").Value : 0;
                var Money5 = appln.Attributes.Contains("lux_moneyinspecifiedsafe5") ? appln.GetAttributeValue<Money>("lux_moneyinspecifiedsafe5").Value : 0;
                var totalMoney = Money1 + Money2 + Money3 + Money4 + Money5;

                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_moneyinspecifiedsafe1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (totalMoney >= 10000)
                    {
                        var FieldName1 = "Money in specified safe in excess of £10,000";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_moneyinspecifiedsafe1";
                        refer["lux_suppliedvalue"] = "£" + totalMoney;
                        service.Create(refer);
                    }
                }
                else
                {
                    if (totalMoney < 10000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (totalMoney >= 10000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = "£" + totalMoney;
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_allriskitems"))
            {
                var AllRiskfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_allriskitem'>
                                                <attribute name='lux_typeofequipment' />
                                                <attribute name='lux_territoriallimit' />
                                                <attribute name='lux_suminsured' />
                                                <attribute name='lux_excess' />
                                                <attribute name='lux_allriskitemid' />
                                                <order attribute='lux_typeofequipment' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                                </filter>
                                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_application' link-type='inner' alias='aa'>
                                                  <filter type='and'>
                                                    <condition attribute='lux_allriskitems' operator='eq' value='1' />
                                                  </filter>
                                                </link-entity>
                                              </entity>
                                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.Count > 0)
                {
                    var CheckAmt = service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.Where(x => x.GetAttributeValue<Money>("lux_suminsured").Value > 10000).Count();
                    var items = service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.Where(x => x.GetAttributeValue<Money>("lux_suminsured").Value > 10000).Select(y => y.FormattedValues["lux_typeofequipment"]).ToArray();

                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_referral'>
                                                    <attribute name='lux_suppliedvalue' />
                                                    <attribute name='lux_fieldname' />
                                                    <attribute name='lux_approve' />
                                                    <attribute name='lux_additionalinfo' />
                                                    <attribute name='lux_referralid' />
                                                    <order attribute='lux_suppliedvalue' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_allriskitems' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                    {
                        if (CheckAmt > 0 && appln.GetAttributeValue<bool>("lux_allriskitems") == true)
                        {
                            var FieldName1 = "All Risk Items";
                            Entity refer = new Entity("lux_referral");
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_allriskitems";
                            refer["lux_suppliedvalue"] = String.Join(",", items);
                            refer["lux_additionalinfo"] = "Sum Insured Amount Exceed £10,000";
                            service.Create(refer);
                        }
                    }
                    else
                    {
                        if (CheckAmt == 0 || appln.GetAttributeValue<bool>("lux_allriskitems") == false)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                        }
                        else if (CheckAmt > 0 && appln.GetAttributeValue<bool>("lux_allriskitems") == true)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            reff["lux_suppliedvalue"] = String.Join(",", items);
                            reff["lux_additionalinfo"] = "Sum Insured Amount Exceed £10,000";
                            service.Update(reff);
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_allriskitems"))
            {
                var AllRiskfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_allriskitem'>
                                                <attribute name='lux_typeofequipment' />
                                                <attribute name='lux_territoriallimit' />
                                                <attribute name='lux_suminsured' />
                                                <attribute name='lux_itemdescription' />
                                                <attribute name='lux_excess' />
                                                <attribute name='lux_allriskitemid' />
                                                <order attribute='lux_typeofequipment' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                                </filter>
                                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_application' link-type='inner' alias='aa'>
                                                  <filter type='and'>
                                                    <condition attribute='lux_allriskitems' operator='eq' value='1' />
                                                  </filter>
                                                </link-entity>
                                              </entity>
                                            </fetch>";

                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_referral'>
                                                    <attribute name='lux_suppliedvalue' />
                                                    <attribute name='lux_fieldname' />
                                                    <attribute name='lux_approve' />                                                    
                                                    <attribute name='lux_additionalinfo' />
                                                    <attribute name='lux_referralid' />
                                                    <order attribute='lux_suppliedvalue' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_allriskitemsothers' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.Count > 0)
                {
                    var items = service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_typeofequipment").Value == 972970010);

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                    {
                        if (items != null && appln.GetAttributeValue<bool>("lux_allriskitems") == true)
                        {
                            var FieldName1 = "All Risk Items - Other";
                            Entity refer = new Entity("lux_referral");
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_allriskitemsothers";
                            if (service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.FirstOrDefault().Attributes.Contains("lux_itemdescription"))
                            {
                                refer["lux_suppliedvalue"] = service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.FirstOrDefault().Attributes["lux_itemdescription"];
                            }
                            refer["lux_additionalinfo"] = "Other";
                            service.Create(refer);
                        }
                    }
                    else
                    {
                        if (items == null || appln.GetAttributeValue<bool>("lux_allriskitems") == false)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                        }
                        else if (items != null && appln.GetAttributeValue<bool>("lux_allriskitems") == true)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            if (service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.FirstOrDefault().Attributes.Contains("lux_itemdescription"))
                            {
                                reff["lux_suppliedvalue"] = service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.FirstOrDefault().Attributes["lux_itemdescription"];
                            }
                            reff["lux_additionalinfo"] = "Other";
                            service.Update(reff);
                        }
                    }
                }
                else
                {
                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouknowinglysupplyormanufactureanyprodu"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouknowinglysupplyormanufactureanyprodu' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouknowinglysupplyormanufactureanyprodu") == true)
                    {
                        var FieldName1 = "Do you knowingly supply or manufacture any products used in Aircraft, Ships, Automotive, Railways or offshore installations";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouknowinglysupplyormanufactureanyprodu";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouknowinglysupplyormanufactureanyprodu") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyoumanufactureorsupplyanysafetycritical"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyoumanufactureorsupplyanysafetycritical' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyoumanufactureorsupplyanysafetycritical") == true)
                    {
                        var FieldName1 = "Do you manufacture or supply any safety critical products";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyoumanufactureorsupplyanysafetycritical";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyoumanufactureorsupplyanysafetycritical") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_thesourceoftheproductsrawmaterialscompone"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_thesourceoftheproductsrawmaterialscompone' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_thesourceoftheproductsrawmaterialscompone") == false)
                    {
                        var FieldName1 = "Do you maintain an adequate system of records which would enable the identification of the source of the products/raw materials/components parts purchased";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_thesourceoftheproductsrawmaterialscompone";
                        refer["lux_suppliedvalue"] = "No";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_thesourceoftheproductsrawmaterialscompone") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_areallgoodslabelledandsuppliedwithclearin"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_areallgoodslabelledandsuppliedwithclearin' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_areallgoodslabelledandsuppliedwithclearin") == false)
                    {
                        var FieldName1 = "Are all goods labelled and supplied with clear instructions in the language of the country to which they are supplied?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_areallgoodslabelledandsuppliedwithclearin";
                        refer["lux_suppliedvalue"] = "No";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_areallgoodslabelledandsuppliedwithclearin") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworkabove10minheight"))
            {
                var heightWorked = appln.Attributes.Contains("lux_maximumheightworkedatmetres") ? appln.GetAttributeValue<decimal>("lux_maximumheightworkedatmetres") : 0;

                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworkabove10minheight' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworkabove10minheight") == true && heightWorked > 10)
                    {
                        var FieldName1 = "Maximum Height Worked at (Metres)";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworkabove10minheight";
                        refer["lux_suppliedvalue"] = appln.Attributes.Contains("lux_maximumheightworkedatmetres") ? appln.GetAttributeValue<decimal>("lux_maximumheightworkedatmetres").ToString("N0") : "0";
                        if (heightWorked > 20)
                        {
                            refer["lux_refertohcc"] = true;
                            refer["lux_additionalinfo"] = "Refer Risk to Liability Carrier for Approval";
                        }
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworkabove10minheight") == false || heightWorked <= 10)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                    else if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworkabove10minheight") == true && heightWorked > 10)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.Attributes.Contains("lux_maximumheightworkedatmetres") ? appln.GetAttributeValue<decimal>("lux_maximumheightworkedatmetres").ToString("N0") : "0";
                        if (heightWorked > 20)
                        {
                            reff["lux_refertohcc"] = true;
                            reff["lux_additionalinfo"] = "Refer Risk to Liability Carrier for Approval";
                        }
                        else
                        {
                            reff["lux_refertohcc"] = false;
                            reff["lux_additionalinfo"] = "";
                        }
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworkatdepth"))
            {
                var depthWorked = appln.Attributes.Contains("lux_maximumdepthworkedatmetres") ? appln.GetAttributeValue<decimal>("lux_maximumdepthworkedatmetres") : 0;

                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworkatdepth' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworkatdepth") == true && depthWorked > 1)
                    {
                        var FieldName1 = "Maximum Depth Worked at (Metres)";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworkatdepth";
                        refer["lux_suppliedvalue"] = appln.Attributes.Contains("lux_maximumdepthworkedatmetres") ? appln.GetAttributeValue<decimal>("lux_maximumdepthworkedatmetres").ToString("N0") : "0";
                        if (depthWorked > 5)
                        {
                            refer["lux_additionalinfo"] = "Refer Risk to Liability Carrier for Approval";
                            refer["lux_refertohcc"] = true;
                        }
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworkatdepth") == false || depthWorked <= 1)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                    else if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworkatdepth") == true && depthWorked > 1)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.Attributes.Contains("lux_maximumdepthworkedatmetres") ? appln.GetAttributeValue<decimal>("lux_maximumdepthworkedatmetres").ToString("N0") : "0";
                        if (depthWorked > 5)
                        {
                            reff["lux_refertohcc"] = true;
                            reff["lux_additionalinfo"] = "Refer Risk to Liability Carrier for Approval";
                        }
                        else
                        {
                            reff["lux_additionalinfo"] = "";
                            reff["lux_refertohcc"] = false;
                        }
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_isanymanufacturingprocessoperatingunatten"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isanymanufacturingprocessoperatingunatten' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_isanymanufacturingprocessoperatingunatten") == true)
                    {
                        var FieldName1 = "Is any manufacturing process operating unattended when no employees are present within the building";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_isanymanufacturingprocessoperatingunatten";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_isanymanufacturingprocessoperatingunatten") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouhaveinexcessof50litresofflammableli"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouhaveinexcessof50litresofflammableli' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouhaveinexcessof50litresofflammableli") == true)
                    {
                        var FieldName1 = "Do you have in excess of 50 litres of flammable liquids which is not stored within a proprietry flammables cabinet?";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouhaveinexcessof50litresofflammableli";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouhaveinexcessof50litresofflammableli") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doestheproposerundertakeanypilingwork"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doestheproposerundertakeanypilingwork' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doestheproposerundertakeanypilingwork") == true)
                    {
                        var FieldName1 = "Does the proposer undertake any piling work?";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doestheproposerundertakeanypilingwork";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doestheproposerundertakeanypilingwork") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doestheproposerundertakeanyunderpinningwo"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doestheproposerundertakeanyunderpinningwo' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doestheproposerundertakeanyunderpinningwo") == true)
                    {
                        var FieldName1 = "Does the proposer undertake any underpinning work?";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doestheproposerundertakeanyunderpinningwo";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doestheproposerundertakeanyunderpinningwo") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doestheproposerundertakeanyroofinwork"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doestheproposerundertakeanyroofinwork' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doestheproposerundertakeanyroofinwork") == true)
                    {
                        var FieldName1 = "Does the proposer undertake any roofin work other than as ancillary part of a contract for construction, alteration or repair carried out by them?";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doestheproposerundertakeanyroofinwork";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doestheproposerundertakeanyroofinwork") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doestheproposerworkawayusingheatequipment"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doestheproposerworkawayusingheatequipment' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doestheproposerworkawayusingheatequipment") == true)
                    {
                        var FieldName1 = "Does the proposer work away using heat equipment?";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doestheproposerworkawayusingheatequipment";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_pleaseconfirmthepercentageofturnoverderiv") ? appln.GetAttributeValue<decimal>("lux_pleaseconfirmthepercentageofturnoverderiv").ToString("#.##") : "0";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doestheproposerworkawayusingheatequipment") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doestheproposerworkorhandleasbestos"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doestheproposerworkorhandleasbestos' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doestheproposerworkorhandleasbestos") == true)
                    {
                        var FieldName1 = "Does the proposer work or handle asbestos or materials containing asbestos?";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doestheproposerworkorhandleasbestos";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_declined"] = true;
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doestheproposerworkorhandleasbestos") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_whoisthepreviousinsurer"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_whoisthepreviousinsurer' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<OptionSetValue>("lux_whoisthepreviousinsurer").Value == 972970008)
                    {
                        var FieldName1 = "Existing insurer";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_whoisthepreviousinsurer";
                        refer["lux_suppliedvalue"] = "Tokio Marine";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<OptionSetValue>("lux_whoisthepreviousinsurer").Value != 972970008)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true)
                            {
                                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                            }
                        }
                    }
                }
            }

            if (appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
            {
                if (appln.Attributes.Contains("lux_businessdescription"))
                {
                    var primaryTrade = appln.Attributes.Contains("lux_contractorsprimarytrade") ? appln.FormattedValues["lux_contractorsprimarytrade"].ToString().Trim() : "";

                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_businessdescription' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                    {
                        if (primaryTrade != "" && primaryTrade != appln.Attributes["lux_businessdescription"].ToString().Trim())
                        {
                            var FieldName1 = "Business Description";

                            Entity refer = new Entity("lux_referral");
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_businessdescription";
                            refer["lux_additionalinfo"] = "Business Description difference";
                            refer["lux_suppliedvalue"] = appln.Attributes["lux_businessdescription"].ToString().Trim();
                            service.Create(refer);
                        }
                    }
                    else
                    {
                        if (primaryTrade == "" || primaryTrade == appln.Attributes["lux_businessdescription"].ToString().Trim())
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                            foreach (var item in reff)
                            {
                                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                            }
                        }
                        else if (primaryTrade != "" && primaryTrade != appln.Attributes["lux_businessdescription"].ToString().Trim())
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            reff["lux_suppliedvalue"] = appln.Attributes["lux_businessdescription"].ToString().Trim();
                            reff["lux_additionalinfo"] = "Business Description difference";
                            service.Update(reff);
                        }
                    }
                }

                var BrokernotesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='lux_note'>
                                        <attribute name='createdon' />
                                        <attribute name='lux_subject' />
                                        <attribute name='lux_notetext' />
                                        <attribute name='lux_addedby' />
                                        <attribute name='lux_noteid' />
                                        <order attribute='createdon' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='statecode' operator='eq' value='0' />
                                          <condition attribute='lux_regardingapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                        </filter>
                                      </entity>
                                    </fetch>";

                var CommentsFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_usercomment'>
                                            <attribute name='createdon' />
                                            <attribute name='lux_portaluser' />
                                            <attribute name='lux_comment' />
                                            <attribute name='lux_usercommentid' />
                                            <order attribute='createdon' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_brokernotes' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                {
                    if (service.RetrieveMultiple(new FetchExpression(BrokernotesFetch)).Entities.Count > 0 || service.RetrieveMultiple(new FetchExpression(CommentsFetch)).Entities.Count > 0)
                    {
                        var FieldName1 = "Broker Notes – Reason – See brokers Notes";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", appln.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_brokernotes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (service.RetrieveMultiple(new FetchExpression(BrokernotesFetch)).Entities.Count == 0 && service.RetrieveMultiple(new FetchExpression(CommentsFetch)).Entities.Count == 0)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch2)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            //if (appln.Attributes.Contains("lux_doestheinsuredalwayscheckandkeeprecordsth"))
            //{
            //    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            //                      <entity name='lux_referral'>
            //                        <attribute name='lux_suppliedvalue' />
            //                        <attribute name='lux_fieldname' />
            //                        <attribute name='lux_approve' />
            //                        <attribute name='lux_additionalinfo' />
            //                        <attribute name='lux_referralid' />
            //                        <order attribute='lux_suppliedvalue' descending='false' />
            //                        <filter type='and'>
            //                          <condition attribute='statecode' operator='eq' value='0' />
            //                          <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
            //                          <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doestheinsuredalwayscheckandkeeprecordsth' />
            //                        </filter>
            //                      </entity>
            //                    </fetch>";

            //    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doestheinsuredalwayscheckandkeeprecordsth") == false)
            //        {
            //            var FieldName1 = "Does the Insured always check and keep records that Bona Fide Sub Contractors have Public Liability Insurance with a limit of indemnity at least the same as the Insured?";
            //            Entity refer = new Entity("lux_referral");
            //            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
            //            refer["lux_fieldname"] = FieldName1;
            //            refer["lux_fieldschemaname"] = "lux_doestheinsuredalwayscheckandkeeprecordsth";
            //            refer["lux_suppliedvalue"] = "No";
            //            service.Create(refer);
            //        }
            //    }
            //    else
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doestheinsuredalwayscheckandkeeprecordsth") == true)
            //        {
            //            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
            //            foreach (var item in reff)
            //            {
            //                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
            //            }
            //        }
            //    }
            //}
            //if (appln.Attributes.Contains("lux_doyouhaveanyholdharmlessagreementsinforce"))
            //{
            //    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            //                      <entity name='lux_referral'>
            //                        <attribute name='lux_suppliedvalue' />
            //                        <attribute name='lux_fieldname' />
            //                        <attribute name='lux_approve' />
            //                        <attribute name='lux_additionalinfo' />
            //                        <attribute name='lux_referralid' />
            //                        <order attribute='lux_suppliedvalue' descending='false' />
            //                        <filter type='and'>
            //                          <condition attribute='statecode' operator='eq' value='0' />
            //                          <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
            //                          <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouhaveanyholdharmlessagreementsinforce' />
            //                        </filter>
            //                      </entity>
            //                    </fetch>";

            //    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doyouhaveanyholdharmlessagreementsinforce") == true)
            //        {
            //            var FieldName1 = "Do you have any Hold Harmless Agreements in force?";
            //            Entity refer = new Entity("lux_referral");
            //            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
            //            refer["lux_fieldname"] = FieldName1;
            //            refer["lux_fieldschemaname"] = "lux_doyouhaveanyholdharmlessagreementsinforce";
            //            refer["lux_suppliedvalue"] = "Yes";
            //            service.Create(refer);
            //        }
            //    }
            //    else
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doyouhaveanyholdharmlessagreementsinforce") == false)
            //        {
            //            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
            //            foreach (var item in reff)
            //            {
            //                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
            //            }
            //        }
            //    }
            //}
            //if (appln.Attributes.Contains("lux_doestheinsuredundertake"))
            //{
            //    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            //                      <entity name='lux_referral'>
            //                        <attribute name='lux_suppliedvalue' />
            //                        <attribute name='lux_fieldname' />
            //                        <attribute name='lux_approve' />
            //                        <attribute name='lux_additionalinfo' />
            //                        <attribute name='lux_referralid' />
            //                        <order attribute='lux_suppliedvalue' descending='false' />
            //                        <filter type='and'>
            //                          <condition attribute='statecode' operator='eq' value='0' />
            //                          <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
            //                          <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doestheinsuredundertake' />
            //                        </filter>
            //                      </entity>
            //                    </fetch>";

            //    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doestheinsuredundertake") == true)
            //        {
            //            var FieldName1 = "Does the Insured undertake any of the following specialist building work, including but not limited to: - Piling - Underpinning - Demolition - Steel Erection - Formwork/Shuttering";
            //            Entity refer = new Entity("lux_referral");
            //            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
            //            refer["lux_fieldname"] = FieldName1;
            //            refer["lux_fieldschemaname"] = "lux_doestheinsuredundertake";
            //            refer["lux_suppliedvalue"] = "Yes";
            //            service.Create(refer);
            //        }
            //    }
            //    else
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doestheinsuredundertake") == false)
            //        {
            //            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
            //            foreach (var item in reff)
            //            {
            //                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
            //            }
            //        }
            //    }
            //}
            //if (appln.Attributes.Contains("lux_canyouconfirmtheinsureddoesnotcarryoutany"))
            //{
            //    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            //                      <entity name='lux_referral'>
            //                        <attribute name='lux_suppliedvalue' />
            //                        <attribute name='lux_fieldname' />
            //                        <attribute name='lux_approve' />
            //                        <attribute name='lux_additionalinfo' />
            //                        <attribute name='lux_referralid' />
            //                        <order attribute='lux_suppliedvalue' descending='false' />
            //                        <filter type='and'>
            //                          <condition attribute='statecode' operator='eq' value='0' />
            //                          <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
            //                          <condition attribute='lux_fieldschemaname' operator='eq' value='lux_canyouconfirmtheinsureddoesnotcarryoutany' />
            //                        </filter>
            //                      </entity>
            //                    </fetch>";

            //    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_canyouconfirmtheinsureddoesnotcarryoutany") == false)
            //        {
            //            var FieldName1 = "Can you confirm the insured does not carry out any works in, on or immediately adjacent to towers, steeples, chimney shafts, bridges, viaducts, motorways, flyovers, underpasses, airports, airside, railway, railway installations, power stations, oil refineries, gas/chemical/petrochemical plants, fuel depots, nuclear installations, collieries, mines, quarries, tunnels, ships, vessels, water-borne craft, docks, harbours, piers, jetties, dams, reservoirs, lakes, rivers, water diversions/canals, sea defences or offshore rigs/platforms/structures.";
            //            Entity refer = new Entity("lux_referral");
            //            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
            //            refer["lux_fieldname"] = FieldName1;
            //            refer["lux_fieldschemaname"] = "lux_canyouconfirmtheinsureddoesnotcarryoutany";
            //            refer["lux_suppliedvalue"] = "No";
            //            service.Create(refer);
            //        }
            //    }
            //    else
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_canyouconfirmtheinsureddoesnotcarryoutany") == true)
            //        {
            //            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
            //            foreach (var item in reff)
            //            {
            //                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
            //            }
            //        }
            //    }
            //}
            //if (appln.Attributes.Contains("lux_doyouundertakeanyworkawayoutsideoftheunit"))
            //{
            //    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            //                      <entity name='lux_referral'>
            //                        <attribute name='lux_suppliedvalue' />
            //                        <attribute name='lux_fieldname' />
            //                        <attribute name='lux_approve' />
            //                        <attribute name='lux_additionalinfo' />
            //                        <attribute name='lux_referralid' />
            //                        <order attribute='lux_suppliedvalue' descending='false' />
            //                        <filter type='and'>
            //                          <condition attribute='statecode' operator='eq' value='0' />
            //                          <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
            //                          <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworkawayoutsideoftheunit' />
            //                        </filter>
            //                      </entity>
            //                    </fetch>";

            //    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworkawayoutsideoftheunit") == true)
            //        {
            //            var FieldName1 = "Do you undertake any work away outside of the United Kingdom?";
            //            Entity refer = new Entity("lux_referral");
            //            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
            //            refer["lux_fieldname"] = FieldName1;
            //            refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworkawayoutsideoftheunit";
            //            refer["lux_suppliedvalue"] = "Yes";
            //            service.Create(refer);
            //        }
            //    }
            //    else
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworkawayoutsideoftheunit") == false)
            //        {
            //            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
            //            foreach (var item in reff)
            //            {
            //                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
            //            }
            //        }
            //    }
            //}
            //if (appln.Attributes.Contains("lux_doyouundertakeanytrafficmanagement"))
            //{
            //    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            //                      <entity name='lux_referral'>
            //                        <attribute name='lux_suppliedvalue' />
            //                        <attribute name='lux_fieldname' />
            //                        <attribute name='lux_approve' />
            //                        <attribute name='lux_additionalinfo' />
            //                        <attribute name='lux_referralid' />
            //                        <order attribute='lux_suppliedvalue' descending='false' />
            //                        <filter type='and'>
            //                          <condition attribute='statecode' operator='eq' value='0' />
            //                          <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
            //                          <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanytrafficmanagement' />
            //                        </filter>
            //                      </entity>
            //                    </fetch>";

            //    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doyouundertakeanytrafficmanagement") == true)
            //        {
            //            var FieldName1 = "Do you undertake any traffic management?";
            //            Entity refer = new Entity("lux_referral");
            //            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
            //            refer["lux_fieldname"] = FieldName1;
            //            refer["lux_fieldschemaname"] = "lux_doyouundertakeanytrafficmanagement";
            //            refer["lux_suppliedvalue"] = "Yes";
            //            service.Create(refer);
            //        }
            //    }
            //    else
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doyouundertakeanytrafficmanagement") == false)
            //        {
            //            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
            //            foreach (var item in reff)
            //            {
            //                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
            //            }
            //        }
            //    }
            //}
            //if (appln.Attributes.Contains("lux_doyouworkonmotorways"))
            //{
            //    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            //                      <entity name='lux_referral'>
            //                        <attribute name='lux_suppliedvalue' />
            //                        <attribute name='lux_fieldname' />
            //                        <attribute name='lux_approve' />
            //                        <attribute name='lux_additionalinfo' />
            //                        <attribute name='lux_referralid' />
            //                        <order attribute='lux_suppliedvalue' descending='false' />
            //                        <filter type='and'>
            //                          <condition attribute='statecode' operator='eq' value='0' />
            //                          <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
            //                          <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouworkonmotorways' />
            //                        </filter>
            //                      </entity>
            //                    </fetch>";

            //    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doyouworkonmotorways") == true)
            //        {
            //            var FieldName1 = "Do you work on motorways?";
            //            Entity refer = new Entity("lux_referral");
            //            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
            //            refer["lux_fieldname"] = FieldName1;
            //            refer["lux_fieldschemaname"] = "lux_doyouworkonmotorways";
            //            refer["lux_suppliedvalue"] = "Yes";
            //            service.Create(refer);
            //        }
            //    }
            //    else
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doyouworkonmotorways") == false)
            //        {
            //            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
            //            foreach (var item in reff)
            //            {
            //                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
            //            }
            //        }
            //    }
            //}
            //if (appln.Attributes.Contains("lux_doyouundertakeanyplumbingworkonhighrisebu"))
            //{
            //    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            //                      <entity name='lux_referral'>
            //                        <attribute name='lux_suppliedvalue' />
            //                        <attribute name='lux_fieldname' />
            //                        <attribute name='lux_approve' />
            //                        <attribute name='lux_additionalinfo' />
            //                        <attribute name='lux_referralid' />
            //                        <order attribute='lux_suppliedvalue' descending='false' />
            //                        <filter type='and'>
            //                          <condition attribute='statecode' operator='eq' value='0' />
            //                          <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
            //                          <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyplumbingworkonhighrisebu' />
            //                        </filter>
            //                      </entity>
            //                    </fetch>";

            //    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyplumbingworkonhighrisebu") == true)
            //        {
            //            var FieldName1 = "Do you undertake any plumbing work on high rise buildings (3 floor and above)?";
            //            Entity refer = new Entity("lux_referral");
            //            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
            //            refer["lux_fieldname"] = FieldName1;
            //            refer["lux_fieldschemaname"] = "lux_doyouundertakeanyplumbingworkonhighrisebu";
            //            refer["lux_suppliedvalue"] = "Yes";
            //            service.Create(refer);
            //        }
            //    }
            //    else
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyplumbingworkonhighrisebu") == false)
            //        {
            //            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
            //            foreach (var item in reff)
            //            {
            //                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
            //            }
            //        }
            //    }
            //}
            //if (appln.Attributes.Contains("lux_doyouundertakeanycladdingwork"))
            //{
            //    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            //                      <entity name='lux_referral'>
            //                        <attribute name='lux_suppliedvalue' />
            //                        <attribute name='lux_fieldname' />
            //                        <attribute name='lux_approve' />
            //                        <attribute name='lux_additionalinfo' />
            //                        <attribute name='lux_referralid' />
            //                        <order attribute='lux_suppliedvalue' descending='false' />
            //                        <filter type='and'>
            //                          <condition attribute='statecode' operator='eq' value='0' />
            //                          <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
            //                          <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanycladdingwork' />
            //                        </filter>
            //                      </entity>
            //                    </fetch>";

            //    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doyouundertakeanycladdingwork") == true)
            //        {
            //            var FieldName1 = "Do you undertake any Cladding work?";
            //            Entity refer = new Entity("lux_referral");
            //            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
            //            refer["lux_fieldname"] = FieldName1;
            //            refer["lux_fieldschemaname"] = "lux_doyouundertakeanycladdingwork";
            //            refer["lux_suppliedvalue"] = "Yes";
            //            service.Create(refer);
            //        }
            //    }
            //    else
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doyouundertakeanycladdingwork") == false)
            //        {
            //            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
            //            foreach (var item in reff)
            //            {
            //                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
            //            }
            //        }
            //    }
            //}
            //if (appln.Attributes.Contains("lux_doyouundertalkeanytimberframeconstruction"))
            //{
            //    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            //                      <entity name='lux_referral'>
            //                        <attribute name='lux_suppliedvalue' />
            //                        <attribute name='lux_fieldname' />
            //                        <attribute name='lux_approve' />
            //                        <attribute name='lux_additionalinfo' />
            //                        <attribute name='lux_referralid' />
            //                        <order attribute='lux_suppliedvalue' descending='false' />
            //                        <filter type='and'>
            //                          <condition attribute='statecode' operator='eq' value='0' />
            //                          <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
            //                          <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertalkeanytimberframeconstruction' />
            //                        </filter>
            //                      </entity>
            //                    </fetch>";

            //    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doyouundertalkeanytimberframeconstruction") == true)
            //        {
            //            var FieldName1 = "Do you undertalke any Timber Frame Construction";
            //            Entity refer = new Entity("lux_referral");
            //            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
            //            refer["lux_fieldname"] = FieldName1;
            //            refer["lux_fieldschemaname"] = "lux_doyouundertalkeanytimberframeconstruction";
            //            refer["lux_suppliedvalue"] = "Yes";
            //            service.Create(refer);
            //        }
            //    }
            //    else
            //    {
            //        if (appln.GetAttributeValue<bool>("lux_doyouundertalkeanytimberframeconstruction") == false)
            //        {
            //            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
            //            foreach (var item in reff)
            //            {
            //                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
            //            }
            //        }
            //    }
            //}

            if (appln.Attributes.Contains("lux_insuredtitle"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_insuredtitle' />
                                    </filter>
                                  </entity>
                                </fetch>";

                var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_policy'>
                                    <attribute name='createdon' />
                                    <attribute name='lux_product' />
                                    <attribute name='lux_policyholder' />
                                    <attribute name='lux_policystartdate' />
                                    <attribute name='lux_name' />
                                    <attribute name='lux_policynumber' />
                                    <attribute name='lux_policyid' />
                                    <order attribute='createdon' descending='true' />
                                    <filter type='and'>
                                      <condition attribute='statuscode' operator='in'>
                                        <value>972970000</value>
                                        <value>1</value>
                                        <value>972970002</value>
                                      </condition>
                                      <condition attribute='lux_name' operator='like' value='%{appln.Attributes["lux_insuredtitle"].ToString().Replace("&", "&amp;").Replace("'", "&apos;").Replace("\"", " &quot;")}%' />
                                    </filter>
                                    <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplication' visible='false' link-type='outer' alias='poa'>
                                      <attribute name='lux_quotenumber' />
                                    </link-entity>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0 && appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                    {
                        var FieldName1 = "Insured Name";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_insuredtitle";
                        refer["lux_suppliedvalue"] = appln.Attributes["lux_insuredtitle"].ToString();
                        refer["lux_additionalinfo"] = "Insured Name already exist for Bound Quote: " + service.RetrieveMultiple(new FetchExpression(fetch1)).Entities[0].GetAttributeValue<AliasedValue>("poa.lux_quotenumber").Value.ToString();
                        service.Create(refer);
                    }
                }
                else
                {
                    if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count == 0 || appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value != 972970001)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_insuredtitle"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_insuredtitle' />
                                    </filter>
                                  </entity>
                                </fetch>";

                var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_propertyownersapplications'>
                                    <attribute name='lux_name' />
                                    <attribute name='createdon' />
                                    <attribute name='lux_postcode' />
                                    <attribute name='lux_insuredtitle' />
                                    <attribute name='lux_quotenumber' />
                                    <attribute name='statuscode' />
                                    <attribute name='lux_inceptiondate' />
                                    <attribute name='lux_broker' />
                                    <attribute name='lux_quotedpremium' />
                                    <attribute name='lux_producttype' />
                                    <attribute name='lux_propertyownersapplicationsid' />
                                    <order attribute='createdon' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_insuredtitle' operator='like' value='%{appln.Attributes["lux_insuredtitle"].ToString().Replace("&", "&amp;").Replace("'", "&apos;").Replace("\"", " &quot;")}%' />
                                      <condition attribute='lux_applicationtype' operator='not-in'>
                                        <value>972970003</value>
                                        <value>972970002</value>
                                      </condition>
                                      <condition attribute='lux_propertyownersapplicationsid' operator='ne' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0 && appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                    {
                        var FieldName1 = "Duplicate title match";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_insuredtitle";
                        refer["lux_suppliedvalue"] = appln.Attributes["lux_insuredtitle"].ToString();
                        refer["lux_additionalinfo"] = "Insured Name already exist for Quote: " + service.RetrieveMultiple(new FetchExpression(fetch1)).Entities[0].GetAttributeValue<string>("lux_quotenumber").ToString();
                        service.Create(refer);
                    }
                }
                else
                {
                    if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count == 0 || appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value != 972970001)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_renewaldate"))
            {
                var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_referral'>
                                            <attribute name='lux_suppliedvalue' />
                                            <attribute name='lux_fieldname' />
                                            <attribute name='lux_approve' />
                                            <attribute name='lux_additionalinfo' />
                                            <attribute name='lux_referralid' />
                                            <order attribute='lux_suppliedvalue' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                              <condition attribute='lux_fieldschemaname' operator='eq' value='lux_renewaldate' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                {
                    if ((RenewalDate - InceptionDate).Days < 364 || (RenewalDate - InceptionDate).Days > 540)
                    {
                        var FieldName1 = "Renewal Date";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_renewaldate";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_renewaldate"];
                        refer["lux_additionalinfo"] = "ARAG: PERIOD OF INSURANCES BOUND: 12 months(plus odd time not exceeding 18 months in total)";
                        service.Create(refer);
                    }
                }
                else
                {
                    if ((RenewalDate - InceptionDate).Days >= 364 && (RenewalDate - InceptionDate).Days <= 540)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch2)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_inceptiondate"))
            {
                var fetch3 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_referral'>
                                            <attribute name='lux_suppliedvalue' />
                                            <attribute name='lux_fieldname' />
                                            <attribute name='lux_approve' />
                                            <attribute name='lux_additionalinfo' />
                                            <attribute name='lux_referralid' />
                                            <order attribute='lux_suppliedvalue' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                              <condition attribute='lux_fieldschemaname' operator='eq' value='lux_inceptiondate' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch3)).Entities.Count == 0)
                {
                    if ((InceptionDate - DateTime.Now).Days > 60)
                    {
                        var FieldName1 = "Renewal Date";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_inceptiondate";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_inceptiondate"];
                        refer["lux_additionalinfo"] = "ARAG: MAXIMUM ADVANCE PERIOD FOR INCEPTION DATES: 60 days";
                        service.Create(refer);
                    }
                }
                else
                {
                    if ((InceptionDate - DateTime.Now).Days <= 60)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch3)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }
        }

        public string GetOptionSetTextUsingValue(string entityName, string fieldName, int optionSetValue, IOrganizationService service)
        {
            var attReq = new RetrieveAttributeRequest();
            attReq.EntityLogicalName = entityName;
            attReq.LogicalName = fieldName;
            attReq.RetrieveAsIfPublished = true;
            var attResponse = (RetrieveAttributeResponse)service.Execute(attReq);
            var attMetadata = (EnumAttributeMetadata)attResponse.AttributeMetadata;
            return attMetadata.OptionSet.Options.Where(x => x.Value == optionSetValue).FirstOrDefault().Label.UserLocalizedLabel.Label;
        }

        public IDictionary<int, string> GetGlobalOptionSetValues(IOrganizationService service, string optionSetLogicalName)
        {
            IDictionary<int, string> optionSet = new Dictionary<int, string>();
            if (string.IsNullOrEmpty(optionSetLogicalName))
                return null;
            var retrieveAttributeRequest = new RetrieveOptionSetRequest
            {
                Name = optionSetLogicalName
            };
            var retrieveAttributeResponse = (RetrieveOptionSetResponse)service.Execute(retrieveAttributeRequest);
            var retrievedPicklistAttributeMetadata = (OptionSetMetadata)retrieveAttributeResponse.OptionSetMetadata;
            for (int i = 0; i < retrievedPicklistAttributeMetadata.Options.Count(); i++)
            {
                optionSet.Add(new KeyValuePair<int, string>(retrievedPicklistAttributeMetadata.Options[i].Value.Value,
                    retrievedPicklistAttributeMetadata.Options[i].Label.LocalizedLabels[0].Label));
            }
            return optionSet;
        }

        public static string RetrieveAttributeDisplayName(string EntitySchemaName, string AttributeSchemaName, IOrganizationService service)
        {
            RetrieveAttributeRequest retrieveAttributeRequest = new RetrieveAttributeRequest
            {
                EntityLogicalName = EntitySchemaName,
                LogicalName = AttributeSchemaName,
                RetrieveAsIfPublished = true
            };
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            AttributeMetadata retrievedAttributeMetadata = (AttributeMetadata)retrieveAttributeResponse.AttributeMetadata;
            return retrievedAttributeMetadata.DisplayName.UserLocalizedLabel.Label;
        }
    }
}
