﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculateELPremiumRetail : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Input("Product")]
        public InArgument<string> Product { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var request = new RetrieveCurrentOrganizationRequest();
            var organzationResponse = (RetrieveCurrentOrganizationResponse)service.Execute(request);
            var uriString = organzationResponse.Detail.UrlName;

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                <attribute name='lux_propertyownersapplicationsid' />
                                <attribute name='lux_name' />
                                <attribute name='lux_policy' />
                                <attribute name='lux_applicationtype' />
                                <attribute name='lux_iselcoverrequired' />
                                <attribute name='lux_limitofindemnity' />
                                <attribute name='lux_clericalcommercialandmanagerialwageroll' />
                                <attribute name='lux_sitesupervisorswageroll' />
                                <attribute name='lux_manualwageroll' />
                                <attribute name='lux_isanyworkawaycarriedoutotherthanforcollec' />
                                <attribute name='lux_workawaywageroll' />
                                <attribute name='lux_quotationdate' />
                                <attribute name='lux_inceptiondate' />
                                <attribute name='lux_insuranceproductrequired' />
                                <attribute name='lux_maintradeforthispremises' />
                                <attribute name='lux_contractorsprimarytrade' />
                                <attribute name='lux_contractorssecondarytrade' />
                                <attribute name='lux_workawaypremium' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplicationsid' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var item = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                var quotationDate = item.Contains("lux_quotationdate") ? item.GetAttributeValue<DateTime>("lux_quotationdate") : DateTime.UtcNow;
                var inceptionDate = item.GetAttributeValue<DateTime>("lux_inceptiondate");
                var ApplicationType = item.Attributes.Contains("lux_applicationtype") ? item.FormattedValues["lux_applicationtype"].ToString() : "";
                var product = item.FormattedValues["lux_insuranceproductrequired"];

                if (product != "Contractors Combined")
                {
                    if (item.GetAttributeValue<bool>("lux_iselcoverrequired") == true)
                    {
                        var clerical = item.Contains("lux_clericalcommercialandmanagerialwageroll") ? item.GetAttributeValue<Money>("lux_clericalcommercialandmanagerialwageroll").Value : 0;
                        var manual = item.Contains("lux_manualwageroll") ? item.GetAttributeValue<Money>("lux_manualwageroll").Value : 0;
                        decimal workaway = 0;
                        decimal ELRate = 0;
                        if (item.Attributes.Contains("lux_isanyworkawaycarriedoutotherthanforcollec") && item.GetAttributeValue<bool>("lux_isanyworkawaycarriedoutotherthanforcollec") == true)
                        {
                            workaway = item.Contains("lux_workawaywageroll") ? item.GetAttributeValue<Money>("lux_workawaywageroll").Value : 0;
                        }

                        if (item.Attributes.Contains("lux_maintradeforthispremises"))
                        {
                            var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                  <filter type='or'>
                                                    <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                    <condition attribute='lux_enddate' operator='null' />
                                                  </filter>
                                                  <condition attribute='lux_name' operator='eq' uiname='' value='{item.FormattedValues["lux_maintradeforthispremises"].ToString()}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                            if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                            {
                                var ELData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];

                                if (Product.Get(executionContext).ToString() == "Pubs & Restaurants" || Product.Get(executionContext).ToString() == "Hotels and Guesthouses")
                                {
                                    ELRate = 0.4M;
                                }
                                else if (Product.Get(executionContext).ToString() == "Retail")
                                {
                                    ELRate = 0.3M;
                                }
                                else if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
                                {
                                    if (ELData.GetAttributeValue<int>("lux_el") == 1)
                                    {
                                        ELRate = 0.10M;
                                    }
                                    else if (ELData.GetAttributeValue<int>("lux_el") == 2)
                                    {
                                        ELRate = 0.30M;
                                    }
                                    else if (ELData.GetAttributeValue<int>("lux_el") == 3)
                                    {
                                        ELRate = 0.40M;
                                    }
                                    else if (ELData.GetAttributeValue<int>("lux_el") == 4)
                                    {
                                        ELRate = 0.50M;
                                    }
                                    else if (ELData.GetAttributeValue<int>("lux_el") == 5)
                                    {
                                        ELRate = 0.75M;
                                    }
                                    else if (ELData.GetAttributeValue<int>("lux_el") == 6)
                                    {
                                        ELRate = 0.00M;
                                    }
                                    else
                                    {
                                        ELRate = ELData.GetAttributeValue<decimal>("lux_elrate");
                                    }
                                }
                                else
                                {
                                    ELRate = ELData.GetAttributeValue<decimal>("lux_elrate");
                                }
                            }
                        }

                        //var clericalPremium = clerical * Convert.ToDecimal(0.15) / 100; Old Rate
                        var clericalPremium = clerical * Convert.ToDecimal(0.1) / 100;
                        var manualPremium = manual * Convert.ToDecimal(ELRate) / 100;
                        var workAwayPremium = workaway * Convert.ToDecimal(1) / 100;

                        if (inceptionDate >= new DateTime(2023, 11, 01))
                        {
                            clericalPremium = 1.1M * clerical * Convert.ToDecimal(0.1) / 100;
                            manualPremium = 1.1M * manual * Convert.ToDecimal(ELRate) / 100;
                            workAwayPremium = 1.1M * workaway * Convert.ToDecimal(1) / 100;
                        }

                        if (quotationDate >= new DateTime(2025, 01, 01))
                        {
                            if (ApplicationType == "New Business")
                            {
                                clericalPremium = 1.06M * clericalPremium;
                                manualPremium = 1.06M * manualPremium;
                                workAwayPremium = 1.06M * workAwayPremium;
                            }
                            else if (ApplicationType == "MTA" || ApplicationType == "Cancellation")
                            {
                                if (item.Attributes.Contains("lux_policy"))
                                {
                                    var Policy = service.Retrieve("lux_policy", item.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                    if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                    {
                                        clericalPremium = 1.06M * clericalPremium;
                                        manualPremium = 1.06M * manualPremium;
                                        workAwayPremium = 1.06M * workAwayPremium;
                                    }
                                }
                            }
                        }

                        var totalPremium = clericalPremium + manualPremium + workAwayPremium;

                        var item1 = service.Retrieve("lux_propertyownersapplications", item.Id, new ColumnSet(true));
                        if (totalPremium < 100)
                        {
                            totalPremium = 100;
                        }
                        item1["lux_employersliabilitypremium"] = new Money(totalPremium);
                        item1["lux_workawaypremium"] = new Money(workAwayPremium);
                        item1["lux_clericalrate"] = Convert.ToDecimal(0.1);
                        //item1["lux_clericalrate"] = Convert.ToDecimal(0.15); Old Rate
                        item1["lux_manualrate"] = ELRate;
                        item1["lux_manualworkawayrate"] = Convert.ToDecimal(1);
                        service.Update(item1);
                    }
                    else
                    {
                        var item1 = service.Retrieve("lux_propertyownersapplications", item.Id, new ColumnSet(true));
                        item1["lux_employersliabilitypremium"] = new Money(0);
                        item1["lux_workawaypremium"] = new Money(0);
                        item1["lux_clericalrate"] = Convert.ToDecimal(0);
                        item1["lux_manualrate"] = Convert.ToDecimal(0);
                        item1["lux_manualworkawayrate"] = Convert.ToDecimal(0);
                        service.Update(item1);
                    }
                }
                else
                {
                    if (item.GetAttributeValue<bool>("lux_iselcoverrequired") == true)
                    {
                        var clerical = item.Contains("lux_clericalcommercialandmanagerialwageroll") ? item.GetAttributeValue<Money>("lux_clericalcommercialandmanagerialwageroll").Value : 0;
                        var siteSupervisor = item.Contains("lux_sitesupervisorswageroll") ? item.GetAttributeValue<Money>("lux_sitesupervisorswageroll").Value : 0;

                        var manual = item.Contains("lux_manualwageroll") ? item.GetAttributeValue<Money>("lux_manualwageroll").Value : 0;
                        var labourOnly = item.Contains("lux_workawaywageroll") ? item.GetAttributeValue<Money>("lux_workawaywageroll").Value : 0;

                        var totalWageroll = clerical + siteSupervisor + manual + labourOnly;

                        decimal ELRate = 0;

                        if (item.Attributes.Contains("lux_contractorsprimarytrade"))
                        {
                            var primaryTrade = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_contractorstrade'>
                                                    <attribute name='lux_contractorstradeid' />
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_tradecategory' />
                                                    <attribute name='lux_plrate' />
                                                    <attribute name='lux_materialdamagefirerate' />
                                                    <attribute name='lux_elrate' />
                                                    <attribute name='lux_carrate' />
                                                    <attribute name='lux_businessinterruptionrate' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                      <filter type='or'>
                                                        <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                        <condition attribute='lux_enddate' operator='null' />
                                                      </filter>
                                                      <condition attribute='lux_contractorstradeid' operator='eq' uiname='Aerial Erection' uitype='lux_contractorstrade' value='{item.GetAttributeValue<EntityReference>("lux_contractorsprimarytrade").Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                            if (service.RetrieveMultiple(new FetchExpression(primaryTrade)).Entities.Count > 0)
                            {
                                var ELData = service.RetrieveMultiple(new FetchExpression(primaryTrade)).Entities[0];
                                ELRate = ELData.GetAttributeValue<decimal>("lux_elrate");
                            }
                        }

                        var clericalPremium = clerical * Convert.ToDecimal(0.1) / 100;
                        var siteSupervisorPremium = siteSupervisor * Convert.ToDecimal(0.5) / 100;

                        var manualPremium = manual * Convert.ToDecimal(ELRate) / 100;
                        var labourOnlyPremium = labourOnly * Convert.ToDecimal(ELRate) / 100;

                        var totalPremium = clericalPremium + siteSupervisorPremium + manualPremium + labourOnlyPremium;

                        var item1 = service.Retrieve("lux_propertyownersapplications", item.Id, new ColumnSet(true));
                        var dateDiffDays = (item1.GetAttributeValue<DateTime>("lux_renewaldate") - item1.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                        if (dateDiffDays == 364 || dateDiffDays == 365 || dateDiffDays == 366)
                        {
                            dateDiffDays = 365;
                        }
                        totalPremium = totalPremium * dateDiffDays / 365;

                        if (inceptionDate >= new DateTime(2023, 11, 01))
                        {
                            totalPremium = 1.1M * totalPremium;
                        }

                        if (quotationDate >= new DateTime(2025, 01, 01))
                        {
                            if (ApplicationType == "New Business")
                            {
                                totalPremium = 1.06M * totalPremium;
                            }
                            else if (ApplicationType == "MTA" || ApplicationType == "Cancellation")
                            {
                                if (item.Attributes.Contains("lux_policy"))
                                {
                                    var Policy = service.Retrieve("lux_policy", item.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                    if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                    {
                                        totalPremium = 1.06M * totalPremium;
                                    }
                                }
                            }
                        }

                        //if (uriString.ToLower().Contains("uat"))
                        //{
                            var SizeDiscountFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_sizediscount'>
                                            <attribute name='lux_effectiveto' />
                                            <attribute name='lux_effectivefrom' />
                                            <attribute name='lux_200k' />
                                            <attribute name='lux_201k500k' />
                                            <attribute name='lux_501k1m' />
                                            <attribute name='lux_10000012m' />
                                            <attribute name='lux_above2m' />
                                            <order attribute='createdon' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <filter type='or'>
                                                <condition attribute='lux_effectivefrom' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                <condition attribute='lux_effectivefrom' operator='null' />
                                              </filter>
                                              <filter type='or'>
                                                <condition attribute='lux_effectiveto' operator='on-or-after' value= '{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                <condition attribute='lux_effectiveto' operator='null' />
                                              </filter>
                                              <condition attribute='lux_section' operator='eq' value='972970002' />
                                              <condition attribute='lux_product' operator='eq' uiname='' uitype='product' value='1ca35a2b-23a4-eb11-b1ac-002248404342' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                            if (service.RetrieveMultiple(new FetchExpression(SizeDiscountFetch)).Entities.Count > 0)
                            {
                                var SI_data = service.RetrieveMultiple(new FetchExpression(SizeDiscountFetch)).Entities;
                                var SI_field = "";
                                if (totalWageroll <= 200000)
                                {
                                    SI_field = "lux_200k";
                                }
                                else if (totalWageroll > 200000 && totalWageroll <= 500000)
                                {
                                    SI_field = "lux_201k500k";
                                }
                                else if (totalWageroll > 500000 && totalWageroll <= 1000000)
                                {
                                    SI_field = "lux_501k1m";
                                }
                                else if (totalWageroll > 1000000 && totalWageroll <= 2000000)
                                {
                                    SI_field = "lux_10000012m";
                                }
                                else if (totalWageroll > 2000000)
                                {
                                    SI_field = "lux_above2m";
                                }
                                var discount = SI_data.FirstOrDefault().GetAttributeValue<decimal>(SI_field);
                                //item1["lux_elaction"] = discount.ToString("#.##") + "%";
                                item1["lux_elaction"] = "0%";
                            }
                        //}

                        if (totalPremium < 250)
                        {
                            totalPremium = 250;
                        }
                        item1["lux_employersliabilitypremium"] = new Money(totalPremium);
                        item1["lux_clericalrate"] = Convert.ToDecimal(0.1);
                        item1["lux_sitesupervisorrate"] = Convert.ToDecimal(0.5);
                        item1["lux_manualrate"] = ELRate;
                        item1["lux_manualworkawayrate"] = ELRate;
                        service.Update(item1);
                    }
                    else
                    {
                        var item1 = service.Retrieve("lux_propertyownersapplications", item.Id, new ColumnSet(true));
                        item1["lux_employersliabilitypremium"] = new Money(0);
                        item1["lux_clericalrate"] = Convert.ToDecimal(0);
                        item1["lux_sitesupervisorrate"] = Convert.ToDecimal(0);
                        item1["lux_manualrate"] = Convert.ToDecimal(0);
                        item1["lux_manualworkawayrate"] = Convert.ToDecimal(0);
                        item1["lux_elaction"] = "";
                        service.Update(item1);
                    }
                }
            }
        }
    }
}
