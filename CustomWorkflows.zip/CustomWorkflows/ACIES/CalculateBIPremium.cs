﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculateBIPremium : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownerspremise'>
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_tenanttype' />
                                <attribute name='lux_declaredvalueforrebuildingthisproperty' />
                                <attribute name='lux_buildingconstruction' />
                                <attribute name='lux_occupancytype' />
                                <attribute name='lux_totalsuminsuredforthislocation' />
                                <attribute name='lux_landlordscontentsinresidentialareas' />
                                <attribute name='lux_totalnumberofcommercialunitsatthisaddress' />
                                <attribute name='lux_howmanyfloorsareofconcreteconstruction' />
                                <attribute name='lux_howmanyfloorsareofwoodenconstruction' />
                                <attribute name='lux_commercialunit1' />
                                <attribute name='lux_commercialunit2' />
                                <attribute name='lux_commercialunit3' />
                                <attribute name='lux_commercialunit4' />
                                <attribute name='lux_commercialunit5' />
                                <attribute name='lux_commercialunit6' />
                                <attribute name='lux_commercialunit7' />
                                <attribute name='lux_commercialunit8' />
                                <attribute name='lux_commercialunit9' />
                                <attribute name='lux_commercialunit10' />
                                <attribute name='lux_commercialunit11' />
                                <attribute name='lux_commercialunit12' />
                                <attribute name='lux_commercialunit13' />
                                <attribute name='lux_commercialunit14' />
                                <attribute name='lux_commercialunit15' />
                                <attribute name='lux_commercialunit16' />
                                <attribute name='lux_commercialunit17' />
                                <attribute name='lux_commercialunit18' />
                                <attribute name='lux_commercialunit19' />
                                <attribute name='lux_commercialunit20' />
                                <attribute name='lux_lossofannualrentalincome' />
                                <attribute name='lux_materialdamagefirerate' />
                                <attribute name='lux_indemnityperiodrequired' />
                                <attribute name='lux_propertyownerspremiseid' />
                                <attribute name='lux_covers' />
                                <attribute name='lux_businessinterruptionperilsrate' />
                                <attribute name='lux_businessinterruptionpremium' />
                                <attribute name='lux_materialdamageperilsrate' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplication' visible='false' link-type='outer' alias='poa'>
                                  <attribute name='lux_levelofcommission' />
                                  <attribute name='lux_whatisyourtrade' />
                                  <attribute name='lux_rpocpoproducttype' />
                                </link-entity>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var premises = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                var item2 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                var dateDiffDays = (item2.GetAttributeValue<DateTime>("lux_renewaldate") - item2.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                if (dateDiffDays == 364 || dateDiffDays == 365 || dateDiffDays == 366)
                {
                    dateDiffDays = 365;
                }
                var quotationDate = item2.Contains("lux_quotationdate") ? item2.GetAttributeValue<DateTime>("lux_quotationdate") : item2.GetAttributeValue<DateTime>("lux_inceptiondate");
                var inceptionDate = item2.GetAttributeValue<DateTime>("lux_inceptiondate");

                decimal TotalBIPremium = 0;
                var NoOfLocations = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count;

                decimal AvgPerils = premises.Sum(x => x.GetAttributeValue<decimal>("lux_materialdamageperilsrate")) / NoOfLocations;
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    var premise_data = item;
                    var LORSum_insured = premise_data.GetAttributeValue<Money>("lux_lossofannualrentalincome");
                    var LOR_indemnity = premise_data.GetAttributeValue<OptionSetValue>("lux_indemnityperiodrequired");

                    decimal PerilsRate = 0;
                    decimal BIFireRate = 0;
                    decimal TotalRate = 0;
                    var Trade = "";
                    if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970002 || item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970003) //residential and unoccupied
                    {
                        Trade = "Property Owner - Residential";
                        if (item.Contains("poa.lux_whatisyourtrade"))
                        {
                            if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970001)
                            {
                                Trade = "Housing Association";
                            }
                            else if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970002)
                            {
                                Trade = "Property Developer";
                            }
                            else if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970003)
                            {
                                Trade = "Property Owner - Residential";
                            }
                            else if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970004)
                            {
                                Trade = "Property Owner - Residential";
                            }
                            else if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970005)
                            {
                                Trade = "Property Management";
                            }
                        }

                        var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_name' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                  <filter type='or'>
                                                    <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                    <condition attribute='lux_enddate' operator='null' />
                                                  </filter>
                                                  <condition attribute='lux_name' operator='eq' uiname='' value='{Trade}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                        {
                            var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];

                            BIFireRate = FireData.GetAttributeValue<decimal>("lux_blfirerate");

                            if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                            {
                                if (BIFireRate < 0.06M)
                                {
                                    BIFireRate = 0.06M;
                                }
                            }
                            else if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                            {
                                if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                {
                                    if (BIFireRate < 0.06M)
                                    {
                                        BIFireRate = 0.06M;
                                    }
                                }
                            }
                            else
                            {
                                if (item2.Attributes.Contains("lux_policy"))
                                {
                                    var Policy = service.Retrieve("lux_policy", item2.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                    if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                    {
                                        if (quotationDate < new DateTime(2023, 02, 15))
                                        {
                                            if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                            {
                                                if (BIFireRate < 0.06M)
                                                {
                                                    BIFireRate = 0.06M;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if (BIFireRate < 0.06M)
                                            {
                                                BIFireRate = 0.06M;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                        {
                                            if (BIFireRate < 0.06M)
                                            {
                                                BIFireRate = 0.06M;
                                            }
                                        }
                                    }
                                }
                            }

                            //GrossRate = BIFireRate;
                            //var timberCount = 0;
                            //decimal ConstructionLoad = 0;
                            //decimal TenantLoad = 0;
                            //decimal ConsructionFireRate = BIFireRate;

                            //var timber = premise_data.Contains("lux_howmanyfloorsareofwoodenconstruction") ? premise_data.Attributes["lux_howmanyfloorsareofwoodenconstruction"].ToString() : "";

                            //if (timber != "" && !timber.Contains("0"))
                            //{
                            //    timberCount = 1;
                            //}

                            //if (timberCount == 1)
                            //{
                            //    ConstructionLoad = 15;
                            //    ConsructionFireRate = BIFireRate + BIFireRate * ConstructionLoad / 100;
                            //}

                            //var tenantType = premise_data.Contains("lux_tenanttype") ? premise_data.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value : 0;
                            //if (tenantType != 0)
                            //{
                            //    var TenantFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                            //                                  <entity name='lux_tenanttypeloaddiscount'>
                            //                                    <attribute name='lux_name' />
                            //                                    <attribute name='createdon' />
                            //                                    <attribute name='lux_loaddiscount' />
                            //                                    <attribute name='lux_tenanttypeloaddiscountid' />
                            //                                    <order attribute='lux_name' descending='false' />
                            //                                    <filter type='and'>
                            //                                      <condition attribute='statecode' operator='eq' value='0' />
                            //                                      <condition attribute='lux_tenanttype' operator='eq' value='{tenantType}' />
                            //                                    </filter>
                            //                                  </entity>
                            //                                </fetch>";
                            //    if (service.RetrieveMultiple(new FetchExpression(TenantFetch)).Entities.Count > 0)
                            //    {
                            //        var LoadData = service.RetrieveMultiple(new FetchExpression(TenantFetch)).Entities[0];
                            //        TenantLoad = LoadData.GetAttributeValue<decimal>("lux_loaddiscount");
                            //    }
                            //}
                            //GrossRate = ConsructionFireRate + ConsructionFireRate * TenantLoad / 100;
                        }
                    }
                    else if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970004) //commercial with residential
                    {
                        var numberofTrades = item.Attributes.Contains("lux_totalnumberofcommercialunitsatthisaddress") ? item.GetAttributeValue<int>("lux_totalnumberofcommercialunitsatthisaddress") : 0;
                        decimal FireRate = 0;
                        if (numberofTrades > 0)
                        {
                            for (int i = 1; i <= numberofTrades; i++)
                            {
                                var fieldName = "lux_commercialunit" + i;
                                //Trade = item.GetAttributeValue<EntityReference>().Id;
                                Trade = item.FormattedValues[fieldName].ToString();


                                var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                  <filter type='or'>
                                                    <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                    <condition attribute='lux_enddate' operator='null' />
                                                  </filter>
                                                  <condition attribute='lux_name' operator='eq' uiname='' value='{Trade}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                                {
                                    var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];

                                    FireRate += FireData.GetAttributeValue<decimal>("lux_blfirerate") < 0.06M ? 0.06M : FireData.GetAttributeValue<decimal>("lux_blfirerate");
                                }
                            }

                            BIFireRate = FireRate / numberofTrades;
                            if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                            {
                                if (BIFireRate < 0.06M)
                                {
                                    BIFireRate = 0.06M;
                                }
                            }
                            else if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                            {
                                if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                {
                                    if (BIFireRate < 0.06M)
                                    {
                                        BIFireRate = 0.06M;
                                    }
                                }
                            }
                            else
                            {
                                if (item2.Attributes.Contains("lux_policy"))
                                {
                                    var Policy = service.Retrieve("lux_policy", item2.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                    if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                    {
                                        if (quotationDate < new DateTime(2023, 02, 15))
                                        {
                                            if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                            {
                                                if (BIFireRate < 0.06M)
                                                {
                                                    BIFireRate = 0.06M;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if (BIFireRate < 0.06M)
                                            {
                                                BIFireRate = 0.06M;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                        {
                                            if (BIFireRate < 0.06M)
                                            {
                                                BIFireRate = 0.06M;
                                            }
                                        }
                                    }
                                }
                            }
                            //GrossRate = BIFireRate;
                            //var timberCount = 0;
                            //decimal ConstructionLoad = 0;
                            //decimal TenantLoad = 0;
                            //decimal ConsructionFireRate = BIFireRate;

                            //var timber = premise_data.Contains("lux_howmanyfloorsareofwoodenconstruction") ? premise_data.Attributes["lux_howmanyfloorsareofwoodenconstruction"].ToString() : "";

                            //if (timber != "" && !timber.Contains("0"))
                            //{
                            //    timberCount = 1;
                            //}

                            //if (timberCount == 1)
                            //{
                            //    ConstructionLoad = 15;
                            //    ConsructionFireRate = BIFireRate + BIFireRate * ConstructionLoad / 100;
                            //}

                            //var tenantType = premise_data.Contains("lux_tenanttype") ? premise_data.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value : 0;
                            //if (tenantType != 0)
                            //{
                            //    var TenantFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                            //                                  <entity name='lux_tenanttypeloaddiscount'>
                            //                                    <attribute name='lux_name' />
                            //                                    <attribute name='createdon' />
                            //                                    <attribute name='lux_loaddiscount' />
                            //                                    <attribute name='lux_tenanttypeloaddiscountid' />
                            //                                    <order attribute='lux_name' descending='false' />
                            //                                    <filter type='and'>
                            //                                      <condition attribute='statecode' operator='eq' value='0' />
                            //                                      <condition attribute='lux_tenanttype' operator='eq' value='{tenantType}' />
                            //                                    </filter>
                            //                                  </entity>
                            //                                </fetch>";
                            //    if (service.RetrieveMultiple(new FetchExpression(TenantFetch)).Entities.Count > 0)
                            //    {
                            //        var LoadData = service.RetrieveMultiple(new FetchExpression(TenantFetch)).Entities[0];
                            //        TenantLoad = LoadData.GetAttributeValue<decimal>("lux_loaddiscount");
                            //    }
                            //}
                            //GrossRate = ConsructionFireRate + ConsructionFireRate * TenantLoad / 100;
                        }
                    }
                    else if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970001) //commercial
                    {
                        var numberofTrades = item.Attributes.Contains("lux_totalnumberofcommercialunitsatthisaddress") ? item.GetAttributeValue<int>("lux_totalnumberofcommercialunitsatthisaddress") : 0;
                        decimal FireRate = 0;
                        if (numberofTrades > 0)
                        {
                            for (int i = 1; i <= numberofTrades; i++)
                            {
                                var fieldName = "lux_commercialunit" + i;
                                //Trade = item.GetAttributeValue<EntityReference>(fieldName).Id;
                                Trade = item.FormattedValues[fieldName].ToString();

                                var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                  <filter type='or'>
                                                    <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                    <condition attribute='lux_enddate' operator='null' />
                                                  </filter>
                                                  <condition attribute='lux_name' operator='eq' uiname='' value='{Trade}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                                {
                                    var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];

                                    FireRate += FireData.GetAttributeValue<decimal>("lux_blfirerate") < 0.06M ? 0.06M : FireData.GetAttributeValue<decimal>("lux_blfirerate");
                                }
                            }

                            BIFireRate = FireRate / numberofTrades;
                            if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                            {
                                if (BIFireRate < 0.06M)
                                {
                                    BIFireRate = 0.06M;
                                }
                            }
                            else if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                            {
                                if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                {
                                    if (BIFireRate < 0.06M)
                                    {
                                        BIFireRate = 0.06M;
                                    }
                                }
                            }
                            else
                            {
                                if (item2.Attributes.Contains("lux_policy"))
                                {
                                    var Policy = service.Retrieve("lux_policy", item2.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                    if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                    {
                                        if (quotationDate < new DateTime(2023, 02, 15))
                                        {
                                            if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                            {
                                                if (BIFireRate < 0.06M)
                                                {
                                                    BIFireRate = 0.06M;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if (BIFireRate < 0.06M)
                                            {
                                                BIFireRate = 0.06M;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                        {
                                            if (BIFireRate < 0.06M)
                                            {
                                                BIFireRate = 0.06M;
                                            }
                                        }
                                    }
                                }
                            }
                            //GrossRate = BIFireRate;
                            //var timberCount = 0;
                            //decimal ConstructionLoad = 0;
                            //decimal ConsructionFireRate = BIFireRate;

                            //var timber = premise_data.Contains("lux_howmanyfloorsareofwoodenconstruction") ? premise_data.Attributes["lux_howmanyfloorsareofwoodenconstruction"].ToString() : "";

                            //if (timber != "" && !timber.Contains("0"))
                            //{
                            //    timberCount = 1;
                            //}

                            //if (timberCount == 1)
                            //{
                            //    ConstructionLoad = 15;
                            //    ConsructionFireRate = BIFireRate + BIFireRate * ConstructionLoad / 100;
                            //}

                            //GrossRate = ConsructionFireRate;
                        }
                    }

                    if (LORSum_insured != null && LOR_indemnity != null && LORSum_insured.Value != 0)
                    {
                        var IndemnityPeriod = "";
                        if (LOR_indemnity.Value == 972970001)
                        {
                            IndemnityPeriod = "12";
                        }
                        else if (LOR_indemnity.Value == 972970002)
                        {
                            IndemnityPeriod = "18";
                        }
                        else if (LOR_indemnity.Value == 972970003)
                        {
                            IndemnityPeriod = "24";
                        }
                        else if (LOR_indemnity.Value == 972970004)
                        {
                            IndemnityPeriod = "36";
                        }

                        var TotalLossOfRentFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_lossofrentrate'>
                                                            <attribute name='lux_name' />
                                                            <attribute name='lux_rating4' />
                                                            <attribute name='lux_rating3' />
                                                            <attribute name='lux_rating2' />
                                                            <attribute name='lux_rating1' />
                                                            <attribute name='lux_lossofrentrateid' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_name' operator='eq' value='{IndemnityPeriod}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";
                        if (service.RetrieveMultiple(new FetchExpression(TotalLossOfRentFetch)).Entities.Count > 0)
                        {
                            var rating = "";
                            var LOR_Rate = service.RetrieveMultiple(new FetchExpression(TotalLossOfRentFetch)).Entities[0];
                            if (NoOfLocations > 0 && NoOfLocations <= 5)
                            {
                                rating = "lux_rating1";
                            }
                            else if (NoOfLocations >= 6 && NoOfLocations <= 20)
                            {
                                rating = "lux_rating2";
                            }
                            else if (NoOfLocations >= 21 && NoOfLocations <= 50)
                            {
                                rating = "lux_rating3";
                            }
                            else if (NoOfLocations >= 51)
                            {
                                rating = "lux_rating4";
                            }
                            var LORRate = LOR_Rate.GetAttributeValue<decimal>(rating);
                            //PerilsRate = Convert.ToDecimal(0.5) * AvgPerils * LORRate; Old Rates
                            PerilsRate = 0.03M;
                        }

                        if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970002) //residential
                        {
                            TotalRate = BIFireRate + PerilsRate;
                        }
                        else
                        {
                            TotalRate = BIFireRate + PerilsRate;
                        }
                        var LORPremium = (LORSum_insured.Value * TotalRate / 100) * dateDiffDays / 365;

                        var item1 = service.Retrieve("lux_propertyownerspremise", item.Id, new ColumnSet(false));
                        if (LORPremium < Convert.ToDecimal(12.5) && item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value != 972970001)
                        {
                            if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                            {
                                LORPremium = Convert.ToDecimal(12.5);
                                item1["lux_businessinterruptionpremium"] = new Money(Convert.ToDecimal(12.5));
                            }
                            else
                            {
                                if (item2.Attributes.Contains("lux_policy"))
                                {
                                    var Policy = service.Retrieve("lux_policy", item2.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                    if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                    {
                                        if (quotationDate < new DateTime(2023, 02, 15))
                                        {
                                            LORPremium = Convert.ToDecimal(12.5);
                                            item1["lux_businessinterruptionpremium"] = new Money(Convert.ToDecimal(12.5));
                                        }
                                        else
                                        {
                                            item1["lux_businessinterruptionpremium"] = new Money(LORPremium);
                                        }
                                    }
                                    else
                                    {
                                        LORPremium = Convert.ToDecimal(12.5);
                                        item1["lux_businessinterruptionpremium"] = new Money(Convert.ToDecimal(12.5));
                                    }
                                }
                            }
                        }
                        else
                        {
                            item1["lux_businessinterruptionpremium"] = new Money(LORPremium);
                        }
                        item1["lux_businessinterruptionperilsrate"] = PerilsRate;
                        item1["lux_businessinterruptionfirerate"] = BIFireRate;
                        item1["lux_businessinterruptionloadedfirerate"] = Convert.ToDecimal(BIFireRate);
                        service.Update(item1);

                        TotalBIPremium += Convert.ToDecimal(LORPremium);
                    }
                    else
                    {
                        var item1 = service.Retrieve("lux_propertyownerspremise", item.Id, new ColumnSet(false));

                        if (inceptionDate < new DateTime(2022, 04, 05) || quotationDate < new DateTime(2022, 04, 05))
                        {
                            TotalBIPremium += Convert.ToDecimal(12.5);
                            item1["lux_businessinterruptionpremium"] = new Money(Convert.ToDecimal(12.5));
                        }
                        else
                        {
                            TotalBIPremium += Convert.ToDecimal(0);
                            item1["lux_businessinterruptionpremium"] = new Money(Convert.ToDecimal(0));
                        }

                        item1["lux_businessinterruptionperilsrate"] = Convert.ToDecimal(0);
                        item1["lux_businessinterruptionfirerate"] = Convert.ToDecimal(0);
                        item1["lux_businessinterruptionloadedfirerate"] = Convert.ToDecimal(0);
                        service.Update(item1);
                    }
                }
                if (inceptionDate < new DateTime(2022, 04, 05) || quotationDate < new DateTime(2022, 04, 05))
                {
                    if (TotalBIPremium < 25)
                    {
                        TotalBIPremium = 25;
                    }
                }
                else
                {
                    if (TotalBIPremium > 0 && TotalBIPremium < 25 && item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value != 972970001)
                    {
                        if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                        {
                            TotalBIPremium = 25;
                        }
                        else
                        {
                            if (item2.Attributes.Contains("lux_policy"))
                            {
                                var Policy = service.Retrieve("lux_policy", item2.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
                                {
                                    TotalBIPremium = 25;
                                }
                            }
                        }
                    }
                }

                item2["lux_businessinterruptionpremium"] = new Money(TotalBIPremium);
                service.Update(item2);
            }
        }
    }
}
