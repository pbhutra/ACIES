﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CustomWorkflows
{
    public class SetPremiseOccupancyType : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownerspremise'>
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_doesthepremiseshaveaflatroof' />
                                <attribute name='lux_occupancytype' />
                                <attribute name='lux_tenanttype' />
                                <attribute name='lux_ispropertyunoccupiedformorethan60days' />
                                <attribute name='lux_totalnumberofcommercialunitsatthisaddress' />
                                <attribute name='lux_commercialunit1' />
                                <attribute name='lux_commercialunit2' />
                                <attribute name='lux_commercialunit3' />
                                <attribute name='lux_commercialunit4' />
                                <attribute name='lux_commercialunit5' />
                                <attribute name='lux_commercialunit6' />
                                <attribute name='lux_commercialunit7' />
                                <attribute name='lux_commercialunit8' />
                                <attribute name='lux_commercialunit9' />
                                <attribute name='lux_commercialunit10' />
                                <attribute name='lux_commercialunit11' />
                                <attribute name='lux_commercialunit12' />
                                <attribute name='lux_commercialunit13' />
                                <attribute name='lux_commercialunit14' />
                                <attribute name='lux_commercialunit15' />
                                <attribute name='lux_commercialunit16' />
                                <attribute name='lux_commercialunit17' />
                                <attribute name='lux_commercialunit18' />
                                <attribute name='lux_commercialunit19' />
                                <attribute name='lux_commercialunit20' />
                                <attribute name='lux_propertyownerspremiseid' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var isRPO = false;
                var isCPO = false;
                var isunoccupied = false;
                var CommTrade = "";
                var ResTrade = "";
                var isHCCOnly = false;
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    var CommercialTrades = "";
                    var ResidentialTrades = "";
                    var OccupancyType = item.Attributes.Contains("lux_occupancytype") ? item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value : 0;
                    if (OccupancyType == 972970001)
                    {
                        var numberofTrades = item.Attributes.Contains("lux_totalnumberofcommercialunitsatthisaddress") ? item.GetAttributeValue<int>("lux_totalnumberofcommercialunitsatthisaddress") : 0;
                        if (numberofTrades > 0)
                        {
                            for (int i = 1; i <= numberofTrades; i++)
                            {
                                var fieldName = "lux_commercialunit" + i;
                                var TradeId = item.GetAttributeValue<EntityReference>(fieldName).Id;

                                var tradeFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_propertyownersrate'>
                                    <attribute name='lux_workaway' />
                                    <attribute name='lux_transitratesendings' />
                                    <attribute name='lux_transitrateownvehicle' />
                                    <attribute name='lux_tradesegment' />
                                    <attribute name='lux_tradesector' />
                                    <attribute name='lux_theftstockrate' />
                                    <attribute name='lux_theftcontentsrate' />
                                    <attribute name='lux_theftbyemployeetradebaserate' />
                                    <attribute name='lux_documenttemplate' />
                                    <attribute name='lux_theft' />
                                    <attribute name='lux_productsrate' />
                                    <attribute name='lux_prods' />
                                    <attribute name='lux_plworkawaywagesrate' />
                                    <attribute name='lux_plpremiserate' />
                                    <attribute name='lux_mdbi' />
                                    <attribute name='lux_mdfirerate' />
                                    <attribute name='lux_fulldescription' />
                                    <attribute name='lux_elrate' />
                                    <attribute name='lux_blfirerate' />
                                    <attribute name='lux_el' />
                                    <attribute name='lux_documenttemplate' />
                                    <attribute name='lux_startdate' />
                                    <attribute name='lux_enddate' />
                                    <attribute name='lux_propertyownersrateid' />
                                    <order attribute='lux_blfirerate' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersrateid' operator='eq' uiname='' uitype='lux_propertyownersrate' value='{TradeId}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(tradeFetch)).Entities.Count > 0)
                                {
                                    var trade = service.RetrieveMultiple(new FetchExpression(tradeFetch)).Entities.FirstOrDefault();
                                    var tradeSector = trade.FormattedValues["lux_tradesector"].ToString();
                                    var BinderTemplate = trade.Attributes.Contains("lux_documenttemplate") ? trade.FormattedValues["lux_documenttemplate"].ToString() : "";
                                    if (tradeSector.Contains("Leisure") || BinderTemplate == "HCC")
                                    {
                                        isHCCOnly = true;
                                    }
                                }

                                if (CommTrade == "")
                                {
                                    CommTrade = item.FormattedValues[fieldName];
                                }
                                else
                                {
                                    if (!CommTrade.Contains(item.FormattedValues[fieldName]))
                                        CommTrade += ", " + item.FormattedValues[fieldName];
                                }

                                if (CommercialTrades == "")
                                {
                                    CommercialTrades = item.FormattedValues[fieldName];
                                }
                                else
                                {
                                    if (!CommercialTrades.Contains(item.FormattedValues[fieldName]))
                                        CommercialTrades += ", " + item.FormattedValues[fieldName];
                                }
                            }
                        }
                        isCPO = true;
                    }
                    else if (OccupancyType == 972970002)
                    {
                        isRPO = true;
                        ResidentialTrades = "Private Rental";
                        ResTrade = "Private Rental";
                    }
                    else if (OccupancyType == 972970004)
                    {
                        var numberofTrades = item.Attributes.Contains("lux_totalnumberofcommercialunitsatthisaddress") ? item.GetAttributeValue<int>("lux_totalnumberofcommercialunitsatthisaddress") : 0;
                        if (numberofTrades > 0)
                        {
                            for (int i = 1; i <= numberofTrades; i++)
                            {
                                var fieldName = "lux_commercialunit" + i;
                                var TradeId = item.GetAttributeValue<EntityReference>(fieldName).Id;

                                var tradeFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_propertyownersrate'>
                                    <attribute name='lux_workaway' />
                                    <attribute name='lux_transitratesendings' />
                                    <attribute name='lux_transitrateownvehicle' />
                                    <attribute name='lux_tradesegment' />
                                    <attribute name='lux_tradesector' />
                                    <attribute name='lux_theftstockrate' />
                                    <attribute name='lux_theftcontentsrate' />
                                    <attribute name='lux_theftbyemployeetradebaserate' />
                                    <attribute name='lux_documenttemplate' />
                                    <attribute name='lux_theft' />
                                    <attribute name='lux_productsrate' />
                                    <attribute name='lux_prods' />
                                    <attribute name='lux_plworkawaywagesrate' />
                                    <attribute name='lux_plpremiserate' />
                                    <attribute name='lux_mdbi' />
                                    <attribute name='lux_mdfirerate' />
                                    <attribute name='lux_fulldescription' />
                                    <attribute name='lux_elrate' />
                                    <attribute name='lux_blfirerate' />
                                    <attribute name='lux_el' />
                                    <attribute name='lux_startdate' />
                                    <attribute name='lux_enddate' />
                                    <attribute name='lux_propertyownersrateid' />
                                    <order attribute='lux_blfirerate' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersrateid' operator='eq' uiname='Abattoir' uitype='lux_propertyownersrate' value='{TradeId}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(tradeFetch)).Entities.Count > 0)
                                {
                                    var trade = service.RetrieveMultiple(new FetchExpression(tradeFetch)).Entities.FirstOrDefault();
                                    var tradeSector = trade.FormattedValues["lux_tradesector"].ToString();
                                    var BinderTemplate = trade.Attributes.Contains("lux_documenttemplate") ? trade.FormattedValues["lux_documenttemplate"].ToString() : "";
                                    if (tradeSector.Contains("Leisure") || BinderTemplate == "HCC")
                                    {
                                        isHCCOnly = true;
                                    }
                                }

                                if (CommTrade == "")
                                {
                                    CommTrade = item.FormattedValues[fieldName];
                                }
                                else
                                {
                                    if (!CommTrade.Contains(item.FormattedValues[fieldName]))
                                        CommTrade += ", " + item.FormattedValues[fieldName];
                                }

                                if (CommercialTrades == "")
                                {
                                    CommercialTrades = item.FormattedValues[fieldName];
                                }
                                else
                                {
                                    if (!CommercialTrades.Contains(item.FormattedValues[fieldName]))
                                        CommercialTrades += ", " + item.FormattedValues[fieldName];
                                }
                            }

                            if (item.Attributes.Contains("lux_tenanttype"))
                            {
                                if (!CommercialTrades.Contains(item.FormattedValues["lux_tenanttype"].ToString()))
                                    CommercialTrades += ", " + item.FormattedValues["lux_tenanttype"].ToString();

                                if (!CommTrade.Contains(item.FormattedValues["lux_tenanttype"].ToString()))
                                    CommTrade += ", " + item.FormattedValues["lux_tenanttype"].ToString();
                            }
                        }
                        isCPO = true;
                        isRPO = true;
                    }

                    var item1 = service.Retrieve("lux_propertyownerspremise", item.Id, new ColumnSet("lux_commercialtrades", "lux_residentialtrades"));
                    item1["lux_commercialtrades"] = CommercialTrades;
                    item1["lux_residentialtrades"] = ResidentialTrades;
                    service.Update(item1);

                    if (item.Attributes.Contains("lux_ispropertyunoccupiedformorethan60days"))
                    {
                        if (item.GetAttributeValue<bool>("lux_ispropertyunoccupiedformorethan60days") == true)
                        {
                            isunoccupied = true;
                        }
                    }

                    if (item.Attributes.Contains("lux_tenanttype"))
                    {
                        if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970006)
                        {
                            isunoccupied = true;
                        }
                    }

                    if (OccupancyType == 972970003)
                    {
                        isunoccupied = true;
                    }
                }

                var item2 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                item2["lux_isrpo"] = isRPO;
                item2["lux_iscpo"] = isCPO;
                if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001 || item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                {
                    if (isHCCOnly == true)
                    {
                        item2["lux_bindertemplate"] = new OptionSetValue(972970001);
                    }
                    else
                    {
                        item2["lux_bindertemplate"] = new OptionSetValue(972970002);
                    }

                    var inceptionDate = Convert.ToDateTime(item2.FormattedValues["lux_inceptiondate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                    if (inceptionDate >= new DateTime(2025, 08, 01))
                    {
                        if (isHCCOnly == true)
                        {
                            item2["lux_bindertemplate"] = new OptionSetValue(972970003);
                        }
                        else
                        {
                            item2["lux_bindertemplate"] = new OptionSetValue(972970004);
                        }

                        if (item2.GetAttributeValue<OptionSetValue>("lux_rpocpoproducttype").Value == 972970003 || item2.GetAttributeValue<OptionSetValue>("lux_rpocpoproducttype").Value == 972970004)
                        {
                            item2["lux_bindertemplate"] = new OptionSetValue(972970004);
                        }
                    }
                }
                item2["lux_isunoccupied"] = isunoccupied;
                item2["lux_commercialtrades"] = CommTrade;
                item2["lux_residentialtrades"] = ResTrade;
                service.Update(item2);
            }
        }
    }
}
