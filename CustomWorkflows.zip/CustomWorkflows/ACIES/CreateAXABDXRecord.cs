﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace CustomWorkflows
{
    public class CreateAXABDXRecord : CodeActivity
    {
        [Input("Policy")]
        [ReferenceTarget("lux_constructionpolicy")]
        [RequiredArgument]
        public InArgument<EntityReference> Policy { get; set; }

        [Input("Application")]
        [ReferenceTarget("lux_constructionquotes")]
        [RequiredArgument]
        public InArgument<EntityReference> Application { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference policyref = Policy.Get<EntityReference>(executionContext);
            Entity policy = service.Retrieve("lux_constructionpolicy", policyref.Id, new ColumnSet(true));

            EntityReference applnref = Application.Get<EntityReference>(executionContext);
            Entity appln = service.Retrieve("lux_constructionquotes", applnref.Id, new ColumnSet(true));

            var IPTRate = appln.Attributes.Contains("lux_iptrate") ? appln.GetAttributeValue<decimal>("lux_iptrate") : 12M;

            Entity bdx = new Entity("lux_constructionaxabdx");
            bdx["lux_constructionquote"] = new EntityReference("lux_constructionquotes", appln.Id);
            bdx["lux_constructionpolicy"] = new EntityReference("lux_constructionpolicy", policy.Id);
            bdx["lux_underwritingyear"] = "2024";

            bdx["lux_policytype"] = new OptionSetValue(appln.GetAttributeValue<OptionSetValue>("lux_typeofpolicy1").Value);
            bdx["lux_policynumber"] = policy.Attributes.Contains("lux_policynumber") ? policy.Attributes["lux_policynumber"].ToString() : "";
            bdx["lux_pslshareofwhole"] = appln.Attributes.Contains("lux_phoenixsharebound") ? appln.GetAttributeValue<decimal>("lux_phoenixsharebound").ToString() : "";
            bdx["lux_axabinderreferencenumber"] = appln.Attributes.Contains("lux_axabdxreference") ? appln.Attributes["lux_axabdxreference"].ToString() : "";

            var fetch = $@"<fetch name='table1' relationshipname='lux_contact_lux_constructionquotes' mapping='logical'>
                             <entity name='contact'>                             
                                  <attribute name='address1_postalcode' />
                                  <attribute name='address1_composite' />
                                  <attribute name='createdon' />
                                  <attribute name='fullname' />
                                  <attribute name='lux_matchstatus' />
                                  <order attribute='createdon' descending='false' priority='1000' sorttype='datetime' />
                                  <link-entity relationshipname='MTOMFilter' name='lux_contact_lux_constructionquotes' from='contactid' visible='false' intersect='true'>
                                       <link-entity name='lux_constructionquotes' to='lux_constructionquotesid'>
                                            <filter type='and'>
                                                 <condition attribute='lux_constructionquotesid' operator='in'>
                                                      <value>{appln.Id}</value>
                                                 </condition>
                                            </filter>
                                       </link-entity>
                                  </link-entity>
                             </entity>
                        </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                bdx["lux_nameofinsured"] = String.Join(", ", service.RetrieveMultiple(new FetchExpression(fetch)).Entities.ToList().Select(x => x.Attributes.Contains("fullname") ? x.Attributes["fullname"].ToString() : ""));
            }

            bdx["lux_dsu"] = appln.GetAttributeValue<bool>("lux_dilayinstartupcoverrequired");
            bdx["lux_ee"] = false;
            bdx["lux_tpl"] = appln.GetAttributeValue<bool>("lux_thirdpartyliabilitycover");
            bdx["lux_651"] = appln.GetAttributeValue<bool>("lux_nonnegligentliability651cover");
            bdx["lux_underwriter"] = appln.FormattedValues["lux_constructionunderwriter"];

            if (appln.FormattedValues["lux_typeofpolicy1"] == "Single Project")
            {
                bdx["lux_projectname"] = appln.Attributes.Contains("lux_project") ? appln.Attributes["lux_project"].ToString() : "";
                bdx["lux_projectdescription"] = appln.Attributes.Contains("lux_projectdescription") ? appln.Attributes["lux_projectdescription"].ToString() : "";
                bdx["lux_address"] = (appln.Attributes.Contains("lux_housenumber") ? appln.Attributes["lux_housenumber"].ToString() + ", " : "") + (appln.Attributes.Contains("lux_street") ? appln.Attributes["lux_street"].ToString() + ", " : "") + (appln.Attributes.Contains("lux_citycounty") ? appln.Attributes["lux_citycounty"].ToString() : "");
                bdx["lux_postcode"] = appln.Attributes.Contains("lux_postcode") == true ? appln.Attributes["lux_postcode"].ToString() : "";
                bdx["lux_country"] = "UK";
                bdx["lux_estimatedcontractvalueecvforsingleproject"] = appln.Attributes.Contains("lux_estimatedcontractvalue") ? appln.GetAttributeValue<Money>("lux_estimatedcontractvalue") : new Money(0);
                bdx["lux_tpllimitofindemnity"] = appln.Attributes.Contains("lux_tpllimit") ? appln.GetAttributeValue<Money>("lux_tpllimit") : new Money(0);
                bdx["lux_nonneg651liabilitylimit"] = appln.Attributes.Contains("lux_nonnegligentliability651limit") ? appln.GetAttributeValue<Money>("lux_nonnegligentliability651limit") : new Money(0);
                bdx["lux_dsulimit"] = appln.Attributes.Contains("lux_totaltsi") ? appln.GetAttributeValue<Money>("lux_totaltsi") : new Money(0);
            }
            else
            {
                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    bdx["lux_address"] = String.Join("|", service.RetrieveMultiple(new FetchExpression(fetch)).Entities.ToList().Select(x => x.Attributes.Contains("address1_composite") ? x.Attributes["address1_composite"].ToString().Replace(x.Attributes.Contains("address1_postalcode") ? x.Attributes["address1_postalcode"].ToString() : "", "").Replace("\r\n", " ").Trim() : ""));
                    bdx["lux_postcode"] = String.Join("|", service.RetrieveMultiple(new FetchExpression(fetch)).Entities.ToList().Select(x => x.Attributes.Contains("address1_postalcode") ? x.Attributes["address1_postalcode"].ToString() : ""));
                    bdx["lux_country"] = "UK";
                }
                bdx["lux_businessdescription"] = appln.Attributes.Contains("lux_businessdescription") ? appln.Attributes["lux_businessdescription"].ToString() : "";
                bdx["lux_carlimitofindemnityannuals"] = appln.Attributes.Contains("lux_maximumcontractlimit") ? appln.GetAttributeValue<Money>("lux_maximumcontractlimit") : new Money(0);
                bdx["lux_turnover"] = appln.Attributes.Contains("lux_fullcoverturnover") ? appln.GetAttributeValue<Money>("lux_fullcoverturnover") : new Money(0);
            }

            bdx["lux_projecttype"] = appln.Attributes.Contains("lux_projecttypeincludingsiccode") ? appln.FormattedValues["lux_projecttypeincludingsiccode"] : "";
            bdx["lux_businessdescription"] = appln.Attributes.Contains("lux_businessdescription") ? appln.Attributes["lux_businessdescription"].ToString() : "";
            bdx["lux_currency"] = appln.Attributes.Contains("transactioncurrencyid") ? appln.FormattedValues["transactioncurrencyid"].ToString() : "";
            bdx["lux_inceptiondate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
            bdx["lux_expirydate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
            bdx["lux_finalexpirydatesingleprojectsonly"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
            bdx["lux_typeofpolicy"] = appln.Attributes.Contains("lux_typeofpolicy2") ? appln.FormattedValues["lux_typeofpolicy2"] : "";

            if (appln.FormattedValues["lux_typeofpolicy2"] == "CAR single project - CR")
            {
                bdx["lux_car"] = true;
                bdx["lux_cpe"] = false;
                if (appln.Attributes.Contains("lux_maintenancedurationmonths"))
                {
                    var Months = Convert.ToInt32(appln.Attributes["lux_maintenancedurationmonths"].ToString().Replace("months", "").Replace("Months", "").Trim());
                    bdx["lux_finalexpirydatesingleprojectsonly"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat).AddMonths(Months);
                }

                if (appln.Attributes.Contains("lux_existingstructure") && appln.GetAttributeValue<bool>("lux_existingstructure") == true)
                {
                    if (appln.Attributes.Contains("lux_existingstructures") && appln.GetAttributeValue<OptionSetValue>("lux_existingstructures").Value == 972970001)//Sublimit
                    {
                        bdx["lux_existingstructurelimittsi"] = appln.Attributes.Contains("lux_sublimit") ? appln.GetAttributeValue<Money>("lux_sublimit") : new Money(0);
                    }
                    else if (appln.Attributes.Contains("lux_existingstructures") && appln.GetAttributeValue<OptionSetValue>("lux_existingstructures").Value == 972970002)//Full Cover
                    {
                        bdx["lux_existingstructurelimittsi"] = appln.Attributes.Contains("lux_existingstructuretsi") ? appln.GetAttributeValue<Money>("lux_existingstructuretsi") : new Money(0);
                    }
                }
            }
            else if (appln.FormattedValues["lux_typeofpolicy2"] == "CAR annual programme - CA")
            {
                bdx["lux_car"] = true;
                bdx["lux_cpe"] = false;
            }
            else if (appln.FormattedValues["lux_typeofpolicy2"] != "CPE annual programme - CP")
            {
                bdx["lux_car"] = false;
                bdx["lux_cpe"] = true;
                if (appln.Attributes.Contains("lux_existingstructure") && appln.GetAttributeValue<bool>("lux_existingstructure") == true)
                {
                    if (appln.Attributes.Contains("lux_existingstructures") && appln.GetAttributeValue<OptionSetValue>("lux_existingstructures").Value == 972970001)//Sublimit
                    {
                        bdx["lux_existingstructurelimittsi"] = appln.Attributes.Contains("lux_sublimit") ? appln.GetAttributeValue<Money>("lux_sublimit") : new Money(0);
                    }
                    else if (appln.Attributes.Contains("lux_existingstructures") && appln.GetAttributeValue<OptionSetValue>("lux_existingstructures").Value == 972970002)//Full Cover
                    {
                        bdx["lux_existingstructurelimittsi"] = appln.Attributes.Contains("lux_existingstructuretsi") ? appln.GetAttributeValue<Money>("lux_existingstructuretsi") : new Money(0);
                    }
                }
            }

            bdx["lux_ownedplantequipmenttiv"] = appln.Attributes.Contains("lux_totalownplantvalue") ? appln.GetAttributeValue<Money>("lux_totalownplantvalue") : new Money(0);
            bdx["lux_hiredinplanthiplimitofindemnity"] = appln.Attributes.Contains("lux_hiredinplantlimit") ? appln.GetAttributeValue<Money>("lux_hiredinplantlimit") : new Money(0);
            bdx["lux_annualhiringcharges"] = appln.Attributes.Contains("lux_annualhiringcharges") ? appln.GetAttributeValue<Money>("lux_annualhiringcharges") : new Money(0);
            bdx["lux_employeestoolspersonaleffects"] = appln.Attributes.Contains("lux_employeestoolstotalvalue") ? appln.GetAttributeValue<Money>("lux_employeestoolstotalvalue") : new Money(0);
            bdx["lux_mpl"] = appln.Attributes.Contains("lux_mplourshare") ? appln.GetAttributeValue<Money>("lux_mplourshare") : new Money(0);
            bdx["lux_referredtoinsurer"] = appln.Attributes.Contains("lux_referredtoinsurer") ? appln.GetAttributeValue<bool>("lux_referredtoinsurer") : false;

            //var FinalRatingfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            //                  <entity name='lux_constructiontechnicalpremiumcalculation'>
            //                    <attribute name='lux_name' />
            //                    <attribute name='lux_ratingbasis' />
            //                    <attribute name='lux_rate' />
            //                    <attribute name='lux_constructionquote' />
            //                    <attribute name='lux_grosspolicypremiumquoted' />
            //                    <attribute name='lux_grosspolicypremiumbound' />
            //                    <attribute name='lux_nettechnicalpremium' />
            //                    <attribute name='lux_ratingfigures' />
            //                    <attribute name='lux_technicalpremiumcalculation' />
            //                    <attribute name='transactioncurrencyid' />
            //                    <attribute name='lux_constructiontechnicalpremiumcalculationid' />
            //                    <order attribute='lux_name' descending='false' />
            //                    <filter type='and'>
            //                      <condition attribute='statecode' operator='eq' value='0' />
            //                      <condition attribute='lux_constructionquote' operator='eq' uiname='' uitype='lux_constructionquotes' value='{appln.Id}' />
            //                    </filter>
            //                  </entity>
            //                </fetch>";

            //var FinalRateItem = service.RetrieveMultiple(new FetchExpression(FinalRatingfetch)).Entities;
            //if (FinalRateItem.Count > 0)
            //{
            //    if (appln.FormattedValues["lux_typeofpolicy1"] == "Single Project")
            //    {
            //        bdx["lux_carpremiumextax"] = FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970001) != null ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970001).Attributes.Contains("lux_grosspolicypremiumbound") ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970001).GetAttributeValue<Money>("lux_grosspolicypremiumbound") : FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970001).Attributes.Contains("lux_nettechnicalpremium") ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970001).GetAttributeValue<Money>("lux_nettechnicalpremium") : new Money(0) : new Money(0);
            //    }
            //    else
            //    {
            //        bdx["lux_carpremiumextax"] = FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970002) != null ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970002).Attributes.Contains("lux_grosspolicypremiumbound") ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970002).GetAttributeValue<Money>("lux_grosspolicypremiumbound") : FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970002).Attributes.Contains("lux_nettechnicalpremium") ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970002).GetAttributeValue<Money>("lux_nettechnicalpremium") : new Money(0) : new Money(0);
            //    }

            //    bdx["lux_dsupremiumextax"] = FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970009) != null ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970009).Attributes.Contains("lux_grosspolicypremiumbound") ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970009).GetAttributeValue<Money>("lux_grosspolicypremiumbound") : FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970009).Attributes.Contains("lux_nettechnicalpremium") ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970009).GetAttributeValue<Money>("lux_nettechnicalpremium") : new Money(0) : new Money(0);
            //    bdx["lux_existingstructurespremiumextax"] = FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970003) != null ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970003).Attributes.Contains("lux_grosspolicypremiumbound") ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970003).GetAttributeValue<Money>("lux_grosspolicypremiumbound") : FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970003).Attributes.Contains("lux_nettechnicalpremium") ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970003).GetAttributeValue<Money>("lux_nettechnicalpremium") : new Money(0) : new Money(0);
            //    bdx["lux_tplpremiumextax"] = FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970010) != null ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970010).Attributes.Contains("lux_grosspolicypremiumbound") ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970010).GetAttributeValue<Money>("lux_grosspolicypremiumbound") : FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970010).Attributes.Contains("lux_nettechnicalpremium") ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970010).GetAttributeValue<Money>("lux_nettechnicalpremium") : new Money(0) : new Money(0);
            //    bdx["lux_nonneg651premiumextax"] = FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970011) != null ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970011).Attributes.Contains("lux_grosspolicypremiumbound") ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970011).GetAttributeValue<Money>("lux_grosspolicypremiumbound") : FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970011).Attributes.Contains("lux_nettechnicalpremium") ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970011).GetAttributeValue<Money>("lux_nettechnicalpremium") : new Money(0) : new Money(0);
            //    bdx["lux_cpepremiumextax"] = FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970004) != null ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970004).Attributes.Contains("lux_grosspolicypremiumbound") ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970004).GetAttributeValue<Money>("lux_grosspolicypremiumbound") : FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970004).Attributes.Contains("lux_nettechnicalpremium") ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970004).GetAttributeValue<Money>("lux_nettechnicalpremium") : new Money(0) : new Money(0);
            //    bdx["lux_employeeseffectspremiumextax"] = FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970006) != null ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970006).Attributes.Contains("lux_grosspolicypremiumbound") ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970006).GetAttributeValue<Money>("lux_grosspolicypremiumbound") : FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970006).Attributes.Contains("lux_nettechnicalpremium") ? FinalRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970006).GetAttributeValue<Money>("lux_nettechnicalpremium") : new Money(0) : new Money(0);
            //}

            bdx["lux_dsuindemnityperiod"] = appln.Attributes.Contains("lux_baseindemnityperiodinmonths") ? appln.FormattedValues["lux_baseindemnityperiodinmonths"].ToString() : "";
            if (appln.Attributes.Contains("lux_premiumpayablebyinstalments") && appln.GetAttributeValue<bool>("lux_premiumpayablebyinstalments") == true)
            {
                bdx["lux_noofinstalments"] = appln.Attributes.Contains("lux_numberofinstalments") ? Convert.ToInt32(appln.FormattedValues["lux_numberofinstalments"]) : 0;
            }
            else
            {
                bdx["lux_noofinstalments"] = 0;
            }

            bdx["lux_surveydeductions"] = "";
            bdx["lux_surveydeductionsamount"] = new Money(0);
            bdx["lux_taxtype"] = "IPT";
            bdx["lux_tax"] = IPTRate.ToString("#.##");

            if (appln.FormattedValues["lux_applicationtype"] == "New Business")
            {
                if (appln.FormattedValues["lux_typeofpolicy1"] == "Single Project")
                {
                    bdx["lux_carpremiumextax"] = appln.Attributes.Contains("lux_constructioncombinedprojectsection") ? appln.GetAttributeValue<Money>("lux_constructioncombinedprojectsection") : new Money(0);
                }
                else
                {
                    bdx["lux_carpremiumextax"] = appln.Attributes.Contains("lux_constructioncombinedannualsection") ? appln.GetAttributeValue<Money>("lux_constructioncombinedannualsection") : new Money(0);
                }

                bdx["lux_dsupremiumextax"] = appln.Attributes.Contains("lux_delayinstartupsection") ? appln.GetAttributeValue<Money>("lux_delayinstartupsection") : new Money(0);
                bdx["lux_existingstructurespremiumextax"] = appln.Attributes.Contains("lux_existingstructurespremium") ? appln.GetAttributeValue<Money>("lux_existingstructurespremium") : new Money(0);
                bdx["lux_tplpremiumextax"] = appln.Attributes.Contains("lux_publicliabilitybuildingandalliedtradessec") ? appln.GetAttributeValue<Money>("lux_publicliabilitybuildingandalliedtradessec") : new Money(0);
                bdx["lux_nonneg651premiumextax"] = appln.Attributes.Contains("lux_nonnegligentdamagesection") ? appln.GetAttributeValue<Money>("lux_nonnegligentdamagesection") : new Money(0);
                bdx["lux_cpepremiumextax"] = appln.Attributes.Contains("lux_contractorsplantandequipmentsection") ? appln.GetAttributeValue<Money>("lux_contractorsplantandequipmentsection") : new Money(0);
                bdx["lux_employeeseffectspremiumextax"] = appln.Attributes.Contains("lux_employeetoolssection") ? appln.GetAttributeValue<Money>("lux_employeetoolssection") : new Money(0);

                bdx["lux_transactiontype"] = new OptionSetValue(972970001);
                bdx["lux_endorsementmta"] = false;
                bdx["lux_witheffectdate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                bdx["lux_entrydate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                var GrossPremium = appln.Attributes.Contains("lux_totalpremiumexcludingterrorism") ? appln.GetAttributeValue<Money>("lux_totalpremiumexcludingterrorism") : new Money(0);
                var Commission = (appln.Attributes.Contains("lux_brokercommission") ? appln.GetAttributeValue<decimal>("lux_brokercommission") : 0) + (appln.Attributes.Contains("lux_pslcommission") ? appln.GetAttributeValue<decimal>("lux_pslcommission") : 0);

                bdx["lux_originalgrosspremiumextax"] = GrossPremium;
                bdx["lux_totalcommission"] = Commission.ToString();
                bdx["lux_totalcommissionamount"] = new Money(GrossPremium.Value * Commission / 100);
                bdx["lux_netpremium"] = new Money(GrossPremium.Value - GrossPremium.Value * Commission / 100);
                bdx["lux_taxamount"] = new Money(GrossPremium.Value * IPTRate / 100);
            }
            else if (appln.FormattedValues["lux_applicationtype"] == "Renewal")
            {
                if (appln.FormattedValues["lux_typeofpolicy1"] == "Single Project")
                {
                    bdx["lux_carpremiumextax"] = appln.Attributes.Contains("lux_constructioncombinedprojectsection") ? appln.GetAttributeValue<Money>("lux_constructioncombinedprojectsection") : new Money(0);
                }
                else
                {
                    bdx["lux_carpremiumextax"] = appln.Attributes.Contains("lux_constructioncombinedannualsection") ? appln.GetAttributeValue<Money>("lux_constructioncombinedannualsection") : new Money(0);
                }

                bdx["lux_dsupremiumextax"] = appln.Attributes.Contains("lux_delayinstartupsection") ? appln.GetAttributeValue<Money>("lux_delayinstartupsection") : new Money(0);
                bdx["lux_existingstructurespremiumextax"] = appln.Attributes.Contains("lux_existingstructurespremium") ? appln.GetAttributeValue<Money>("lux_existingstructurespremium") : new Money(0);
                bdx["lux_tplpremiumextax"] = appln.Attributes.Contains("lux_publicliabilitybuildingandalliedtradessec") ? appln.GetAttributeValue<Money>("lux_publicliabilitybuildingandalliedtradessec") : new Money(0);
                bdx["lux_nonneg651premiumextax"] = appln.Attributes.Contains("lux_nonnegligentdamagesection") ? appln.GetAttributeValue<Money>("lux_nonnegligentdamagesection") : new Money(0);
                bdx["lux_cpepremiumextax"] = appln.Attributes.Contains("lux_contractorsplantandequipmentsection") ? appln.GetAttributeValue<Money>("lux_contractorsplantandequipmentsection") : new Money(0);
                bdx["lux_employeeseffectspremiumextax"] = appln.Attributes.Contains("lux_employeetoolssection") ? appln.GetAttributeValue<Money>("lux_employeetoolssection") : new Money(0);

                bdx["lux_transactiontype"] = new OptionSetValue(972970002);
                bdx["lux_endorsementmta"] = false;
                bdx["lux_witheffectdate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                bdx["lux_entrydate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                var GrossPremium = appln.Attributes.Contains("lux_totalpremiumexcludingterrorism") ? appln.GetAttributeValue<Money>("lux_totalpremiumexcludingterrorism") : new Money(0);
                var Commission = (appln.Attributes.Contains("lux_brokercommission") ? appln.GetAttributeValue<decimal>("lux_brokercommission") : 0) + (appln.Attributes.Contains("lux_pslcommission") ? appln.GetAttributeValue<decimal>("lux_pslcommission") : 0);

                bdx["lux_originalgrosspremiumextax"] = GrossPremium;
                bdx["lux_totalcommission"] = Commission.ToString();
                bdx["lux_totalcommissionamount"] = new Money(GrossPremium.Value * Commission / 100);
                bdx["lux_netpremium"] = new Money(GrossPremium.Value - GrossPremium.Value * Commission / 100);
                bdx["lux_taxamount"] = new Money(GrossPremium.Value * IPTRate / 100);
            }
            else if (appln.FormattedValues["lux_applicationtype"] == "Cancellation")
            {
                if (appln.FormattedValues["lux_typeofpolicy1"] == "Single Project")
                {
                    bdx["lux_carpremiumextax"] = appln.Attributes.Contains("lux_constructioncombinedprojectsectionmta") ? appln.GetAttributeValue<Money>("lux_constructioncombinedprojectsectionmta") : new Money(0);
                }
                else
                {
                    bdx["lux_carpremiumextax"] = appln.Attributes.Contains("lux_constructioncombinedannualsectionmta") ? appln.GetAttributeValue<Money>("lux_constructioncombinedannualsectionmta") : new Money(0);
                }

                bdx["lux_dsupremiumextax"] = appln.Attributes.Contains("lux_delayinstartupsectionmta") ? appln.GetAttributeValue<Money>("lux_delayinstartupsectionmta") : new Money(0);
                bdx["lux_existingstructurespremiumextax"] = appln.Attributes.Contains("lux_existingstructurespremiummta") ? appln.GetAttributeValue<Money>("lux_existingstructurespremiummta") : new Money(0);
                bdx["lux_tplpremiumextax"] = appln.Attributes.Contains("lux_publicliabilitybuildingandalliedtradesmta") ? appln.GetAttributeValue<Money>("lux_publicliabilitybuildingandalliedtradesmta") : new Money(0);
                bdx["lux_nonneg651premiumextax"] = appln.Attributes.Contains("lux_nonnegligentdamagesectionmta") ? appln.GetAttributeValue<Money>("lux_nonnegligentdamagesectionmta") : new Money(0);
                bdx["lux_cpepremiumextax"] = appln.Attributes.Contains("lux_contractorsplantandequipmentsectionmta") ? appln.GetAttributeValue<Money>("lux_contractorsplantandequipmentsectionmta") : new Money(0);
                bdx["lux_employeeseffectspremiumextax"] = appln.Attributes.Contains("lux_employeetoolssectionmta") ? appln.GetAttributeValue<Money>("lux_employeetoolssectionmta") : new Money(0);

                bdx["lux_transactiontype"] = new OptionSetValue(972970003);
                bdx["lux_endorsementmta"] = true;
                bdx["lux_witheffectdate"] = Convert.ToDateTime(appln.Attributes.Contains("lux_mtadate") == true ? appln.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                bdx["lux_entrydate"] = Convert.ToDateTime(policy.Attributes.Contains("modifiedon") == true ? policy.FormattedValues["modifiedon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                var GrossPremium = appln.Attributes.Contains("lux_mtatotalpremiumexcludingterrorisms") ? appln.GetAttributeValue<Money>("lux_mtatotalpremiumexcludingterrorisms") : new Money(0);
                var Commission = (appln.Attributes.Contains("lux_mtabrokercommission") ? appln.GetAttributeValue<decimal>("lux_mtabrokercommission") : 0) + (appln.Attributes.Contains("lux_mtapslcommission") ? appln.GetAttributeValue<decimal>("lux_mtapslcommission") : 0);

                bdx["lux_originalgrosspremiumextax"] = GrossPremium;
                bdx["lux_totalcommission"] = Commission.ToString();
                bdx["lux_totalcommissionamount"] = new Money(GrossPremium.Value * Commission / 100);
                bdx["lux_netpremium"] = new Money(GrossPremium.Value - GrossPremium.Value * Commission / 100);
                bdx["lux_taxamount"] = new Money(GrossPremium.Value * IPTRate / 100);
            }
            else if (appln.FormattedValues["lux_applicationtype"] == "MTA")
            {
                if (appln.FormattedValues["lux_typeofpolicy1"] == "Single Project")
                {
                    bdx["lux_carpremiumextax"] = appln.Attributes.Contains("lux_constructioncombinedprojectsectionmta") ? appln.GetAttributeValue<Money>("lux_constructioncombinedprojectsectionmta") : new Money(0);
                }
                else
                {
                    bdx["lux_carpremiumextax"] = appln.Attributes.Contains("lux_constructioncombinedannualsectionmta") ? appln.GetAttributeValue<Money>("lux_constructioncombinedannualsectionmta") : new Money(0);
                }

                bdx["lux_dsupremiumextax"] = appln.Attributes.Contains("lux_delayinstartupsectionmta") ? appln.GetAttributeValue<Money>("lux_delayinstartupsectionmta") : new Money(0);
                bdx["lux_existingstructurespremiumextax"] = appln.Attributes.Contains("lux_existingstructurespremiummta") ? appln.GetAttributeValue<Money>("lux_existingstructurespremiummta") : new Money(0);
                bdx["lux_tplpremiumextax"] = appln.Attributes.Contains("lux_publicliabilitybuildingandalliedtradesmta") ? appln.GetAttributeValue<Money>("lux_publicliabilitybuildingandalliedtradesmta") : new Money(0);
                bdx["lux_nonneg651premiumextax"] = appln.Attributes.Contains("lux_nonnegligentdamagesectionmta") ? appln.GetAttributeValue<Money>("lux_nonnegligentdamagesectionmta") : new Money(0);
                bdx["lux_cpepremiumextax"] = appln.Attributes.Contains("lux_contractorsplantandequipmentsectionmta") ? appln.GetAttributeValue<Money>("lux_contractorsplantandequipmentsectionmta") : new Money(0);
                bdx["lux_employeeseffectspremiumextax"] = appln.Attributes.Contains("lux_employeetoolssectionmta") ? appln.GetAttributeValue<Money>("lux_employeetoolssectionmta") : new Money(0);

                bdx["lux_transactiontype"] = new OptionSetValue(972970004);
                bdx["lux_endorsementmta"] = true;
                bdx["lux_witheffectdate"] = Convert.ToDateTime(appln.Attributes.Contains("lux_mtadate") == true ? appln.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                bdx["lux_entrydate"] = Convert.ToDateTime(policy.Attributes.Contains("modifiedon") == true ? policy.FormattedValues["modifiedon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                var GrossPremium = appln.Attributes.Contains("lux_mtatotalpremiumexcludingterrorisms") ? appln.GetAttributeValue<Money>("lux_mtatotalpremiumexcludingterrorisms") : new Money(0);
                var Commission = (appln.Attributes.Contains("lux_mtabrokercommission") ? appln.GetAttributeValue<decimal>("lux_mtabrokercommission") : 0) + (appln.Attributes.Contains("lux_mtapslcommission") ? appln.GetAttributeValue<decimal>("lux_mtapslcommission") : 0);

                bdx["lux_originalgrosspremiumextax"] = GrossPremium;
                bdx["lux_totalcommission"] = Commission.ToString();
                bdx["lux_totalcommissionamount"] = new Money(GrossPremium.Value * Commission / 100);
                bdx["lux_netpremium"] = new Money(GrossPremium.Value - GrossPremium.Value * Commission / 100);
                bdx["lux_taxamount"] = new Money(GrossPremium.Value * IPTRate / 100);
            }

            bdx["lux_bordereaunumber"] = "";
            bdx["lux_accidentalreleaseofasbestosundertpl"] = appln.GetAttributeValue<bool>("lux_accidentaldiscoveryofasbestosprovided");
            bdx["lux_ratedeviation"] = appln.Attributes.Contains("lux_boundratedeviation") ? appln.Attributes["lux_boundratedeviation"].ToString() : "";

            service.Create(bdx);
        }
    }
}