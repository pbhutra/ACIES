﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class MarkReferralAsApprovedforMTA : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    var referral = service.Retrieve("lux_referral", item.Id, new ColumnSet(true));
                    referral["lux_approve"] = true;
                    referral["lux_approvaldate"] = DateTime.Now;
                    service.Update(referral);
                }
            }
        }
    }
}
