﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CustomWorkflows
{
    public class CalculatePLPremiumRetail : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Input("Product")]
        public InArgument<string> Product { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var request = new RetrieveCurrentOrganizationRequest();
            var organzationResponse = (RetrieveCurrentOrganizationResponse)service.Execute(request);
            var uriString = organzationResponse.Detail.UrlName;

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_propertyownersapplicationsid' />
                                <attribute name='lux_ukturnover' />
                                <attribute name='lux_policy' />
                                <attribute name='lux_applicationtype' />
                                <attribute name='lux_typeofworkawayundertaken' />
                                <attribute name='lux_turnover' />
                                <attribute name='lux_restoftheworldturnover' />
                                <attribute name='lux_pllimitofindemnity' />
                                <attribute name='lux_northamericaandcanadaturnover' />
                                <attribute name='lux_isanyworkawaycarriedoutotherthanforcollec' />
                                <attribute name='lux_heatworkawaywageroll' />
                                <attribute name='lux_euturnover' />
                                <attribute name='lux_anyheatworkawayundertaken' />
                                <attribute name='lux_workawaywageroll' />
                                <attribute name='lux_quotationdate' />
                                <attribute name='lux_inceptiondate' />
                                <attribute name='lux_bonafidesubcontractorswageroll' />
                                <attribute name='lux_maintradeforthispremises' />
                                <attribute name='lux_ispublicandproductsliabilitycoverrequired' />
                                <attribute name='lux_workawaytrade' />
                                <attribute name='lux_plworkawaypremium' />
                                <attribute name='lux_contractorsprimarytrade' />
                                <attribute name='lux_contractorssecondarytrade' />
                                <attribute name='lux_primarytradeturnover' />
                                <attribute name='lux_secondarytradeturnover' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplicationsid' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var item = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                var quotationDate = item.Contains("lux_quotationdate") ? item.GetAttributeValue<DateTime>("lux_quotationdate") : DateTime.UtcNow;
                var inceptionDate = item.GetAttributeValue<DateTime>("lux_inceptiondate");
                var ApplicationType = item.Attributes.Contains("lux_applicationtype") ? item.FormattedValues["lux_applicationtype"].ToString() : "";

                if (Product.Get(executionContext).ToString() != "Contractors Combined")
                {
                    decimal PremisePremium = 0;
                    decimal UKPremium = 0;
                    decimal EUPremium = 0;
                    decimal ROWPremium = 0;
                    decimal USPremium = 0;
                    decimal WorkAwayPremium = 0;
                    decimal totalPremium = 0;

                    var RetailFetch = "";
                    if (Product.Get(executionContext).ToString() == "Retail")
                    {
                        RetailFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_propertyownersretail'>
                                            <attribute name='lux_propertyownersretailid' />
                                            <attribute name='lux_name' />
                                            <attribute name='createdon' />
                                            <attribute name='lux_maintradeforthispremises' />
                                            <order attribute='lux_name' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";
                    }
                    else if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
                    {
                        RetailFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='lux_commercialcombinedapplication'>
                                        <attribute name='lux_commercialcombinedapplicationid' />
                                        <attribute name='lux_name' />
                                        <attribute name='createdon' />
                                        <order attribute='lux_name' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                        </filter>
                                      </entity>
                                    </fetch>";
                    }
                    else if (Product.Get(executionContext).ToString() == "Pubs & Restaurants" || Product.Get(executionContext).ToString() == "Hotels and Guesthouses")
                    {
                        RetailFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_pubsrestaurantspropertyownersapplicatio'>
                                                <attribute name='lux_pubsrestaurantspropertyownersapplicatioid' />
                                                <attribute name='lux_name' />
                                                <attribute name='createdon' />
                                                <attribute name='lux_maintradeforthispremises' />
                                                <order attribute='lux_name' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                                </filter>
                                              </entity>
                                            </fetch>";
                    }

                    var PremiseCount = service.RetrieveMultiple(new FetchExpression(RetailFetch)).Entities.Count();
                    decimal WorkAwayRate = 0;
                    decimal ProductsRate = 0;
                    if (item.Attributes.Contains("lux_maintradeforthispremises"))
                    {
                        var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                  <filter type='or'>
                                                    <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                    <condition attribute='lux_enddate' operator='null' />
                                                  </filter>
                                                  <condition attribute='lux_name' operator='eq' uiname='' value='{item.FormattedValues["lux_maintradeforthispremises"].ToString()}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                        {
                            var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];
                            if (Product.Get(executionContext).ToString() == "Pubs & Restaurants" || Product.Get(executionContext).ToString() == "Hotels and Guesthouses")
                            {
                                PremisePremium = 250;
                                ProductsRate = 0.04M;
                                WorkAwayRate = FireData.GetAttributeValue<decimal>("lux_plworkawaywagesrate");
                            }
                            else if (Product.Get(executionContext).ToString() == "Retail")
                            {
                                PremisePremium = FireData.GetAttributeValue<decimal>("lux_plpremiserate");
                                if (FireData.GetAttributeValue<int>("lux_prods") >= 1 && FireData.GetAttributeValue<int>("lux_prods") <= 4)
                                {
                                    ProductsRate = 0.02M;
                                }
                                else if (FireData.GetAttributeValue<int>("lux_prods") == 5)
                                {
                                    ProductsRate = 0.06M;
                                }
                                else if (FireData.GetAttributeValue<int>("lux_prods") == 6)
                                {
                                    ProductsRate = 0.00M;
                                }
                                else
                                {
                                    ProductsRate = FireData.GetAttributeValue<decimal>("lux_productsrate");
                                }

                                if (FireData.GetAttributeValue<int>("lux_workaway") < 6)
                                {
                                    WorkAwayRate = 0.4M;
                                }
                                else
                                {
                                    WorkAwayRate = FireData.GetAttributeValue<decimal>("lux_plworkawaywagesrate");
                                }
                            }
                            else if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
                            {
                                WorkAwayRate = FireData.GetAttributeValue<decimal>("lux_plworkawaywagesrate");
                                PremisePremium = FireData.GetAttributeValue<decimal>("lux_plpremiserate");
                                if (FireData.GetAttributeValue<int>("lux_prods") == 1)
                                {
                                    ProductsRate = 0.02M;
                                }
                                else if (FireData.GetAttributeValue<int>("lux_prods") == 2)
                                {
                                    ProductsRate = 0.03M;
                                }
                                else if (FireData.GetAttributeValue<int>("lux_prods") == 3)
                                {
                                    ProductsRate = 0.04M;
                                }
                                else if (FireData.GetAttributeValue<int>("lux_prods") == 4)
                                {
                                    ProductsRate = 0.05M;
                                }
                                else if (FireData.GetAttributeValue<int>("lux_prods") == 5)
                                {
                                    ProductsRate = 0.075M;
                                }
                                else if (FireData.GetAttributeValue<int>("lux_prods") == 6)
                                {
                                    ProductsRate = 0.00M;
                                }
                                else
                                {
                                    ProductsRate = FireData.GetAttributeValue<decimal>("lux_productsrate");
                                }
                            }
                            else
                            {
                                PremisePremium = FireData.GetAttributeValue<decimal>("lux_plpremiserate");
                                ProductsRate = FireData.GetAttributeValue<decimal>("lux_productsrate");
                                WorkAwayRate = FireData.GetAttributeValue<decimal>("lux_plworkawaywagesrate");
                            }
                        }
                    }
                    if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
                    {
                        if (item.Attributes.Contains("lux_workawaytrade"))
                        {
                            var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                  <filter type='or'>
                                                    <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                    <condition attribute='lux_enddate' operator='null' />
                                                  </filter>
                                                  <condition attribute='lux_name' operator='eq' uiname='' value='{item.FormattedValues["lux_workawaytrade"].ToString()}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                            if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                            {
                                var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];
                                WorkAwayRate = FireData.GetAttributeValue<decimal>("lux_plworkawaywagesrate");
                            }
                        }
                    }

                    decimal TurnoverRate = ProductsRate;

                    var UKTurnover = item.Attributes.Contains("lux_ukturnover") ? item.GetAttributeValue<Money>("lux_ukturnover").Value : 0;
                    var EUTurnover = item.Attributes.Contains("lux_euturnover") ? item.GetAttributeValue<Money>("lux_euturnover").Value : 0;
                    var RestOfWorldTurnover = item.Attributes.Contains("lux_restoftheworldturnover") ? item.GetAttributeValue<Money>("lux_restoftheworldturnover").Value : 0;
                    var NorthAmericaTurnover = item.Attributes.Contains("lux_northamericaandcanadaturnover") ? item.GetAttributeValue<Money>("lux_northamericaandcanadaturnover").Value : 0;

                    UKPremium = UKTurnover * TurnoverRate / 100;
                    EUPremium = EUTurnover * TurnoverRate / 100;
                    ROWPremium = RestOfWorldTurnover * TurnoverRate * Convert.ToDecimal(2.5) / 100;
                    USPremium = NorthAmericaTurnover * TurnoverRate * 10 / 100;

                    var PLLimitofIndemnity = item.Attributes.Contains("lux_pllimitofindemnity") ? item.GetAttributeValue<OptionSetValue>("lux_pllimitofindemnity").Value : 0;
                    var Load = 0;
                    if (PLLimitofIndemnity == 972970001)
                    {
                        Load = 0;
                    }
                    else if (PLLimitofIndemnity == 972970002)
                    {
                        Load = 20;
                    }
                    else if (PLLimitofIndemnity == 972970003)
                    {
                        Load = 40;
                    }

                    decimal workaway = 0;
                    decimal bonafide = 0;
                    if (item.Attributes.Contains("lux_isanyworkawaycarriedoutotherthanforcollec") && item.GetAttributeValue<bool>("lux_isanyworkawaycarriedoutotherthanforcollec") == true)
                    {
                        workaway = item.Contains("lux_workawaywageroll") ? item.GetAttributeValue<Money>("lux_workawaywageroll").Value : 0;
                        bonafide = item.Contains("lux_bonafidesubcontractorswageroll") ? item.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value : 0;
                    }

                    WorkAwayPremium = workaway * WorkAwayRate / 100 + bonafide * (WorkAwayRate * Convert.ToDecimal(0.30)) / 100;

                    if (inceptionDate >= new DateTime(2023, 11, 01))
                    {
                        UKPremium = 1.1M * UKPremium;
                        EUPremium = 1.1M * EUPremium;
                        ROWPremium = 1.1M * ROWPremium;
                        USPremium = 1.1M * USPremium;
                        WorkAwayPremium = 1.1M * WorkAwayPremium;
                        PremisePremium = 1.1M * PremisePremium;
                    }

                    if (quotationDate >= new DateTime(2025, 01, 01))
                    {
                        if (ApplicationType == "New Business")
                        {
                            UKPremium = 1.05M * UKPremium;
                            EUPremium = 1.05M * EUPremium;
                            ROWPremium = 1.05M * ROWPremium;
                            USPremium = 1.05M * USPremium;
                            WorkAwayPremium = 1.05M * WorkAwayPremium;
                            PremisePremium = 1.05M * PremisePremium;
                        }
                        else if (ApplicationType == "MTA" || ApplicationType == "Cancellation")
                        {
                            if (item.Attributes.Contains("lux_policy"))
                            {
                                var Policy = service.Retrieve("lux_policy", item.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                {
                                    UKPremium = 1.05M * UKPremium;
                                    EUPremium = 1.05M * EUPremium;
                                    ROWPremium = 1.05M * ROWPremium;
                                    USPremium = 1.05M * USPremium;
                                    WorkAwayPremium = 1.05M * WorkAwayPremium;
                                    PremisePremium = 1.05M * PremisePremium;
                                }
                            }
                        }
                    }

                    totalPremium = UKPremium + EUPremium + ROWPremium + USPremium + WorkAwayPremium + PremisePremium * PremiseCount;

                    totalPremium = totalPremium + totalPremium * Load / 100;

                    var item1 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));

                    if (Product.Get(executionContext).ToString() == "Retail")
                    {
                        if (totalPremium < 100)
                        {
                            totalPremium = 100;
                        }
                    }
                    else if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
                    {
                        if (totalPremium < 100)
                        {
                            totalPremium = 100;
                        }
                    }
                    else if (Product.Get(executionContext).ToString() == "Pubs & Restaurants" || Product.Get(executionContext).ToString() == "Hotels and Guesthouses")
                    {
                        if (totalPremium < 350)
                        {
                            totalPremium = 350;
                        }
                    }
                    item1["lux_publicproductsliabilitypremium"] = new Money(totalPremium);
                    item1["lux_plworkawaypremium"] = new Money(WorkAwayPremium);
                    item1["lux_premisesrate"] = new Money(PremisePremium * PremiseCount);
                    item1["lux_ukeuturnoverrate"] = TurnoverRate;
                    item1["lux_restoftheworldrate"] = TurnoverRate * Convert.ToDecimal(2.5);
                    item1["lux_northamericacanadarate"] = TurnoverRate * Convert.ToDecimal(10);
                    item1["lux_plproductspremiumload"] = Convert.ToDecimal(Load);
                    item1["lux_workawaydirectemployeesrate"] = WorkAwayRate;
                    item1["lux_workawaybonafidesubcontractorsrate"] = WorkAwayRate * Convert.ToDecimal(0.30);
                    if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
                    {
                        if (item.GetAttributeValue<bool>("lux_ispublicandproductsliabilitycoverrequired") == false)
                        {
                            item1["lux_publicproductsliabilitypremium"] = new Money(0);
                            item1["lux_plworkawaypremium"] = new Money(0);
                            item1["lux_premisesrate"] = new Money(0);
                            item1["lux_ukeuturnoverrate"] = Convert.ToDecimal(0);
                            item1["lux_restoftheworldrate"] = Convert.ToDecimal(0);
                            item1["lux_northamericacanadarate"] = Convert.ToDecimal(0);
                            item1["lux_plproductspremiumload"] = Convert.ToDecimal(0);
                            item1["lux_workawaydirectemployeesrate"] = Convert.ToDecimal(0);
                            item1["lux_workawaybonafidesubcontractorsrate"] = Convert.ToDecimal(0);
                        }
                    }
                    service.Update(item1);
                }
                else
                {
                    if (item.GetAttributeValue<bool>("lux_ispublicandproductsliabilitycoverrequired") == true)
                    {
                        decimal primaryTradePremium = 0;
                        decimal secondaryTradePremium = 0;
                        decimal totalPremium = 0;
                        decimal primaryTradeRate = 0;
                        decimal secondaryTradeRate = 0;

                        if (item.Attributes.Contains("lux_contractorsprimarytrade"))
                        {
                            var primaryTrade = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_contractorstrade'>
                                                    <attribute name='lux_contractorstradeid' />
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_tradecategory' />
                                                    <attribute name='lux_plrate' />
                                                    <attribute name='lux_materialdamagefirerate' />
                                                    <attribute name='lux_elrate' />
                                                    <attribute name='lux_carrate' />
                                                    <attribute name='lux_businessinterruptionrate' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                      <filter type='or'>
                                                        <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                        <condition attribute='lux_enddate' operator='null' />
                                                      </filter>
                                                      <condition attribute='lux_contractorstradeid' operator='eq' uiname='Aerial Erection' uitype='lux_contractorstrade' value='{item.GetAttributeValue<EntityReference>("lux_contractorsprimarytrade").Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                            if (service.RetrieveMultiple(new FetchExpression(primaryTrade)).Entities.Count > 0)
                            {
                                var PLData = service.RetrieveMultiple(new FetchExpression(primaryTrade)).Entities[0];
                                primaryTradeRate = PLData.GetAttributeValue<decimal>("lux_plrate");
                            }
                        }
                        if (item.Attributes.Contains("lux_contractorssecondarytrade"))
                        {
                            var secondaryTrade = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_contractorstrade'>
                                                    <attribute name='lux_contractorstradeid' />
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_tradecategory' />
                                                    <attribute name='lux_plrate' />
                                                    <attribute name='lux_materialdamagefirerate' />
                                                    <attribute name='lux_elrate' />
                                                    <attribute name='lux_carrate' />
                                                    <attribute name='lux_businessinterruptionrate' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                      <filter type='or'>
                                                        <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                        <condition attribute='lux_enddate' operator='null' />
                                                      </filter>
                                                      <condition attribute='lux_contractorstradeid' operator='eq' uiname='Aerial Erection' uitype='lux_contractorstrade' value='{item.GetAttributeValue<EntityReference>("lux_contractorssecondarytrade").Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                            if (service.RetrieveMultiple(new FetchExpression(secondaryTrade)).Entities.Count > 0)
                            {
                                var PLData = service.RetrieveMultiple(new FetchExpression(secondaryTrade)).Entities[0];
                                secondaryTradeRate = PLData.GetAttributeValue<decimal>("lux_plrate");
                            }
                        }

                        var primaryTurnover = item.Contains("lux_primarytradeturnover") ? item.GetAttributeValue<Money>("lux_primarytradeturnover").Value : 0;
                        var secondaryTurnover = item.Contains("lux_secondarytradeturnover") ? item.GetAttributeValue<Money>("lux_secondarytradeturnover").Value : 0;
                        var BFSCWageroll = item.Contains("lux_bonafidesubcontractorswageroll") ? item.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value : 0;

                        var totalTurnover = primaryTurnover + secondaryTurnover;

                        primaryTradePremium = (primaryTurnover - BFSCWageroll) * primaryTradeRate / 100;
                        secondaryTradePremium = secondaryTurnover * secondaryTradeRate / 100;

                        var bonafidewageroll = item.Contains("lux_bonafidesubcontractorswageroll") ? item.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value : 0;
                        var bfscPremium = bonafidewageroll * Convert.ToDecimal(0.1) / 100;

                        totalPremium = primaryTradePremium + secondaryTradePremium + bfscPremium;

                        var PLLimitofIndemnity = item.Attributes.Contains("lux_pllimitofindemnity") ? item.GetAttributeValue<OptionSetValue>("lux_pllimitofindemnity").Value : 0;
                        var Load = 0;
                        if (PLLimitofIndemnity == 972970004)
                        {
                            Load = -30;
                        }
                        else if (PLLimitofIndemnity == 972970001)
                        {
                            Load = -20;
                        }
                        else if (PLLimitofIndemnity == 972970002)
                        {
                            Load = 0;
                        }

                        totalPremium = totalPremium + totalPremium * Load / 100;

                        var item1 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                        var dateDiffDays = (item1.GetAttributeValue<DateTime>("lux_renewaldate") - item1.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                        if (dateDiffDays == 364 || dateDiffDays == 365 || dateDiffDays == 366)
                        {
                            dateDiffDays = 365;
                        }
                        totalPremium = totalPremium * dateDiffDays / 365;

                        if (inceptionDate >= new DateTime(2023, 11, 01))
                        {
                            totalPremium = 1.1M * totalPremium;
                        }

                        if (quotationDate >= new DateTime(2025, 01, 01))
                        {
                            if (ApplicationType == "New Business")
                            {
                                totalPremium = 1.05M * totalPremium;
                            }
                            else if (ApplicationType == "MTA" || ApplicationType == "Cancellation")
                            {
                                if (item.Attributes.Contains("lux_policy"))
                                {
                                    var Policy = service.Retrieve("lux_policy", item.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                    if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                    {
                                        totalPremium = 1.05M * totalPremium;
                                    }
                                }
                            }
                        }

                        //if (uriString.ToLower().Contains("uat"))
                        //{
                        var SizeDiscountFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_sizediscount'>
                                            <attribute name='lux_effectiveto' />
                                            <attribute name='lux_effectivefrom' />
                                            <attribute name='lux_below500k' />
                                            <attribute name='lux_above5m' />
                                            <attribute name='lux_501k1m' />
                                            <attribute name='lux_20000015m' />
                                            <attribute name='lux_10000012m' />
                                            <order attribute='createdon' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <filter type='or'>
                                                <condition attribute='lux_effectivefrom' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                <condition attribute='lux_effectivefrom' operator='null' />
                                              </filter>
                                              <filter type='or'>
                                                <condition attribute='lux_effectiveto' operator='on-or-after' value= '{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                <condition attribute='lux_effectiveto' operator='null' />
                                              </filter>
                                              <condition attribute='lux_section' operator='eq' value='972970003' />
                                              <condition attribute='lux_product' operator='eq' uiname='' uitype='product' value='1ca35a2b-23a4-eb11-b1ac-002248404342' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(SizeDiscountFetch)).Entities.Count > 0)
                        {
                            var SI_data = service.RetrieveMultiple(new FetchExpression(SizeDiscountFetch)).Entities;
                            var SI_field = "";
                            if (totalTurnover <= 500000)
                            {
                                SI_field = "lux_below500k";
                            }
                            else if (totalTurnover > 500000 && totalTurnover <= 1000000)
                            {
                                SI_field = "lux_501k1m";
                            }
                            else if (totalTurnover > 1000000 && totalTurnover <= 2000000)
                            {
                                SI_field = "lux_10000012m";
                            }
                            else if (totalTurnover > 2000000 && totalTurnover <= 5000000)
                            {
                                SI_field = "lux_20000015m";
                            }
                            else if (totalTurnover > 5000000)
                            {
                                SI_field = "lux_above5m";
                            }
                            var discount = SI_data.FirstOrDefault().GetAttributeValue<decimal>(SI_field);
                            //item1["lux_plproductsaction"] = discount.ToString("#.##") + "%";
                            item1["lux_plproductsaction"] = "0%";
                        }
                        //}

                        if (totalPremium < 250)
                        {
                            totalPremium = 250;
                        }

                        item1["lux_publicproductsliabilitypremium"] = new Money(totalPremium);
                        item1["lux_ukeuturnoverrate"] = primaryTradeRate;
                        item1["lux_restoftheworldrate"] = secondaryTradeRate;
                        item1["lux_workawaybonafidesubcontractorsrate"] = Convert.ToDecimal(0.1);
                        if (item.GetAttributeValue<bool>("lux_ispublicandproductsliabilitycoverrequired") == false)
                        {
                            item1["lux_publicproductsliabilitypremium"] = new Money(0);
                            item1["lux_ukeuturnoverrate"] = Convert.ToDecimal(0);
                            item1["lux_restoftheworldrate"] = Convert.ToDecimal(0);
                            item1["lux_workawaybonafidesubcontractorsrate"] = Convert.ToDecimal(0);
                        }
                        service.Update(item1);
                    }
                    else
                    {
                        var item1 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                        item1["lux_publicproductsliabilitypremium"] = new Money(0);
                        item1["lux_plworkawaypremium"] = new Money(0);
                        item1["lux_premisesrate"] = new Money(0);
                        item1["lux_ukeuturnoverrate"] = Convert.ToDecimal(0);
                        item1["lux_restoftheworldrate"] = Convert.ToDecimal(0);
                        item1["lux_northamericacanadarate"] = Convert.ToDecimal(0);
                        item1["lux_plproductspremiumload"] = Convert.ToDecimal(0);
                        item1["lux_workawaydirectemployeesrate"] = Convert.ToDecimal(0);
                        item1["lux_workawaybonafidesubcontractorsrate"] = Convert.ToDecimal(0);
                        item1["lux_plproductsaction"] = "";
                        service.Update(item1);
                    }
                }
            }
            else
            {
                var item1 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                item1["lux_publicproductsliabilitypremium"] = new Money(0);
                item1["lux_plworkawaypremium"] = new Money(0);
                item1["lux_premisesrate"] = new Money(0);
                item1["lux_ukeuturnoverrate"] = Convert.ToDecimal(0);
                item1["lux_restoftheworldrate"] = Convert.ToDecimal(0);
                item1["lux_northamericacanadarate"] = Convert.ToDecimal(0);
                item1["lux_plproductspremiumload"] = Convert.ToDecimal(0);
                item1["lux_workawaydirectemployeesrate"] = Convert.ToDecimal(0);
                item1["lux_workawaybonafidesubcontractorsrate"] = Convert.ToDecimal(0);
                service.Update(item1);
            }
        }
    }
}
