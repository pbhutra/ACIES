﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculateRefundPremiumCEDAR : CodeActivity
    {
        [Input("Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> Application { get; set; }

        [Input("Policy")]
        [ReferenceTarget("lux_policy")]
        public InArgument<EntityReference> Policy { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            Entity applnref = service.Retrieve("lux_propertyownersapplications", Application.Get(executionContext).Id, new ColumnSet(true));
            Entity appln = service.Retrieve(applnref.LogicalName, applnref.Id, new ColumnSet(true));

            var mainfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_mtadate' />
                                <attribute name='lux_propertyownersapplicationsid' />
                                <attribute name='lux_renewaldate' />
                                <attribute name='lux_inceptiondate' /> 
                                <attribute name='lux_policytotalpremium' />                                
                                <attribute name='lux_insuranceproductrequired' />
                                <attribute name='lux_policybrokercommissionamount' />
                                <attribute name='lux_policycedarcommissionamount' />
                                <attribute name='lux_mtacedarcommissionamount' />
                                <attribute name='lux_mtabrokercommissionamount' />
                                <attribute name='lux_policybrokercommission' />
                                <attribute name='lux_policycedarcommission' /> 
                                <attribute name='lux_buildingspolicypremium' />
                                <attribute name='lux_contentspolicypremium' />
                                <attribute name='lux_propertyownersliabilitypolicypremium' />
                                <attribute name='lux_policycedarfee' />
                                <order attribute='lux_inceptiondate' descending='true' />
                                <order attribute='lux_quotenumber' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_quotenumber' operator='eq' value='{appln.Attributes["lux_originalquotenumber"].ToString()}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities.Count > 0)
            {
                var MTAfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersapplications'>
                                                <attribute name='lux_name' />
                                                <attribute name='createdon' />
                                                <attribute name='lux_mtadate' />
                                                <attribute name='lux_propertyownersapplicationsid' />
                                                <attribute name='lux_renewaldate' />
                                                <attribute name='lux_inceptiondate' /> 
                                                <attribute name='lux_policytotalpremium' />                                
                                                <attribute name='lux_insuranceproductrequired' />
                                                <attribute name='lux_policybrokercommissionamount' />
                                                <attribute name='lux_policycedarcommissionamount' />
                                                <attribute name='lux_mtacedarcommissionamount' />
                                                <attribute name='lux_mtabrokercommissionamount' />
                                                <attribute name='lux_mtapremium' />
                                                <attribute name='lux_mtaipt' />
                                                <attribute name='lux_mtapolicyfee' />
                                                <attribute name='lux_mtanetpremium' />
                                                <attribute name='lux_buildingsmtapremium' />
                                                <attribute name='lux_contentsmtapremium' />
                                                <attribute name='lux_propertyownersliabilitymtapremium' />
                                                <attribute name='lux_policybrokercommission' />
                                                <attribute name='lux_policycedarcommission' /> 
                                                <attribute name='lux_buildingspolicypremium' />
                                                <attribute name='lux_contentspolicypremium' />
                                                <attribute name='lux_propertyownersliabilitypolicypremium' />
                                                <attribute name='lux_policycedarfee' />
                                                <order attribute='lux_quotenumber' descending='true' />
                                                <filter type='and'>
                                                    <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{Policy.Get(executionContext).Id}' />
                                                    <condition attribute='lux_applicationtype' operator='eq' value='972970002' />     
                                                    <condition attribute='statuscode' operator='eq' value='972970006' />
                                                 </filter>
                                              </entity>
                                            </fetch>";

                var mainRecord = service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities[0];

                var mainGrossPremium = mainRecord.Attributes.Contains("lux_policytotalpremium") ? mainRecord.GetAttributeValue<Money>("lux_policytotalpremium").Value : 0;
                var mainBrokerComm = mainRecord.Attributes.Contains("lux_policybrokercommissionamount") ? mainRecord.GetAttributeValue<Money>("lux_policybrokercommissionamount").Value : 0;
                var mainGrossComm = mainRecord.Attributes.Contains("lux_policycedarcommissionamount") ? mainRecord.GetAttributeValue<Money>("lux_policycedarcommissionamount").Value : 0;
                var mainBuildingsPremium = mainRecord.Attributes.Contains("lux_buildingspolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_buildingspolicypremium").Value : 0;
                var mainContentsPremium = mainRecord.Attributes.Contains("lux_contentspolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_contentspolicypremium").Value : 0;
                var mainPOLPremium = mainRecord.Attributes.Contains("lux_propertyownersliabilitypolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_propertyownersliabilitypolicypremium").Value : 0;
                var mainPolicyFee = mainRecord.Attributes.Contains("lux_policycedarfee") ? mainRecord.GetAttributeValue<Money>("lux_policycedarfee").Value : 0;

                var mtaGrossPremium = 0M;
                var mtaBrokerComm = 0M;
                var mtaGrossComm = 0M;
                var mtaBuildingsPremium = 0M;
                var mtaContentsPremium = 0M;
                var mtaPOLPremium = 0M;
                var mtaPolicyFee = 0M;


                if (service.RetrieveMultiple(new FetchExpression(MTAfetch)).Entities.Count > 0)
                {
                    var mtaRocords = service.RetrieveMultiple(new FetchExpression(MTAfetch)).Entities;
                    mtaGrossPremium = mtaRocords.Sum(x => x.Contains("lux_mtapremium") ? x.GetAttributeValue<Money>("lux_mtapremium").Value : 0);
                    mtaBrokerComm = mtaRocords.Sum(x => x.Contains("lux_mtabrokercommissionamount") ? x.GetAttributeValue<Money>("lux_mtabrokercommissionamount").Value : 0);
                    mtaGrossComm = mtaRocords.Sum(x => x.Contains("lux_mtacedarcommissionamount") ? x.GetAttributeValue<Money>("lux_mtacedarcommissionamount").Value : 0);
                    mtaBuildingsPremium = mtaRocords.Sum(x => x.Contains("lux_buildingsmtapremium") ? x.GetAttributeValue<Money>("lux_buildingsmtapremium").Value : 0);
                    mtaContentsPremium = mtaRocords.Sum(x => x.Contains("lux_contentsmtapremium") ? x.GetAttributeValue<Money>("lux_contentsmtapremium").Value : 0);
                    mtaPOLPremium = mtaRocords.Sum(x => x.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);
                    mtaPolicyFee = mtaRocords.Sum(x => x.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);
                }

                var PolicyDuration = (appln.GetAttributeValue<DateTime>("lux_renewaldate") - appln.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                var LengthtillNow = (appln.GetAttributeValue<DateTime>("lux_mtadate") - appln.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                var remainingDays = PolicyDuration - LengthtillNow;

                var MTAGrossPremium = (mainGrossPremium + mtaGrossPremium) * remainingDays / PolicyDuration;
                var MTABrokerCommission = (mainBrokerComm + mtaBrokerComm) * remainingDays / PolicyDuration;
                var MTAGrossCommission = (mainGrossComm + mtaGrossComm) * remainingDays / PolicyDuration;
                var MTANetPremium = MTAGrossPremium - MTABrokerCommission - MTAGrossCommission;
                var MTABuildingsPremium = (mainBuildingsPremium + mtaBuildingsPremium) * remainingDays / PolicyDuration;
                var MTAContentsPremium = (mainContentsPremium + mtaContentsPremium) * remainingDays / PolicyDuration;
                var MTAPOLPremium = (mainPOLPremium + mtaPOLPremium) * remainingDays / PolicyDuration;

                appln["lux_mtapremium"] = new Money(-1 * MTAGrossPremium);
                appln["lux_mtabrokercommissionamount"] = new Money(-1 * MTABrokerCommission);
                appln["lux_mtacedarcommissionamount"] = new Money(-1 * MTAGrossCommission);
                appln["lux_mtanetpremium"] = new Money(-1 * MTANetPremium);
                if (appln.Attributes.Contains("lux_postcode") && appln.Attributes["lux_postcode"].ToString().StartsWith("IM"))
                {
                    appln["lux_mtaipt"] = new Money(0);
                }
                else
                {
                    appln["lux_mtaipt"] = new Money(-1 * MTAGrossPremium * 12 / 100);
                }

                appln["lux_buildingsmtapremium"] = new Money(-1 * MTABuildingsPremium);
                appln["lux_contentsmtapremium"] = new Money(-1 * MTAContentsPremium);
                appln["lux_propertyownersliabilitymtapremium"] = new Money(-1 * MTAPOLPremium);

                if (LengthtillNow == 0)
                {
                    appln["lux_mtapolicyfee"] = new Money(-1 * mainPolicyFee);
                }
                else
                {
                    appln["lux_mtapolicyfee"] = new Money(0);
                }

                service.Update(appln);
            }
        }
    }
}