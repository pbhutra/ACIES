﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace CustomWorkflows
{
    public class CreateBDXRecord : CodeActivity
    {
        [Input("Policy")]
        [ReferenceTarget("lux_policy")]
        [RequiredArgument]
        public InArgument<EntityReference> Policy { get; set; }

        [Input("Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        [RequiredArgument]
        public InArgument<EntityReference> Application { get; set; }

        [Input("Tradesman Application")]
        [ReferenceTarget("lux_tradesman")]
        [RequiredArgument]
        public InArgument<EntityReference> TradesmanApplication { get; set; }

        [RequiredArgument]
        [Input("Product")]
        public InArgument<string> Product { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            var ProductName = Product.Get<string>(executionContext).ToString();

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference policyref = Policy.Get<EntityReference>(executionContext);
            Entity policy = service.Retrieve("lux_policy", policyref.Id, new ColumnSet(true));

            if (!ProductName.Contains("Tradesman")) //Tradesman
            {
                EntityReference appref = Application.Get<EntityReference>(executionContext);
                Entity appln = service.Retrieve("lux_propertyownersapplications", appref.Id, new ColumnSet(true));
                bool isIsleofManPolicy = false;
                if (appln.Attributes.Contains("lux_isisleofmanrisk") && appln.GetAttributeValue<bool>("lux_isisleofmanrisk") == true)
                {
                    isIsleofManPolicy = true;
                }

                //Property Owners
                if (ProductName.Contains("Property Owners") || ProductName.Contains("Unoccupied"))
                {
                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_propertyownerspremise'>
                                    <attribute name='lux_subsidencescore' />
                                    <attribute name='lux_securityrating' />
                                    <attribute name='lux_riskpostcode' />
                                    <attribute name='lux_locationnumber' />
                                    <attribute name='lux_propertyownerspremiseid' />
                                    <order attribute='lux_locationnumber' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                    {
                        var firstLocationNumber = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Attributes.Contains("lux_locationnumber") ? service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].GetAttributeValue<int>("lux_locationnumber") : 1;
                        foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                        {
                            var item = service.Retrieve("lux_propertyownerspremise", item1.Id, new ColumnSet(true));
                            var LocationNo = item.Attributes.Contains("lux_locationnumber") ? item.GetAttributeValue<int>("lux_locationnumber") : 1;

                            Entity bdx = new Entity("lux_bordereau");
                            bdx["lux_lloydsriskcode"] = "B5";
                            bdx["lux_application"] = new EntityReference("lux_propertyownersapplications", appref.Id);
                            bdx["lux_policy"] = new EntityReference("lux_policy", policyref.Id);
                            bdx["lux_policynumber"] = policy.Attributes.Contains("lux_policynumber") ? policy.Attributes["lux_policynumber"].ToString() : "";
                            bdx["lux_inceptiondate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_expirydate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                            bdx["lux_customerclassification"] = appln.Attributes.Contains("lux_policyholdertype") ? appln.FormattedValues["lux_policyholdertype"].ToString() : "";

                            var TransactionType = "Original Premium";
                            if (appln.Attributes.Contains("lux_applicationtype") && (appln.FormattedValues["lux_applicationtype"] == "MTA" || appln.FormattedValues["lux_applicationtype"] == "Cancellation"))
                            {
                                bdx["lux_covereffectivedate"] = Convert.ToDateTime(appln.Attributes.Contains("lux_mtadate") == true ? appln.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                                bdx["lux_certificateissuancedate"] = Convert.ToDateTime(policy.Attributes.Contains("modifiedon") == true ? policy.FormattedValues["modifiedon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                                if (appln.Attributes.Contains("lux_mtagrosspremium") && appln.GetAttributeValue<Money>("lux_mtagrosspremium").Value >= 0)
                                {
                                    TransactionType = "Additional Premium";
                                }
                                else if (appln.Attributes.Contains("lux_mtagrosspremium") && appln.GetAttributeValue<Money>("lux_mtagrosspremium").Value < 0)
                                {
                                    TransactionType = "Returned Premium";
                                }
                            }
                            else
                            {
                                bdx["lux_covereffectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                                bdx["lux_certificateissuancedate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            }
                            bdx["lux_locationid"] = LocationNo.ToString();

                            bdx["lux_doesthepremiseshaveabasement"] = item.Attributes.Contains("lux_doesthepremiseshaveabasement") ? item.GetAttributeValue<bool>("lux_doesthepremiseshaveabasement") : false;

                            if (item.Attributes.Contains("lux_covers"))
                            {
                                if (item.GetAttributeValue<OptionSetValueCollection>("lux_covers").Contains(new OptionSetValue(972970011)))
                                {
                                    bdx["lux_floodcover"] = true;
                                }
                                else
                                {
                                    bdx["lux_floodcover"] = false;
                                }
                            }
                            else
                            {
                                bdx["lux_floodcover"] = false;
                            }
                            if (policy.FormattedValues["lux_policytype"] == "Renewal")
                            {
                                bdx["lux_neworrenewal"] = "Renewal";
                            }
                            else
                            {
                                bdx["lux_neworrenewal"] = "New";
                            }
                            bdx["lux_nameofinsured"] = appln.Attributes.Contains("lux_insuredtitle") ? appln.Attributes["lux_insuredtitle"] : "";
                            bdx["lux_insuredaddress"] = (appln.Attributes.Contains("lux_housenumber") ? appln.Attributes["lux_housenumber"] + ", " : "") + (appln.Attributes.Contains("lux_street") ? appln.Attributes["lux_street"] + ", " : "") + (appln.Attributes.Contains("lux_citycounty") ? appln.Attributes["lux_citycounty"] : "");
                            bdx["lux_insuredzipcodepostalcode"] = appln.Attributes.Contains("lux_postcode") == true ? appln.Attributes["lux_postcode"] : "";
                            bdx["lux_insuredcountry"] = "United Kingdom";

                            bdx["lux_locationofriskaddress"] = (item.Attributes.Contains("lux_housenumber") ? item.Attributes["lux_housenumber"] + ", " : "") + (item.Attributes.Contains("lux_riskaddress") ? item.Attributes["lux_riskaddress"] + ", " : "") + (item.Attributes.Contains("lux_citycounty") ? item.Attributes["lux_citycounty"] : "");
                            bdx["lux_locationofriskpostcodezipcodeorsimilar"] = item.Attributes.Contains("lux_riskpostcode") == true ? item.Attributes["lux_riskpostcode"] : "";
                            bdx["lux_locationofriskcountry"] = "United Kingdom";

                            var DeclaredValue = item.Attributes.Contains("lux_declaredvalueforrebuildingthisproperty") == true ? item.GetAttributeValue<Money>("lux_declaredvalueforrebuildingthisproperty").Value : 0;
                            var CommunalContent = item.Attributes.Contains("lux_totalcontentsofcommunalareas") == true ? item.GetAttributeValue<Money>("lux_totalcontentsofcommunalareas").Value : 0;
                            var LandlordContent = item.Attributes.Contains("lux_landlordscontentsinresidentialareas") == true ? item.GetAttributeValue<Money>("lux_landlordscontentsinresidentialareas").Value : 0;
                            var LORPayable = item.Attributes.Contains("lux_lossofannualrentalincome") == true ? item.GetAttributeValue<Money>("lux_lossofannualrentalincome").Value : 0;

                            bdx["lux_mdbuildingdeclaredvalue"] = new Money(DeclaredValue);
                            bdx["lux_mdtenantsimprovementsdeclaredvalue"] = new Money(0);
                            bdx["lux_mdcontentsdeclaredvalue"] = new Money(LandlordContent);
                            bdx["lux_mdcontentsofcommunalarea"] = new Money(CommunalContent);
                            bdx["lux_mdcomputerandelectronicbusinessequipment"] = new Money(0);
                            bdx["lux_mdlossofrentpayable"] = new Money(LORPayable);
                            bdx["lux_mdstockexcludingtargetstock"] = new Money(0);
                            bdx["lux_mdtargetstocksuminsured"] = new Money(0);

                            var TotalInsurableValues = DeclaredValue + CommunalContent + LandlordContent + LORPayable;
                            bdx["lux_totalinsurablevalues"] = new Money(TotalInsurableValues);
                            bdx["lux_mdtotaldeclaredvalue"] = new Money(TotalInsurableValues);

                            bdx["lux_methodofadjustment"] = item.Attributes.Contains("lux_basisofcover") == true ? new OptionSetValue(item.GetAttributeValue<OptionSetValue>("lux_basisofcover").Value) : new OptionSetValue(972970002);
                            bdx["lux_day1uplift"] = item.Attributes.Contains("lux_indexlinkingdayone") == true ? item.FormattedValues["lux_indexlinkingdayone"].ToString() : "";

                            if (item.GetAttributeValue<OptionSetValue>("lux_basisofcover").Value == 972970001)
                            {
                                var indexingValue = item.Attributes.Contains("lux_indexlinkingdayone") ? item.FormattedValues["lux_indexlinkingdayone"].ToString() : "";
                                if (indexingValue != "")
                                {
                                    var indexed = Convert.ToDecimal(indexingValue.Replace("%", ""));
                                    var Amount = DeclaredValue + CommunalContent + LandlordContent;
                                    var upliftedAmount = Amount + Amount * indexed / 100 + LORPayable;
                                    bdx["lux_suminsuredamount"] = new Money(upliftedAmount);
                                }
                            }
                            else
                            {
                                bdx["lux_suminsuredamount"] = new Money(TotalInsurableValues);
                            }

                            bdx["lux_suminsuredcurrency"] = "GBP";
                            bdx["lux_transactiontypeoriginalpremiumetc"] = TransactionType;

                            if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970001)
                            {
                                bdx["lux_occupancytype"] = "Commercial";
                                bdx["lux_propertytype"] = item.FormattedValues["lux_commericalpropertytype"].ToString();
                                bdx["lux_occupancydescription"] = item.Attributes.Contains("lux_commercialtrades") ? item.Attributes["lux_commercialtrades"].ToString() : "";
                            }
                            else if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970002)
                            {
                                bdx["lux_occupancytype"] = "Let";

                                var propertyType = item.Attributes.Contains("lux_residentialpropertytype") ? item.GetAttributeValue<OptionSetValue>("lux_residentialpropertytype").Value : 0;

                                if (propertyType == 972970001 || propertyType == 972970002 || propertyType == 972970003)
                                    bdx["lux_propertytype"] = "Flat";
                                else if (propertyType == 972970005)
                                    bdx["lux_propertytype"] = "Detached";
                                else if (propertyType == 972970006)
                                    bdx["lux_propertytype"] = "Semi Detached";
                                else if (propertyType == 972970007)
                                    bdx["lux_propertytype"] = "Terraced";
                                else if (propertyType == 972970008)
                                    bdx["lux_propertytype"] = "Flat";
                                else if (propertyType == 972970010)
                                    bdx["lux_propertytype"] = "Flat";
                                else if (propertyType == 972970011)
                                    bdx["lux_propertytype"] = "House";

                                var OccDesc = "";

                                if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970007) //Asylum Seeker
                                {
                                    OccDesc = "Asylum Seeker let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970012) // Charity Let
                                {
                                    OccDesc = "";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970011) // Company Let
                                {
                                    OccDesc = "Professional Let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970009) // Holiday Let
                                {
                                    OccDesc = "Overseas Holiday Let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970008) // HMO
                                {
                                    OccDesc = "HMO";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970005) // Lease Hold
                                {
                                    OccDesc = "Professional Let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970004) // Local Authority
                                {
                                    OccDesc = "DSS Let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970001) // Private Rental
                                {
                                    OccDesc = "Professional Let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970002) // Professional
                                {
                                    OccDesc = "Professional Let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970010) // Seviced Apartments
                                {
                                    OccDesc = "UK Holiday Home Let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970003) // Students
                                {
                                    OccDesc = "Student Let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970006) // Unoccupied
                                {
                                    OccDesc = "Unoccupied";
                                }

                                var HMO = item.Contains("lux_isthepremisesahouseofmultipleoccupation") ? item.GetAttributeValue<bool>("lux_isthepremisesahouseofmultipleoccupation") : false;
                                if (HMO == true)
                                {
                                    if (OccDesc != "")
                                    {
                                        OccDesc += ", HMO";
                                    }
                                    else
                                    {
                                        OccDesc = "HMO";
                                    }
                                }
                                bdx["lux_occupancydescription"] = OccDesc;
                            }
                            else if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970003)
                            {
                                bdx["lux_occupancytype"] = "Unoccupied";
                                bdx["lux_occupancydescription"] = "Unoccupied";
                            }
                            else if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970004)
                            {
                                bdx["lux_occupancytype"] = "Commercial";
                                bdx["lux_propertytype"] = item.FormattedValues["lux_commericalpropertytype"].ToString();

                                if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970007) //Asylum Seeker
                                {
                                    bdx["lux_occupancydescription"] = "Asylum Seeker let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970012) // Charity Let
                                {
                                    bdx["lux_occupancydescription"] = "";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970011) // Company Let
                                {
                                    bdx["lux_occupancydescription"] = "Professional Let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970009) // Holiday Let
                                {
                                    bdx["lux_occupancydescription"] = "Overseas Holiday Let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970008) // HMO
                                {
                                    bdx["lux_occupancydescription"] = "HMO";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970005) // Lease Hold
                                {
                                    bdx["lux_occupancydescription"] = "Professional Let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970004) // Local Authority
                                {
                                    bdx["lux_occupancydescription"] = "DSS Let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970001) // Private Rental
                                {
                                    bdx["lux_occupancydescription"] = "Professional Let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970002) // Professional
                                {
                                    bdx["lux_occupancydescription"] = "Professional Let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970010) // Seviced Apartments
                                {
                                    bdx["lux_occupancydescription"] = "UK Holiday Home Let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970003) // Students
                                {
                                    bdx["lux_occupancydescription"] = "Student Let";
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970006) // Unoccupied
                                {
                                    bdx["lux_occupancydescription"] = "Unoccupied";
                                }
                            }

                            if (appln.GetAttributeValue<OptionSetValue>("lux_rpocpoproducttype").Value == 972970001)
                            {
                                bdx["lux_occupancycategory"] = "Residential";
                            }
                            else if (appln.GetAttributeValue<OptionSetValue>("lux_rpocpoproducttype").Value == 972970002)
                            {
                                bdx["lux_occupancycategory"] = "Commercial";
                            }

                            if (item.GetAttributeValue<OptionSetValue>("lux_buildingconstruction").Value == 972970001)
                            {
                                bdx["lux_roofconstructiontype1"] = "Standard";
                                bdx["lux_wallconstructiontype1"] = "Standard";

                                bdx["lux_roofconstructiontype2"] = "Standard";
                                bdx["lux_wallconstructiontype2"] = "Standard";
                            }
                            else
                            {
                                bdx["lux_roofconstructiontype1"] = "Non Standard";
                                bdx["lux_wallconstructiontype1"] = "Non Standard";


                                //var wallmaterial = item.FormattedValues["lux_wallmaterials"].ToString().Replace("Glass", "Other").Replace("Slate", "Other").Replace("Tile", "Other");
                                //var roofmaterial = item.FormattedValues["lux_roofmaterials"].ToString().Replace("Flat roof", "Felt on Timber").Replace("Thatched", "Thatch - Fibre");

                                //if (wallmaterial.Contains("Other"))
                                //{
                                //    wallmaterial = wallmaterial.Replace("; Other", "") + "; Other";
                                //}
                                //if (roofmaterial.Contains("Felt on Timber"))
                                //{
                                //    roofmaterial = roofmaterial.Replace("; Felt on Timber", "") + "; Felt on Timber";
                                //}
                                //if (roofmaterial.Contains("Other"))
                                //{
                                //    roofmaterial = roofmaterial.Replace("; Other", "") + "; Other";
                                //}


                                var wallmaterial = item.Attributes.Contains("lux_wallmaterials") ? item.FormattedValues["lux_wallmaterials"].ToString() : "";
                                var roofmaterial = item.Attributes.Contains("lux_roofmaterials") ? item.FormattedValues["lux_roofmaterials"].ToString() : "";

                                if (wallmaterial.Contains("Other"))
                                {
                                    if (item.Attributes.Contains("lux_pleasespecifywallmaterial"))
                                    {
                                        wallmaterial = wallmaterial.Replace("; Other", "; " + item.Attributes["lux_pleasespecifywallmaterial"].ToString());
                                    }
                                }
                                if (wallmaterial.Contains("Composite Panels"))
                                {
                                    if (item.Attributes.Contains("lux_wallmaterialtype"))
                                    {
                                        wallmaterial = wallmaterial.Replace("; Composite Panels", "; Composite Panels ; " + item.FormattedValues["lux_wallmaterialtype"].ToString());
                                    }
                                }

                                if (roofmaterial.Contains("Other"))
                                {
                                    if (item.Attributes.Contains("lux_pleasespecifyroofmaterial"))
                                    {
                                        roofmaterial = roofmaterial.Replace("; Other", "; " + item.Attributes["lux_pleasespecifyroofmaterial"].ToString());
                                    }
                                }
                                if (roofmaterial.Contains("Composite Panels"))
                                {
                                    if (item.Attributes.Contains("lux_roofmaterialtype"))
                                    {
                                        roofmaterial = roofmaterial.Replace("; Composite Panels", "; Composite Panels ; " + item.FormattedValues["lux_roofmaterialtype"].ToString());
                                    }
                                }

                                IEnumerable<string> WallallWords = wallmaterial.Replace(";", ",").Split(',');
                                IEnumerable<string> WalluniqueWords = WallallWords.GroupBy(w => w).Where(g => g.Count() == 1).Select(g => g.Key.Trim());
                                var finalwallmaterial = "";
                                foreach (var item2 in WalluniqueWords)
                                {
                                    if (finalwallmaterial == "")
                                    {
                                        finalwallmaterial += item2;
                                    }
                                    else
                                    {
                                        if (!finalwallmaterial.Contains(item2))
                                        {
                                            finalwallmaterial += ", " + item2;
                                        }
                                    }
                                }

                                IEnumerable<string> RoofallWords = roofmaterial.Replace(";", ",").Split(',');
                                IEnumerable<string> RoofuniqueWords = RoofallWords.GroupBy(w => w).Where(g => g.Count() == 1).Select(g => g.Key.Trim());
                                var finalroofmaterial = "";
                                foreach (var item2 in RoofuniqueWords)
                                {
                                    if (finalroofmaterial == "")
                                    {
                                        finalroofmaterial += item2;
                                    }
                                    else
                                    {
                                        if (!finalroofmaterial.Contains(item2))
                                        {
                                            finalroofmaterial += ", " + item2;
                                        }
                                    }
                                }

                                bdx["lux_wallconstructiontype2"] = finalwallmaterial;
                                bdx["lux_roofconstructiontype2"] = finalroofmaterial;
                            }

                            if (LocationNo == firstLocationNumber)
                            {
                                if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "MTA")
                                {
                                    var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_propertyownersapplications'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_postcode' />
                                                        <attribute name='lux_insuredtitle' />
                                                        <attribute name='lux_quotenumber' />
                                                        <attribute name='statuscode' />
                                                        <attribute name='lux_inceptiondate' />
                                                        <attribute name='lux_broker' />
                                                        <attribute name='lux_quotedpremium' />
                                                        <attribute name='lux_policytotalcommission' />
                                                        <attribute name='lux_mtabrokercommissionpercentage' />
                                                        <attribute name='lux_lepolicygrosspremium' />
                                                        <attribute name='lux_legalexpensesmtapremium' />
                                                        <attribute name='lux_quotedpremiumbrokercommissionamount' />
                                                        <attribute name='lux_quotedpremiumaciescommissionamount' />
                                                        <attribute name='lux_mtabrokercommission' />
                                                        <attribute name='lux_mtaaciescommission' />
                                                        <attribute name='lux_mtagrosspremium' />
                                                        <attribute name='lux_totalquotedpremiuminciptandfee' />
                                                        <attribute name='lux_mtatotalpremiumincipt' />
                                                        <attribute name='lux_policyfee' /> 
                                                        <attribute name='lux_mtapolicyfee' />
                                                        <attribute name='lux_policynetpremium' />
                                                        <attribute name='lux_mtanetpremium' />
                                                        <attribute name='lux_lepolicynetpremium' />
                                                        <attribute name='lux_legalexpensesmtanetpremium' />
                                                        <attribute name='lux_quotedpremiumipt' />
                                                        <attribute name='lux_mtaipt' />
                                                        <attribute name='lux_employersliabilitypolicypremium' />
                                                        <attribute name='lux_employersliabilitymtapremium' />
                                                        <attribute name='lux_propertyownersliabilitypolicypremium' />
                                                        <attribute name='lux_propertyownersliabilitymtapremium' />
                                                        <attribute name='lux_publicproductsliabilitypolicypremium' />
                                                        <attribute name='lux_publicproductsliabilitymtapremium' />
                                                        <attribute name='lux_producttype' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='lux_propertyownersapplicationsid' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970006' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                                    var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001 || x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003);
                                    var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);

                                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                                    bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));
                                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));
                                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));

                                    var BrokerCommission = appln.Attributes["lux_mtabrokercommissionpercentage"];

                                    var LEMainPolicyPremium = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicygrosspremium") ? x.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value : 0);
                                    var LEMTAPolicyPremium = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);

                                    var LEPolicyPremium = LEMainPolicyPremium + LEMTAPolicyPremium;
                                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                                    var MainBrokerCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumbrokercommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value : 0);
                                    var MainACIESCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumaciescommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumaciescommissionamount").Value : 0);

                                    var MTABrokerCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                                    var MTAACIESCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                                    var CommAmount = MainBrokerCommAmt + MainACIESCommAmt + MTABrokerCommAmt + MTAACIESCommAmt - LEBrokerCommAmt;

                                    bdx["lux_commissionamount"] = new Money(CommAmount);
                                    bdx["lux_localsubproducerscommissionamount"] = new Money(MainBrokerCommAmt + MTABrokerCommAmt - LEBrokerCommAmt);

                                    var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremium") ? x.GetAttributeValue<Money>("lux_quotedpremium").Value : 0);
                                    var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);

                                    bdx["lux_totalgrosswrittenpremium"] = new Money(MainGWPAmt + MTAGWPAmt - LEPolicyPremium);

                                    var MainGrossAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_totalquotedpremiuminciptandfee") ? x.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value : 0);
                                    var MTAGrossAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);

                                    var PolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_policyfee") ? x.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                                    var MTAPolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_grosspremium"] = new Money(MainGrossAmt + MTAGrossAmt - PolicyFee - MTAPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_grosspremium"] = new Money(MainGrossAmt + MTAGrossAmt - PolicyFee - MTAPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100);
                                    }

                                    var MainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policynetpremium") ? x.GetAttributeValue<Money>("lux_policynetpremium").Value : 0);
                                    var MTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);

                                    var LEMainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicynetpremium") ? x.GetAttributeValue<Money>("lux_lepolicynetpremium").Value : 0);
                                    var LEMTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);

                                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = new Money(MainNetAmt + MTANetAmt - LEMainNetAmt - LEMTANetAmt);
                                    bdx["lux_finalnetpremiumoriginalcurrency"] = new Money(MainNetAmt + MTANetAmt - LEMainNetAmt - LEMTANetAmt);

                                    bdx["lux_brokerageamountoriginalcurrency"] = new Money(MainBrokerCommAmt + MTABrokerCommAmt - LEBrokerCommAmt);

                                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                                    bdx["lux_otherfeesordeductionsamount"] = new Money(PolicyFee + MTAPolicyFee);

                                    var MainIPTAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumipt") ? x.GetAttributeValue<Money>("lux_quotedpremiumipt").Value : 0);
                                    var MTAIPTAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);

                                    bdx["lux_tax1taxtype"] = "IPT";
                                    bdx["lux_tax1amountoftaxablepremium"] = new Money(MainGWPAmt + MTAGWPAmt - LEPolicyPremium);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_tax1amount"] = new Money((MainGWPAmt + MTAGWPAmt - LEPolicyPremium) * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_tax1amount"] = new Money((MainGWPAmt + MTAGWPAmt - LEPolicyPremium) * 0 / 100);
                                    }

                                    var MainELAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0);
                                    var MTAELAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);
                                    bdx["lux_elpremium"] = new Money(MainELAmt + MTAELAmt);

                                    var MainPOLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitypolicypremium").Value : 0);
                                    var MTAPOLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);
                                    bdx["lux_propertyownersliabilitypremium"] = new Money(MainPOLAmt + MTAPOLAmt);

                                    var MainPLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0);
                                    var MTAPLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);
                                    bdx["lux_plpremium"] = new Money(MainPLAmt + MTAPLAmt);
                                }
                                else if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "Cancellation")
                                {
                                    var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_propertyownersapplications'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_postcode' />
                                                        <attribute name='lux_insuredtitle' />
                                                        <attribute name='lux_quotenumber' />
                                                        <attribute name='statuscode' />
                                                        <attribute name='lux_inceptiondate' />
                                                        <attribute name='lux_broker' />
                                                        <attribute name='lux_quotedpremium' />
                                                        <attribute name='lux_policytotalcommission' />
                                                        <attribute name='lux_mtabrokercommissionpercentage' />
                                                        <attribute name='lux_lepolicygrosspremium' />
                                                        <attribute name='lux_legalexpensesmtapremium' />
                                                        <attribute name='lux_quotedpremiumbrokercommissionamount' />
                                                        <attribute name='lux_quotedpremiumaciescommissionamount' />
                                                        <attribute name='lux_mtabrokercommission' />
                                                        <attribute name='lux_mtaaciescommission' />
                                                        <attribute name='lux_mtagrosspremium' />
                                                        <attribute name='lux_totalquotedpremiuminciptandfee' />
                                                        <attribute name='lux_mtatotalpremiumincipt' />
                                                        <attribute name='lux_policyfee' /> 
                                                        <attribute name='lux_mtapolicyfee' />
                                                        <attribute name='lux_policynetpremium' />
                                                        <attribute name='lux_mtanetpremium' />
                                                        <attribute name='lux_lepolicynetpremium' />
                                                        <attribute name='lux_legalexpensesmtanetpremium' />
                                                        <attribute name='lux_quotedpremiumipt' />
                                                        <attribute name='lux_mtaipt' />
                                                        <attribute name='lux_employersliabilitypolicypremium' />
                                                        <attribute name='lux_employersliabilitymtapremium' />
                                                        <attribute name='lux_propertyownersliabilitypolicypremium' />
                                                        <attribute name='lux_propertyownersliabilitymtapremium' />
                                                        <attribute name='lux_publicproductsliabilitypolicypremium' />
                                                        <attribute name='lux_publicproductsliabilitymtapremium' />
                                                        <attribute name='lux_producttype' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='lux_propertyownersapplicationsid' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970009' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                                    var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001 || x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003);
                                    var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);
                                    var cancellationRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970004);

                                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                                    bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));
                                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));
                                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));

                                    var BrokerCommission = appln.Attributes["lux_mtabrokercommissionpercentage"];


                                    var LEMainPolicyPremium = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicygrosspremium") ? x.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value : 0);
                                    var LEMTAPolicyPremium = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);
                                    var LECancelPolicyPremium = cancellationRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);

                                    var LEPolicyPremium = LEMainPolicyPremium + LEMTAPolicyPremium + LECancelPolicyPremium;
                                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                                    var MainBrokerCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumbrokercommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value : 0);
                                    var MainACIESCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumaciescommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumaciescommissionamount").Value : 0);

                                    var MTABrokerCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                                    var MTAACIESCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                                    var CancelBrokerCommAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                                    var CancelACIESCommAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                                    var CommAmount = MainBrokerCommAmt + MainACIESCommAmt + MTABrokerCommAmt + MTAACIESCommAmt + CancelBrokerCommAmt + CancelACIESCommAmt - LEBrokerCommAmt;

                                    bdx["lux_commissionamount"] = (CommAmount <= 0.02M && CommAmount >= -0.02M) ? new Money(0) : new Money(CommAmount);
                                    bdx["lux_localsubproducerscommissionamount"] = (MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt <= 0.02M && MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt >= -0.02M) ? new Money(0) : new Money(MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt);

                                    var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremium") ? x.GetAttributeValue<Money>("lux_quotedpremium").Value : 0);
                                    var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);
                                    var CancelGWPAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);

                                    bdx["lux_totalgrosswrittenpremium"] = (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium <= 0.02M && MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium >= -0.02M) ? new Money(0) : new Money(MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium);


                                    var MainGrossAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_totalquotedpremiuminciptandfee") ? x.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value : 0);
                                    var MTAGrossAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);
                                    var CancelGrossAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);

                                    var PolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_policyfee") ? x.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                                    var MTAPolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);
                                    var CancelPolicyFee = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_grosspremium"] = (MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100 <= 0.02M && MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100 >= -0.02M) ? new Money(0) : new Money(MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_grosspremium"] = (MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100 <= 0.02M && MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100 >= -0.02M) ? new Money(0) : new Money(MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100);
                                    }

                                    var MainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policynetpremium") ? x.GetAttributeValue<Money>("lux_policynetpremium").Value : 0);
                                    var MTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);
                                    var CancelNetAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);

                                    var LEMainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicynetpremium") ? x.GetAttributeValue<Money>("lux_lepolicynetpremium").Value : 0);
                                    var LEMTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);
                                    var LECancelNetAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);

                                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = (MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt <= 0.02M && MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt >= -0.02M) ? new Money(0) : new Money(MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt);
                                    bdx["lux_finalnetpremiumoriginalcurrency"] = (MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt <= 0.02M && MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt >= -0.02M) ? new Money(0) : new Money(MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt);

                                    bdx["lux_brokerageamountoriginalcurrency"] = (MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt <= 0.02M && MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt >= -0.02M) ? new Money(0) : new Money(MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt);

                                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                                    bdx["lux_otherfeesordeductionsamount"] = (PolicyFee + MTAPolicyFee + CancelPolicyFee <= 0.02M && PolicyFee + MTAPolicyFee + CancelPolicyFee >= -0.02M) ? new Money(0) : new Money(PolicyFee + MTAPolicyFee + CancelPolicyFee);

                                    var MainIPTAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumipt") ? x.GetAttributeValue<Money>("lux_quotedpremiumipt").Value : 0);
                                    var MTAIPTAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);
                                    var CancelIPTAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);

                                    bdx["lux_tax1taxtype"] = "IPT";
                                    bdx["lux_tax1amountoftaxablepremium"] = (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium <= 0.02M && MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium >= -0.02M) ? new Money(0) : new Money(MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_tax1amount"] = ((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100 <= 0.02M && (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100 >= -0.02M) ? new Money(0) : new Money((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_tax1amount"] = ((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100 <= 0.02M && (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100 >= -0.02M) ? new Money(0) : new Money((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100);
                                    }

                                    var MainELAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0);
                                    var MTAELAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);
                                    var CancelELAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);

                                    bdx["lux_elpremium"] = (MainELAmt + MTAELAmt + CancelELAmt <= 0.02M && MainELAmt + MTAELAmt + CancelELAmt >= -0.02M) ? new Money(0) : new Money(MainELAmt + MTAELAmt + CancelELAmt);

                                    var MainPOLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitypolicypremium").Value : 0);
                                    var MTAPOLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);
                                    var CancelPOLAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);

                                    bdx["lux_propertyownersliabilitypremium"] = (MainPOLAmt + MTAPOLAmt + CancelPOLAmt <= 0.02M && MainPOLAmt + MTAPOLAmt + CancelPOLAmt >= -0.02M) ? new Money(0) : new Money(MainPOLAmt + MTAPOLAmt + CancelPOLAmt);

                                    var MainPLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0);
                                    var MTAPLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);
                                    var CancelPLAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);

                                    bdx["lux_plpremium"] = (MainPLAmt + MTAPLAmt + CancelPLAmt <= 0.02M && MainPLAmt + MTAPLAmt + CancelPLAmt >= -0.02M) ? new Money(0) : new Money(MainPLAmt + MTAPLAmt + CancelPLAmt);

                                    var MainCWAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_contractorspolicypremium") ? x.GetAttributeValue<Money>("lux_contractorspolicypremium").Value : 0);
                                    var MTACWAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);
                                    var CancelCWAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);

                                    bdx["lux_cwpremium"] = (MainCWAmt + MTACWAmt + CancelCWAmt <= 0.02M && MainCWAmt + MTACWAmt + CancelCWAmt >= -0.02M) ? new Money(0) : new Money(MainCWAmt + MTACWAmt + CancelCWAmt);

                                    var MainMDAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_materialdamagepolicypremium") ? x.GetAttributeValue<Money>("lux_materialdamagepolicypremium").Value : 0);
                                    var MTAMDAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_materialdamagemtapremium") ? x.GetAttributeValue<Money>("lux_materialdamagemtapremium").Value : 0);
                                    var CancelMDAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_materialdamagemtapremium") ? x.GetAttributeValue<Money>("lux_materialdamagemtapremium").Value : 0);

                                    bdx["lux_propertymdpremium"] = (MainMDAmt + MTAMDAmt + CancelMDAmt <= 0.02M && MainMDAmt + MTAMDAmt + CancelMDAmt >= -0.02M) ? new Money(0) : new Money(MainMDAmt + MTAMDAmt + CancelMDAmt);

                                    var MainBIAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionpolicypremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionpolicypremium").Value : 0);
                                    var MTABIAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionmtapremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionmtapremium").Value : 0);
                                    var CancelBIAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionmtapremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionmtapremium").Value : 0);

                                    bdx["lux_bipremium"] = (MainBIAmt + MTABIAmt + CancelBIAmt <= 0.02M && MainBIAmt + MTABIAmt + CancelBIAmt >= -0.02M) ? new Money(0) : new Money(MainBIAmt + MTABIAmt + CancelBIAmt);

                                    bdx["lux_reasonforcancellation"] = appln.Attributes.Contains("lux_reasonforcancellation") ? appln.FormattedValues["lux_reasonforcancellation"].ToString() : "";
                                }
                                //else if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "Cancellation")
                                //{
                                //    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                                //    bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));
                                //    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));
                                //    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));

                                //    var BrokerCommission = appln.Attributes["lux_mtabrokercommissionpercentage"];

                                //    var LEPolicyPremium = appln.Attributes.Contains("lux_legalexpensesmtapremium") ? appln.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0;

                                //    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                                //    var MTABrokerCommAmt = appln.Attributes.Contains("lux_mtabrokercommission") ? appln.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0;
                                //    var MTAACIESCommAmt = appln.Attributes.Contains("lux_mtaaciescommission") ? appln.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0;

                                //    var CommAmount = MTABrokerCommAmt + MTAACIESCommAmt - LEBrokerCommAmt;

                                //    bdx["lux_commissionamount"] = new Money(CommAmount);
                                //    bdx["lux_localsubproducerscommissionamount"] = new Money(MTABrokerCommAmt - LEBrokerCommAmt);

                                //    var MTAGWPAmt = appln.Attributes.Contains("lux_mtagrosspremium") ? appln.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0;

                                //    bdx["lux_totalgrosswrittenpremium"] = new Money(MTAGWPAmt - LEPolicyPremium);

                                //    var MTAGrossAmt = appln.Attributes.Contains("lux_mtatotalpremiumincipt") ? appln.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0;

                                //    var MTAPolicyFee = appln.Attributes.Contains("lux_mtapolicyfee") ? appln.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0;

                                //    if (isIsleofManPolicy == false)
                                //    {
                                //        bdx["lux_grosspremium"] = new Money(MTAGrossAmt - MTAPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100);
                                //    }
                                //    else
                                //    {
                                //        bdx["lux_grosspremium"] = new Money(MTAGrossAmt - MTAPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100);
                                //    }

                                //    var MTANetAmt = appln.Attributes.Contains("lux_mtanetpremium") ? appln.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0;
                                //    var LEMTANetAmt = appln.Attributes.Contains("lux_legalexpensesmtanetpremium") ? appln.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0;

                                //    bdx["lux_netpremiumtolondoninoriginalcurrency"] = new Money(MTANetAmt - LEMTANetAmt);
                                //    bdx["lux_finalnetpremiumoriginalcurrency"] = new Money(MTANetAmt - LEMTANetAmt);

                                //    bdx["lux_brokerageamountoriginalcurrency"] = new Money(MTABrokerCommAmt - LEBrokerCommAmt);

                                //    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                                //    bdx["lux_otherfeesordeductionsamount"] = new Money(MTAPolicyFee);

                                //    var MTAIPTAmt = appln.Attributes.Contains("lux_mtaipt") ? appln.GetAttributeValue<Money>("lux_mtaipt").Value : 0;

                                //    bdx["lux_tax1taxtype"] = "IPT";
                                //    bdx["lux_tax1amountoftaxablepremium"] = new Money(MTAGWPAmt - LEPolicyPremium);

                                //    if (isIsleofManPolicy == false)
                                //    {
                                //        bdx["lux_tax1amount"] = new Money((MTAGWPAmt - LEPolicyPremium) * 12 / 100);
                                //    }
                                //    else
                                //    {
                                //        bdx["lux_tax1amount"] = new Money((MTAGWPAmt - LEPolicyPremium) * 0 / 100);
                                //    }

                                //    var MTAELAmt = appln.Attributes.Contains("lux_employersliabilitymtapremium") ? appln.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0;
                                //    bdx["lux_elpremium"] = new Money(MTAELAmt);

                                //    var MTAPOLAmt = appln.Attributes.Contains("lux_propertyownersliabilitymtapremium") ? appln.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0;
                                //    bdx["lux_propertyownersliabilitypremium"] = new Money(MTAPOLAmt);

                                //    var MTAPLAmt = appln.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? appln.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0;
                                //    bdx["lux_plpremium"] = new Money(MTAPLAmt);
                                //    bdx["lux_reasonforcancellation"] = appln.Attributes.Contains("lux_reasonforcancellation") ? appln.FormattedValues["lux_reasonforcancellation"].ToString() : "";
                                //}
                                else
                                {
                                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                                    bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));

                                    var BrokerCommission = appln.Attributes["lux_policybrokercommission"];
                                    var LEPolicyPremium = appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value;
                                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                                    bdx["lux_commissionamount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumtotalcommissionamount").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosscommission").Value - LEBrokerCommAmt);

                                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_policybrokercommission"].ToString().Replace("%", ""));
                                    bdx["lux_localsubproducerscommissionamount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value - LEBrokerCommAmt);

                                    bdx["lux_totalgrosswrittenpremium"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value);
                                    var PolicyFee = appln.GetAttributeValue<Money>("lux_policyfee").Value;

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_grosspremium"] = new Money(appln.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value - PolicyFee - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_grosspremium"] = new Money(appln.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value - PolicyFee - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 0 / 100);
                                    }

                                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_policynetpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicynetpremium").Value);
                                    bdx["lux_finalnetpremiumoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_policynetpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicynetpremium").Value);

                                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_policybrokercommission"].ToString().Replace("%", ""));
                                    bdx["lux_brokerageamountoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value - LEBrokerCommAmt);

                                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                                    bdx["lux_otherfeesordeductionsamount"] = new Money(appln.GetAttributeValue<Money>("lux_policyfee").Value);

                                    bdx["lux_tax1taxtype"] = "IPT";
                                    bdx["lux_tax1amountoftaxablepremium"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_tax1amount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumipt").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_tax1amount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumipt").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 0 / 100);
                                    }
                                }

                                bdx["lux_biincreasedcostofworking"] = new Money(0);
                                bdx["lux_biadditionalincreasedcostofworking"] = new Money(0);
                                bdx["lux_bibookdebts"] = new Money(0);
                                bdx["lux_birentreceivable"] = new Money(0);
                                bdx["lux_bilossoflicence"] = new Money(0);
                                bdx["lux_bisuminsured"] = new Money(0);
                                bdx["lux_bicoverbasissuminsured"] = new Money(0);
                            }
                            service.Create(bdx);
                        }
                    }
                }
                else if (ProductName.Contains("Retail")) //Retail
                {
                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_propertyownersretail'>
                                    <attribute name='lux_propertyownersretailid' />
                                    <attribute name='lux_name' />
                                    <attribute name='lux_riskpostcode' />                                
                                    <attribute name='lux_locationnumber' />
                                    <attribute name='createdon' />
                                    <order attribute='lux_locationnumber' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                    {
                        var firstLocationNumber = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Attributes.Contains("lux_locationnumber") ? service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].GetAttributeValue<int>("lux_locationnumber") : 1;
                        foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                        {
                            var item = service.Retrieve("lux_propertyownersretail", item1.Id, new ColumnSet(true));
                            var LocationNo = item.Attributes.Contains("lux_locationnumber") ? item.GetAttributeValue<int>("lux_locationnumber") : 1;

                            Entity bdx = new Entity("lux_bordereau");
                            bdx["lux_lloydsriskcode"] = "B5";
                            bdx["lux_application"] = new EntityReference("lux_propertyownersapplications", appref.Id);
                            bdx["lux_policy"] = new EntityReference("lux_policy", policyref.Id);
                            bdx["lux_policynumber"] = policy.Attributes.Contains("lux_policynumber") ? policy.Attributes["lux_policynumber"].ToString() : "";
                            bdx["lux_inceptiondate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_expirydate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_customerclassification"] = appln.Attributes.Contains("lux_policyholdertype") ? appln.FormattedValues["lux_policyholdertype"].ToString() : "";
                            var TransactionType = "Original Premium";
                            if (appln.Attributes.Contains("lux_applicationtype") && (appln.FormattedValues["lux_applicationtype"] == "MTA" || appln.FormattedValues["lux_applicationtype"] == "Cancellation"))
                            {
                                bdx["lux_covereffectivedate"] = Convert.ToDateTime(appln.Attributes.Contains("lux_mtadate") == true ? appln.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                                bdx["lux_certificateissuancedate"] = Convert.ToDateTime(policy.Attributes.Contains("modifiedon") == true ? policy.FormattedValues["modifiedon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                                if (appln.Attributes.Contains("lux_mtagrosspremium") && appln.GetAttributeValue<Money>("lux_mtagrosspremium").Value >= 0)
                                {
                                    TransactionType = "Additional Premium";
                                }
                                else if (appln.Attributes.Contains("lux_mtagrosspremium") && appln.GetAttributeValue<Money>("lux_mtagrosspremium").Value < 0)
                                {
                                    TransactionType = "Returned Premium";
                                }
                            }
                            else
                            {
                                bdx["lux_covereffectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                                bdx["lux_certificateissuancedate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            }
                            bdx["lux_locationid"] = LocationNo.ToString();
                            if (item.Attributes.Contains("lux_materialdamagecoverdetails"))
                            {
                                if (item.GetAttributeValue<OptionSetValueCollection>("lux_materialdamagecoverdetails").Contains(new OptionSetValue(972970011)))
                                {
                                    bdx["lux_floodcover"] = true;
                                }
                                else
                                {
                                    bdx["lux_floodcover"] = false;
                                }
                            }
                            else
                            {
                                bdx["lux_floodcover"] = false;
                            }
                            if (policy.FormattedValues["lux_policytype"] == "Renewal")
                            {
                                bdx["lux_neworrenewal"] = "Renewal";
                            }
                            else
                            {
                                bdx["lux_neworrenewal"] = "New";
                            }
                            bdx["lux_nameofinsured"] = appln.Attributes.Contains("lux_insuredtitle") ? appln.Attributes["lux_insuredtitle"] : "";
                            bdx["lux_insuredaddress"] = (appln.Attributes.Contains("lux_housenumber") ? appln.Attributes["lux_housenumber"] + ", " : "") + (appln.Attributes.Contains("lux_street") ? appln.Attributes["lux_street"] + ", " : "") + (appln.Attributes.Contains("lux_citycounty") ? appln.Attributes["lux_citycounty"] : "");
                            bdx["lux_insuredzipcodepostalcode"] = appln.Attributes.Contains("lux_postcode") == true ? appln.Attributes["lux_postcode"] : "";
                            bdx["lux_insuredcountry"] = "United Kingdom";

                            bdx["lux_locationofriskaddress"] = (item.Attributes.Contains("lux_housenumber") ? item.Attributes["lux_housenumber"] + ", " : "") + (item.Attributes.Contains("lux_riskaddress") ? item.Attributes["lux_riskaddress"] + ", " : "") + (item.Attributes.Contains("lux_citycounty") ? item.Attributes["lux_citycounty"] : "");
                            bdx["lux_locationofriskpostcodezipcodeorsimilar"] = item.Attributes.Contains("lux_riskpostcode") == true ? item.Attributes["lux_riskpostcode"] : "";
                            bdx["lux_locationofriskcountry"] = "United Kingdom";

                            bdx["lux_suminsuredcurrency"] = "GBP";
                            bdx["lux_transactiontypeoriginalpremiumetc"] = TransactionType;

                            bdx["lux_methodofadjustment"] = item.GetAttributeValue<bool>("lux_isdayoneupliftcoverrequired") == true ? new OptionSetValue(972970001) : new OptionSetValue(972970002);
                            bdx["lux_day1uplift"] = item.Attributes.Contains("lux_dayoneupliftcover") == true ? item.FormattedValues["lux_dayoneupliftcover"].ToString() : "";
                            bdx["lux_mdcontentsofcommunalarea"] = new Money(0);

                            var Buildings = item.Attributes.Contains("lux_buildingsdeclaredvalue") == true ? item.GetAttributeValue<Money>("lux_buildingsdeclaredvalue").Value : 0;
                            bdx["lux_mdbuildingdeclaredvalue"] = new Money(Buildings);
                            var Contents = item.Attributes.Contains("lux_generalcontentsdeclaredvalueincludingmach") == true ? item.GetAttributeValue<Money>("lux_generalcontentsdeclaredvalueincludingmach").Value : 0;
                            bdx["lux_mdcontentsdeclaredvalue"] = new Money(Contents);
                            var Tenents = item.Attributes.Contains("lux_tenantsimprovementsdeclaredvalue") == true ? item.GetAttributeValue<Money>("lux_tenantsimprovementsdeclaredvalue").Value : 0;
                            bdx["lux_mdtenantsimprovementsdeclaredvalue"] = new Money(Tenents);
                            var ComputerEquipment = item.Attributes.Contains("lux_computerandelectronicbusinessequipment") == true ? item.GetAttributeValue<Money>("lux_computerandelectronicbusinessequipment").Value : 0;
                            bdx["lux_mdcomputerandelectronicbusinessequipment"] = new Money(ComputerEquipment);
                            var LossofRent = item.Attributes.Contains("lux_materialdamagelossofrentpayable") == true ? item.GetAttributeValue<Money>("lux_materialdamagelossofrentpayable").Value : 0;
                            bdx["lux_mdlossofrentpayable"] = new Money(LossofRent);
                            var Stock = item.Attributes.Contains("lux_stockexcludinghighvaluestock") == true ? item.GetAttributeValue<Money>("lux_stockexcludinghighvaluestock").Value : 0;
                            bdx["lux_mdstockexcludingtargetstock"] = new Money(Stock);

                            decimal Ciggerates = item.Attributes.Contains("lux_cigarettescigarsortobaccoproductssuminsur") == true ? item.GetAttributeValue<Money>("lux_cigarettescigarsortobaccoproductssuminsur").Value : 0;
                            decimal Wines = item.Attributes.Contains("lux_winesfortifiedwinesspiritsfinesuminsured") == true ? item.GetAttributeValue<Money>("lux_winesfortifiedwinesspiritsfinesuminsured").Value : 0;
                            decimal NonFerrus = item.Attributes.Contains("lux_nonferrousmetalssuminsured") ? item.GetAttributeValue<Money>("lux_nonferrousmetalssuminsured").Value : 0;
                            decimal Mobile = item.Attributes.Contains("lux_mobilephonessuminsured") ? item.GetAttributeValue<Money>("lux_mobilephonessuminsured").Value : 0;
                            decimal Computer = item.Attributes.Contains("lux_computerequipmentsuminsured") ? item.GetAttributeValue<Money>("lux_computerequipmentsuminsured").Value : 0;
                            decimal Alcohol = item.Attributes.Contains("lux_alcoholsuminsured") ? item.GetAttributeValue<Money>("lux_alcoholsuminsured").Value : 0;
                            decimal Audio = item.Attributes.Contains("lux_audiovideoequipmentsuminsured") ? item.GetAttributeValue<Money>("lux_audiovideoequipmentsuminsured").Value : 0;
                            decimal ComputerGames = item.Attributes.Contains("lux_computergamesandorconsolessuminsured") ? item.GetAttributeValue<Money>("lux_computergamesandorconsolessuminsured").Value : 0;
                            decimal Jewellery = item.Attributes.Contains("lux_jewellerywatchessuminsured") ? item.GetAttributeValue<Money>("lux_jewellerywatchessuminsured").Value : 0;
                            decimal PowerTools = item.Attributes.Contains("lux_powertoolssuminsured") ? item.GetAttributeValue<Money>("lux_powertoolssuminsured").Value : 0;
                            decimal FineArt = item.Attributes.Contains("lux_fineartsuminsured") ? item.GetAttributeValue<Money>("lux_fineartsuminsured").Value : 0;
                            var TargetStock = Wines + NonFerrus + Mobile + Computer + Alcohol + Audio + Ciggerates + Computer + Jewellery + PowerTools + FineArt;
                            bdx["lux_mdtargetstocksuminsured"] = new Money(TargetStock);

                            var TotalMDDV = Buildings + Contents + Tenents + ComputerEquipment + LossofRent + Stock + TargetStock;
                            bdx["lux_mdtotaldeclaredvalue"] = new Money(TotalMDDV);

                            var TotalMDSI = TotalMDDV;
                            if (item.GetAttributeValue<bool>("lux_isdayoneupliftcoverrequired") == true)
                            {
                                var indexingValue = item.Attributes.Contains("lux_dayoneupliftcover") ? item.FormattedValues["lux_dayoneupliftcover"].ToString() : "";
                                if (indexingValue != "")
                                {
                                    var indexed = Convert.ToDecimal(indexingValue.Replace("%", ""));
                                    var Amount = Buildings + Tenents + Contents;
                                    var upliftedAmount = Amount + Amount * indexed / 100 + Stock + TargetStock + ComputerEquipment + LossofRent;
                                    TotalMDSI = upliftedAmount;
                                }
                            }

                            if (item.GetAttributeValue<OptionSetValue>("lux_typesofconstruction").Value == 972970001)
                            {
                                bdx["lux_roofconstructiontype1"] = "Standard";
                                bdx["lux_wallconstructiontype1"] = "Standard";

                                bdx["lux_roofconstructiontype2"] = "Standard";
                                bdx["lux_wallconstructiontype2"] = "Standard";
                            }
                            else
                            {
                                bdx["lux_roofconstructiontype1"] = "Non Standard";
                                bdx["lux_wallconstructiontype1"] = "Non Standard";

                                //var wallmaterial = item.FormattedValues["lux_wallmaterials"].ToString().Replace("Glass", "Other").Replace("Slate", "Other").Replace("Tile", "Other");
                                //var roofmaterial = item.FormattedValues["lux_roofmaterials"].ToString().Replace("Flat roof", "Felt on Timber").Replace("Thatched", "Thatch - Fibre");

                                //if (wallmaterial.Contains("Other"))
                                //{
                                //    wallmaterial = wallmaterial.Replace("; Other", "") + "; Other";
                                //}
                                //if (roofmaterial.Contains("Felt on Timber"))
                                //{
                                //    roofmaterial = roofmaterial.Replace("; Felt on Timber", "") + "; Felt on Timber";
                                //}
                                //if (roofmaterial.Contains("Other"))
                                //{
                                //    roofmaterial = roofmaterial.Replace("; Other", "") + "; Other";
                                //}

                                var wallmaterial = item.Attributes.Contains("lux_wallmaterials") ? item.FormattedValues["lux_wallmaterials"].ToString() : "";
                                var roofmaterial = item.Attributes.Contains("lux_roofmaterials") ? item.FormattedValues["lux_roofmaterials"].ToString() : "";

                                if (wallmaterial.Contains("Other"))
                                {
                                    if (item.Attributes.Contains("lux_pleasespecifywallmaterial"))
                                    {
                                        wallmaterial = wallmaterial.Replace("; Other", "; " + item.Attributes["lux_pleasespecifywallmaterial"].ToString());
                                    }
                                }
                                if (wallmaterial.Contains("Composite Panels"))
                                {
                                    if (item.Attributes.Contains("lux_wallmaterialtype"))
                                    {
                                        wallmaterial = wallmaterial.Replace("; Composite Panels", "; Composite Panels ; " + item.FormattedValues["lux_wallmaterialtype"].ToString());
                                    }
                                }

                                if (roofmaterial.Contains("Other"))
                                {
                                    if (item.Attributes.Contains("lux_pleasespecifyroofmaterial"))
                                    {
                                        roofmaterial = roofmaterial.Replace("; Other", "; " + item.Attributes["lux_pleasespecifyroofmaterial"].ToString());
                                    }
                                }
                                if (roofmaterial.Contains("Composite Panels"))
                                {
                                    if (item.Attributes.Contains("lux_roofmaterialtype"))
                                    {
                                        roofmaterial = roofmaterial.Replace("; Composite Panels", "; Composite Panels ; " + item.FormattedValues["lux_roofmaterialtype"].ToString());
                                    }
                                }

                                IEnumerable<string> WallallWords = wallmaterial.Replace(";", ",").Split(',');
                                IEnumerable<string> WalluniqueWords = WallallWords.GroupBy(w => w).Where(g => g.Count() == 1).Select(g => g.Key.Trim());
                                var finalwallmaterial = "";
                                foreach (var item2 in WalluniqueWords)
                                {
                                    if (finalwallmaterial == "")
                                    {
                                        finalwallmaterial += item2;
                                    }
                                    else
                                    {
                                        if (!finalwallmaterial.Contains(item2))
                                        {
                                            finalwallmaterial += ", " + item2;
                                        }
                                    }
                                }

                                IEnumerable<string> RoofallWords = roofmaterial.Replace(";", ",").Split(',');
                                IEnumerable<string> RoofuniqueWords = RoofallWords.GroupBy(w => w).Where(g => g.Count() == 1).Select(g => g.Key.Trim());
                                var finalroofmaterial = "";
                                foreach (var item2 in RoofuniqueWords)
                                {
                                    if (finalroofmaterial == "")
                                    {
                                        finalroofmaterial += item2;
                                    }
                                    else
                                    {
                                        if (!finalroofmaterial.Contains(item2))
                                        {
                                            finalroofmaterial += ", " + item2;
                                        }
                                    }
                                }

                                bdx["lux_wallconstructiontype2"] = finalwallmaterial;
                                bdx["lux_roofconstructiontype2"] = finalroofmaterial;
                            }

                            bdx["lux_propertytype"] = "Commercial";
                            bdx["lux_occupancytype"] = "Commercial";
                            bdx["lux_occupancycategory"] = "Commercial";
                            bdx["lux_occupancydescription"] = "Retail";

                            if (LocationNo == firstLocationNumber)
                            {
                                if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "MTA")
                                {
                                    var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_propertyownersapplications'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_postcode' />
                                                        <attribute name='lux_insuredtitle' />
                                                        <attribute name='lux_quotenumber' />
                                                        <attribute name='statuscode' />
                                                        <attribute name='lux_inceptiondate' />
                                                        <attribute name='lux_broker' />
                                                        <attribute name='lux_quotedpremium' />
                                                        <attribute name='lux_policytotalcommission' />
                                                        <attribute name='lux_mtabrokercommissionpercentage' />
                                                        <attribute name='lux_lepolicygrosspremium' />
                                                        <attribute name='lux_legalexpensesmtapremium' />
                                                        <attribute name='lux_quotedpremiumbrokercommissionamount' />
                                                        <attribute name='lux_quotedpremiumaciescommissionamount' />
                                                        <attribute name='lux_mtabrokercommission' />
                                                        <attribute name='lux_mtaaciescommission' />
                                                        <attribute name='lux_mtagrosspremium' />
                                                        <attribute name='lux_totalquotedpremiuminciptandfee' />
                                                        <attribute name='lux_mtatotalpremiumincipt' />
                                                        <attribute name='lux_policyfee' />
                                                        <attribute name='lux_mtapolicyfee' />
                                                        <attribute name='lux_policynetpremium' />
                                                        <attribute name='lux_mtanetpremium' />
                                                        <attribute name='lux_lepolicynetpremium' />
                                                        <attribute name='lux_legalexpensesmtanetpremium' />
                                                        <attribute name='lux_quotedpremiumipt' />
                                                        <attribute name='lux_mtaipt' />
                                                        <attribute name='lux_employersliabilitypolicypremium' />
                                                        <attribute name='lux_employersliabilitymtapremium' />
                                                        <attribute name='lux_propertyownersliabilitypolicypremium' />
                                                        <attribute name='lux_propertyownersliabilitymtapremium' />
                                                        <attribute name='lux_publicproductsliabilitypolicypremium' />
                                                        <attribute name='lux_publicproductsliabilitymtapremium' />
                                                        <attribute name='lux_producttype' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='lux_propertyownersapplicationsid' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970006' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                                    var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001 || x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003);
                                    var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);

                                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                                    bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));
                                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));
                                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));

                                    var BrokerCommission = appln.Attributes["lux_mtabrokercommissionpercentage"];

                                    var LEMainPolicyPremium = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicygrosspremium") ? x.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value : 0);
                                    var LEMTAPolicyPremium = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);

                                    var LEPolicyPremium = LEMainPolicyPremium + LEMTAPolicyPremium;
                                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                                    var MainBrokerCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumbrokercommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value : 0);
                                    var MainACIESCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumaciescommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumaciescommissionamount").Value : 0);

                                    var MTABrokerCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                                    var MTAACIESCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                                    var CommAmount = MainBrokerCommAmt + MainACIESCommAmt + MTABrokerCommAmt + MTAACIESCommAmt - LEBrokerCommAmt;

                                    bdx["lux_commissionamount"] = new Money(CommAmount);
                                    bdx["lux_localsubproducerscommissionamount"] = new Money(MainBrokerCommAmt + MTABrokerCommAmt - LEBrokerCommAmt);

                                    var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremium") ? x.GetAttributeValue<Money>("lux_quotedpremium").Value : 0);
                                    var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);

                                    bdx["lux_totalgrosswrittenpremium"] = new Money(MainGWPAmt + MTAGWPAmt - LEPolicyPremium);

                                    var MainGrossAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_totalquotedpremiuminciptandfee") ? x.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value : 0);
                                    var MTAGrossAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);

                                    var PolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_policyfee") ? x.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                                    var MTAPolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_grosspremium"] = new Money(MainGrossAmt + MTAGrossAmt - PolicyFee - MTAPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_grosspremium"] = new Money(MainGrossAmt + MTAGrossAmt - PolicyFee - MTAPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100);
                                    }

                                    var MainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policynetpremium") ? x.GetAttributeValue<Money>("lux_policynetpremium").Value : 0);
                                    var MTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);

                                    var LEMainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicynetpremium") ? x.GetAttributeValue<Money>("lux_lepolicynetpremium").Value : 0);
                                    var LEMTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);

                                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = new Money(MainNetAmt + MTANetAmt - LEMainNetAmt - LEMTANetAmt);
                                    bdx["lux_finalnetpremiumoriginalcurrency"] = new Money(MainNetAmt + MTANetAmt - LEMainNetAmt - LEMTANetAmt);

                                    bdx["lux_brokerageamountoriginalcurrency"] = new Money(MainBrokerCommAmt + MTABrokerCommAmt - LEBrokerCommAmt);

                                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                                    bdx["lux_otherfeesordeductionsamount"] = new Money(PolicyFee + MTAPolicyFee);

                                    var MainIPTAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumipt") ? x.GetAttributeValue<Money>("lux_quotedpremiumipt").Value : 0);
                                    var MTAIPTAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);

                                    bdx["lux_tax1taxtype"] = "IPT";
                                    bdx["lux_tax1amountoftaxablepremium"] = new Money(MainGWPAmt + MTAGWPAmt - LEPolicyPremium);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_tax1amount"] = new Money((MainGWPAmt + MTAGWPAmt - LEPolicyPremium) * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_tax1amount"] = new Money((MainGWPAmt + MTAGWPAmt - LEPolicyPremium) * 0 / 100);
                                    }

                                    var MainELAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0);
                                    var MTAELAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);
                                    bdx["lux_elpremium"] = new Money(MainELAmt + MTAELAmt);

                                    var MainPOLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitypolicypremium").Value : 0);
                                    var MTAPOLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);
                                    bdx["lux_propertyownersliabilitypremium"] = new Money(MainPOLAmt + MTAPOLAmt);

                                    var MainPLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0);
                                    var MTAPLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);
                                    bdx["lux_plpremium"] = new Money(MainPLAmt + MTAPLAmt);
                                }
                                else if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "Cancellation")
                                {
                                    var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_propertyownersapplications'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_postcode' />
                                                        <attribute name='lux_insuredtitle' />
                                                        <attribute name='lux_quotenumber' />
                                                        <attribute name='statuscode' />
                                                        <attribute name='lux_inceptiondate' />
                                                        <attribute name='lux_broker' />
                                                        <attribute name='lux_quotedpremium' />
                                                        <attribute name='lux_policytotalcommission' />
                                                        <attribute name='lux_mtabrokercommissionpercentage' />
                                                        <attribute name='lux_lepolicygrosspremium' />
                                                        <attribute name='lux_legalexpensesmtapremium' />
                                                        <attribute name='lux_quotedpremiumbrokercommissionamount' />
                                                        <attribute name='lux_quotedpremiumaciescommissionamount' />
                                                        <attribute name='lux_mtabrokercommission' />
                                                        <attribute name='lux_mtaaciescommission' />
                                                        <attribute name='lux_mtagrosspremium' />
                                                        <attribute name='lux_totalquotedpremiuminciptandfee' />
                                                        <attribute name='lux_mtatotalpremiumincipt' />
                                                        <attribute name='lux_policyfee' /> 
                                                        <attribute name='lux_mtapolicyfee' />
                                                        <attribute name='lux_policynetpremium' />
                                                        <attribute name='lux_mtanetpremium' />
                                                        <attribute name='lux_lepolicynetpremium' />
                                                        <attribute name='lux_legalexpensesmtanetpremium' />
                                                        <attribute name='lux_quotedpremiumipt' />
                                                        <attribute name='lux_mtaipt' />
                                                        <attribute name='lux_employersliabilitypolicypremium' />
                                                        <attribute name='lux_employersliabilitymtapremium' />
                                                        <attribute name='lux_propertyownersliabilitypolicypremium' />
                                                        <attribute name='lux_propertyownersliabilitymtapremium' />
                                                        <attribute name='lux_publicproductsliabilitypolicypremium' />
                                                        <attribute name='lux_publicproductsliabilitymtapremium' />
                                                        <attribute name='lux_producttype' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='lux_propertyownersapplicationsid' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970009' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                                    var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001 || x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003);
                                    var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);
                                    var cancellationRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970004);

                                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                                    bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));
                                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));
                                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));

                                    var BrokerCommission = appln.Attributes["lux_mtabrokercommissionpercentage"];


                                    var LEMainPolicyPremium = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicygrosspremium") ? x.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value : 0);
                                    var LEMTAPolicyPremium = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);
                                    var LECancelPolicyPremium = cancellationRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);

                                    var LEPolicyPremium = LEMainPolicyPremium + LEMTAPolicyPremium + LECancelPolicyPremium;
                                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                                    var MainBrokerCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumbrokercommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value : 0);
                                    var MainACIESCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumaciescommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumaciescommissionamount").Value : 0);

                                    var MTABrokerCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                                    var MTAACIESCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                                    var CancelBrokerCommAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                                    var CancelACIESCommAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                                    var CommAmount = MainBrokerCommAmt + MainACIESCommAmt + MTABrokerCommAmt + MTAACIESCommAmt + CancelBrokerCommAmt + CancelACIESCommAmt - LEBrokerCommAmt;

                                    bdx["lux_commissionamount"] = (CommAmount <= 0.02M && CommAmount >= -0.02M) ? new Money(0) : new Money(CommAmount);
                                    bdx["lux_localsubproducerscommissionamount"] = (MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt <= 0.02M && MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt >= -0.02M) ? new Money(0) : new Money(MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt);

                                    var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremium") ? x.GetAttributeValue<Money>("lux_quotedpremium").Value : 0);
                                    var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);
                                    var CancelGWPAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);

                                    bdx["lux_totalgrosswrittenpremium"] = (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium <= 0.02M && MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium >= -0.02M) ? new Money(0) : new Money(MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium);


                                    var MainGrossAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_totalquotedpremiuminciptandfee") ? x.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value : 0);
                                    var MTAGrossAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);
                                    var CancelGrossAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);

                                    var PolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_policyfee") ? x.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                                    var MTAPolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);
                                    var CancelPolicyFee = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_grosspremium"] = (MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100 <= 0.02M && MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100 >= -0.02M) ? new Money(0) : new Money(MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_grosspremium"] = (MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100 <= 0.02M && MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100 >= -0.02M) ? new Money(0) : new Money(MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100);
                                    }

                                    var MainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policynetpremium") ? x.GetAttributeValue<Money>("lux_policynetpremium").Value : 0);
                                    var MTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);
                                    var CancelNetAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);

                                    var LEMainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicynetpremium") ? x.GetAttributeValue<Money>("lux_lepolicynetpremium").Value : 0);
                                    var LEMTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);
                                    var LECancelNetAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);

                                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = (MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt <= 0.02M && MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt >= -0.02M) ? new Money(0) : new Money(MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt);
                                    bdx["lux_finalnetpremiumoriginalcurrency"] = (MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt <= 0.02M && MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt >= -0.02M) ? new Money(0) : new Money(MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt);

                                    bdx["lux_brokerageamountoriginalcurrency"] = (MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt <= 0.02M && MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt >= -0.02M) ? new Money(0) : new Money(MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt);

                                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                                    bdx["lux_otherfeesordeductionsamount"] = (PolicyFee + MTAPolicyFee + CancelPolicyFee <= 0.02M && PolicyFee + MTAPolicyFee + CancelPolicyFee >= -0.02M) ? new Money(0) : new Money(PolicyFee + MTAPolicyFee + CancelPolicyFee);

                                    var MainIPTAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumipt") ? x.GetAttributeValue<Money>("lux_quotedpremiumipt").Value : 0);
                                    var MTAIPTAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);
                                    var CancelIPTAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);

                                    bdx["lux_tax1taxtype"] = "IPT";
                                    bdx["lux_tax1amountoftaxablepremium"] = (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium <= 0.02M && MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium >= -0.02M) ? new Money(0) : new Money(MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_tax1amount"] = ((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100 <= 0.02M && (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100 >= -0.02M) ? new Money(0) : new Money((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_tax1amount"] = ((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100 <= 0.02M && (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100 >= -0.02M) ? new Money(0) : new Money((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100);
                                    }

                                    var MainELAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0);
                                    var MTAELAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);
                                    var CancelELAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);

                                    bdx["lux_elpremium"] = (MainELAmt + MTAELAmt + CancelELAmt <= 0.02M && MainELAmt + MTAELAmt + CancelELAmt >= -0.02M) ? new Money(0) : new Money(MainELAmt + MTAELAmt + CancelELAmt);

                                    var MainPOLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitypolicypremium").Value : 0);
                                    var MTAPOLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);
                                    var CancelPOLAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);

                                    bdx["lux_propertyownersliabilitypremium"] = (MainPOLAmt + MTAPOLAmt + CancelPOLAmt <= 0.02M && MainPOLAmt + MTAPOLAmt + CancelPOLAmt >= -0.02M) ? new Money(0) : new Money(MainPOLAmt + MTAPOLAmt + CancelPOLAmt);

                                    var MainPLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0);
                                    var MTAPLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);
                                    var CancelPLAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);

                                    bdx["lux_plpremium"] = (MainPLAmt + MTAPLAmt + CancelPLAmt <= 0.02M && MainPLAmt + MTAPLAmt + CancelPLAmt >= -0.02M) ? new Money(0) : new Money(MainPLAmt + MTAPLAmt + CancelPLAmt);

                                    var MainCWAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_contractorspolicypremium") ? x.GetAttributeValue<Money>("lux_contractorspolicypremium").Value : 0);
                                    var MTACWAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);
                                    var CancelCWAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);

                                    bdx["lux_cwpremium"] = (MainCWAmt + MTACWAmt + CancelCWAmt <= 0.02M && MainCWAmt + MTACWAmt + CancelCWAmt >= -0.02M) ? new Money(0) : new Money(MainCWAmt + MTACWAmt + CancelCWAmt);

                                    var MainMDAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_materialdamagepolicypremium") ? x.GetAttributeValue<Money>("lux_materialdamagepolicypremium").Value : 0);
                                    var MTAMDAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_materialdamagemtapremium") ? x.GetAttributeValue<Money>("lux_materialdamagemtapremium").Value : 0);
                                    var CancelMDAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_materialdamagemtapremium") ? x.GetAttributeValue<Money>("lux_materialdamagemtapremium").Value : 0);

                                    bdx["lux_propertymdpremium"] = (MainMDAmt + MTAMDAmt + CancelMDAmt <= 0.02M && MainMDAmt + MTAMDAmt + CancelMDAmt >= -0.02M) ? new Money(0) : new Money(MainMDAmt + MTAMDAmt + CancelMDAmt);

                                    var MainBIAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionpolicypremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionpolicypremium").Value : 0);
                                    var MTABIAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionmtapremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionmtapremium").Value : 0);
                                    var CancelBIAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionmtapremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionmtapremium").Value : 0);

                                    bdx["lux_bipremium"] = (MainBIAmt + MTABIAmt + CancelBIAmt <= 0.02M && MainBIAmt + MTABIAmt + CancelBIAmt >= -0.02M) ? new Money(0) : new Money(MainBIAmt + MTABIAmt + CancelBIAmt);

                                    bdx["lux_reasonforcancellation"] = appln.Attributes.Contains("lux_reasonforcancellation") ? appln.FormattedValues["lux_reasonforcancellation"].ToString() : "";
                                }
                                else
                                {
                                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                                    bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));

                                    var BrokerCommission = appln.Attributes["lux_policybrokercommission"];
                                    var LEPolicyPremium = appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value;
                                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                                    bdx["lux_commissionamount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumtotalcommissionamount").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosscommission").Value - LEBrokerCommAmt);

                                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_policybrokercommission"].ToString().Replace("%", ""));
                                    bdx["lux_localsubproducerscommissionamount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value - LEBrokerCommAmt);

                                    bdx["lux_totalgrosswrittenpremium"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value);
                                    var PolicyFee = appln.GetAttributeValue<Money>("lux_policyfee").Value;

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_grosspremium"] = new Money(appln.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value - PolicyFee - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_grosspremium"] = new Money(appln.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value - PolicyFee - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 0 / 100);
                                    }

                                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_policynetpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicynetpremium").Value);
                                    bdx["lux_finalnetpremiumoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_policynetpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicynetpremium").Value);

                                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_policybrokercommission"].ToString().Replace("%", ""));
                                    bdx["lux_brokerageamountoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value - LEBrokerCommAmt);

                                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                                    bdx["lux_otherfeesordeductionsamount"] = new Money(appln.GetAttributeValue<Money>("lux_policyfee").Value);

                                    bdx["lux_tax1taxtype"] = "IPT";
                                    bdx["lux_tax1amountoftaxablepremium"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_tax1amount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumipt").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_tax1amount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumipt").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 0 / 100);
                                    }
                                }

                                decimal GrossProfitRevenue = appln.Attributes.Contains("lux_amount") ? appln.GetAttributeValue<Money>("lux_amount").Value : 0;
                                bdx["lux_bicoverbasissuminsured"] = new Money(GrossProfitRevenue);
                                decimal IncreasedCOW = appln.Attributes.Contains("lux_icow") ? appln.GetAttributeValue<Money>("lux_icow").Value : 0;
                                bdx["lux_biincreasedcostofworking"] = new Money(IncreasedCOW);
                                decimal AdditionalIncreasedCOW = appln.Attributes.Contains("lux_additionalincreasedcostofworking") ? appln.GetAttributeValue<Money>("lux_additionalincreasedcostofworking").Value : 0;
                                bdx["lux_biadditionalincreasedcostofworking"] = new Money(AdditionalIncreasedCOW);
                                decimal BookDebts = appln.Attributes.Contains("lux_bookdebts") ? appln.GetAttributeValue<Money>("lux_bookdebts").Value : 0;
                                bdx["lux_bibookdebts"] = new Money(BookDebts);
                                decimal LOR = appln.Attributes.Contains("lux_rentreceivable") ? appln.GetAttributeValue<Money>("lux_rentreceivable").Value : 0;
                                bdx["lux_birentreceivable"] = new Money(LOR);
                                decimal LORAmount = 0;
                                if (appln.GetAttributeValue<bool>("lux_lossoflicense") == true)
                                {
                                    var lolAmount = appln.Attributes.Contains("lux_lossoflicenseindemnitylimit") ? appln.GetAttributeValue<OptionSetValue>("lux_lossoflicenseindemnitylimit").Value : 0;
                                    if (lolAmount == 972970002)
                                    {
                                        LORAmount = 250000;
                                        bdx["lux_bilossoflicence"] = new Money(250000);
                                    }
                                    else
                                    {
                                        LORAmount = 100000;
                                        bdx["lux_bilossoflicence"] = new Money(100000);
                                    }
                                }
                                else
                                {
                                    LORAmount = 0;
                                    bdx["lux_bilossoflicence"] = new Money(0);
                                }

                                var TotalBISumInsured = GrossProfitRevenue + IncreasedCOW + AdditionalIncreasedCOW + BookDebts + LOR + LORAmount;

                                bdx["lux_bisuminsured"] = new Money(TotalBISumInsured);
                                bdx["lux_totalinsurablevalues"] = new Money(TotalMDDV + TotalBISumInsured);
                                bdx["lux_suminsuredamount"] = new Money(TotalMDSI + TotalBISumInsured);
                            }
                            else
                            {
                                bdx["lux_totalinsurablevalues"] = new Money(TotalMDDV);
                                bdx["lux_suminsuredamount"] = new Money(TotalMDSI);
                            }
                            service.Create(bdx);
                        }
                    }
                }
                else if (ProductName.Contains("Pubs & Restaurants") || ProductName.Contains("Hotels and Guesthouses")) //Leisure
                {
                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_pubsrestaurantspropertyownersapplicatio'>
                                    <attribute name='lux_pubsrestaurantspropertyownersapplicatioid' />
                                    <attribute name='lux_name' />
                                    <attribute name='createdon' />
                                    <attribute name='lux_riskpostcode' />                                    
                                    <attribute name='lux_locationnumber' />
                                    <attribute name='createdon' />
                                    <order attribute='lux_locationnumber' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                    {
                        var firstLocationNumber = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Attributes.Contains("lux_locationnumber") ? service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].GetAttributeValue<int>("lux_locationnumber") : 1;
                        foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                        {
                            var item = service.Retrieve("lux_pubsrestaurantspropertyownersapplicatio", item1.Id, new ColumnSet(true));
                            var LocationNo = item.Attributes.Contains("lux_locationnumber") ? item.GetAttributeValue<int>("lux_locationnumber") : 1;

                            Entity bdx = new Entity("lux_bordereau");
                            bdx["lux_lloydsriskcode"] = "B5";
                            bdx["lux_application"] = new EntityReference("lux_propertyownersapplications", appref.Id);
                            bdx["lux_policy"] = new EntityReference("lux_policy", policyref.Id);
                            bdx["lux_policynumber"] = policy.Attributes.Contains("lux_policynumber") ? policy.Attributes["lux_policynumber"].ToString() : "";
                            bdx["lux_inceptiondate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_expirydate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_customerclassification"] = appln.Attributes.Contains("lux_policyholdertype") ? appln.FormattedValues["lux_policyholdertype"].ToString() : "";
                            var TransactionType = "Original Premium";
                            if (appln.Attributes.Contains("lux_applicationtype") && (appln.FormattedValues["lux_applicationtype"] == "MTA" || appln.FormattedValues["lux_applicationtype"] == "Cancellation"))
                            {
                                bdx["lux_covereffectivedate"] = Convert.ToDateTime(appln.Attributes.Contains("lux_mtadate") == true ? appln.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                                bdx["lux_certificateissuancedate"] = Convert.ToDateTime(policy.Attributes.Contains("modifiedon") == true ? policy.FormattedValues["modifiedon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                                if (appln.Attributes.Contains("lux_mtagrosspremium") && appln.GetAttributeValue<Money>("lux_mtagrosspremium").Value >= 0)
                                {
                                    TransactionType = "Additional Premium";
                                }
                                else if (appln.Attributes.Contains("lux_mtagrosspremium") && appln.GetAttributeValue<Money>("lux_mtagrosspremium").Value < 0)
                                {
                                    TransactionType = "Returned Premium";
                                }
                            }
                            else
                            {
                                bdx["lux_covereffectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                                bdx["lux_certificateissuancedate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            }
                            bdx["lux_locationid"] = LocationNo.ToString();
                            if (item.Attributes.Contains("lux_materialdamagecoverdetails"))
                            {
                                if (item.GetAttributeValue<OptionSetValueCollection>("lux_materialdamagecoverdetails").Contains(new OptionSetValue(972970011)))
                                {
                                    bdx["lux_floodcover"] = true;
                                }
                                else
                                {
                                    bdx["lux_floodcover"] = false;
                                }
                            }
                            else
                            {
                                bdx["lux_floodcover"] = false;
                            }
                            if (policy.FormattedValues["lux_policytype"] == "Renewal")
                            {
                                bdx["lux_neworrenewal"] = "Renewal";
                            }
                            else
                            {
                                bdx["lux_neworrenewal"] = "New";
                            }
                            bdx["lux_nameofinsured"] = appln.Attributes.Contains("lux_insuredtitle") ? appln.Attributes["lux_insuredtitle"] : "";
                            bdx["lux_insuredaddress"] = (appln.Attributes.Contains("lux_housenumber") ? appln.Attributes["lux_housenumber"] + ", " : "") + (appln.Attributes.Contains("lux_street") ? appln.Attributes["lux_street"] + ", " : "") + (appln.Attributes.Contains("lux_citycounty") ? appln.Attributes["lux_citycounty"] : "");
                            bdx["lux_insuredzipcodepostalcode"] = appln.Attributes.Contains("lux_postcode") == true ? appln.Attributes["lux_postcode"] : "";
                            bdx["lux_insuredcountry"] = "United Kingdom";

                            bdx["lux_locationofriskaddress"] = (item.Attributes.Contains("lux_housenumber") ? item.Attributes["lux_housenumber"] + ", " : "") + (item.Attributes.Contains("lux_riskaddress") ? item.Attributes["lux_riskaddress"] + ", " : "") + (item.Attributes.Contains("lux_citycounty") ? item.Attributes["lux_citycounty"] : "");
                            bdx["lux_locationofriskpostcodezipcodeorsimilar"] = item.Attributes.Contains("lux_riskpostcode") == true ? item.Attributes["lux_riskpostcode"] : "";
                            bdx["lux_locationofriskcountry"] = "United Kingdom";

                            bdx["lux_suminsuredcurrency"] = "GBP";
                            bdx["lux_transactiontypeoriginalpremiumetc"] = TransactionType;

                            bdx["lux_methodofadjustment"] = item.GetAttributeValue<bool>("lux_isdayoneupliftcoverrequired") == true ? new OptionSetValue(972970001) : new OptionSetValue(972970002);
                            bdx["lux_day1uplift"] = item.Attributes.Contains("lux_dayoneupliftcover") == true ? item.FormattedValues["lux_dayoneupliftcover"].ToString() : "";
                            bdx["lux_mdcontentsofcommunalarea"] = new Money(0);

                            var Buildings = item.Attributes.Contains("lux_buildingsdeclaredvalue") == true ? item.GetAttributeValue<Money>("lux_buildingsdeclaredvalue").Value : 0;
                            bdx["lux_mdbuildingdeclaredvalue"] = new Money(Buildings);
                            var Contents = item.Attributes.Contains("lux_generalcontentsdeclaredvalueincludingmach") == true ? item.GetAttributeValue<Money>("lux_generalcontentsdeclaredvalueincludingmach").Value : 0;
                            bdx["lux_mdcontentsdeclaredvalue"] = new Money(Contents);
                            var Tenents = item.Attributes.Contains("lux_tenantsimprovementsdeclaredvalue") == true ? item.GetAttributeValue<Money>("lux_tenantsimprovementsdeclaredvalue").Value : 0;
                            bdx["lux_mdtenantsimprovementsdeclaredvalue"] = new Money(Tenents);
                            var ComputerEquipment = item.Attributes.Contains("lux_computerandelectronicbusinessequipment") == true ? item.GetAttributeValue<Money>("lux_computerandelectronicbusinessequipment").Value : 0;
                            bdx["lux_mdcomputerandelectronicbusinessequipment"] = new Money(ComputerEquipment);
                            var LossofRent = item.Attributes.Contains("lux_materialdamagelossofrentpayable") == true ? item.GetAttributeValue<Money>("lux_materialdamagelossofrentpayable").Value : 0;
                            bdx["lux_mdlossofrentpayable"] = new Money(LossofRent);
                            var Stock = item.Attributes.Contains("lux_stockexcludinghighvaluestock") == true ? item.GetAttributeValue<Money>("lux_stockexcludinghighvaluestock").Value : 0;
                            bdx["lux_mdstockexcludingtargetstock"] = new Money(Stock);

                            decimal Ciggerates = item.Attributes.Contains("lux_cigarettescigarsortobaccoproductssuminsur") == true ? item.GetAttributeValue<Money>("lux_cigarettescigarsortobaccoproductssuminsur").Value : 0;
                            decimal Wines = item.Attributes.Contains("lux_winesfortifiedwinesspiritsfinesuminsured") == true ? item.GetAttributeValue<Money>("lux_winesfortifiedwinesspiritsfinesuminsured").Value : 0;
                            decimal NonFerrus = item.Attributes.Contains("lux_nonferrousmetalssuminsured") ? item.GetAttributeValue<Money>("lux_nonferrousmetalssuminsured").Value : 0;
                            decimal Mobile = item.Attributes.Contains("lux_mobilephonessuminsured") ? item.GetAttributeValue<Money>("lux_mobilephonessuminsured").Value : 0;
                            decimal Computer = item.Attributes.Contains("lux_computerequipmentsuminsured") ? item.GetAttributeValue<Money>("lux_computerequipmentsuminsured").Value : 0;
                            decimal Alcohol = item.Attributes.Contains("lux_alcoholsuminsured") ? item.GetAttributeValue<Money>("lux_alcoholsuminsured").Value : 0;
                            decimal Audio = item.Attributes.Contains("lux_audiovideoequipmentsuminsured") ? item.GetAttributeValue<Money>("lux_audiovideoequipmentsuminsured").Value : 0;
                            decimal ComputerGames = item.Attributes.Contains("lux_computergamesandorconsolessuminsured") ? item.GetAttributeValue<Money>("lux_computergamesandorconsolessuminsured").Value : 0;
                            decimal Jewellery = item.Attributes.Contains("lux_jewellerywatchessuminsured") ? item.GetAttributeValue<Money>("lux_jewellerywatchessuminsured").Value : 0;
                            decimal PowerTools = item.Attributes.Contains("lux_powertoolssuminsured") ? item.GetAttributeValue<Money>("lux_powertoolssuminsured").Value : 0;
                            decimal FineArt = item.Attributes.Contains("lux_fineartsuminsured") ? item.GetAttributeValue<Money>("lux_fineartsuminsured").Value : 0;
                            var TargetStock = Wines + NonFerrus + Mobile + Computer + Alcohol + Audio + Ciggerates + Computer + Jewellery + PowerTools + FineArt;
                            bdx["lux_mdtargetstocksuminsured"] = new Money(TargetStock);

                            var TotalMDDV = Buildings + Contents + Tenents + ComputerEquipment + LossofRent + Stock + TargetStock;
                            bdx["lux_mdtotaldeclaredvalue"] = new Money(TotalMDDV);

                            var TotalMDSI = TotalMDDV;
                            if (item.GetAttributeValue<bool>("lux_isdayoneupliftcoverrequired") == true)
                            {
                                var indexingValue = item.Attributes.Contains("lux_dayoneupliftcover") ? item.FormattedValues["lux_dayoneupliftcover"].ToString() : "";
                                if (indexingValue != "")
                                {
                                    var indexed = Convert.ToDecimal(indexingValue.Replace("%", ""));
                                    var Amount = Buildings + Tenents + Contents;
                                    var upliftedAmount = Amount + Amount * indexed / 100 + Stock + TargetStock + ComputerEquipment + LossofRent;
                                    TotalMDSI = upliftedAmount;
                                }
                            }

                            if (item.GetAttributeValue<OptionSetValue>("lux_typesofconstruction").Value == 972970001)
                            {
                                bdx["lux_roofconstructiontype1"] = "Standard";
                                bdx["lux_wallconstructiontype1"] = "Standard";

                                bdx["lux_roofconstructiontype2"] = "Standard";
                                bdx["lux_wallconstructiontype2"] = "Standard";
                            }
                            else
                            {
                                bdx["lux_roofconstructiontype1"] = "Non Standard";
                                bdx["lux_wallconstructiontype1"] = "Non Standard";

                                //var wallmaterial = item.FormattedValues["lux_wallmaterials"].ToString().Replace("Glass", "Other").Replace("Slate", "Other").Replace("Tile", "Other");
                                //var roofmaterial = item.FormattedValues["lux_roofmaterials"].ToString().Replace("Flat roof", "Felt on Timber").Replace("Thatched", "Thatch - Fibre");

                                //if (wallmaterial.Contains("Other"))
                                //{
                                //    wallmaterial = wallmaterial.Replace("; Other", "") + "; Other";
                                //}
                                //if (roofmaterial.Contains("Felt on Timber"))
                                //{
                                //    roofmaterial = roofmaterial.Replace("; Felt on Timber", "") + "; Felt on Timber";
                                //}
                                //if (roofmaterial.Contains("Other"))
                                //{
                                //    roofmaterial = roofmaterial.Replace("; Other", "") + "; Other";
                                //}

                                var wallmaterial = item.Attributes.Contains("lux_wallmaterials") ? item.FormattedValues["lux_wallmaterials"].ToString() : "";
                                var roofmaterial = item.Attributes.Contains("lux_roofmaterials") ? item.FormattedValues["lux_roofmaterials"].ToString() : "";

                                if (wallmaterial.Contains("Other"))
                                {
                                    if (item.Attributes.Contains("lux_pleasespecifywallmaterial"))
                                    {
                                        wallmaterial = wallmaterial.Replace("; Other", "; " + item.Attributes["lux_pleasespecifywallmaterial"].ToString());
                                    }
                                }
                                if (wallmaterial.Contains("Composite Panels"))
                                {
                                    if (item.Attributes.Contains("lux_wallmaterialtype"))
                                    {
                                        wallmaterial = wallmaterial.Replace("; Composite Panels", "; Composite Panels ; " + item.FormattedValues["lux_wallmaterialtype"].ToString());
                                    }
                                }

                                if (roofmaterial.Contains("Other"))
                                {
                                    if (item.Attributes.Contains("lux_pleasespecifyroofmaterial"))
                                    {
                                        roofmaterial = roofmaterial.Replace("; Other", "; " + item.Attributes["lux_pleasespecifyroofmaterial"].ToString());
                                    }
                                }
                                if (roofmaterial.Contains("Composite Panels"))
                                {
                                    if (item.Attributes.Contains("lux_roofmaterialtype"))
                                    {
                                        roofmaterial = roofmaterial.Replace("; Composite Panels", "; Composite Panels ; " + item.FormattedValues["lux_roofmaterialtype"].ToString());
                                    }
                                }

                                IEnumerable<string> WallallWords = wallmaterial.Replace(";", ",").Split(',');
                                IEnumerable<string> WalluniqueWords = WallallWords.GroupBy(w => w).Where(g => g.Count() == 1).Select(g => g.Key.Trim());
                                var finalwallmaterial = "";
                                foreach (var item2 in WalluniqueWords)
                                {
                                    if (finalwallmaterial == "")
                                    {
                                        finalwallmaterial += item2;
                                    }
                                    else
                                    {
                                        if (!finalwallmaterial.Contains(item2))
                                        {
                                            finalwallmaterial += ", " + item2;
                                        }
                                    }
                                }

                                IEnumerable<string> RoofallWords = roofmaterial.Replace(";", ",").Split(',');
                                IEnumerable<string> RoofuniqueWords = RoofallWords.GroupBy(w => w).Where(g => g.Count() == 1).Select(g => g.Key.Trim());
                                var finalroofmaterial = "";
                                foreach (var item2 in RoofuniqueWords)
                                {
                                    if (finalroofmaterial == "")
                                    {
                                        finalroofmaterial += item2;
                                    }
                                    else
                                    {
                                        if (!finalroofmaterial.Contains(item2))
                                        {
                                            finalroofmaterial += ", " + item2;
                                        }
                                    }
                                }

                                bdx["lux_wallconstructiontype2"] = finalwallmaterial;
                                bdx["lux_roofconstructiontype2"] = finalroofmaterial;
                            }

                            bdx["lux_propertytype"] = "Commercial";
                            bdx["lux_occupancytype"] = "Commercial";
                            bdx["lux_occupancycategory"] = "Commercial";

                            if (appln.Attributes.Contains("lux_pubsrestaurantproducttype"))
                            {
                                if (appln.GetAttributeValue<OptionSetValue>("lux_pubsrestaurantproducttype").Value == 972970001)
                                {
                                    bdx["lux_occupancydescription"] = "Pub";
                                }
                                else if (appln.GetAttributeValue<OptionSetValue>("lux_pubsrestaurantproducttype").Value == 972970002)
                                {
                                    bdx["lux_occupancydescription"] = "Restaurant";
                                }
                                else if (appln.GetAttributeValue<OptionSetValue>("lux_pubsrestaurantproducttype").Value == 972970003)
                                {
                                    bdx["lux_occupancydescription"] = "Hotel";
                                }
                            }

                            if (LocationNo == firstLocationNumber)
                            {
                                if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "MTA")
                                {
                                    var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_propertyownersapplications'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_postcode' />
                                                        <attribute name='lux_insuredtitle' />
                                                        <attribute name='lux_quotenumber' />
                                                        <attribute name='statuscode' />
                                                        <attribute name='lux_inceptiondate' />
                                                        <attribute name='lux_broker' />
                                                        <attribute name='lux_quotedpremium' />
                                                        <attribute name='lux_policytotalcommission' />
                                                        <attribute name='lux_mtabrokercommissionpercentage' />
                                                        <attribute name='lux_lepolicygrosspremium' />
                                                        <attribute name='lux_legalexpensesmtapremium' />
                                                        <attribute name='lux_quotedpremiumbrokercommissionamount' />
                                                        <attribute name='lux_quotedpremiumaciescommissionamount' />
                                                        <attribute name='lux_mtabrokercommission' />
                                                        <attribute name='lux_mtaaciescommission' />
                                                        <attribute name='lux_mtagrosspremium' />
                                                        <attribute name='lux_totalquotedpremiuminciptandfee' />
                                                        <attribute name='lux_mtatotalpremiumincipt' />
                                                        <attribute name='lux_policyfee' />
                                                        <attribute name='lux_mtapolicyfee' />
                                                        <attribute name='lux_policynetpremium' />
                                                        <attribute name='lux_mtanetpremium' />
                                                        <attribute name='lux_lepolicynetpremium' />
                                                        <attribute name='lux_legalexpensesmtanetpremium' />
                                                        <attribute name='lux_quotedpremiumipt' />
                                                        <attribute name='lux_mtaipt' />
                                                        <attribute name='lux_employersliabilitypolicypremium' />
                                                        <attribute name='lux_employersliabilitymtapremium' />
                                                        <attribute name='lux_propertyownersliabilitypolicypremium' />
                                                        <attribute name='lux_propertyownersliabilitymtapremium' />
                                                        <attribute name='lux_publicproductsliabilitypolicypremium' />
                                                        <attribute name='lux_publicproductsliabilitymtapremium' />
                                                        <attribute name='lux_producttype' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='lux_propertyownersapplicationsid' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970006' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                                    var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001 || x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003);
                                    var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);

                                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                                    bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));
                                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));
                                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));

                                    var BrokerCommission = appln.Attributes["lux_mtabrokercommissionpercentage"];

                                    var LEMainPolicyPremium = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicygrosspremium") ? x.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value : 0);
                                    var LEMTAPolicyPremium = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);

                                    var LEPolicyPremium = LEMainPolicyPremium + LEMTAPolicyPremium;
                                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                                    var MainBrokerCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumbrokercommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value : 0);
                                    var MainACIESCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumaciescommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumaciescommissionamount").Value : 0);

                                    var MTABrokerCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                                    var MTAACIESCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                                    var CommAmount = MainBrokerCommAmt + MainACIESCommAmt + MTABrokerCommAmt + MTAACIESCommAmt - LEBrokerCommAmt;

                                    bdx["lux_commissionamount"] = new Money(CommAmount);
                                    bdx["lux_localsubproducerscommissionamount"] = new Money(MainBrokerCommAmt + MTABrokerCommAmt - LEBrokerCommAmt);

                                    var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremium") ? x.GetAttributeValue<Money>("lux_quotedpremium").Value : 0);
                                    var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);

                                    bdx["lux_totalgrosswrittenpremium"] = new Money(MainGWPAmt + MTAGWPAmt - LEPolicyPremium);

                                    var MainGrossAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_totalquotedpremiuminciptandfee") ? x.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value : 0);
                                    var MTAGrossAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);

                                    var PolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_policyfee") ? x.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                                    var MTAPolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_grosspremium"] = new Money(MainGrossAmt + MTAGrossAmt - PolicyFee - MTAPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_grosspremium"] = new Money(MainGrossAmt + MTAGrossAmt - PolicyFee - MTAPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100);
                                    }

                                    var MainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policynetpremium") ? x.GetAttributeValue<Money>("lux_policynetpremium").Value : 0);
                                    var MTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);

                                    var LEMainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicynetpremium") ? x.GetAttributeValue<Money>("lux_lepolicynetpremium").Value : 0);
                                    var LEMTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);

                                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = new Money(MainNetAmt + MTANetAmt - LEMainNetAmt - LEMTANetAmt);
                                    bdx["lux_finalnetpremiumoriginalcurrency"] = new Money(MainNetAmt + MTANetAmt - LEMainNetAmt - LEMTANetAmt);

                                    bdx["lux_brokerageamountoriginalcurrency"] = new Money(MainBrokerCommAmt + MTABrokerCommAmt - LEBrokerCommAmt);

                                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                                    bdx["lux_otherfeesordeductionsamount"] = new Money(PolicyFee + MTAPolicyFee);

                                    var MainIPTAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumipt") ? x.GetAttributeValue<Money>("lux_quotedpremiumipt").Value : 0);
                                    var MTAIPTAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);

                                    bdx["lux_tax1taxtype"] = "IPT";
                                    bdx["lux_tax1amountoftaxablepremium"] = new Money(MainGWPAmt + MTAGWPAmt - LEPolicyPremium);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_tax1amount"] = new Money((MainGWPAmt + MTAGWPAmt - LEPolicyPremium) * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_tax1amount"] = new Money((MainGWPAmt + MTAGWPAmt - LEPolicyPremium) * 0 / 100);
                                    }

                                    var MainELAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0);
                                    var MTAELAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);
                                    bdx["lux_elpremium"] = new Money(MainELAmt + MTAELAmt);

                                    var MainPOLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitypolicypremium").Value : 0);
                                    var MTAPOLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);
                                    bdx["lux_propertyownersliabilitypremium"] = new Money(MainPOLAmt + MTAPOLAmt);

                                    var MainPLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0);
                                    var MTAPLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);
                                    bdx["lux_plpremium"] = new Money(MainPLAmt + MTAPLAmt);
                                }
                                else if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "Cancellation")
                                {
                                    var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_propertyownersapplications'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_postcode' />
                                                        <attribute name='lux_insuredtitle' />
                                                        <attribute name='lux_quotenumber' />
                                                        <attribute name='statuscode' />
                                                        <attribute name='lux_inceptiondate' />
                                                        <attribute name='lux_broker' />
                                                        <attribute name='lux_quotedpremium' />
                                                        <attribute name='lux_policytotalcommission' />
                                                        <attribute name='lux_mtabrokercommissionpercentage' />
                                                        <attribute name='lux_lepolicygrosspremium' />
                                                        <attribute name='lux_legalexpensesmtapremium' />
                                                        <attribute name='lux_quotedpremiumbrokercommissionamount' />
                                                        <attribute name='lux_quotedpremiumaciescommissionamount' />
                                                        <attribute name='lux_mtabrokercommission' />
                                                        <attribute name='lux_mtaaciescommission' />
                                                        <attribute name='lux_mtagrosspremium' />
                                                        <attribute name='lux_totalquotedpremiuminciptandfee' />
                                                        <attribute name='lux_mtatotalpremiumincipt' />
                                                        <attribute name='lux_policyfee' /> 
                                                        <attribute name='lux_mtapolicyfee' />
                                                        <attribute name='lux_policynetpremium' />
                                                        <attribute name='lux_mtanetpremium' />
                                                        <attribute name='lux_lepolicynetpremium' />
                                                        <attribute name='lux_legalexpensesmtanetpremium' />
                                                        <attribute name='lux_quotedpremiumipt' />
                                                        <attribute name='lux_mtaipt' />
                                                        <attribute name='lux_employersliabilitypolicypremium' />
                                                        <attribute name='lux_employersliabilitymtapremium' />
                                                        <attribute name='lux_propertyownersliabilitypolicypremium' />
                                                        <attribute name='lux_propertyownersliabilitymtapremium' />
                                                        <attribute name='lux_publicproductsliabilitypolicypremium' />
                                                        <attribute name='lux_publicproductsliabilitymtapremium' />
                                                        <attribute name='lux_producttype' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='lux_propertyownersapplicationsid' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970009' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                                    var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001 || x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003);
                                    var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);
                                    var cancellationRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970004);

                                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                                    bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));
                                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));
                                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));

                                    var BrokerCommission = appln.Attributes["lux_mtabrokercommissionpercentage"];


                                    var LEMainPolicyPremium = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicygrosspremium") ? x.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value : 0);
                                    var LEMTAPolicyPremium = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);
                                    var LECancelPolicyPremium = cancellationRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);

                                    var LEPolicyPremium = LEMainPolicyPremium + LEMTAPolicyPremium + LECancelPolicyPremium;
                                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                                    var MainBrokerCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumbrokercommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value : 0);
                                    var MainACIESCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumaciescommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumaciescommissionamount").Value : 0);

                                    var MTABrokerCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                                    var MTAACIESCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                                    var CancelBrokerCommAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                                    var CancelACIESCommAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                                    var CommAmount = MainBrokerCommAmt + MainACIESCommAmt + MTABrokerCommAmt + MTAACIESCommAmt + CancelBrokerCommAmt + CancelACIESCommAmt - LEBrokerCommAmt;

                                    bdx["lux_commissionamount"] = (CommAmount <= 0.02M && CommAmount >= -0.02M) ? new Money(0) : new Money(CommAmount);
                                    bdx["lux_localsubproducerscommissionamount"] = (MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt <= 0.02M && MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt >= -0.02M) ? new Money(0) : new Money(MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt);

                                    var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremium") ? x.GetAttributeValue<Money>("lux_quotedpremium").Value : 0);
                                    var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);
                                    var CancelGWPAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);

                                    bdx["lux_totalgrosswrittenpremium"] = (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium <= 0.02M && MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium >= -0.02M) ? new Money(0) : new Money(MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium);


                                    var MainGrossAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_totalquotedpremiuminciptandfee") ? x.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value : 0);
                                    var MTAGrossAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);
                                    var CancelGrossAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);

                                    var PolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_policyfee") ? x.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                                    var MTAPolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);
                                    var CancelPolicyFee = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_grosspremium"] = (MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100 <= 0.02M && MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100 >= -0.02M) ? new Money(0) : new Money(MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_grosspremium"] = (MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100 <= 0.02M && MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100 >= -0.02M) ? new Money(0) : new Money(MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100);
                                    }

                                    var MainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policynetpremium") ? x.GetAttributeValue<Money>("lux_policynetpremium").Value : 0);
                                    var MTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);
                                    var CancelNetAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);

                                    var LEMainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicynetpremium") ? x.GetAttributeValue<Money>("lux_lepolicynetpremium").Value : 0);
                                    var LEMTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);
                                    var LECancelNetAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);

                                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = (MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt <= 0.02M && MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt >= -0.02M) ? new Money(0) : new Money(MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt);
                                    bdx["lux_finalnetpremiumoriginalcurrency"] = (MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt <= 0.02M && MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt >= -0.02M) ? new Money(0) : new Money(MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt);

                                    bdx["lux_brokerageamountoriginalcurrency"] = (MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt <= 0.02M && MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt >= -0.02M) ? new Money(0) : new Money(MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt);

                                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                                    bdx["lux_otherfeesordeductionsamount"] = (PolicyFee + MTAPolicyFee + CancelPolicyFee <= 0.02M && PolicyFee + MTAPolicyFee + CancelPolicyFee >= -0.02M) ? new Money(0) : new Money(PolicyFee + MTAPolicyFee + CancelPolicyFee);

                                    var MainIPTAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumipt") ? x.GetAttributeValue<Money>("lux_quotedpremiumipt").Value : 0);
                                    var MTAIPTAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);
                                    var CancelIPTAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);

                                    bdx["lux_tax1taxtype"] = "IPT";
                                    bdx["lux_tax1amountoftaxablepremium"] = (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium <= 0.02M && MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium >= -0.02M) ? new Money(0) : new Money(MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_tax1amount"] = ((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100 <= 0.02M && (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100 >= -0.02M) ? new Money(0) : new Money((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_tax1amount"] = ((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100 <= 0.02M && (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100 >= -0.02M) ? new Money(0) : new Money((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100);
                                    }

                                    var MainELAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0);
                                    var MTAELAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);
                                    var CancelELAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);

                                    bdx["lux_elpremium"] = (MainELAmt + MTAELAmt + CancelELAmt <= 0.02M && MainELAmt + MTAELAmt + CancelELAmt >= -0.02M) ? new Money(0) : new Money(MainELAmt + MTAELAmt + CancelELAmt);

                                    var MainPOLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitypolicypremium").Value : 0);
                                    var MTAPOLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);
                                    var CancelPOLAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);

                                    bdx["lux_propertyownersliabilitypremium"] = (MainPOLAmt + MTAPOLAmt + CancelPOLAmt <= 0.02M && MainPOLAmt + MTAPOLAmt + CancelPOLAmt >= -0.02M) ? new Money(0) : new Money(MainPOLAmt + MTAPOLAmt + CancelPOLAmt);

                                    var MainPLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0);
                                    var MTAPLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);
                                    var CancelPLAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);

                                    bdx["lux_plpremium"] = (MainPLAmt + MTAPLAmt + CancelPLAmt <= 0.02M && MainPLAmt + MTAPLAmt + CancelPLAmt >= -0.02M) ? new Money(0) : new Money(MainPLAmt + MTAPLAmt + CancelPLAmt);

                                    var MainCWAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_contractorspolicypremium") ? x.GetAttributeValue<Money>("lux_contractorspolicypremium").Value : 0);
                                    var MTACWAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);
                                    var CancelCWAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);

                                    bdx["lux_cwpremium"] = (MainCWAmt + MTACWAmt + CancelCWAmt <= 0.02M && MainCWAmt + MTACWAmt + CancelCWAmt >= -0.02M) ? new Money(0) : new Money(MainCWAmt + MTACWAmt + CancelCWAmt);

                                    var MainMDAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_materialdamagepolicypremium") ? x.GetAttributeValue<Money>("lux_materialdamagepolicypremium").Value : 0);
                                    var MTAMDAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_materialdamagemtapremium") ? x.GetAttributeValue<Money>("lux_materialdamagemtapremium").Value : 0);
                                    var CancelMDAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_materialdamagemtapremium") ? x.GetAttributeValue<Money>("lux_materialdamagemtapremium").Value : 0);

                                    bdx["lux_propertymdpremium"] = (MainMDAmt + MTAMDAmt + CancelMDAmt <= 0.02M && MainMDAmt + MTAMDAmt + CancelMDAmt >= -0.02M) ? new Money(0) : new Money(MainMDAmt + MTAMDAmt + CancelMDAmt);

                                    var MainBIAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionpolicypremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionpolicypremium").Value : 0);
                                    var MTABIAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionmtapremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionmtapremium").Value : 0);
                                    var CancelBIAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionmtapremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionmtapremium").Value : 0);

                                    bdx["lux_bipremium"] = (MainBIAmt + MTABIAmt + CancelBIAmt <= 0.02M && MainBIAmt + MTABIAmt + CancelBIAmt >= -0.02M) ? new Money(0) : new Money(MainBIAmt + MTABIAmt + CancelBIAmt);

                                    bdx["lux_reasonforcancellation"] = appln.Attributes.Contains("lux_reasonforcancellation") ? appln.FormattedValues["lux_reasonforcancellation"].ToString() : "";
                                }
                                else
                                {
                                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                                    bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));

                                    var BrokerCommission = appln.Attributes["lux_policybrokercommission"];
                                    var LEPolicyPremium = appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value;
                                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                                    bdx["lux_commissionamount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumtotalcommissionamount").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosscommission").Value - LEBrokerCommAmt);

                                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_policybrokercommission"].ToString().Replace("%", ""));
                                    bdx["lux_localsubproducerscommissionamount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value - LEBrokerCommAmt);

                                    bdx["lux_totalgrosswrittenpremium"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value);
                                    var PolicyFee = appln.GetAttributeValue<Money>("lux_policyfee").Value;

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_grosspremium"] = new Money(appln.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value - PolicyFee - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_grosspremium"] = new Money(appln.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value - PolicyFee - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 0 / 100);
                                    }

                                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_policynetpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicynetpremium").Value);
                                    bdx["lux_finalnetpremiumoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_policynetpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicynetpremium").Value);

                                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_policybrokercommission"].ToString().Replace("%", ""));
                                    bdx["lux_brokerageamountoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value - LEBrokerCommAmt);

                                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                                    bdx["lux_otherfeesordeductionsamount"] = new Money(appln.GetAttributeValue<Money>("lux_policyfee").Value);

                                    bdx["lux_tax1taxtype"] = "IPT";
                                    bdx["lux_tax1amountoftaxablepremium"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_tax1amount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumipt").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_tax1amount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumipt").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 0 / 100);
                                    }
                                }

                                decimal GrossProfitRevenue = appln.Attributes.Contains("lux_amount") ? appln.GetAttributeValue<Money>("lux_amount").Value : 0;
                                bdx["lux_bicoverbasissuminsured"] = new Money(GrossProfitRevenue);
                                decimal IncreasedCOW = appln.Attributes.Contains("lux_icow") ? appln.GetAttributeValue<Money>("lux_icow").Value : 0;
                                bdx["lux_biincreasedcostofworking"] = new Money(IncreasedCOW);
                                decimal AdditionalIncreasedCOW = appln.Attributes.Contains("lux_additionalincreasedcostofworking") ? appln.GetAttributeValue<Money>("lux_additionalincreasedcostofworking").Value : 0;
                                bdx["lux_biadditionalincreasedcostofworking"] = new Money(AdditionalIncreasedCOW);
                                decimal BookDebts = appln.Attributes.Contains("lux_bookdebts") ? appln.GetAttributeValue<Money>("lux_bookdebts").Value : 0;
                                bdx["lux_bibookdebts"] = new Money(BookDebts);
                                decimal LOR = appln.Attributes.Contains("lux_rentreceivable") ? appln.GetAttributeValue<Money>("lux_rentreceivable").Value : 0;
                                bdx["lux_birentreceivable"] = new Money(LOR);
                                decimal LORAmount = 0;
                                if (appln.GetAttributeValue<bool>("lux_lossoflicense") == true)
                                {
                                    var lolAmount = appln.Attributes.Contains("lux_lossoflicenseindemnitylimit") ? appln.GetAttributeValue<OptionSetValue>("lux_lossoflicenseindemnitylimit").Value : 0;
                                    if (lolAmount == 972970002)
                                    {
                                        LORAmount = 250000;
                                        bdx["lux_bilossoflicence"] = new Money(250000);
                                    }
                                    else
                                    {
                                        LORAmount = 100000;
                                        bdx["lux_bilossoflicence"] = new Money(100000);
                                    }
                                }
                                else
                                {
                                    LORAmount = 0;
                                    bdx["lux_bilossoflicence"] = new Money(0);
                                }

                                var TotalBISumInsured = GrossProfitRevenue + IncreasedCOW + AdditionalIncreasedCOW + BookDebts + LOR + LORAmount;

                                bdx["lux_bisuminsured"] = new Money(TotalBISumInsured);
                                bdx["lux_totalinsurablevalues"] = new Money(TotalMDDV + TotalBISumInsured);
                                bdx["lux_suminsuredamount"] = new Money(TotalMDSI + TotalBISumInsured);
                            }
                            else
                            {
                                bdx["lux_totalinsurablevalues"] = new Money(TotalMDDV);
                                bdx["lux_suminsuredamount"] = new Money(TotalMDSI);
                            }
                            service.Create(bdx);
                        }
                    }
                }
                else if (ProductName.Contains("Commercial Combined") || ProductName.Contains("Office")) //Commercial Combined
                {
                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                   <entity name='lux_commercialcombinedapplication'>
                                    <attribute name='lux_commercialcombinedapplicationid' />
                                    <attribute name='lux_name' />
                                    <attribute name='lux_riskpostcode' />                                  
                                    <attribute name='lux_locationnumber' />
                                    <attribute name='createdon' />
                                    <order attribute='lux_locationnumber' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                    {
                        var firstLocationNumber = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Attributes.Contains("lux_locationnumber") ? service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].GetAttributeValue<int>("lux_locationnumber") : 1;
                        foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                        {
                            var item = service.Retrieve("lux_commercialcombinedapplication", item1.Id, new ColumnSet(true));
                            var LocationNo = item.Attributes.Contains("lux_locationnumber") ? item.GetAttributeValue<int>("lux_locationnumber") : 1;

                            Entity bdx = new Entity("lux_bordereau");
                            bdx["lux_lloydsriskcode"] = "B5";
                            bdx["lux_application"] = new EntityReference("lux_propertyownersapplications", appref.Id);
                            bdx["lux_policy"] = new EntityReference("lux_policy", policyref.Id);
                            bdx["lux_policynumber"] = policy.Attributes.Contains("lux_policynumber") ? policy.Attributes["lux_policynumber"].ToString() : "";
                            bdx["lux_inceptiondate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_expirydate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_customerclassification"] = appln.Attributes.Contains("lux_policyholdertype") ? appln.FormattedValues["lux_policyholdertype"].ToString() : "";
                            var TransactionType = "Original Premium";
                            if (appln.Attributes.Contains("lux_applicationtype") && (appln.FormattedValues["lux_applicationtype"] == "MTA" || appln.FormattedValues["lux_applicationtype"] == "Cancellation"))
                            {
                                bdx["lux_covereffectivedate"] = Convert.ToDateTime(appln.Attributes.Contains("lux_mtadate") == true ? appln.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                                bdx["lux_certificateissuancedate"] = Convert.ToDateTime(policy.Attributes.Contains("modifiedon") == true ? policy.FormattedValues["modifiedon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                                if (appln.Attributes.Contains("lux_mtagrosspremium") && appln.GetAttributeValue<Money>("lux_mtagrosspremium").Value >= 0)
                                {
                                    TransactionType = "Additional Premium";
                                }
                                else if (appln.Attributes.Contains("lux_mtagrosspremium") && appln.GetAttributeValue<Money>("lux_mtagrosspremium").Value < 0)
                                {
                                    TransactionType = "Returned Premium";
                                }
                            }
                            else
                            {
                                bdx["lux_covereffectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                                bdx["lux_certificateissuancedate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            }
                            bdx["lux_locationid"] = LocationNo.ToString();
                            if (item.Attributes.Contains("lux_materialdamagecoverdetails"))
                            {
                                if (item.GetAttributeValue<OptionSetValueCollection>("lux_materialdamagecoverdetails").Contains(new OptionSetValue(972970011)))
                                {
                                    bdx["lux_floodcover"] = true;
                                }
                                else
                                {
                                    bdx["lux_floodcover"] = false;
                                }
                            }
                            else
                            {
                                bdx["lux_floodcover"] = false;
                            }
                            if (policy.FormattedValues["lux_policytype"] == "Renewal")
                            {
                                bdx["lux_neworrenewal"] = "Renewal";
                            }
                            else
                            {
                                bdx["lux_neworrenewal"] = "New";
                            }
                            bdx["lux_nameofinsured"] = appln.Attributes.Contains("lux_insuredtitle") ? appln.Attributes["lux_insuredtitle"] : "";
                            bdx["lux_insuredaddress"] = (appln.Attributes.Contains("lux_housenumber") ? appln.Attributes["lux_housenumber"] + ", " : "") + (appln.Attributes.Contains("lux_street") ? appln.Attributes["lux_street"] + ", " : "") + (appln.Attributes.Contains("lux_citycounty") ? appln.Attributes["lux_citycounty"] : "");
                            bdx["lux_insuredzipcodepostalcode"] = appln.Attributes.Contains("lux_postcode") == true ? appln.Attributes["lux_postcode"] : "";
                            bdx["lux_insuredcountry"] = "United Kingdom";

                            bdx["lux_locationofriskaddress"] = bdx["lux_locationofriskaddress"] = (item.Attributes.Contains("lux_housenumber") ? item.Attributes["lux_housenumber"] + ", " : "") + (item.Attributes.Contains("lux_riskaddress") ? item.Attributes["lux_riskaddress"] + ", " : "") + (item.Attributes.Contains("lux_citycounty") ? item.Attributes["lux_citycounty"] : "");
                            bdx["lux_locationofriskpostcodezipcodeorsimilar"] = item.Attributes.Contains("lux_riskpostcode") == true ? item.Attributes["lux_riskpostcode"] : "";
                            bdx["lux_locationofriskcountry"] = "United Kingdom";

                            bdx["lux_suminsuredcurrency"] = "GBP";
                            bdx["lux_transactiontypeoriginalpremiumetc"] = TransactionType;

                            bdx["lux_methodofadjustment"] = item.GetAttributeValue<bool>("lux_isdayoneupliftcoverrequired") == true ? new OptionSetValue(972970001) : new OptionSetValue(972970002);
                            bdx["lux_day1uplift"] = item.Attributes.Contains("lux_dayoneupliftcover") == true ? item.FormattedValues["lux_dayoneupliftcover"].ToString() : "";
                            bdx["lux_mdcontentsofcommunalarea"] = new Money(0);

                            var Buildings = item.Attributes.Contains("lux_buildingsdeclaredvalue") == true ? item.GetAttributeValue<Money>("lux_buildingsdeclaredvalue").Value : 0;
                            bdx["lux_mdbuildingdeclaredvalue"] = new Money(Buildings);
                            var Contents = item.Attributes.Contains("lux_generalcontentsdeclaredvalueincludingmach") == true ? item.GetAttributeValue<Money>("lux_generalcontentsdeclaredvalueincludingmach").Value : 0;
                            bdx["lux_mdcontentsdeclaredvalue"] = new Money(Contents);
                            var Tenents = item.Attributes.Contains("lux_tenantsimprovementsdeclaredvalue") == true ? item.GetAttributeValue<Money>("lux_tenantsimprovementsdeclaredvalue").Value : 0;
                            bdx["lux_mdtenantsimprovementsdeclaredvalue"] = new Money(Tenents);
                            var ComputerEquipment = item.Attributes.Contains("lux_computerandelectronicbusinessequipment") == true ? item.GetAttributeValue<Money>("lux_computerandelectronicbusinessequipment").Value : 0;
                            bdx["lux_mdcomputerandelectronicbusinessequipment"] = new Money(ComputerEquipment);
                            var LossofRent = item.Attributes.Contains("lux_materialdamagelossofrentpayable") == true ? item.GetAttributeValue<Money>("lux_materialdamagelossofrentpayable").Value : 0;
                            bdx["lux_mdlossofrentpayable"] = new Money(LossofRent);
                            var Stock = item.Attributes.Contains("lux_stockexcludinghighvaluestock") == true ? item.GetAttributeValue<Money>("lux_stockexcludinghighvaluestock").Value : 0;
                            bdx["lux_mdstockexcludingtargetstock"] = new Money(Stock);

                            decimal Ciggerates = item.Attributes.Contains("lux_cigarettescigarsortobaccoproductssuminsur") == true ? item.GetAttributeValue<Money>("lux_cigarettescigarsortobaccoproductssuminsur").Value : 0;
                            decimal Wines = item.Attributes.Contains("lux_winesfortifiedwinesspiritsfinesuminsured") == true ? item.GetAttributeValue<Money>("lux_winesfortifiedwinesspiritsfinesuminsured").Value : 0;
                            decimal NonFerrus = item.Attributes.Contains("lux_nonferrousmetalssuminsured") ? item.GetAttributeValue<Money>("lux_nonferrousmetalssuminsured").Value : 0;
                            decimal Mobile = item.Attributes.Contains("lux_mobilephonessuminsured") ? item.GetAttributeValue<Money>("lux_mobilephonessuminsured").Value : 0;
                            decimal Computer = item.Attributes.Contains("lux_computerequipmentsuminsured") ? item.GetAttributeValue<Money>("lux_computerequipmentsuminsured").Value : 0;
                            decimal Alcohol = item.Attributes.Contains("lux_alcoholsuminsured") ? item.GetAttributeValue<Money>("lux_alcoholsuminsured").Value : 0;
                            decimal Audio = item.Attributes.Contains("lux_audiovideoequipmentsuminsured") ? item.GetAttributeValue<Money>("lux_audiovideoequipmentsuminsured").Value : 0;
                            decimal ComputerGames = item.Attributes.Contains("lux_computergamesandorconsolessuminsured") ? item.GetAttributeValue<Money>("lux_computergamesandorconsolessuminsured").Value : 0;
                            decimal Jewellery = item.Attributes.Contains("lux_jewellerywatchessuminsured") ? item.GetAttributeValue<Money>("lux_jewellerywatchessuminsured").Value : 0;
                            decimal PowerTools = item.Attributes.Contains("lux_powertoolssuminsured") ? item.GetAttributeValue<Money>("lux_powertoolssuminsured").Value : 0;
                            decimal FineArt = item.Attributes.Contains("lux_fineartsuminsured") ? item.GetAttributeValue<Money>("lux_fineartsuminsured").Value : 0;
                            var TargetStock = Wines + NonFerrus + Mobile + Computer + Alcohol + Audio + Ciggerates + Computer + Jewellery + PowerTools + FineArt;
                            bdx["lux_mdtargetstocksuminsured"] = new Money(TargetStock);

                            var TotalMDDV = Buildings + Contents + Tenents + ComputerEquipment + LossofRent + Stock + TargetStock;
                            bdx["lux_mdtotaldeclaredvalue"] = new Money(TotalMDDV);

                            var TotalMDSI = TotalMDDV;
                            if (item.GetAttributeValue<bool>("lux_isdayoneupliftcoverrequired") == true)
                            {
                                var indexingValue = item.Attributes.Contains("lux_dayoneupliftcover") ? item.FormattedValues["lux_dayoneupliftcover"].ToString() : "";
                                if (indexingValue != "")
                                {
                                    var indexed = Convert.ToDecimal(indexingValue.Replace("%", ""));
                                    var Amount = Buildings + Tenents + Contents;
                                    var upliftedAmount = Amount + Amount * indexed / 100 + Stock + TargetStock + ComputerEquipment + LossofRent;
                                    TotalMDSI = upliftedAmount;
                                }
                            }

                            if (item.GetAttributeValue<OptionSetValue>("lux_typesofconstruction").Value == 972970001)
                            {
                                bdx["lux_roofconstructiontype1"] = "Standard";
                                bdx["lux_wallconstructiontype1"] = "Standard";

                                bdx["lux_roofconstructiontype2"] = "Standard";
                                bdx["lux_wallconstructiontype2"] = "Standard";
                            }
                            else
                            {
                                bdx["lux_roofconstructiontype1"] = "Non Standard";
                                bdx["lux_wallconstructiontype1"] = "Non Standard";

                                //var wallmaterial = item.FormattedValues["lux_wallmaterials"].ToString().Replace("Glass", "Other").Replace("Slate", "Other").Replace("Tile", "Other");
                                //var roofmaterial = item.FormattedValues["lux_roofmaterials"].ToString().Replace("Flat roof", "Felt on Timber").Replace("Thatched", "Thatch - Fibre");

                                //if (wallmaterial.Contains("Other"))
                                //{
                                //    wallmaterial = wallmaterial.Replace("; Other", "") + "; Other";
                                //}
                                //if (roofmaterial.Contains("Felt on Timber"))
                                //{
                                //    roofmaterial = roofmaterial.Replace("; Felt on Timber", "") + "; Felt on Timber";
                                //}
                                //if (roofmaterial.Contains("Other"))
                                //{
                                //    roofmaterial = roofmaterial.Replace("; Other", "") + "; Other";
                                //}

                                var wallmaterial = item.Attributes.Contains("lux_wallmaterials") ? item.FormattedValues["lux_wallmaterials"].ToString() : "";
                                var roofmaterial = item.Attributes.Contains("lux_roofmaterials") ? item.FormattedValues["lux_roofmaterials"].ToString() : "";

                                if (wallmaterial.Contains("Other"))
                                {
                                    if (item.Attributes.Contains("lux_pleasespecifywallmaterial"))
                                    {
                                        wallmaterial = wallmaterial.Replace("; Other", "; " + item.Attributes["lux_pleasespecifywallmaterial"].ToString());
                                    }
                                }
                                if (wallmaterial.Contains("Composite Panels"))
                                {
                                    if (item.Attributes.Contains("lux_wallmaterialtype"))
                                    {
                                        wallmaterial = wallmaterial.Replace("; Composite Panels", "; Composite Panels ; " + item.FormattedValues["lux_wallmaterialtype"].ToString());
                                    }
                                }

                                if (roofmaterial.Contains("Other"))
                                {
                                    if (item.Attributes.Contains("lux_pleasespecifyroofmaterial"))
                                    {
                                        roofmaterial = roofmaterial.Replace("; Other", "; " + item.Attributes["lux_pleasespecifyroofmaterial"].ToString());
                                    }
                                }
                                if (roofmaterial.Contains("Composite Panels"))
                                {
                                    if (item.Attributes.Contains("lux_roofmaterialtype"))
                                    {
                                        roofmaterial = roofmaterial.Replace("; Composite Panels", "; Composite Panels ; " + item.FormattedValues["lux_roofmaterialtype"].ToString());
                                    }
                                }

                                IEnumerable<string> WallallWords = wallmaterial.Replace(";", ",").Split(',');
                                IEnumerable<string> WalluniqueWords = WallallWords.GroupBy(w => w).Where(g => g.Count() == 1).Select(g => g.Key.Trim());
                                var finalwallmaterial = "";
                                foreach (var item2 in WalluniqueWords)
                                {
                                    if (finalwallmaterial == "")
                                    {
                                        finalwallmaterial += item2;
                                    }
                                    else
                                    {
                                        if (!finalwallmaterial.Contains(item2))
                                        {
                                            finalwallmaterial += ", " + item2;
                                        }
                                    }
                                }

                                IEnumerable<string> RoofallWords = roofmaterial.Replace(";", ",").Split(',');
                                IEnumerable<string> RoofuniqueWords = RoofallWords.GroupBy(w => w).Where(g => g.Count() == 1).Select(g => g.Key.Trim());
                                var finalroofmaterial = "";
                                foreach (var item2 in RoofuniqueWords)
                                {
                                    if (finalroofmaterial == "")
                                    {
                                        finalroofmaterial += item2;
                                    }
                                    else
                                    {
                                        if (!finalroofmaterial.Contains(item2))
                                        {
                                            finalroofmaterial += ", " + item2;
                                        }
                                    }
                                }

                                bdx["lux_wallconstructiontype2"] = finalwallmaterial;
                                bdx["lux_roofconstructiontype2"] = finalroofmaterial;
                            }

                            bdx["lux_propertytype"] = "Commercial";
                            bdx["lux_occupancytype"] = "Commercial";
                            bdx["lux_occupancycategory"] = "Commercial";
                            bdx["lux_occupancydescription"] = "Commercial";

                            if (LocationNo == firstLocationNumber)
                            {
                                if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "MTA")
                                {
                                    var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_propertyownersapplications'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_postcode' />
                                                        <attribute name='lux_insuredtitle' />
                                                        <attribute name='lux_quotenumber' />
                                                        <attribute name='statuscode' />
                                                        <attribute name='lux_inceptiondate' />
                                                        <attribute name='lux_broker' />
                                                        <attribute name='lux_quotedpremium' />
                                                        <attribute name='lux_policytotalcommission' />
                                                        <attribute name='lux_mtabrokercommissionpercentage' />
                                                        <attribute name='lux_lepolicygrosspremium' />
                                                        <attribute name='lux_legalexpensesmtapremium' />
                                                        <attribute name='lux_quotedpremiumbrokercommissionamount' />
                                                        <attribute name='lux_quotedpremiumaciescommissionamount' />
                                                        <attribute name='lux_mtabrokercommission' />
                                                        <attribute name='lux_mtaaciescommission' />
                                                        <attribute name='lux_mtagrosspremium' />
                                                        <attribute name='lux_totalquotedpremiuminciptandfee' />
                                                        <attribute name='lux_mtatotalpremiumincipt' />
                                                        <attribute name='lux_policyfee' />
                                                        <attribute name='lux_mtapolicyfee' />
                                                        <attribute name='lux_policynetpremium' />
                                                        <attribute name='lux_mtanetpremium' />
                                                        <attribute name='lux_lepolicynetpremium' />
                                                        <attribute name='lux_legalexpensesmtanetpremium' />
                                                        <attribute name='lux_quotedpremiumipt' />
                                                        <attribute name='lux_mtaipt' />
                                                        <attribute name='lux_employersliabilitypolicypremium' />
                                                        <attribute name='lux_employersliabilitymtapremium' />
                                                        <attribute name='lux_propertyownersliabilitypolicypremium' />
                                                        <attribute name='lux_propertyownersliabilitymtapremium' />
                                                        <attribute name='lux_publicproductsliabilitypolicypremium' />
                                                        <attribute name='lux_publicproductsliabilitymtapremium' />
                                                        <attribute name='lux_producttype' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='lux_propertyownersapplicationsid' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970006' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                                    var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001 || x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003);
                                    var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);

                                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                                    bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));
                                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));
                                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));

                                    var BrokerCommission = appln.Attributes["lux_mtabrokercommissionpercentage"];

                                    var LEMainPolicyPremium = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicygrosspremium") ? x.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value : 0);
                                    var LEMTAPolicyPremium = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);

                                    var LEPolicyPremium = LEMainPolicyPremium + LEMTAPolicyPremium;
                                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                                    var MainBrokerCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumbrokercommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value : 0);
                                    var MainACIESCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumaciescommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumaciescommissionamount").Value : 0);

                                    var MTABrokerCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                                    var MTAACIESCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                                    var CommAmount = MainBrokerCommAmt + MainACIESCommAmt + MTABrokerCommAmt + MTAACIESCommAmt - LEBrokerCommAmt;

                                    bdx["lux_commissionamount"] = new Money(CommAmount);
                                    bdx["lux_localsubproducerscommissionamount"] = new Money(MainBrokerCommAmt + MTABrokerCommAmt - LEBrokerCommAmt);

                                    var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremium") ? x.GetAttributeValue<Money>("lux_quotedpremium").Value : 0);
                                    var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);

                                    bdx["lux_totalgrosswrittenpremium"] = new Money(MainGWPAmt + MTAGWPAmt - LEPolicyPremium);

                                    var MainGrossAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_totalquotedpremiuminciptandfee") ? x.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value : 0);
                                    var MTAGrossAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);

                                    var PolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_policyfee") ? x.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                                    var MTAPolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_grosspremium"] = new Money(MainGrossAmt + MTAGrossAmt - PolicyFee - MTAPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_grosspremium"] = new Money(MainGrossAmt + MTAGrossAmt - PolicyFee - MTAPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100);
                                    }

                                    var MainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policynetpremium") ? x.GetAttributeValue<Money>("lux_policynetpremium").Value : 0);
                                    var MTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);

                                    var LEMainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicynetpremium") ? x.GetAttributeValue<Money>("lux_lepolicynetpremium").Value : 0);
                                    var LEMTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);

                                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = new Money(MainNetAmt + MTANetAmt - LEMainNetAmt - LEMTANetAmt);
                                    bdx["lux_finalnetpremiumoriginalcurrency"] = new Money(MainNetAmt + MTANetAmt - LEMainNetAmt - LEMTANetAmt);

                                    bdx["lux_brokerageamountoriginalcurrency"] = new Money(MainBrokerCommAmt + MTABrokerCommAmt - LEBrokerCommAmt);

                                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                                    bdx["lux_otherfeesordeductionsamount"] = new Money(PolicyFee + MTAPolicyFee);

                                    var MainIPTAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumipt") ? x.GetAttributeValue<Money>("lux_quotedpremiumipt").Value : 0);
                                    var MTAIPTAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);

                                    bdx["lux_tax1taxtype"] = "IPT";
                                    bdx["lux_tax1amountoftaxablepremium"] = new Money(MainGWPAmt + MTAGWPAmt - LEPolicyPremium);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_tax1amount"] = new Money((MainGWPAmt + MTAGWPAmt - LEPolicyPremium) * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_tax1amount"] = new Money((MainGWPAmt + MTAGWPAmt - LEPolicyPremium) * 0 / 100);
                                    }

                                    var MainELAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0);
                                    var MTAELAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);
                                    bdx["lux_elpremium"] = new Money(MainELAmt + MTAELAmt);

                                    var MainPOLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitypolicypremium").Value : 0);
                                    var MTAPOLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);
                                    bdx["lux_propertyownersliabilitypremium"] = new Money(MainPOLAmt + MTAPOLAmt);

                                    var MainPLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0);
                                    var MTAPLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);
                                    bdx["lux_plpremium"] = new Money(MainPLAmt + MTAPLAmt);
                                }
                                else if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "Cancellation")
                                {
                                    var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_propertyownersapplications'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_postcode' />
                                                        <attribute name='lux_insuredtitle' />
                                                        <attribute name='lux_quotenumber' />
                                                        <attribute name='statuscode' />
                                                        <attribute name='lux_inceptiondate' />
                                                        <attribute name='lux_broker' />
                                                        <attribute name='lux_quotedpremium' />
                                                        <attribute name='lux_policytotalcommission' />
                                                        <attribute name='lux_mtabrokercommissionpercentage' />
                                                        <attribute name='lux_lepolicygrosspremium' />
                                                        <attribute name='lux_legalexpensesmtapremium' />
                                                        <attribute name='lux_quotedpremiumbrokercommissionamount' />
                                                        <attribute name='lux_quotedpremiumaciescommissionamount' />
                                                        <attribute name='lux_mtabrokercommission' />
                                                        <attribute name='lux_mtaaciescommission' />
                                                        <attribute name='lux_mtagrosspremium' />
                                                        <attribute name='lux_totalquotedpremiuminciptandfee' />
                                                        <attribute name='lux_mtatotalpremiumincipt' />
                                                        <attribute name='lux_policyfee' /> 
                                                        <attribute name='lux_mtapolicyfee' />
                                                        <attribute name='lux_policynetpremium' />
                                                        <attribute name='lux_mtanetpremium' />
                                                        <attribute name='lux_lepolicynetpremium' />
                                                        <attribute name='lux_legalexpensesmtanetpremium' />
                                                        <attribute name='lux_quotedpremiumipt' />
                                                        <attribute name='lux_mtaipt' />
                                                        <attribute name='lux_employersliabilitypolicypremium' />
                                                        <attribute name='lux_employersliabilitymtapremium' />
                                                        <attribute name='lux_propertyownersliabilitypolicypremium' />
                                                        <attribute name='lux_propertyownersliabilitymtapremium' />
                                                        <attribute name='lux_publicproductsliabilitypolicypremium' />
                                                        <attribute name='lux_publicproductsliabilitymtapremium' />
                                                        <attribute name='lux_producttype' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='lux_propertyownersapplicationsid' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970009' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                                    var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001 || x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003);
                                    var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);
                                    var cancellationRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970004);

                                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                                    bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));
                                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));
                                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));

                                    var BrokerCommission = appln.Attributes["lux_mtabrokercommissionpercentage"];


                                    var LEMainPolicyPremium = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicygrosspremium") ? x.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value : 0);
                                    var LEMTAPolicyPremium = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);
                                    var LECancelPolicyPremium = cancellationRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);

                                    var LEPolicyPremium = LEMainPolicyPremium + LEMTAPolicyPremium + LECancelPolicyPremium;
                                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                                    var MainBrokerCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumbrokercommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value : 0);
                                    var MainACIESCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumaciescommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumaciescommissionamount").Value : 0);

                                    var MTABrokerCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                                    var MTAACIESCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                                    var CancelBrokerCommAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                                    var CancelACIESCommAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                                    var CommAmount = MainBrokerCommAmt + MainACIESCommAmt + MTABrokerCommAmt + MTAACIESCommAmt + CancelBrokerCommAmt + CancelACIESCommAmt - LEBrokerCommAmt;

                                    bdx["lux_commissionamount"] = (CommAmount <= 0.02M && CommAmount >= -0.02M) ? new Money(0) : new Money(CommAmount);
                                    bdx["lux_localsubproducerscommissionamount"] = (MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt <= 0.02M && MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt >= -0.02M) ? new Money(0) : new Money(MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt);

                                    var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremium") ? x.GetAttributeValue<Money>("lux_quotedpremium").Value : 0);
                                    var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);
                                    var CancelGWPAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);

                                    bdx["lux_totalgrosswrittenpremium"] = (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium <= 0.02M && MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium >= -0.02M) ? new Money(0) : new Money(MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium);


                                    var MainGrossAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_totalquotedpremiuminciptandfee") ? x.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value : 0);
                                    var MTAGrossAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);
                                    var CancelGrossAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);

                                    var PolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_policyfee") ? x.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                                    var MTAPolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);
                                    var CancelPolicyFee = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_grosspremium"] = (MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100 <= 0.02M && MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100 >= -0.02M) ? new Money(0) : new Money(MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_grosspremium"] = (MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100 <= 0.02M && MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100 >= -0.02M) ? new Money(0) : new Money(MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100);
                                    }

                                    var MainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policynetpremium") ? x.GetAttributeValue<Money>("lux_policynetpremium").Value : 0);
                                    var MTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);
                                    var CancelNetAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);

                                    var LEMainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicynetpremium") ? x.GetAttributeValue<Money>("lux_lepolicynetpremium").Value : 0);
                                    var LEMTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);
                                    var LECancelNetAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);

                                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = (MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt <= 0.02M && MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt >= -0.02M) ? new Money(0) : new Money(MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt);
                                    bdx["lux_finalnetpremiumoriginalcurrency"] = (MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt <= 0.02M && MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt >= -0.02M) ? new Money(0) : new Money(MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt);

                                    bdx["lux_brokerageamountoriginalcurrency"] = (MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt <= 0.02M && MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt >= -0.02M) ? new Money(0) : new Money(MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt);

                                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                                    bdx["lux_otherfeesordeductionsamount"] = (PolicyFee + MTAPolicyFee + CancelPolicyFee <= 0.02M && PolicyFee + MTAPolicyFee + CancelPolicyFee >= -0.02M) ? new Money(0) : new Money(PolicyFee + MTAPolicyFee + CancelPolicyFee);

                                    var MainIPTAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumipt") ? x.GetAttributeValue<Money>("lux_quotedpremiumipt").Value : 0);
                                    var MTAIPTAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);
                                    var CancelIPTAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);

                                    bdx["lux_tax1taxtype"] = "IPT";
                                    bdx["lux_tax1amountoftaxablepremium"] = (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium <= 0.02M && MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium >= -0.02M) ? new Money(0) : new Money(MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_tax1amount"] = ((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100 <= 0.02M && (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100 >= -0.02M) ? new Money(0) : new Money((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_tax1amount"] = ((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100 <= 0.02M && (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100 >= -0.02M) ? new Money(0) : new Money((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100);
                                    }

                                    var MainELAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0);
                                    var MTAELAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);
                                    var CancelELAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);

                                    bdx["lux_elpremium"] = (MainELAmt + MTAELAmt + CancelELAmt <= 0.02M && MainELAmt + MTAELAmt + CancelELAmt >= -0.02M) ? new Money(0) : new Money(MainELAmt + MTAELAmt + CancelELAmt);

                                    var MainPOLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitypolicypremium").Value : 0);
                                    var MTAPOLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);
                                    var CancelPOLAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);

                                    bdx["lux_propertyownersliabilitypremium"] = (MainPOLAmt + MTAPOLAmt + CancelPOLAmt <= 0.02M && MainPOLAmt + MTAPOLAmt + CancelPOLAmt >= -0.02M) ? new Money(0) : new Money(MainPOLAmt + MTAPOLAmt + CancelPOLAmt);

                                    var MainPLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0);
                                    var MTAPLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);
                                    var CancelPLAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);

                                    bdx["lux_plpremium"] = (MainPLAmt + MTAPLAmt + CancelPLAmt <= 0.02M && MainPLAmt + MTAPLAmt + CancelPLAmt >= -0.02M) ? new Money(0) : new Money(MainPLAmt + MTAPLAmt + CancelPLAmt);

                                    var MainCWAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_contractorspolicypremium") ? x.GetAttributeValue<Money>("lux_contractorspolicypremium").Value : 0);
                                    var MTACWAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);
                                    var CancelCWAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);

                                    bdx["lux_cwpremium"] = (MainCWAmt + MTACWAmt + CancelCWAmt <= 0.02M && MainCWAmt + MTACWAmt + CancelCWAmt >= -0.02M) ? new Money(0) : new Money(MainCWAmt + MTACWAmt + CancelCWAmt);

                                    var MainMDAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_materialdamagepolicypremium") ? x.GetAttributeValue<Money>("lux_materialdamagepolicypremium").Value : 0);
                                    var MTAMDAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_materialdamagemtapremium") ? x.GetAttributeValue<Money>("lux_materialdamagemtapremium").Value : 0);
                                    var CancelMDAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_materialdamagemtapremium") ? x.GetAttributeValue<Money>("lux_materialdamagemtapremium").Value : 0);

                                    bdx["lux_propertymdpremium"] = (MainMDAmt + MTAMDAmt + CancelMDAmt <= 0.02M && MainMDAmt + MTAMDAmt + CancelMDAmt >= -0.02M) ? new Money(0) : new Money(MainMDAmt + MTAMDAmt + CancelMDAmt);

                                    var MainBIAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionpolicypremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionpolicypremium").Value : 0);
                                    var MTABIAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionmtapremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionmtapremium").Value : 0);
                                    var CancelBIAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionmtapremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionmtapremium").Value : 0);

                                    bdx["lux_bipremium"] = (MainBIAmt + MTABIAmt + CancelBIAmt <= 0.02M && MainBIAmt + MTABIAmt + CancelBIAmt >= -0.02M) ? new Money(0) : new Money(MainBIAmt + MTABIAmt + CancelBIAmt);

                                    bdx["lux_reasonforcancellation"] = appln.Attributes.Contains("lux_reasonforcancellation") ? appln.FormattedValues["lux_reasonforcancellation"].ToString() : "";
                                }
                                else
                                {
                                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                                    bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));

                                    var BrokerCommission = appln.Attributes["lux_policybrokercommission"];
                                    var LEPolicyPremium = appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value;
                                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                                    bdx["lux_commissionamount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumtotalcommissionamount").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosscommission").Value - LEBrokerCommAmt);

                                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_policybrokercommission"].ToString().Replace("%", ""));
                                    bdx["lux_localsubproducerscommissionamount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value - LEBrokerCommAmt);

                                    bdx["lux_totalgrosswrittenpremium"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value);
                                    var PolicyFee = appln.GetAttributeValue<Money>("lux_policyfee").Value;

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_grosspremium"] = new Money(appln.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value - PolicyFee - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_grosspremium"] = new Money(appln.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value - PolicyFee - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 0 / 100);
                                    }

                                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_policynetpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicynetpremium").Value);
                                    bdx["lux_finalnetpremiumoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_policynetpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicynetpremium").Value);

                                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_policybrokercommission"].ToString().Replace("%", ""));
                                    bdx["lux_brokerageamountoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value - LEBrokerCommAmt);

                                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                                    bdx["lux_otherfeesordeductionsamount"] = new Money(appln.GetAttributeValue<Money>("lux_policyfee").Value);

                                    bdx["lux_tax1taxtype"] = "IPT";
                                    bdx["lux_tax1amountoftaxablepremium"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value);
                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_tax1amount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumipt").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_tax1amount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumipt").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 0 / 100);
                                    }
                                }

                                if (!appln.Attributes.Contains("lux_isbusinessinterruptioncoverrequired") || appln.GetAttributeValue<bool>("lux_isbusinessinterruptioncoverrequired") == true)
                                {
                                    decimal GrossProfitRevenue = appln.Attributes.Contains("lux_amount") ? appln.GetAttributeValue<Money>("lux_amount").Value : 0;
                                    bdx["lux_bicoverbasissuminsured"] = new Money(GrossProfitRevenue);
                                    decimal IncreasedCOW = appln.Attributes.Contains("lux_icow") ? appln.GetAttributeValue<Money>("lux_icow").Value : 0;
                                    bdx["lux_biincreasedcostofworking"] = new Money(IncreasedCOW);
                                    decimal AdditionalIncreasedCOW = appln.Attributes.Contains("lux_additionalincreasedcostofworking") ? appln.GetAttributeValue<Money>("lux_additionalincreasedcostofworking").Value : 0;
                                    bdx["lux_biadditionalincreasedcostofworking"] = new Money(AdditionalIncreasedCOW);
                                    decimal BookDebts = appln.Attributes.Contains("lux_bookdebts") ? appln.GetAttributeValue<Money>("lux_bookdebts").Value : 0;
                                    bdx["lux_bibookdebts"] = new Money(BookDebts);
                                    decimal LOR = appln.Attributes.Contains("lux_rentreceivable") ? appln.GetAttributeValue<Money>("lux_rentreceivable").Value : 0;
                                    bdx["lux_birentreceivable"] = new Money(LOR);
                                    decimal LORAmount = 0;
                                    if (appln.GetAttributeValue<bool>("lux_lossoflicense") == true)
                                    {
                                        var lolAmount = appln.Attributes.Contains("lux_lossoflicenseindemnitylimit") ? appln.GetAttributeValue<OptionSetValue>("lux_lossoflicenseindemnitylimit").Value : 0;
                                        if (lolAmount == 972970002)
                                        {
                                            LORAmount = 250000;
                                            bdx["lux_bilossoflicence"] = new Money(250000);
                                        }
                                        else
                                        {
                                            LORAmount = 100000;
                                            bdx["lux_bilossoflicence"] = new Money(100000);
                                        }
                                    }
                                    else
                                    {
                                        LORAmount = 0;
                                        bdx["lux_bilossoflicence"] = new Money(0);
                                    }

                                    var TotalBISumInsured = GrossProfitRevenue + IncreasedCOW + AdditionalIncreasedCOW + BookDebts + LOR + LORAmount;

                                    bdx["lux_bisuminsured"] = new Money(TotalBISumInsured);
                                    bdx["lux_totalinsurablevalues"] = new Money(TotalMDDV + TotalBISumInsured);
                                    bdx["lux_suminsuredamount"] = new Money(TotalMDSI + TotalBISumInsured);
                                }
                                else
                                {
                                    bdx["lux_bicoverbasissuminsured"] = new Money(0);
                                    bdx["lux_biincreasedcostofworking"] = new Money(0);
                                    bdx["lux_biadditionalincreasedcostofworking"] = new Money(0);
                                    bdx["lux_bibookdebts"] = new Money(0);
                                    bdx["lux_birentreceivable"] = new Money(0);
                                    bdx["lux_bilossoflicence"] = new Money(0);

                                    var TotalBISumInsured = 0;

                                    bdx["lux_bisuminsured"] = new Money(TotalBISumInsured);
                                    bdx["lux_totalinsurablevalues"] = new Money(TotalMDDV + TotalBISumInsured);
                                    bdx["lux_suminsuredamount"] = new Money(TotalMDSI + TotalBISumInsured);
                                }
                            }
                            else
                            {
                                bdx["lux_totalinsurablevalues"] = new Money(TotalMDDV);
                                bdx["lux_suminsuredamount"] = new Money(TotalMDSI);
                            }
                            service.Create(bdx);
                        }
                    }
                }
                else if (ProductName.Contains("Contractors Combined")) //Contractors Combined
                {
                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                   <entity name='lux_contractorscombined'>
                                    <attribute name='lux_contractorscombinedid' />
                                    <attribute name='lux_name' />
                                    <attribute name='lux_riskpostcode' />                                  
                                    <attribute name='lux_locationnumber' />
                                    <attribute name='createdon' />
                                    <order attribute='lux_locationnumber' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                    {
                        var firstLocationNumber = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Attributes.Contains("lux_locationnumber") ? service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].GetAttributeValue<int>("lux_locationnumber") : 1;
                        foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                        {
                            var item = service.Retrieve("lux_contractorscombined", item1.Id, new ColumnSet(true));
                            var LocationNo = item.Attributes.Contains("lux_locationnumber") ? item.GetAttributeValue<int>("lux_locationnumber") : 1;

                            Entity bdx = new Entity("lux_bordereau");
                            bdx["lux_lloydsriskcode"] = "B5";
                            bdx["lux_application"] = new EntityReference("lux_propertyownersapplications", appref.Id);
                            bdx["lux_policy"] = new EntityReference("lux_policy", policyref.Id);
                            bdx["lux_policynumber"] = policy.Attributes.Contains("lux_policynumber") ? policy.Attributes["lux_policynumber"].ToString() : "";
                            bdx["lux_inceptiondate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_expirydate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_customerclassification"] = appln.Attributes.Contains("lux_policyholdertype") ? appln.FormattedValues["lux_policyholdertype"].ToString() : "";
                            var TransactionType = "Original Premium";
                            if (appln.Attributes.Contains("lux_applicationtype") && (appln.FormattedValues["lux_applicationtype"] == "MTA" || appln.FormattedValues["lux_applicationtype"] == "Cancellation"))
                            {
                                bdx["lux_covereffectivedate"] = Convert.ToDateTime(appln.Attributes.Contains("lux_mtadate") == true ? appln.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                                bdx["lux_certificateissuancedate"] = Convert.ToDateTime(policy.Attributes.Contains("modifiedon") == true ? policy.FormattedValues["modifiedon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                                if (appln.Attributes.Contains("lux_mtagrosspremium") && appln.GetAttributeValue<Money>("lux_mtagrosspremium").Value >= 0)
                                {
                                    TransactionType = "Additional Premium";
                                }
                                else if (appln.Attributes.Contains("lux_mtagrosspremium") && appln.GetAttributeValue<Money>("lux_mtagrosspremium").Value < 0)
                                {
                                    TransactionType = "Returned Premium";
                                }
                            }
                            else
                            {
                                bdx["lux_covereffectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                                bdx["lux_certificateissuancedate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            }
                            bdx["lux_locationid"] = LocationNo.ToString();
                            if (item.Attributes.Contains("lux_materialdamagecoverdetails"))
                            {
                                if (item.GetAttributeValue<OptionSetValueCollection>("lux_materialdamagecoverdetails").Contains(new OptionSetValue(972970011)))
                                {
                                    bdx["lux_floodcover"] = true;
                                }
                                else
                                {
                                    bdx["lux_floodcover"] = false;
                                }
                            }
                            else
                            {
                                bdx["lux_floodcover"] = false;
                            }
                            if (policy.FormattedValues["lux_policytype"] == "Renewal")
                            {
                                bdx["lux_neworrenewal"] = "Renewal";
                            }
                            else
                            {
                                bdx["lux_neworrenewal"] = "New";
                            }
                            bdx["lux_nameofinsured"] = appln.Attributes.Contains("lux_insuredtitle") ? appln.Attributes["lux_insuredtitle"] : "";
                            bdx["lux_insuredaddress"] = (appln.Attributes.Contains("lux_housenumber") ? appln.Attributes["lux_housenumber"] + ", " : "") + (appln.Attributes.Contains("lux_street") ? appln.Attributes["lux_street"] + ", " : "") + (appln.Attributes.Contains("lux_citycounty") ? appln.Attributes["lux_citycounty"] : "");
                            bdx["lux_insuredzipcodepostalcode"] = appln.Attributes.Contains("lux_postcode") == true ? appln.Attributes["lux_postcode"] : "";
                            bdx["lux_insuredcountry"] = "United Kingdom";

                            bdx["lux_locationofriskaddress"] = bdx["lux_locationofriskaddress"] = (item.Attributes.Contains("lux_housenumber") ? item.Attributes["lux_housenumber"] + ", " : "") + (item.Attributes.Contains("lux_riskaddress") ? item.Attributes["lux_riskaddress"] + ", " : "") + (item.Attributes.Contains("lux_citycounty") ? item.Attributes["lux_citycounty"] : "");
                            bdx["lux_locationofriskpostcodezipcodeorsimilar"] = item.Attributes.Contains("lux_riskpostcode") == true ? item.Attributes["lux_riskpostcode"] : "";
                            bdx["lux_locationofriskcountry"] = "United Kingdom";

                            bdx["lux_suminsuredcurrency"] = "GBP";
                            bdx["lux_transactiontypeoriginalpremiumetc"] = TransactionType;

                            bdx["lux_mdbuildingdeclaredvalue"] = item.Attributes.Contains("lux_buildingsdeclaredvalue") == true ? item.GetAttributeValue<Money>("lux_buildingsdeclaredvalue") : new Money(0);
                            bdx["lux_methodofadjustment"] = item.GetAttributeValue<bool>("lux_isdayoneupliftcoverrequired") == true ? new OptionSetValue(972970001) : new OptionSetValue(972970002);
                            bdx["lux_day1uplift"] = item.Attributes.Contains("lux_dayoneupliftcover") == true ? item.FormattedValues["lux_dayoneupliftcover"].ToString() : "";

                            bdx["lux_mdtenantsimprovementsdeclaredvalue"] = item.Attributes.Contains("lux_tenantsimprovementsdeclaredvalue") == true ? item.GetAttributeValue<Money>("lux_tenantsimprovementsdeclaredvalue") : new Money(0);
                            bdx["lux_mdcontentsdeclaredvalue"] = item.Attributes.Contains("lux_generalcontentsdeclaredvalueincludingmach") == true ? item.GetAttributeValue<Money>("lux_generalcontentsdeclaredvalueincludingmach") : new Money(0);
                            bdx["lux_mdcontentsofcommunalarea"] = new Money(0);
                            bdx["lux_mdcomputerandelectronicbusinessequipment"] = item.Attributes.Contains("lux_computerandelectronicbusinessequipment") == true ? item.GetAttributeValue<Money>("lux_computerandelectronicbusinessequipment") : new Money(0);
                            bdx["lux_mdlossofrentpayable"] = item.Attributes.Contains("lux_materialdamagelossofrentpayable") == true ? item.GetAttributeValue<Money>("lux_materialdamagelossofrentpayable") : new Money(0);
                            bdx["lux_mdstockexcludingtargetstock"] = item.Attributes.Contains("lux_stockexcludinghighvaluestock") == true ? item.GetAttributeValue<Money>("lux_stockexcludinghighvaluestock") : new Money(0);
                            bdx["lux_mdcigarettescigarsortobaccoproducts"] = item.Attributes.Contains("lux_cigarettescigarsortobaccoproductssuminsur") == true ? item.GetAttributeValue<Money>("lux_cigarettescigarsortobaccoproductssuminsur") : new Money(0);
                            bdx["lux_mdwinesandspiritssuminsured"] = item.Attributes.Contains("lux_winesfortifiedwinesspiritsfinesuminsured") == true ? item.GetAttributeValue<Money>("lux_winesfortifiedwinesspiritsfinesuminsured") : new Money(0);
                            bdx["lux_mdtotaldeclaredvalue"] = item.Attributes.Contains("lux_totalmdsuminsured") == true ? item.GetAttributeValue<Money>("lux_totalmdsuminsured") : new Money(0);

                            if (item.GetAttributeValue<OptionSetValue>("lux_typesofconstruction").Value == 972970001)
                            {
                                bdx["lux_roofconstructiontype1"] = "Standard";
                                bdx["lux_wallconstructiontype1"] = "Standard";

                                bdx["lux_roofconstructiontype2"] = "Standard";
                                bdx["lux_wallconstructiontype2"] = "Standard";
                            }
                            else
                            {
                                bdx["lux_roofconstructiontype1"] = "Non Standard";
                                bdx["lux_wallconstructiontype1"] = "Non Standard";

                                //var wallmaterial = item.FormattedValues["lux_wallmaterials"].ToString().Replace("Glass", "Other").Replace("Slate", "Other").Replace("Tile", "Other");
                                //var roofmaterial = item.FormattedValues["lux_roofmaterials"].ToString().Replace("Flat roof", "Felt on Timber").Replace("Thatched", "Thatch - Fibre");

                                //if (wallmaterial.Contains("Other"))
                                //{
                                //    wallmaterial = wallmaterial.Replace("; Other", "") + "; Other";
                                //}
                                //if (roofmaterial.Contains("Felt on Timber"))
                                //{
                                //    roofmaterial = roofmaterial.Replace("; Felt on Timber", "") + "; Felt on Timber";
                                //}
                                //if (roofmaterial.Contains("Other"))
                                //{
                                //    roofmaterial = roofmaterial.Replace("; Other", "") + "; Other";
                                //}

                                var wallmaterial = item.Attributes.Contains("lux_wallmaterials") ? item.FormattedValues["lux_wallmaterials"].ToString() : "";
                                var roofmaterial = item.Attributes.Contains("lux_roofmaterials") ? item.FormattedValues["lux_roofmaterials"].ToString() : "";

                                if (wallmaterial.Contains("Other"))
                                {
                                    if (item.Attributes.Contains("lux_pleasespecifywallmaterial"))
                                    {
                                        wallmaterial = wallmaterial.Replace("; Other", "; " + item.Attributes["lux_pleasespecifywallmaterial"].ToString());
                                    }
                                }
                                if (wallmaterial.Contains("Composite Panels"))
                                {
                                    if (item.Attributes.Contains("lux_wallmaterialtype"))
                                    {
                                        wallmaterial = wallmaterial.Replace("; Composite Panels", "; Composite Panels ; " + item.FormattedValues["lux_wallmaterialtype"].ToString());
                                    }
                                }

                                if (roofmaterial.Contains("Other"))
                                {
                                    if (item.Attributes.Contains("lux_pleasespecifyroofmaterial"))
                                    {
                                        roofmaterial = roofmaterial.Replace("; Other", "; " + item.Attributes["lux_pleasespecifyroofmaterial"].ToString());
                                    }
                                }
                                if (roofmaterial.Contains("Composite Panels"))
                                {
                                    if (item.Attributes.Contains("lux_roofmaterialtype"))
                                    {
                                        roofmaterial = roofmaterial.Replace("; Composite Panels", "; Composite Panels ; " + item.FormattedValues["lux_roofmaterialtype"].ToString());
                                    }
                                }

                                IEnumerable<string> WallallWords = wallmaterial.Replace(";", ",").Split(',');
                                IEnumerable<string> WalluniqueWords = WallallWords.GroupBy(w => w).Where(g => g.Count() == 1).Select(g => g.Key.Trim());
                                var finalwallmaterial = "";
                                foreach (var item2 in WalluniqueWords)
                                {
                                    if (finalwallmaterial == "")
                                    {
                                        finalwallmaterial += item2;
                                    }
                                    else
                                    {
                                        if (!finalwallmaterial.Contains(item2))
                                        {
                                            finalwallmaterial += ", " + item2;
                                        }
                                    }
                                }

                                IEnumerable<string> RoofallWords = roofmaterial.Replace(";", ",").Split(',');
                                IEnumerable<string> RoofuniqueWords = RoofallWords.GroupBy(w => w).Where(g => g.Count() == 1).Select(g => g.Key.Trim());
                                var finalroofmaterial = "";
                                foreach (var item2 in RoofuniqueWords)
                                {
                                    if (finalroofmaterial == "")
                                    {
                                        finalroofmaterial += item2;
                                    }
                                    else
                                    {
                                        if (!finalroofmaterial.Contains(item2))
                                        {
                                            finalroofmaterial += ", " + item2;
                                        }
                                    }
                                }

                                bdx["lux_wallconstructiontype2"] = finalwallmaterial;
                                bdx["lux_roofconstructiontype2"] = finalroofmaterial;
                            }

                            bdx["lux_propertytype"] = "Commercial";
                            bdx["lux_occupancytype"] = "Commercial";
                            bdx["lux_occupancycategory"] = "Commercial";
                            bdx["lux_occupancydescription"] = "Commercial";

                            if (LocationNo == firstLocationNumber)
                            {
                                if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "MTA")
                                {
                                    var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_propertyownersapplications'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_postcode' />
                                                        <attribute name='lux_insuredtitle' />
                                                        <attribute name='lux_quotenumber' />
                                                        <attribute name='statuscode' />
                                                        <attribute name='lux_inceptiondate' />
                                                        <attribute name='lux_broker' />
                                                        <attribute name='lux_quotedpremium' />
                                                        <attribute name='lux_policytotalcommission' />
                                                        <attribute name='lux_mtabrokercommissionpercentage' />
                                                        <attribute name='lux_lepolicygrosspremium' />
                                                        <attribute name='lux_legalexpensesmtapremium' />
                                                        <attribute name='lux_quotedpremiumbrokercommissionamount' />
                                                        <attribute name='lux_quotedpremiumaciescommissionamount' />
                                                        <attribute name='lux_mtabrokercommission' />
                                                        <attribute name='lux_mtaaciescommission' />
                                                        <attribute name='lux_mtagrosspremium' />
                                                        <attribute name='lux_totalquotedpremiuminciptandfee' />
                                                        <attribute name='lux_mtatotalpremiumincipt' />
                                                        <attribute name='lux_policyfee' />
                                                        <attribute name='lux_mtapolicyfee' />
                                                        <attribute name='lux_policynetpremium' />
                                                        <attribute name='lux_mtanetpremium' />
                                                        <attribute name='lux_lepolicynetpremium' />
                                                        <attribute name='lux_legalexpensesmtanetpremium' />
                                                        <attribute name='lux_quotedpremiumipt' />
                                                        <attribute name='lux_mtaipt' />
                                                        <attribute name='lux_employersliabilitypolicypremium' />
                                                        <attribute name='lux_employersliabilitymtapremium' />
                                                        <attribute name='lux_contractorspolicypremium' />
                                                        <attribute name='lux_contractorsmtapremium' />
                                                        <attribute name='lux_publicproductsliabilitypolicypremium' />
                                                        <attribute name='lux_publicproductsliabilitymtapremium' />
                                                        <attribute name='lux_producttype' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='lux_propertyownersapplicationsid' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970006' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                                    var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001 || x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003);
                                    var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);

                                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                                    bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));
                                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));
                                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));

                                    var BrokerCommission = appln.Attributes["lux_mtabrokercommissionpercentage"];

                                    var LEMainPolicyPremium = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicygrosspremium") ? x.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value : 0);
                                    var LEMTAPolicyPremium = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);

                                    var LEPolicyPremium = LEMainPolicyPremium + LEMTAPolicyPremium;
                                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                                    var MainBrokerCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumbrokercommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value : 0);
                                    var MainACIESCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumaciescommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumaciescommissionamount").Value : 0);

                                    var MTABrokerCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                                    var MTAACIESCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                                    var CommAmount = MainBrokerCommAmt + MainACIESCommAmt + MTABrokerCommAmt + MTAACIESCommAmt - LEBrokerCommAmt;

                                    bdx["lux_commissionamount"] = new Money(CommAmount);
                                    bdx["lux_localsubproducerscommissionamount"] = new Money(MainBrokerCommAmt + MTABrokerCommAmt - LEBrokerCommAmt);

                                    var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremium") ? x.GetAttributeValue<Money>("lux_quotedpremium").Value : 0);
                                    var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);

                                    bdx["lux_totalgrosswrittenpremium"] = new Money(MainGWPAmt + MTAGWPAmt - LEPolicyPremium);

                                    var MainGrossAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_totalquotedpremiuminciptandfee") ? x.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value : 0);
                                    var MTAGrossAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);

                                    var PolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_policyfee") ? x.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                                    var MTAPolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);
                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_grosspremium"] = new Money(MainGrossAmt + MTAGrossAmt - PolicyFee - MTAPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_grosspremium"] = new Money(MainGrossAmt + MTAGrossAmt - PolicyFee - MTAPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100);
                                    }

                                    var MainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policynetpremium") ? x.GetAttributeValue<Money>("lux_policynetpremium").Value : 0);
                                    var MTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);

                                    var LEMainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicynetpremium") ? x.GetAttributeValue<Money>("lux_lepolicynetpremium").Value : 0);
                                    var LEMTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);

                                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = new Money(MainNetAmt + MTANetAmt - LEMainNetAmt - LEMTANetAmt);
                                    bdx["lux_finalnetpremiumoriginalcurrency"] = new Money(MainNetAmt + MTANetAmt - LEMainNetAmt - LEMTANetAmt);

                                    bdx["lux_brokerageamountoriginalcurrency"] = new Money(MainBrokerCommAmt + MTABrokerCommAmt - LEBrokerCommAmt);

                                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                                    bdx["lux_otherfeesordeductionsamount"] = new Money(PolicyFee + MTAPolicyFee);

                                    var MainIPTAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumipt") ? x.GetAttributeValue<Money>("lux_quotedpremiumipt").Value : 0);
                                    var MTAIPTAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);

                                    bdx["lux_tax1taxtype"] = "IPT";
                                    bdx["lux_tax1amountoftaxablepremium"] = new Money(MainGWPAmt + MTAGWPAmt - LEPolicyPremium);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_tax1amount"] = new Money((MainGWPAmt + MTAGWPAmt - LEPolicyPremium) * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_tax1amount"] = new Money((MainGWPAmt + MTAGWPAmt - LEPolicyPremium) * 0 / 100);
                                    }

                                    var MainELAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0);
                                    var MTAELAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);
                                    bdx["lux_elpremium"] = new Money(MainELAmt + MTAELAmt);

                                    var MainCWAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_contractorspolicypremium") ? x.GetAttributeValue<Money>("lux_contractorspolicypremium").Value : 0);
                                    var MTACWAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);
                                    bdx["lux_cwpremium"] = new Money(MainCWAmt + MTACWAmt);

                                    var MainPLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0);
                                    var MTAPLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);
                                    bdx["lux_plpremium"] = new Money(MainPLAmt + MTAPLAmt);
                                }
                                else if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "Cancellation")
                                {
                                    var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_propertyownersapplications'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_postcode' />
                                                        <attribute name='lux_insuredtitle' />
                                                        <attribute name='lux_quotenumber' />
                                                        <attribute name='statuscode' />
                                                        <attribute name='lux_inceptiondate' />
                                                        <attribute name='lux_broker' />
                                                        <attribute name='lux_quotedpremium' />
                                                        <attribute name='lux_policytotalcommission' />
                                                        <attribute name='lux_mtabrokercommissionpercentage' />
                                                        <attribute name='lux_lepolicygrosspremium' />
                                                        <attribute name='lux_legalexpensesmtapremium' />
                                                        <attribute name='lux_quotedpremiumbrokercommissionamount' />
                                                        <attribute name='lux_quotedpremiumaciescommissionamount' />
                                                        <attribute name='lux_mtabrokercommission' />
                                                        <attribute name='lux_mtaaciescommission' />
                                                        <attribute name='lux_mtagrosspremium' />
                                                        <attribute name='lux_totalquotedpremiuminciptandfee' />
                                                        <attribute name='lux_mtatotalpremiumincipt' />
                                                        <attribute name='lux_policyfee' /> 
                                                        <attribute name='lux_mtapolicyfee' />
                                                        <attribute name='lux_policynetpremium' />
                                                        <attribute name='lux_mtanetpremium' />
                                                        <attribute name='lux_lepolicynetpremium' />
                                                        <attribute name='lux_legalexpensesmtanetpremium' />
                                                        <attribute name='lux_quotedpremiumipt' />
                                                        <attribute name='lux_mtaipt' />
                                                        <attribute name='lux_employersliabilitypolicypremium' />
                                                        <attribute name='lux_employersliabilitymtapremium' />
                                                        <attribute name='lux_propertyownersliabilitypolicypremium' />
                                                        <attribute name='lux_propertyownersliabilitymtapremium' />
                                                        <attribute name='lux_publicproductsliabilitypolicypremium' />
                                                        <attribute name='lux_publicproductsliabilitymtapremium' />
                                                        <attribute name='lux_producttype' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='lux_propertyownersapplicationsid' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970009' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                                    var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001 || x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003);
                                    var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);
                                    var cancellationRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970004);

                                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                                    bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));
                                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));
                                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));

                                    var BrokerCommission = appln.Attributes["lux_mtabrokercommissionpercentage"];


                                    var LEMainPolicyPremium = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicygrosspremium") ? x.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value : 0);
                                    var LEMTAPolicyPremium = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);
                                    var LECancelPolicyPremium = cancellationRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);

                                    var LEPolicyPremium = LEMainPolicyPremium + LEMTAPolicyPremium + LECancelPolicyPremium;
                                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                                    var MainBrokerCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumbrokercommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value : 0);
                                    var MainACIESCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumaciescommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumaciescommissionamount").Value : 0);

                                    var MTABrokerCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                                    var MTAACIESCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                                    var CancelBrokerCommAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                                    var CancelACIESCommAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                                    var CommAmount = MainBrokerCommAmt + MainACIESCommAmt + MTABrokerCommAmt + MTAACIESCommAmt + CancelBrokerCommAmt + CancelACIESCommAmt - LEBrokerCommAmt;

                                    bdx["lux_commissionamount"] = (CommAmount <= 0.02M && CommAmount >= -0.02M) ? new Money(0) : new Money(CommAmount);
                                    bdx["lux_localsubproducerscommissionamount"] = (MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt <= 0.02M && MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt >= -0.02M) ? new Money(0) : new Money(MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt);

                                    var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremium") ? x.GetAttributeValue<Money>("lux_quotedpremium").Value : 0);
                                    var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);
                                    var CancelGWPAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);

                                    bdx["lux_totalgrosswrittenpremium"] = (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium <= 0.02M && MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium >= -0.02M) ? new Money(0) : new Money(MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium);


                                    var MainGrossAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_totalquotedpremiuminciptandfee") ? x.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value : 0);
                                    var MTAGrossAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);
                                    var CancelGrossAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);

                                    var PolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_policyfee") ? x.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                                    var MTAPolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);
                                    var CancelPolicyFee = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_grosspremium"] = (MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100 <= 0.02M && MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100 >= -0.02M) ? new Money(0) : new Money(MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_grosspremium"] = (MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100 <= 0.02M && MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100 >= -0.02M) ? new Money(0) : new Money(MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100);
                                    }

                                    var MainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policynetpremium") ? x.GetAttributeValue<Money>("lux_policynetpremium").Value : 0);
                                    var MTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);
                                    var CancelNetAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);

                                    var LEMainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicynetpremium") ? x.GetAttributeValue<Money>("lux_lepolicynetpremium").Value : 0);
                                    var LEMTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);
                                    var LECancelNetAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);

                                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = (MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt <= 0.02M && MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt >= -0.02M) ? new Money(0) : new Money(MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt);
                                    bdx["lux_finalnetpremiumoriginalcurrency"] = (MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt <= 0.02M && MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt >= -0.02M) ? new Money(0) : new Money(MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt);

                                    bdx["lux_brokerageamountoriginalcurrency"] = (MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt <= 0.02M && MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt >= -0.02M) ? new Money(0) : new Money(MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt);

                                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                                    bdx["lux_otherfeesordeductionsamount"] = (PolicyFee + MTAPolicyFee + CancelPolicyFee <= 0.02M && PolicyFee + MTAPolicyFee + CancelPolicyFee >= -0.02M) ? new Money(0) : new Money(PolicyFee + MTAPolicyFee + CancelPolicyFee);

                                    var MainIPTAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumipt") ? x.GetAttributeValue<Money>("lux_quotedpremiumipt").Value : 0);
                                    var MTAIPTAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);
                                    var CancelIPTAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);

                                    bdx["lux_tax1taxtype"] = "IPT";
                                    bdx["lux_tax1amountoftaxablepremium"] = (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium <= 0.02M && MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium >= -0.02M) ? new Money(0) : new Money(MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium);

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_tax1amount"] = ((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100 <= 0.02M && (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100 >= -0.02M) ? new Money(0) : new Money((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_tax1amount"] = ((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100 <= 0.02M && (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100 >= -0.02M) ? new Money(0) : new Money((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100);
                                    }

                                    var MainELAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0);
                                    var MTAELAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);
                                    var CancelELAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);

                                    bdx["lux_elpremium"] = (MainELAmt + MTAELAmt + CancelELAmt <= 0.02M && MainELAmt + MTAELAmt + CancelELAmt >= -0.02M) ? new Money(0) : new Money(MainELAmt + MTAELAmt + CancelELAmt);

                                    var MainPOLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitypolicypremium").Value : 0);
                                    var MTAPOLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);
                                    var CancelPOLAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);

                                    bdx["lux_propertyownersliabilitypremium"] = (MainPOLAmt + MTAPOLAmt + CancelPOLAmt <= 0.02M && MainPOLAmt + MTAPOLAmt + CancelPOLAmt >= -0.02M) ? new Money(0) : new Money(MainPOLAmt + MTAPOLAmt + CancelPOLAmt);

                                    var MainPLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0);
                                    var MTAPLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);
                                    var CancelPLAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);

                                    bdx["lux_plpremium"] = (MainPLAmt + MTAPLAmt + CancelPLAmt <= 0.02M && MainPLAmt + MTAPLAmt + CancelPLAmt >= -0.02M) ? new Money(0) : new Money(MainPLAmt + MTAPLAmt + CancelPLAmt);

                                    var MainCWAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_contractorspolicypremium") ? x.GetAttributeValue<Money>("lux_contractorspolicypremium").Value : 0);
                                    var MTACWAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);
                                    var CancelCWAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);

                                    bdx["lux_cwpremium"] = (MainCWAmt + MTACWAmt + CancelCWAmt <= 0.02M && MainCWAmt + MTACWAmt + CancelCWAmt >= -0.02M) ? new Money(0) : new Money(MainCWAmt + MTACWAmt + CancelCWAmt);

                                    var MainMDAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_materialdamagepolicypremium") ? x.GetAttributeValue<Money>("lux_materialdamagepolicypremium").Value : 0);
                                    var MTAMDAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_materialdamagemtapremium") ? x.GetAttributeValue<Money>("lux_materialdamagemtapremium").Value : 0);
                                    var CancelMDAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_materialdamagemtapremium") ? x.GetAttributeValue<Money>("lux_materialdamagemtapremium").Value : 0);

                                    bdx["lux_propertymdpremium"] = (MainMDAmt + MTAMDAmt + CancelMDAmt <= 0.02M && MainMDAmt + MTAMDAmt + CancelMDAmt >= -0.02M) ? new Money(0) : new Money(MainMDAmt + MTAMDAmt + CancelMDAmt);

                                    var MainBIAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionpolicypremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionpolicypremium").Value : 0);
                                    var MTABIAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionmtapremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionmtapremium").Value : 0);
                                    var CancelBIAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionmtapremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionmtapremium").Value : 0);

                                    bdx["lux_bipremium"] = (MainBIAmt + MTABIAmt + CancelBIAmt <= 0.02M && MainBIAmt + MTABIAmt + CancelBIAmt >= -0.02M) ? new Money(0) : new Money(MainBIAmt + MTABIAmt + CancelBIAmt);

                                    bdx["lux_reasonforcancellation"] = appln.Attributes.Contains("lux_reasonforcancellation") ? appln.FormattedValues["lux_reasonforcancellation"].ToString() : "";
                                }
                                else
                                {
                                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                                    bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));

                                    var BrokerCommission = appln.Attributes["lux_policybrokercommission"];
                                    var LEPolicyPremium = appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value;
                                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                                    bdx["lux_commissionamount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumtotalcommissionamount").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosscommission").Value - LEBrokerCommAmt);

                                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_policybrokercommission"].ToString().Replace("%", ""));
                                    bdx["lux_localsubproducerscommissionamount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value - LEBrokerCommAmt);

                                    bdx["lux_totalgrosswrittenpremium"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value);
                                    var PolicyFee = appln.GetAttributeValue<Money>("lux_policyfee").Value;

                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_grosspremium"] = new Money(appln.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value - PolicyFee - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_grosspremium"] = new Money(appln.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value - PolicyFee - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 0 / 100);
                                    }

                                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_policynetpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicynetpremium").Value);
                                    bdx["lux_finalnetpremiumoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_policynetpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicynetpremium").Value);

                                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_policybrokercommission"].ToString().Replace("%", ""));
                                    bdx["lux_brokerageamountoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value - LEBrokerCommAmt);

                                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                                    bdx["lux_otherfeesordeductionsamount"] = new Money(appln.GetAttributeValue<Money>("lux_policyfee").Value);

                                    bdx["lux_tax1taxtype"] = "IPT";
                                    bdx["lux_tax1amountoftaxablepremium"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value);
                                    if (isIsleofManPolicy == false)
                                    {
                                        bdx["lux_tax1amount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumipt").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 12 / 100);
                                    }
                                    else
                                    {
                                        bdx["lux_tax1amount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumipt").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 0 / 100);
                                    }
                                }

                                bdx["lux_biincreasedcostofworking"] = appln.Attributes.Contains("lux_icow") == true ? appln.GetAttributeValue<Money>("lux_icow") : new Money(0);
                                bdx["lux_biadditionalincreasedcostofworking"] = appln.Attributes.Contains("lux_additionalincreasedcostofworking") == true ? appln.GetAttributeValue<Money>("lux_additionalincreasedcostofworking") : new Money(0);
                                bdx["lux_bibookdebts"] = appln.Attributes.Contains("lux_bookdebts") == true ? appln.GetAttributeValue<Money>("lux_bookdebts") : new Money(0);
                                bdx["lux_birentreceivable"] = appln.Attributes.Contains("lux_rentreceivable") == true ? appln.GetAttributeValue<Money>("lux_rentreceivable") : new Money(0);
                                bdx["lux_bilossoflicence"] = appln.Attributes.Contains("lux_lossoflicense") == true ? appln.GetAttributeValue<Money>("lux_lossoflicense") : new Money(0);
                                bdx["lux_bisuminsured"] = appln.Attributes.Contains("lux_totalbisuminsured") == true ? appln.GetAttributeValue<Money>("lux_totalbisuminsured") : new Money(0);

                                var TotalMDInsurableValues = item.Attributes.Contains("lux_totalmdsuminsured") == true ? item.GetAttributeValue<Money>("lux_totalmdsuminsured").Value : 0;
                                var TotalBIInsurableValues = appln.Attributes.Contains("lux_totalbisuminsured") == true ? appln.GetAttributeValue<Money>("lux_totalbisuminsured").Value : 0;
                                var TotalInsurableValues = TotalMDInsurableValues + TotalBIInsurableValues;
                                bdx["lux_totalinsurablevalues"] = new Money(TotalInsurableValues);

                                var TotalMDSI = item.Attributes.Contains("lux_totalmdsuminsuredwithupliftedamount") == true ? item.GetAttributeValue<Money>("lux_totalmdsuminsuredwithupliftedamount").Value : 0;
                                var TotalBISI = appln.Attributes.Contains("lux_totalbisuminsured") == true ? appln.GetAttributeValue<Money>("lux_totalbisuminsured").Value : 0;

                                var SumInsuredAmount = TotalMDSI + TotalBISI;
                                bdx["lux_suminsuredamount"] = new Money(SumInsuredAmount);
                            }
                            else
                            {
                                var TotalMDInsurableValues = item.Attributes.Contains("lux_totalmdsuminsured") == true ? item.GetAttributeValue<Money>("lux_totalmdsuminsured").Value : 0;
                                bdx["lux_totalinsurablevalues"] = new Money(TotalMDInsurableValues);

                                var TotalMDSI = item.Attributes.Contains("lux_totalmdsuminsuredwithupliftedamount") == true ? item.GetAttributeValue<Money>("lux_totalmdsuminsuredwithupliftedamount").Value : 0;
                                bdx["lux_suminsuredamount"] = new Money(TotalMDSI);
                            }
                            service.Create(bdx);
                        }
                    }
                    else
                    {
                        var LocationNo = appln.Attributes.Contains("lux_locationnumber") ? appln.GetAttributeValue<int>("lux_locationnumber") : 1;

                        Entity bdx = new Entity("lux_bordereau");
                        bdx["lux_lloydsriskcode"] = "B5";
                        bdx["lux_application"] = new EntityReference("lux_propertyownersapplications", appref.Id);
                        bdx["lux_policy"] = new EntityReference("lux_policy", policyref.Id);
                        bdx["lux_policynumber"] = policy.Attributes.Contains("lux_policynumber") ? policy.Attributes["lux_policynumber"].ToString() : "";
                        bdx["lux_inceptiondate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_expirydate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                        var TransactionType = "Original Premium";
                        if (appln.Attributes.Contains("lux_applicationtype") && (appln.FormattedValues["lux_applicationtype"] == "MTA" || appln.FormattedValues["lux_applicationtype"] == "Cancellation"))
                        {
                            bdx["lux_covereffectivedate"] = Convert.ToDateTime(appln.Attributes.Contains("lux_mtadate") == true ? appln.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_certificateissuancedate"] = Convert.ToDateTime(policy.Attributes.Contains("modifiedon") == true ? policy.FormattedValues["modifiedon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                            if (appln.Attributes.Contains("lux_mtagrosspremium") && appln.GetAttributeValue<Money>("lux_mtagrosspremium").Value >= 0)
                            {
                                TransactionType = "Additional Premium";
                            }
                            else if (appln.Attributes.Contains("lux_mtagrosspremium") && appln.GetAttributeValue<Money>("lux_mtagrosspremium").Value < 0)
                            {
                                TransactionType = "Returned Premium";
                            }
                        }
                        else
                        {
                            bdx["lux_covereffectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_certificateissuancedate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        }
                        bdx["lux_locationid"] = LocationNo.ToString();
                        if (policy.FormattedValues["lux_policytype"] == "Renewal")
                        {
                            bdx["lux_neworrenewal"] = "Renewal";
                        }
                        else
                        {
                            bdx["lux_neworrenewal"] = "New";
                        }
                        bdx["lux_nameofinsured"] = appln.Attributes.Contains("lux_insuredtitle") ? appln.Attributes["lux_insuredtitle"] : "";
                        bdx["lux_insuredaddress"] = (appln.Attributes.Contains("lux_housenumber") ? appln.Attributes["lux_housenumber"] + ", " : "") + (appln.Attributes.Contains("lux_street") ? appln.Attributes["lux_street"] + ", " : "") + (appln.Attributes.Contains("lux_citycounty") ? appln.Attributes["lux_citycounty"] : "");
                        bdx["lux_insuredzipcodepostalcode"] = appln.Attributes.Contains("lux_postcode") == true ? appln.Attributes["lux_postcode"] : "";
                        bdx["lux_insuredcountry"] = "United Kingdom";

                        bdx["lux_locationofriskaddress"] = (appln.Attributes.Contains("lux_housenumber") ? appln.Attributes["lux_housenumber"] + ", " : "") + (appln.Attributes.Contains("lux_street") ? appln.Attributes["lux_street"] + ", " : "") + (appln.Attributes.Contains("lux_citycounty") ? appln.Attributes["lux_citycounty"] : "");
                        bdx["lux_locationofriskpostcodezipcodeorsimilar"] = appln.Attributes.Contains("lux_postcode") == true ? appln.Attributes["lux_postcode"] : "";
                        bdx["lux_locationofriskcountry"] = "United Kingdom";

                        bdx["lux_suminsuredcurrency"] = "GBP";
                        bdx["lux_transactiontypeoriginalpremiumetc"] = TransactionType;

                        bdx["lux_mdbuildingdeclaredvalue"] = new Money(0);
                        bdx["lux_mdtenantsimprovementsdeclaredvalue"] = new Money(0);
                        bdx["lux_mdcontentsdeclaredvalue"] = new Money(0);
                        bdx["lux_mdcontentsofcommunalarea"] = new Money(0);
                        bdx["lux_mdcomputerandelectronicbusinessequipment"] = new Money(0);
                        bdx["lux_mdlossofrentpayable"] = new Money(0);
                        bdx["lux_mdstockexcludingtargetstock"] = new Money(0);
                        bdx["lux_mdcigarettescigarsortobaccoproducts"] = new Money(0);
                        bdx["lux_mdwinesandspiritssuminsured"] = new Money(0);
                        bdx["lux_mdtotaldeclaredvalue"] = new Money(0);

                        bdx["lux_biincreasedcostofworking"] = new Money(0);
                        bdx["lux_biadditionalincreasedcostofworking"] = new Money(0);
                        bdx["lux_bibookdebts"] = new Money(0);
                        bdx["lux_birentreceivable"] = new Money(0);
                        bdx["lux_bilossoflicence"] = new Money(0);
                        bdx["lux_bisuminsured"] = new Money(0);

                        bdx["lux_propertytype"] = "Commercial";
                        bdx["lux_occupancytype"] = "Commercial";
                        bdx["lux_occupancycategory"] = "Commercial";
                        bdx["lux_occupancydescription"] = "Commercial";

                        if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "MTA")
                        {
                            var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_propertyownersapplications'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_postcode' />
                                                        <attribute name='lux_insuredtitle' />
                                                        <attribute name='lux_quotenumber' />
                                                        <attribute name='statuscode' />
                                                        <attribute name='lux_inceptiondate' />
                                                        <attribute name='lux_broker' />
                                                        <attribute name='lux_quotedpremium' />
                                                        <attribute name='lux_policytotalcommission' />
                                                        <attribute name='lux_mtabrokercommissionpercentage' />
                                                        <attribute name='lux_lepolicygrosspremium' />
                                                        <attribute name='lux_legalexpensesmtapremium' />
                                                        <attribute name='lux_quotedpremiumbrokercommissionamount' />
                                                        <attribute name='lux_quotedpremiumaciescommissionamount' />
                                                        <attribute name='lux_mtabrokercommission' />
                                                        <attribute name='lux_mtaaciescommission' />
                                                        <attribute name='lux_mtagrosspremium' />
                                                        <attribute name='lux_totalquotedpremiuminciptandfee' />
                                                        <attribute name='lux_mtatotalpremiumincipt' />
                                                        <attribute name='lux_policyfee' />
                                                        <attribute name='lux_mtapolicyfee' />
                                                        <attribute name='lux_policynetpremium' />
                                                        <attribute name='lux_mtanetpremium' />
                                                        <attribute name='lux_lepolicynetpremium' />
                                                        <attribute name='lux_legalexpensesmtanetpremium' />
                                                        <attribute name='lux_quotedpremiumipt' />
                                                        <attribute name='lux_mtaipt' />
                                                        <attribute name='lux_employersliabilitypolicypremium' />
                                                        <attribute name='lux_employersliabilitymtapremium' />
                                                        <attribute name='lux_contractorsmtatechnicalpremium' />
                                                        <attribute name='lux_publicproductsliabilitypolicypremium' />
                                                        <attribute name='lux_publicproductsliabilitymtapremium' />
                                                        <attribute name='lux_contractorspolicypremium' />
                                                        <attribute name='lux_contractorsmtapremium' />
                                                        <attribute name='lux_producttype' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='lux_propertyownersapplicationsid' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970006' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                            var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001 || x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003);
                            var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);

                            bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                            bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));
                            bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));
                            bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));

                            var BrokerCommission = appln.Attributes["lux_mtabrokercommissionpercentage"];

                            var LEMainPolicyPremium = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicygrosspremium") ? x.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value : 0);
                            var LEMTAPolicyPremium = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);

                            var LEPolicyPremium = LEMainPolicyPremium + LEMTAPolicyPremium;
                            var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                            var MainBrokerCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumbrokercommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value : 0);
                            var MainACIESCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumaciescommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumaciescommissionamount").Value : 0);

                            var MTABrokerCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                            var MTAACIESCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                            var CommAmount = MainBrokerCommAmt + MainACIESCommAmt + MTABrokerCommAmt + MTAACIESCommAmt - LEBrokerCommAmt;

                            bdx["lux_commissionamount"] = new Money(CommAmount);
                            bdx["lux_localsubproducerscommissionamount"] = new Money(MainBrokerCommAmt + MTABrokerCommAmt - LEBrokerCommAmt);

                            var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremium") ? x.GetAttributeValue<Money>("lux_quotedpremium").Value : 0);
                            var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);

                            bdx["lux_totalgrosswrittenpremium"] = new Money(MainGWPAmt + MTAGWPAmt - LEPolicyPremium);

                            var MainGrossAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_totalquotedpremiuminciptandfee") ? x.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value : 0);
                            var MTAGrossAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);

                            var PolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_policyfee") ? x.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                            var MTAPolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);
                            if (isIsleofManPolicy == false)
                            {
                                bdx["lux_grosspremium"] = new Money(MainGrossAmt + MTAGrossAmt - PolicyFee - MTAPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100);
                            }
                            else
                            {
                                bdx["lux_grosspremium"] = new Money(MainGrossAmt + MTAGrossAmt - PolicyFee - MTAPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100);
                            }

                            var MainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policynetpremium") ? x.GetAttributeValue<Money>("lux_policynetpremium").Value : 0);
                            var MTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);

                            var LEMainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicynetpremium") ? x.GetAttributeValue<Money>("lux_lepolicynetpremium").Value : 0);
                            var LEMTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);

                            bdx["lux_netpremiumtolondoninoriginalcurrency"] = new Money(MainNetAmt + MTANetAmt - LEMainNetAmt - LEMTANetAmt);
                            bdx["lux_finalnetpremiumoriginalcurrency"] = new Money(MainNetAmt + MTANetAmt - LEMainNetAmt - LEMTANetAmt);

                            bdx["lux_brokerageamountoriginalcurrency"] = new Money(MainBrokerCommAmt + MTABrokerCommAmt - LEBrokerCommAmt);

                            bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                            bdx["lux_otherfeesordeductionsamount"] = new Money(PolicyFee + MTAPolicyFee);

                            var MainIPTAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumipt") ? x.GetAttributeValue<Money>("lux_quotedpremiumipt").Value : 0);
                            var MTAIPTAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);

                            bdx["lux_tax1taxtype"] = "IPT";
                            bdx["lux_tax1amountoftaxablepremium"] = new Money(MainGWPAmt + MTAGWPAmt - LEPolicyPremium);

                            if (isIsleofManPolicy == false)
                            {
                                bdx["lux_tax1amount"] = new Money((MainGWPAmt + MTAGWPAmt - LEPolicyPremium) * 12 / 100);
                            }
                            else
                            {
                                bdx["lux_tax1amount"] = new Money((MainGWPAmt + MTAGWPAmt - LEPolicyPremium) * 0 / 100);
                            }
                            var MainELAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0);
                            var MTAELAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);
                            bdx["lux_elpremium"] = new Money(MainELAmt + MTAELAmt);

                            var MainCWAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_contractorspolicypremium") ? x.GetAttributeValue<Money>("lux_contractorspolicypremium").Value : 0);
                            var MTACWAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);
                            bdx["lux_cwpremium"] = new Money(MainCWAmt + MTACWAmt);

                            var MainPLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0);
                            var MTAPLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);
                            bdx["lux_plpremium"] = new Money(MainPLAmt + MTAPLAmt);
                        }
                        else if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "Cancellation")
                        {
                            var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_propertyownersapplications'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_postcode' />
                                                        <attribute name='lux_insuredtitle' />
                                                        <attribute name='lux_quotenumber' />
                                                        <attribute name='statuscode' />
                                                        <attribute name='lux_inceptiondate' />
                                                        <attribute name='lux_broker' />
                                                        <attribute name='lux_quotedpremium' />
                                                        <attribute name='lux_policytotalcommission' />
                                                        <attribute name='lux_mtabrokercommissionpercentage' />
                                                        <attribute name='lux_lepolicygrosspremium' />
                                                        <attribute name='lux_legalexpensesmtapremium' />
                                                        <attribute name='lux_quotedpremiumbrokercommissionamount' />
                                                        <attribute name='lux_quotedpremiumaciescommissionamount' />
                                                        <attribute name='lux_mtabrokercommission' />
                                                        <attribute name='lux_mtaaciescommission' />
                                                        <attribute name='lux_mtagrosspremium' />
                                                        <attribute name='lux_totalquotedpremiuminciptandfee' />
                                                        <attribute name='lux_mtatotalpremiumincipt' />
                                                        <attribute name='lux_policyfee' /> 
                                                        <attribute name='lux_mtapolicyfee' />
                                                        <attribute name='lux_policynetpremium' />
                                                        <attribute name='lux_mtanetpremium' />
                                                        <attribute name='lux_lepolicynetpremium' />
                                                        <attribute name='lux_legalexpensesmtanetpremium' />
                                                        <attribute name='lux_quotedpremiumipt' />
                                                        <attribute name='lux_mtaipt' />
                                                        <attribute name='lux_employersliabilitypolicypremium' />
                                                        <attribute name='lux_employersliabilitymtapremium' />
                                                        <attribute name='lux_propertyownersliabilitypolicypremium' />
                                                        <attribute name='lux_propertyownersliabilitymtapremium' />
                                                        <attribute name='lux_publicproductsliabilitypolicypremium' />
                                                        <attribute name='lux_publicproductsliabilitymtapremium' />
                                                        <attribute name='lux_producttype' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='lux_propertyownersapplicationsid' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970009' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                            var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001 || x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003);
                            var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);
                            var cancellationRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970004);

                            bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                            bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));
                            bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));
                            bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));

                            var BrokerCommission = appln.Attributes["lux_mtabrokercommissionpercentage"];


                            var LEMainPolicyPremium = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicygrosspremium") ? x.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value : 0);
                            var LEMTAPolicyPremium = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);
                            var LECancelPolicyPremium = cancellationRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);

                            var LEPolicyPremium = LEMainPolicyPremium + LEMTAPolicyPremium + LECancelPolicyPremium;
                            var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                            var MainBrokerCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumbrokercommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value : 0);
                            var MainACIESCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumaciescommissionamount") ? x.GetAttributeValue<Money>("lux_quotedpremiumaciescommissionamount").Value : 0);

                            var MTABrokerCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                            var MTAACIESCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                            var CancelBrokerCommAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                            var CancelACIESCommAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                            var CommAmount = MainBrokerCommAmt + MainACIESCommAmt + MTABrokerCommAmt + MTAACIESCommAmt + CancelBrokerCommAmt + CancelACIESCommAmt - LEBrokerCommAmt;

                            bdx["lux_commissionamount"] = (CommAmount <= 0.02M && CommAmount >= -0.02M) ? new Money(0) : new Money(CommAmount);
                            bdx["lux_localsubproducerscommissionamount"] = (MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt <= 0.02M && MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt >= -0.02M) ? new Money(0) : new Money(MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt);

                            var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremium") ? x.GetAttributeValue<Money>("lux_quotedpremium").Value : 0);
                            var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);
                            var CancelGWPAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);

                            bdx["lux_totalgrosswrittenpremium"] = (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium <= 0.02M && MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium >= -0.02M) ? new Money(0) : new Money(MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium);


                            var MainGrossAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_totalquotedpremiuminciptandfee") ? x.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value : 0);
                            var MTAGrossAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);
                            var CancelGrossAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);

                            var PolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_policyfee") ? x.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                            var MTAPolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);
                            var CancelPolicyFee = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);

                            if (isIsleofManPolicy == false)
                            {
                                bdx["lux_grosspremium"] = (MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100 <= 0.02M && MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100 >= -0.02M) ? new Money(0) : new Money(MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100);
                            }
                            else
                            {
                                bdx["lux_grosspremium"] = (MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100 <= 0.02M && MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100 >= -0.02M) ? new Money(0) : new Money(MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100);
                            }

                            var MainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policynetpremium") ? x.GetAttributeValue<Money>("lux_policynetpremium").Value : 0);
                            var MTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);
                            var CancelNetAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);

                            var LEMainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicynetpremium") ? x.GetAttributeValue<Money>("lux_lepolicynetpremium").Value : 0);
                            var LEMTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);
                            var LECancelNetAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);

                            bdx["lux_netpremiumtolondoninoriginalcurrency"] = (MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt <= 0.02M && MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt >= -0.02M) ? new Money(0) : new Money(MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt);
                            bdx["lux_finalnetpremiumoriginalcurrency"] = (MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt <= 0.02M && MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt >= -0.02M) ? new Money(0) : new Money(MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt);

                            bdx["lux_brokerageamountoriginalcurrency"] = (MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt <= 0.02M && MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt >= -0.02M) ? new Money(0) : new Money(MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt);

                            bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                            bdx["lux_otherfeesordeductionsamount"] = (PolicyFee + MTAPolicyFee + CancelPolicyFee <= 0.02M && PolicyFee + MTAPolicyFee + CancelPolicyFee >= -0.02M) ? new Money(0) : new Money(PolicyFee + MTAPolicyFee + CancelPolicyFee);

                            var MainIPTAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumipt") ? x.GetAttributeValue<Money>("lux_quotedpremiumipt").Value : 0);
                            var MTAIPTAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);
                            var CancelIPTAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);

                            bdx["lux_tax1taxtype"] = "IPT";
                            bdx["lux_tax1amountoftaxablepremium"] = (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium <= 0.02M && MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium >= -0.02M) ? new Money(0) : new Money(MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium);

                            if (isIsleofManPolicy == false)
                            {
                                bdx["lux_tax1amount"] = ((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100 <= 0.02M && (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100 >= -0.02M) ? new Money(0) : new Money((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100);
                            }
                            else
                            {
                                bdx["lux_tax1amount"] = ((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100 <= 0.02M && (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100 >= -0.02M) ? new Money(0) : new Money((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100);
                            }

                            var MainELAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0);
                            var MTAELAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);
                            var CancelELAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);

                            bdx["lux_elpremium"] = (MainELAmt + MTAELAmt + CancelELAmt <= 0.02M && MainELAmt + MTAELAmt + CancelELAmt >= -0.02M) ? new Money(0) : new Money(MainELAmt + MTAELAmt + CancelELAmt);

                            var MainPOLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitypolicypremium").Value : 0);
                            var MTAPOLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);
                            var CancelPOLAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);

                            bdx["lux_propertyownersliabilitypremium"] = (MainPOLAmt + MTAPOLAmt + CancelPOLAmt <= 0.02M && MainPOLAmt + MTAPOLAmt + CancelPOLAmt >= -0.02M) ? new Money(0) : new Money(MainPOLAmt + MTAPOLAmt + CancelPOLAmt);

                            var MainPLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0);
                            var MTAPLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);
                            var CancelPLAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);

                            bdx["lux_plpremium"] = (MainPLAmt + MTAPLAmt + CancelPLAmt <= 0.02M && MainPLAmt + MTAPLAmt + CancelPLAmt >= -0.02M) ? new Money(0) : new Money(MainPLAmt + MTAPLAmt + CancelPLAmt);

                            var MainCWAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_contractorspolicypremium") ? x.GetAttributeValue<Money>("lux_contractorspolicypremium").Value : 0);
                            var MTACWAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);
                            var CancelCWAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);

                            bdx["lux_cwpremium"] = (MainCWAmt + MTACWAmt + CancelCWAmt <= 0.02M && MainCWAmt + MTACWAmt + CancelCWAmt >= -0.02M) ? new Money(0) : new Money(MainCWAmt + MTACWAmt + CancelCWAmt);

                            var MainMDAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_materialdamagepolicypremium") ? x.GetAttributeValue<Money>("lux_materialdamagepolicypremium").Value : 0);
                            var MTAMDAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_materialdamagemtapremium") ? x.GetAttributeValue<Money>("lux_materialdamagemtapremium").Value : 0);
                            var CancelMDAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_materialdamagemtapremium") ? x.GetAttributeValue<Money>("lux_materialdamagemtapremium").Value : 0);

                            bdx["lux_propertymdpremium"] = (MainMDAmt + MTAMDAmt + CancelMDAmt <= 0.02M && MainMDAmt + MTAMDAmt + CancelMDAmt >= -0.02M) ? new Money(0) : new Money(MainMDAmt + MTAMDAmt + CancelMDAmt);

                            var MainBIAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionpolicypremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionpolicypremium").Value : 0);
                            var MTABIAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionmtapremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionmtapremium").Value : 0);
                            var CancelBIAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_businessinterruptionmtapremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionmtapremium").Value : 0);

                            bdx["lux_bipremium"] = (MainBIAmt + MTABIAmt + CancelBIAmt <= 0.02M && MainBIAmt + MTABIAmt + CancelBIAmt >= -0.02M) ? new Money(0) : new Money(MainBIAmt + MTABIAmt + CancelBIAmt);

                            bdx["lux_reasonforcancellation"] = appln.Attributes.Contains("lux_reasonforcancellation") ? appln.FormattedValues["lux_reasonforcancellation"].ToString() : "";
                        }
                        else
                        {
                            bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                            bdx["lux_commission"] = Convert.ToDecimal(appln.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));

                            var BrokerCommission = appln.Attributes["lux_policybrokercommission"];
                            var LEPolicyPremium = appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value;
                            var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                            bdx["lux_commissionamount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumtotalcommissionamount").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosscommission").Value - LEBrokerCommAmt);

                            bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(appln.Attributes["lux_policybrokercommission"].ToString().Replace("%", ""));
                            bdx["lux_localsubproducerscommissionamount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value - LEBrokerCommAmt);

                            bdx["lux_totalgrosswrittenpremium"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value);
                            var PolicyFee = appln.GetAttributeValue<Money>("lux_policyfee").Value;

                            if (isIsleofManPolicy == false)
                            {
                                bdx["lux_grosspremium"] = new Money(appln.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value - PolicyFee - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 12 / 100);
                            }
                            else
                            {
                                bdx["lux_grosspremium"] = new Money(appln.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value - PolicyFee - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 0 / 100);
                            }

                            bdx["lux_netpremiumtolondoninoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_policynetpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicynetpremium").Value);
                            bdx["lux_finalnetpremiumoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_policynetpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicynetpremium").Value);

                            bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(appln.Attributes["lux_policybrokercommission"].ToString().Replace("%", ""));
                            bdx["lux_brokerageamountoriginalcurrency"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value - LEBrokerCommAmt);

                            bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                            bdx["lux_otherfeesordeductionsamount"] = new Money(appln.GetAttributeValue<Money>("lux_policyfee").Value);

                            bdx["lux_tax1taxtype"] = "IPT";
                            bdx["lux_tax1amountoftaxablepremium"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremium").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value);

                            if (isIsleofManPolicy == false)
                            {
                                bdx["lux_tax1amount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumipt").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 12 / 100);
                            }
                            else
                            {
                                bdx["lux_tax1amount"] = new Money(appln.GetAttributeValue<Money>("lux_quotedpremiumipt").Value - appln.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value * 0 / 100);
                            }
                        }
                        service.Create(bdx);
                    }
                }
            }
            else
            {
                EntityReference tradesmanref = TradesmanApplication.Get<EntityReference>(executionContext);
                Entity item = service.Retrieve("lux_tradesman", tradesmanref.Id, new ColumnSet(true));

                bool isIsleofManPolicy = false;
                if (item.Attributes.Contains("lux_postcode") && item.Attributes["lux_postcode"].ToString().StartsWith("IM"))
                {
                    isIsleofManPolicy = true;
                }

                var LocationNo = item.Attributes.Contains("lux_locationnumber") ? item.GetAttributeValue<int>("lux_locationnumber") : 1;

                Entity bdx = new Entity("lux_bordereau");
                bdx["lux_lloydsriskcode"] = "B5";
                bdx["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", tradesmanref.Id);
                bdx["lux_policy"] = new EntityReference("lux_policy", policyref.Id);
                bdx["lux_policynumber"] = policy.Attributes.Contains("lux_policynumber") ? policy.Attributes["lux_policynumber"].ToString() : "";
                bdx["lux_inceptiondate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                bdx["lux_expirydate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                bdx["lux_customerclassification"] = item.Attributes.Contains("lux_policyholdertype") ? item.FormattedValues["lux_policyholdertype"].ToString() : "";
                var TransactionType = "Original Premium";
                if (item.Attributes.Contains("lux_applicationtype") && (item.FormattedValues["lux_applicationtype"] == "MTA" || item.FormattedValues["lux_applicationtype"] == "Cancellation"))
                {
                    bdx["lux_covereffectivedate"] = Convert.ToDateTime(item.Attributes.Contains("lux_mtaeffectivedate") == true ? item.FormattedValues["lux_mtaeffectivedate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                    bdx["lux_certificateissuancedate"] = Convert.ToDateTime(policy.Attributes.Contains("modifiedon") == true ? policy.FormattedValues["modifiedon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                    if (item.Attributes.Contains("lux_mtagrosspremium") && item.GetAttributeValue<Money>("lux_mtagrosspremium").Value >= 0)
                    {
                        TransactionType = "Additional Premium";
                    }
                    else if (item.Attributes.Contains("lux_mtagrosspremium") && item.GetAttributeValue<Money>("lux_mtagrosspremium").Value < 0)
                    {
                        TransactionType = "Returned Premium";
                    }
                }
                else
                {
                    bdx["lux_covereffectivedate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                    bdx["lux_certificateissuancedate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                }
                bdx["lux_locationid"] = LocationNo.ToString();
                if (policy.FormattedValues["lux_policytype"] == "Renewal")
                {
                    bdx["lux_neworrenewal"] = "Renewal";
                }
                else
                {
                    bdx["lux_neworrenewal"] = "New";
                }
                bdx["lux_nameofinsured"] = item.Attributes.Contains("lux_insuredtitle") ? item.Attributes["lux_insuredtitle"] : "";
                bdx["lux_insuredaddress"] = (item.Attributes.Contains("lux_housenumber") ? item.Attributes["lux_housenumber"] + ", " : "") + (item.Attributes.Contains("lux_street") ? item.Attributes["lux_street"] + ", " : "") + (item.Attributes.Contains("lux_citycounty") ? item.Attributes["lux_citycounty"] : "");
                bdx["lux_insuredzipcodepostalcode"] = item.Attributes.Contains("lux_postcode") == true ? item.Attributes["lux_postcode"] : "";
                bdx["lux_insuredcountry"] = "United Kingdom";

                bdx["lux_locationofriskaddress"] = (item.Attributes.Contains("lux_housenumber") ? item.Attributes["lux_housenumber"] + ", " : "") + (item.Attributes.Contains("lux_street") ? item.Attributes["lux_street"] + ", " : "") + (item.Attributes.Contains("lux_citycounty") ? item.Attributes["lux_citycounty"] : "");
                bdx["lux_locationofriskpostcodezipcodeorsimilar"] = item.Attributes.Contains("lux_postcode") == true ? item.Attributes["lux_postcode"] : "";
                bdx["lux_locationofriskcountry"] = "United Kingdom";

                //var TotalMDInsurableValues = item.Attributes.Contains("lux_totalmdsuminsured") == true ? item.GetAttributeValue<Money>("lux_totalmdsuminsured").Value : 0;
                //var TotalBIInsurableValues = item.Attributes.Contains("lux_totalbisuminsured") == true ? item.GetAttributeValue<Money>("lux_totalbisuminsured").Value : 0;
                //var TotalInsurableValues = TotalMDInsurableValues + TotalBIInsurableValues;
                //bdx["lux_totalinsurablevalues"] = new Money(TotalInsurableValues);

                //var SumInsuredAmount = item.Attributes.Contains("lux_totalsuminsured") == true ? item.GetAttributeValue<Money>("lux_totalsuminsured").Value : 0;
                //bdx["lux_suminsuredamount"] = new Money(SumInsuredAmount);
                bdx["lux_suminsuredcurrency"] = "GBP";
                bdx["lux_transactiontypeoriginalpremiumetc"] = TransactionType;
                bdx["lux_reasonforcancellation"] = "";
                bdx["lux_propertytype"] = "Commercial";
                bdx["lux_occupancytype"] = "Commercial";
                bdx["lux_occupancycategory"] = "Commercial";
                bdx["lux_occupancydescription"] = "Commercial";

                bdx["lux_mdbuildingdeclaredvalue"] = new Money(0);
                bdx["lux_mdtenantsimprovementsdeclaredvalue"] = new Money(0);
                bdx["lux_mdcontentsdeclaredvalue"] = new Money(0);
                bdx["lux_mdcontentsofcommunalarea"] = new Money(0);
                bdx["lux_mdcomputerandelectronicbusinessequipment"] = new Money(0);
                bdx["lux_mdlossofrentpayable"] = new Money(0);
                bdx["lux_mdstockexcludingtargetstock"] = new Money(0);
                bdx["lux_mdcigarettescigarsortobaccoproducts"] = new Money(0);
                bdx["lux_mdwinesandspiritssuminsured"] = new Money(0);
                bdx["lux_mdtotaldeclaredvalue"] = new Money(0);

                bdx["lux_biincreasedcostofworking"] = new Money(0);
                bdx["lux_biadditionalincreasedcostofworking"] = new Money(0);
                bdx["lux_bibookdebts"] = new Money(0);
                bdx["lux_birentreceivable"] = new Money(0);
                bdx["lux_bilossoflicence"] = new Money(0);
                bdx["lux_bisuminsured"] = new Money(0);

                if (item.Attributes.Contains("lux_applicationtype") && item.FormattedValues["lux_applicationtype"] == "MTA")
                {
                    var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_tradesman'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_postcode' />
                                                        <attribute name='lux_insuredtitle' />
                                                        <attribute name='lux_quotenumber' />
                                                        <attribute name='statuscode' />
                                                        <attribute name='lux_inceptiondate' />
                                                        <attribute name='lux_broker' />
                                                        <attribute name='lux_policypremiumbeforeipt' />
                                                        <attribute name='lux_policytotalcommission' />
                                                        <attribute name='lux_mtabrokercommissionpercentage' />
                                                        <attribute name='lux_legalexpensespolicygrosspremium' />
                                                        <attribute name='lux_legalexpensesmtapremium' />
                                                        <attribute name='lux_policybrokercommissionamount' />
                                                        <attribute name='lux_policyaciescommissionamount' />
                                                        <attribute name='lux_mtabrokercommission' />
                                                        <attribute name='lux_mtaaciescommission' />
                                                        <attribute name='lux_mtagrosspremium' />
                                                        <attribute name='lux_policytotalpremiuminciptandfee' />
                                                        <attribute name='lux_mtatotalpremiumincipt' />
                                                        <attribute name='lux_policyfee' />
                                                        <attribute name='lux_mtapolicyfee' />
                                                        <attribute name='lux_policynetpremiumexcludingipt' />
                                                        <attribute name='lux_mtanetpremium' />
                                                        <attribute name='lux_legalexpensespolicynetpremium' />
                                                        <attribute name='lux_legalexpensesmtanetpremium' />
                                                        <attribute name='lux_policyipt' />
                                                        <attribute name='lux_mtaipt' />
                                                        <attribute name='lux_elpolicypremium' />
                                                        <attribute name='lux_employersliabilitymtapremium' />
                                                        <attribute name='lux_plpolicypremium' />
                                                        <attribute name='lux_publicproductsliabilitymtapremium' />
                                                        <attribute name='lux_carpolicypremium' />
                                                        <attribute name='lux_contractorsmtapremium' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='lux_tradesmanid' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970006' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                    var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001 || x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003);
                    var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);

                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                    bdx["lux_commission"] = Convert.ToDecimal(item.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));
                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(item.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));
                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(item.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));

                    var BrokerCommission = item.Attributes["lux_mtabrokercommissionpercentage"];

                    var LEMainPolicyPremium = mainRecord.Sum(x => x.Attributes.Contains("lux_legalexpensespolicygrosspremium") ? x.GetAttributeValue<Money>("lux_legalexpensespolicygrosspremium").Value : 0);
                    var LEMTAPolicyPremium = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);

                    var LEPolicyPremium = LEMainPolicyPremium + LEMTAPolicyPremium;
                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                    var MainBrokerCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policybrokercommissionamount") ? x.GetAttributeValue<Money>("lux_policybrokercommissionamount").Value : 0);
                    var MainACIESCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policyaciescommissionamount") ? x.GetAttributeValue<Money>("lux_policyaciescommissionamount").Value : 0);

                    var MTABrokerCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                    var MTAACIESCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                    var CommAmount = MainBrokerCommAmt + MainACIESCommAmt + MTABrokerCommAmt + MTAACIESCommAmt - LEBrokerCommAmt;

                    bdx["lux_commissionamount"] = new Money(CommAmount);
                    bdx["lux_localsubproducerscommissionamount"] = new Money(MainBrokerCommAmt + MTABrokerCommAmt - LEBrokerCommAmt);

                    var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policypremiumbeforeipt") ? x.GetAttributeValue<Money>("lux_policypremiumbeforeipt").Value : 0);
                    var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);

                    bdx["lux_totalgrosswrittenpremium"] = new Money(MainGWPAmt + MTAGWPAmt - LEPolicyPremium);

                    var MainGrossAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policytotalpremiuminciptandfee") ? x.GetAttributeValue<Money>("lux_policytotalpremiuminciptandfee").Value : 0);
                    var MTAGrossAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);

                    var PolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_policyfee") ? x.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                    var MTAPolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);

                    if (isIsleofManPolicy == false)
                    {
                        bdx["lux_grosspremium"] = new Money(MainGrossAmt + MTAGrossAmt - PolicyFee - MTAPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100);
                    }
                    else
                    {
                        bdx["lux_grosspremium"] = new Money(MainGrossAmt + MTAGrossAmt - PolicyFee - MTAPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100);
                    }

                    var MainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policynetpremiumexcludingipt") ? x.GetAttributeValue<Money>("lux_policynetpremiumexcludingipt").Value : 0);
                    var MTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);

                    var LEMainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_legalexpensespolicynetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensespolicynetpremium").Value : 0);
                    var LEMTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);

                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = new Money(MainNetAmt + MTANetAmt - LEMainNetAmt - LEMTANetAmt);
                    bdx["lux_finalnetpremiumoriginalcurrency"] = new Money(MainNetAmt + MTANetAmt - LEMainNetAmt - LEMTANetAmt);

                    bdx["lux_brokerageamountoriginalcurrency"] = new Money(MainBrokerCommAmt + MTABrokerCommAmt - LEBrokerCommAmt);

                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                    bdx["lux_otherfeesordeductionsamount"] = new Money(PolicyFee + MTAPolicyFee);

                    var MainIPTAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policyipt") ? x.GetAttributeValue<Money>("lux_policyipt").Value : 0);
                    var MTAIPTAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);

                    bdx["lux_tax1taxtype"] = "IPT";
                    bdx["lux_tax1amountoftaxablepremium"] = new Money(MainGWPAmt + MTAGWPAmt - LEPolicyPremium);

                    if (isIsleofManPolicy == false)
                    {
                        bdx["lux_tax1amount"] = new Money((MainGWPAmt + MTAGWPAmt - LEPolicyPremium) * 12 / 100);
                    }
                    else
                    {
                        bdx["lux_tax1amount"] = new Money((MainGWPAmt + MTAGWPAmt - LEPolicyPremium) * 0 / 100);
                    }

                    var MainELAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_elpolicypremium") ? x.GetAttributeValue<Money>("lux_elpolicypremium").Value : 0);
                    var MTAELAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);
                    bdx["lux_elpremium"] = new Money(MainELAmt + MTAELAmt);

                    var MainPLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_plpolicypremium") ? x.GetAttributeValue<Money>("lux_plpolicypremium").Value : 0);
                    var MTAPLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);
                    bdx["lux_plpremium"] = new Money(MainPLAmt + MTAPLAmt);

                    var MainCWAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_carpolicypremium") ? x.GetAttributeValue<Money>("lux_carpolicypremium").Value : 0);
                    var MTACWAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);
                    bdx["lux_cwpremium"] = new Money(MainCWAmt + MTACWAmt);
                }
                if (item.Attributes.Contains("lux_applicationtype") && item.FormattedValues["lux_applicationtype"] == "Cancellation")
                {
                    var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_tradesman'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_postcode' />
                                                        <attribute name='lux_insuredtitle' />
                                                        <attribute name='lux_quotenumber' />
                                                        <attribute name='statuscode' />
                                                        <attribute name='lux_inceptiondate' />
                                                        <attribute name='lux_broker' />
                                                        <attribute name='lux_policypremiumbeforeipt' />
                                                        <attribute name='lux_policytotalcommission' />
                                                        <attribute name='lux_mtabrokercommissionpercentage' />
                                                        <attribute name='lux_legalexpensespolicygrosspremium' />
                                                        <attribute name='lux_legalexpensesmtapremium' />
                                                        <attribute name='lux_policybrokercommissionamount' />
                                                        <attribute name='lux_policyaciescommissionamount' />
                                                        <attribute name='lux_mtabrokercommission' />
                                                        <attribute name='lux_mtaaciescommission' />
                                                        <attribute name='lux_mtagrosspremium' />
                                                        <attribute name='lux_policytotalpremiuminciptandfee' />
                                                        <attribute name='lux_mtatotalpremiumincipt' />
                                                        <attribute name='lux_policyfee' />
                                                        <attribute name='lux_mtapolicyfee' />
                                                        <attribute name='lux_policynetpremiumexcludingipt' />
                                                        <attribute name='lux_mtanetpremium' />
                                                        <attribute name='lux_legalexpensespolicynetpremium' />
                                                        <attribute name='lux_legalexpensesmtanetpremium' />
                                                        <attribute name='lux_policyipt' />
                                                        <attribute name='lux_mtaipt' />
                                                        <attribute name='lux_elpolicypremium' />
                                                        <attribute name='lux_employersliabilitymtapremium' />
                                                        <attribute name='lux_plpolicypremium' />
                                                        <attribute name='lux_publicproductsliabilitymtapremium' />
                                                        <attribute name='lux_carpolicypremium' />
                                                        <attribute name='lux_contractorsmtapremium' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='lux_tradesmanid' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970006' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                    var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001 || x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003);
                    var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);
                    var cancellationRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970004);

                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                    bdx["lux_commission"] = Convert.ToDecimal(item.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));
                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(item.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));
                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(item.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", ""));

                    var BrokerCommission = item.Attributes["lux_mtabrokercommissionpercentage"];

                    var LEMainPolicyPremium = mainRecord.Sum(x => x.Attributes.Contains("lux_legalexpensespolicygrosspremium") ? x.GetAttributeValue<Money>("lux_legalexpensespolicygrosspremium").Value : 0);
                    var LEMTAPolicyPremium = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);
                    var LECancelPolicyPremium = cancellationRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);

                    var LEPolicyPremium = LEMainPolicyPremium + LEMTAPolicyPremium + LECancelPolicyPremium;
                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                    var MainBrokerCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policybrokercommissionamount") ? x.GetAttributeValue<Money>("lux_policybrokercommissionamount").Value : 0);
                    var MainACIESCommAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policyaciescommissionamount") ? x.GetAttributeValue<Money>("lux_policyaciescommissionamount").Value : 0);

                    var MTABrokerCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                    var MTAACIESCommAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                    var CancelBrokerCommAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                    var CancelACIESCommAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);

                    var CommAmount = MainBrokerCommAmt + MainACIESCommAmt + MTABrokerCommAmt + MTAACIESCommAmt + CancelBrokerCommAmt + CancelACIESCommAmt - LEBrokerCommAmt;

                    bdx["lux_commissionamount"] = (CommAmount <= 0.02M && CommAmount >= -0.02M) ? new Money(0) : new Money(CommAmount);
                    bdx["lux_localsubproducerscommissionamount"] = (MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt <= 0.02M && MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt >= -0.02M) ? new Money(0) : new Money(MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt);

                    var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremium") ? x.GetAttributeValue<Money>("lux_quotedpremium").Value : 0);
                    var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);
                    var CancelGWPAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);

                    bdx["lux_totalgrosswrittenpremium"] = (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium <= 0.02M && MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium >= -0.02M) ? new Money(0) : new Money(MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium);

                    var MainGrossAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_totalquotedpremiuminciptandfee") ? x.GetAttributeValue<Money>("lux_totalquotedpremiuminciptandfee").Value : 0);
                    var MTAGrossAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);
                    var CancelGrossAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtatotalpremiumincipt") ? x.GetAttributeValue<Money>("lux_mtatotalpremiumincipt").Value : 0);

                    var PolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_policyfee") ? x.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                    var MTAPolicyFee = mainRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);
                    var CancelPolicyFee = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtapolicyfee") ? x.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);

                    if (isIsleofManPolicy == false)
                    {
                        bdx["lux_grosspremium"] = (MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100 <= 0.02M && MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100 >= -0.02M) ? new Money(0) : new Money(MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 12 / 100);
                    }
                    else
                    {
                        bdx["lux_grosspremium"] = (MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100 <= 0.02M && MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100 >= -0.02M) ? new Money(0) : new Money(MainGrossAmt + MTAGrossAmt + CancelGrossAmt - PolicyFee - MTAPolicyFee - CancelPolicyFee - LEPolicyPremium - LEPolicyPremium * 0 / 100);
                    }

                    var MainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_policynetpremium") ? x.GetAttributeValue<Money>("lux_policynetpremium").Value : 0);
                    var MTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);
                    var CancelNetAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtanetpremium") ? x.GetAttributeValue<Money>("lux_mtanetpremium").Value : 0);

                    var LEMainNetAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_lepolicynetpremium") ? x.GetAttributeValue<Money>("lux_lepolicynetpremium").Value : 0);
                    var LEMTANetAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);
                    var LECancelNetAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);

                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = (MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt <= 0.02M && MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt >= -0.02M) ? new Money(0) : new Money(MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt);
                    bdx["lux_finalnetpremiumoriginalcurrency"] = (MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt <= 0.02M && MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt >= -0.02M) ? new Money(0) : new Money(MainNetAmt + MTANetAmt + CancelNetAmt - LEMainNetAmt - LEMTANetAmt - LECancelNetAmt);

                    bdx["lux_brokerageamountoriginalcurrency"] = (MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt <= 0.02M && MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt >= -0.02M) ? new Money(0) : new Money(MainBrokerCommAmt + MTABrokerCommAmt + CancelBrokerCommAmt - LEBrokerCommAmt);

                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                    bdx["lux_otherfeesordeductionsamount"] = (PolicyFee + MTAPolicyFee + CancelPolicyFee <= 0.02M && PolicyFee + MTAPolicyFee + CancelPolicyFee >= -0.02M) ? new Money(0) : new Money(PolicyFee + MTAPolicyFee + CancelPolicyFee);

                    var MainIPTAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_quotedpremiumipt") ? x.GetAttributeValue<Money>("lux_quotedpremiumipt").Value : 0);
                    var MTAIPTAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);
                    var CancelIPTAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_mtaipt") ? x.GetAttributeValue<Money>("lux_mtaipt").Value : 0);

                    bdx["lux_tax1taxtype"] = "IPT";
                    bdx["lux_tax1amountoftaxablepremium"] = (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium <= 0.02M && MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium >= -0.02M) ? new Money(0) : new Money(MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium);


                    if (isIsleofManPolicy == false)
                    {
                        bdx["lux_tax1amount"] = ((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100 <= 0.02M && (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100 >= -0.02M) ? new Money(0) : new Money((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 12 / 100);
                    }
                    else
                    {
                        bdx["lux_tax1amount"] = ((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100 <= 0.02M && (MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100 >= -0.02M) ? new Money(0) : new Money((MainGWPAmt + MTAGWPAmt + CancelGWPAmt - LEPolicyPremium) * 0 / 100);
                    }

                    var MainELAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0);
                    var MTAELAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);
                    var CancelELAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);

                    bdx["lux_elpremium"] = (MainELAmt + MTAELAmt + CancelELAmt <= 0.02M && MainELAmt + MTAELAmt + CancelELAmt >= -0.02M) ? new Money(0) : new Money(MainELAmt + MTAELAmt + CancelELAmt);

                    var MainPLAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0);
                    var MTAPLAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);
                    var CancelPLAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);

                    bdx["lux_plpremium"] = (MainPLAmt + MTAPLAmt + CancelPLAmt <= 0.02M && MainPLAmt + MTAPLAmt + CancelPLAmt >= -0.02M) ? new Money(0) : new Money(MainPLAmt + MTAPLAmt + CancelPLAmt);

                    var MainCWAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_contractorspolicypremium") ? x.GetAttributeValue<Money>("lux_contractorspolicypremium").Value : 0);
                    var MTACWAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);
                    var CancelCWAmt = cancellationRecord.Sum(x => x.Attributes.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);

                    bdx["lux_cwpremium"] = (MainCWAmt + MTACWAmt + CancelCWAmt <= 0.02M && MainCWAmt + MTACWAmt + CancelCWAmt >= -0.02M) ? new Money(0) : new Money(MainCWAmt + MTACWAmt + CancelCWAmt);

                    bdx["lux_reasonforcancellation"] = item.Attributes.Contains("lux_reasonforcancellation") ? item.FormattedValues["lux_reasonforcancellation"].ToString() : "";
                }
                else
                {
                    bdx["lux_grosspremiumpaidthistime"] = new Money(0);
                    bdx["lux_commission"] = Convert.ToDecimal(item.Attributes["lux_policytotalcommission"].ToString().Replace("%", ""));

                    var BrokerCommission = item.Attributes["lux_policybrokercommission"];
                    var LEPolicyPremium = item.GetAttributeValue<Money>("lux_legalexpensespolicygrosspremium").Value;
                    var LEBrokerCommAmt = LEPolicyPremium * Convert.ToDecimal(BrokerCommission.ToString().Replace("%", "")) / 100;

                    bdx["lux_commissionamount"] = new Money(item.GetAttributeValue<Money>("lux_policytotalcommissionamount").Value - item.GetAttributeValue<Money>("lux_policyacieslegalexpensescommissionamount").Value - LEBrokerCommAmt);

                    bdx["lux_localsubproducerscommission"] = Convert.ToDecimal(item.Attributes["lux_policybrokercommission"].ToString().Replace("%", ""));
                    bdx["lux_localsubproducerscommissionamount"] = new Money(item.GetAttributeValue<Money>("lux_policybrokercommissionamount").Value - LEBrokerCommAmt);

                    bdx["lux_totalgrosswrittenpremium"] = new Money(item.GetAttributeValue<Money>("lux_policypremiumbeforeipt").Value - item.GetAttributeValue<Money>("lux_legalexpensespolicygrosspremium").Value);
                    var PolicyFee = item.GetAttributeValue<Money>("lux_policyfee").Value;

                    if (isIsleofManPolicy == false)
                    {
                        bdx["lux_grosspremium"] = new Money(item.GetAttributeValue<Money>("lux_policytotalpremiuminciptandfee").Value - PolicyFee - item.GetAttributeValue<Money>("lux_legalexpensespolicygrosspremium").Value - item.GetAttributeValue<Money>("lux_legalexpensespolicygrosspremium").Value * 12 / 100);
                    }
                    else
                    {
                        bdx["lux_grosspremium"] = new Money(item.GetAttributeValue<Money>("lux_policytotalpremiuminciptandfee").Value - PolicyFee - item.GetAttributeValue<Money>("lux_legalexpensespolicygrosspremium").Value - item.GetAttributeValue<Money>("lux_legalexpensespolicygrosspremium").Value * 0 / 100);
                    }

                    bdx["lux_netpremiumtolondoninoriginalcurrency"] = new Money(item.GetAttributeValue<Money>("lux_policynetpremiumexcludingipt").Value - item.GetAttributeValue<Money>("lux_legalexpensespolicynetpremium").Value);
                    bdx["lux_finalnetpremiumoriginalcurrency"] = new Money(item.GetAttributeValue<Money>("lux_policynetpremiumexcludingipt").Value - item.GetAttributeValue<Money>("lux_legalexpensespolicynetpremium").Value);

                    bdx["lux_brokeragepercentofgrosspremium"] = Convert.ToDecimal(item.Attributes["lux_policybrokercommission"].ToString().Replace("%", ""));
                    bdx["lux_brokerageamountoriginalcurrency"] = new Money(item.GetAttributeValue<Money>("lux_policybrokercommissionamount").Value - LEBrokerCommAmt);

                    bdx["lux_otherfeesordeductionsdescription"] = "Admin Fee";
                    bdx["lux_otherfeesordeductionsamount"] = new Money(item.GetAttributeValue<Money>("lux_policyfee").Value);

                    bdx["lux_tax1taxtype"] = "IPT";
                    bdx["lux_tax1amountoftaxablepremium"] = new Money(item.GetAttributeValue<Money>("lux_policypremiumbeforeipt").Value - item.GetAttributeValue<Money>("lux_legalexpensespolicygrosspremium").Value);

                    if (isIsleofManPolicy == false)
                    {
                        bdx["lux_tax1amount"] = new Money((item.GetAttributeValue<Money>("lux_policypremiumbeforeipt").Value - item.GetAttributeValue<Money>("lux_legalexpensespolicygrosspremium").Value) * 12 / 100);
                    }
                    else
                    {
                        bdx["lux_tax1amount"] = new Money((item.GetAttributeValue<Money>("lux_policypremiumbeforeipt").Value - item.GetAttributeValue<Money>("lux_legalexpensespolicygrosspremium").Value) * 0 / 100);
                    }
                }
                service.Create(bdx);
            }
        }
    }
}


//var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
//                  <entity name='lux_bordereau'>
//                    <attribute name='lux_wallconstructiontype2' />
//                    <attribute name='lux_wallconstructiontype1' />
//                    <attribute name='lux_totalgrosswrittenpremium' />
//                    <attribute name='lux_tax1taxtype' />
//                    <attribute name='lux_tax1amountoftaxablepremium' />
//                    <attribute name='lux_tax1amount' />
//                    <attribute name='lux_suminsuredamount' />
//                    <attribute name='lux_roofconstructiontype2' />
//                    <attribute name='lux_roofconstructiontype1' />
//                    <attribute name='lux_reasonforcancellation' />
//                    <attribute name='lux_propertytype' />
//                    <attribute name='lux_policynumber' />
//                    <attribute name='lux_otherfeesordeductionsdescription' />
//                    <attribute name='lux_otherfeesordeductionsamount' />
//                    <attribute name='lux_occupancytype' />
//                    <attribute name='lux_occupancydescription' />
//                    <attribute name='lux_occupancycategory' />
//                    <attribute name='lux_netpremiumtolondoninoriginalcurrency' />
//                    <attribute name='lux_nameofinsured' />
//                    <attribute name='lux_locationofriskpostcodezipcodeorsimilar' />
//                    <attribute name='lux_locationofriskcountry' />
//                    <attribute name='lux_locationofriskaddress' />
//                    <attribute name='lux_localsubproducerscommissionamount' />
//                    <attribute name='lux_lloydsriskcode' />
//                    <attribute name='lux_insuredzipcodepostalcode' />
//                    <attribute name='lux_insuredcountry' />
//                    <attribute name='lux_insuredaddress' />
//                    <attribute name='lux_inceptiondate' />
//                    <attribute name='lux_grosspremiumpaidthistime' />
//                    <attribute name='lux_grosspremium' />
//                    <attribute name='lux_finalnetpremiumoriginalcurrency' />
//                    <attribute name='lux_expirydate' />
//                    <attribute name='lux_covereffectivedate' />
//                    <attribute name='lux_commissionamount' />
//                    <attribute name='lux_brokerageamountoriginalcurrency' />
//                    <attribute name='lux_certificateissuancedate' />
//                    <attribute name='lux_totalinsurablevalues' />
//                    <attribute name='lux_transactiontypeoriginalpremiumetc' />
//                    <attribute name='lux_suminsuredcurrency' />
//                    <attribute name='lux_neworrenewal' />
//                    <attribute name='lux_commission' />
//                    <attribute name='lux_localsubproducerscommission' />
//                    <attribute name='lux_brokeragepercentofgrosspremium' />
//                    <attribute name='lux_locationid' />
//                    <attribute name='lux_plpremium' />
//                    <attribute name='lux_elpremium' />
//                    <attribute name='lux_wageroll' />
//                    <attribute name='lux_turnover' />
//                    <attribute name='lux_trade' />
//                    <attribute name='lux_propertyownersliabilitypremium' />
//                    <attribute name='lux_application' />
//                    <attribute name='lux_floodcover' />
//                    <attribute name='lux_bordereauid' />
//                    <order attribute='lux_covereffectivedate' descending='false' />
//                    <filter type='and'>
//                      <condition attribute='statecode' operator='eq' value='0' />
//                      <condition attribute='lux_covereffectivedate' operator='on-or-after' value='2021-05-01' />
//                      <condition attribute='lux_application' operator='not-null' />
//                    </filter>
//                  </entity>
//                </fetch>";

//if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
//{
//    var bordereau = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
//    foreach (var item1 in bordereau)
//    {
//        var application = service.Retrieve("lux_propertyownersapplications", item1.GetAttributeValue<EntityReference>("lux_application").Id, new ColumnSet("lux_insuranceproductrequired"));
//        if (application.FormattedValues["lux_insuranceproductrequired"] == "Property Owners" || application.FormattedValues["lux_insuranceproductrequired"] == "Unoccupied")
//        {
//            var premfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
//                      <entity name='lux_propertyownerspremise'>
//                        <attribute name='lux_subsidencescore' />
//                        <attribute name='lux_securityrating' />
//                        <attribute name='lux_covers' />
//                        <attribute name='lux_riskpostcode' />
//                        <attribute name='lux_locationnumber' />
//                        <attribute name='lux_propertyownerspremiseid' />
//                        <order attribute='lux_locationnumber' descending='false' />
//                        <filter type='and'>
//                          <condition attribute='statecode' operator='eq' value='0' />
//                          <condition attribute='lux_locationnumber' operator='eq' value='{item1.GetAttributeValue<string>("lux_locationid")}' />
//                          <condition attribute='lux_propertyownersapplication' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{application.Id}' />
//                        </filter>
//                      </entity>
//                    </fetch>";

//            if (service.RetrieveMultiple(new FetchExpression(premfetch)).Entities.Count > 0)
//            {
//                var item = service.RetrieveMultiple(new FetchExpression(premfetch)).Entities[0];
//                Entity bdx = service.Retrieve("lux_bordereau", item1.Id, new ColumnSet("lux_floodcover"));
//                if (item.Attributes.Contains("lux_covers"))
//                {
//                    if (item.GetAttributeValue<OptionSetValueCollection>("lux_covers").Contains(new OptionSetValue(972970011)))
//                    {
//                        bdx["lux_floodcover"] = true;
//                    }
//                    else
//                    {
//                        bdx["lux_floodcover"] = false;
//                    }
//                }
//                else
//                {
//                    bdx["lux_floodcover"] = false;
//                }
//                service.Update(bdx);
//            }
//        }
//        else if (application.FormattedValues["lux_insuranceproductrequired"] == "Retail")
//        {
//            var premfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
//                                  <entity name='lux_propertyownersretail'>
//                                    <attribute name='lux_propertyownersretailid' />
//                                    <attribute name='lux_name' />
//                                    <attribute name='lux_riskpostcode' />       
//                                    <attribute name='lux_materialdamagecoverdetails' />       
//                                    <attribute name='lux_locationnumber' />
//                                    <attribute name='createdon' />
//                                    <order attribute='lux_locationnumber' descending='false' />
//                                    <filter type='and'>
//                                      <condition attribute='statecode' operator='eq' value='0' />
//                                      <condition attribute='lux_locationnumber' operator='eq' value='{item1.GetAttributeValue<string>("lux_locationid")}' />
//                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{application.Id}' />
//                                    </filter>
//                                  </entity>
//                                </fetch>";

//            if (service.RetrieveMultiple(new FetchExpression(premfetch)).Entities.Count > 0)
//            {
//                var item = service.RetrieveMultiple(new FetchExpression(premfetch)).Entities[0];
//                Entity bdx = service.Retrieve("lux_bordereau", item1.Id, new ColumnSet("lux_floodcover"));
//                if (item.Attributes.Contains("lux_materialdamagecoverdetails"))
//                {
//                    if (item.GetAttributeValue<OptionSetValueCollection>("lux_materialdamagecoverdetails").Contains(new OptionSetValue(972970011)))
//                    {
//                        bdx["lux_floodcover"] = true;
//                    }
//                    else
//                    {
//                        bdx["lux_floodcover"] = false;
//                    }
//                }
//                else
//                {
//                    bdx["lux_floodcover"] = false;
//                }
//                service.Update(bdx);
//            }
//        }
//        else if (application.FormattedValues["lux_insuranceproductrequired"] == "Pubs & Restaurants" || application.FormattedValues["lux_insuranceproductrequired"] == "Hotels and Guesthouses")
//        {
//            var premfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
//                                  <entity name='lux_pubsrestaurantspropertyownersapplicatio'>
//                                    <attribute name='lux_pubsrestaurantspropertyownersapplicatioid' />
//                                    <attribute name='lux_name' />
//                                    <attribute name='lux_riskpostcode' />       
//                                    <attribute name='lux_materialdamagecoverdetails' />       
//                                    <attribute name='lux_locationnumber' />
//                                    <attribute name='createdon' />
//                                    <order attribute='lux_locationnumber' descending='false' />
//                                    <filter type='and'>
//                                      <condition attribute='statecode' operator='eq' value='0' />
//                                      <condition attribute='lux_locationnumber' operator='eq' value='{item1.GetAttributeValue<string>("lux_locationid")}' />
//                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{application.Id}' />
//                                    </filter>
//                                  </entity>
//                                </fetch>";

//            if (service.RetrieveMultiple(new FetchExpression(premfetch)).Entities.Count > 0)
//            {
//                var item = service.RetrieveMultiple(new FetchExpression(premfetch)).Entities[0];
//                Entity bdx = service.Retrieve("lux_bordereau", item1.Id, new ColumnSet("lux_floodcover"));
//                if (item.Attributes.Contains("lux_materialdamagecoverdetails"))
//                {
//                    if (item.GetAttributeValue<OptionSetValueCollection>("lux_materialdamagecoverdetails").Contains(new OptionSetValue(972970011)))
//                    {
//                        bdx["lux_floodcover"] = true;
//                    }
//                    else
//                    {
//                        bdx["lux_floodcover"] = false;
//                    }
//                }
//                else
//                {
//                    bdx["lux_floodcover"] = false;
//                }
//                service.Update(bdx);
//            }
//        }
//        else if (application.FormattedValues["lux_insuranceproductrequired"] == "Commercial Combined")
//        {
//            var premfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
//                                  <entity name='lux_commercialcombinedapplication'>
//                                    <attribute name='lux_commercialcombinedapplicationid' />
//                                    <attribute name='lux_name' />
//                                    <attribute name='lux_riskpostcode' />       
//                                    <attribute name='lux_materialdamagecoverdetails' />       
//                                    <attribute name='lux_locationnumber' />
//                                    <attribute name='createdon' />
//                                    <order attribute='lux_locationnumber' descending='false' />
//                                    <filter type='and'>
//                                      <condition attribute='statecode' operator='eq' value='0' />
//                                      <condition attribute='lux_locationnumber' operator='eq' value='{item1.GetAttributeValue<string>("lux_locationid")}' />
//                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{application.Id}' />
//                                    </filter>
//                                  </entity>
//                                </fetch>";

//            if (service.RetrieveMultiple(new FetchExpression(premfetch)).Entities.Count > 0)
//            {
//                var item = service.RetrieveMultiple(new FetchExpression(premfetch)).Entities[0];
//                Entity bdx = service.Retrieve("lux_bordereau", item1.Id, new ColumnSet("lux_floodcover"));
//                if (item.Attributes.Contains("lux_materialdamagecoverdetails"))
//                {
//                    if (item.GetAttributeValue<OptionSetValueCollection>("lux_materialdamagecoverdetails").Contains(new OptionSetValue(972970011)))
//                    {
//                        bdx["lux_floodcover"] = true;
//                    }
//                    else
//                    {
//                        bdx["lux_floodcover"] = false;
//                    }
//                }
//                else
//                {
//                    bdx["lux_floodcover"] = false;
//                }
//                service.Update(bdx);
//            }
//        }
//        else if (application.FormattedValues["lux_insuranceproductrequired"] == "Contractors Combined")
//        {
//            var premfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
//                                  <entity name='lux_contractorscombined'>
//                                    <attribute name='lux_contractorscombinedid' />
//                                    <attribute name='lux_name' />
//                                    <attribute name='lux_riskpostcode' />       
//                                    <attribute name='lux_materialdamagecoverdetails' />       
//                                    <attribute name='lux_locationnumber' />
//                                    <attribute name='createdon' />
//                                    <order attribute='lux_locationnumber' descending='false' />
//                                    <filter type='and'>
//                                      <condition attribute='statecode' operator='eq' value='0' />
//                                      <condition attribute='lux_locationnumber' operator='eq' value='{item1.GetAttributeValue<string>("lux_locationid")}' />
//                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{application.Id}' />
//                                    </filter>
//                                  </entity>
//                                </fetch>";

//            if (service.RetrieveMultiple(new FetchExpression(premfetch)).Entities.Count > 0)
//            {
//                var item = service.RetrieveMultiple(new FetchExpression(premfetch)).Entities[0];
//                Entity bdx = service.Retrieve("lux_bordereau", item1.Id, new ColumnSet("lux_floodcover"));
//                if (item.Attributes.Contains("lux_materialdamagecoverdetails"))
//                {
//                    if (item.GetAttributeValue<OptionSetValueCollection>("lux_materialdamagecoverdetails").Contains(new OptionSetValue(972970011)))
//                    {
//                        bdx["lux_floodcover"] = true;
//                    }
//                    else
//                    {
//                        bdx["lux_floodcover"] = false;
//                    }
//                }
//                else
//                {
//                    bdx["lux_floodcover"] = false;
//                }
//                service.Update(bdx);
//            }
//        }
//        else
//        {
//            Entity bdx = service.Retrieve("lux_bordereau", item1.Id, new ColumnSet("lux_floodcover"));
//            bdx["lux_floodcover"] = false;
//            service.Update(bdx);
//        }
//    }
//}