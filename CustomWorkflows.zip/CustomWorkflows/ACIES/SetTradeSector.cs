﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class SetTradeSector : CodeActivity
    {
        [RequiredArgument]
        [Input("TradeSegmentTxt")]
        public InArgument<string> TradeSegmentTxt { get; set; }

        [Input("TradeSector")]
        [ReferenceTarget("lux_tradesector")]
        public InArgument<EntityReference> TradeSector { get; set; }

        [Output("TradeSegment")]
        [ReferenceTarget("lux_tradesegment")]
        public OutArgument<EntityReference> TradeSegment { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_tradesegment'>
                                <attribute name='lux_tradesegmentid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_tradesector' operator='eq' uiname='' uitype='lux_tradesector' value='{TradeSector.Get(executionContext).Id}' />
                                  <condition attribute='lux_name' operator='eq' value='{TradeSegmentTxt.Get(executionContext).ToString().Replace("&", "&amp;").Replace("'", "&apos;").Replace("\"", " &quot;")}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var contact = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                TradeSegment.Set(executionContext, contact.ToEntityReference());
            }
        }
    }
}
