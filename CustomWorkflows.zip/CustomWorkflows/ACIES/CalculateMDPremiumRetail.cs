﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculateMDPremiumRetail : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Input("Product")]
        public InArgument<string> Product { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = "";
            var entityName = "";
            if (Product.Get(executionContext).ToString() == "Retail")
            {
                entityName = "lux_propertyownersretail";
                fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersretail'>
                                <attribute name='lux_propertyownersretailid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_generalcontentsdeclaredvalueincludingmach' />
                                <attribute name='lux_buildingsdeclaredvalue' />
                                <attribute name='lux_listhighvaluestock' />
                                <attribute name='lux_stockexcludinghighvaluestock' />
                                <attribute name='lux_computerandelectronicbusinessequipment' />
                                <attribute name='lux_winesfortifiedwinesspiritsfinesuminsured' />
                                <attribute name='lux_materialdamagecoverdetails' />
                                <attribute name='lux_powertoolssuminsured' />                                
                                <attribute name='lux_tenantsimprovementsdeclaredvalue' />
                                <attribute name='lux_nonferrousmetalssuminsured' />
                                <attribute name='lux_mobilephonessuminsured' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_computerequipmentsuminsured' />
                                <attribute name='lux_audiovideoequipmentsuminsured' />
                                <attribute name='lux_alcoholsuminsured' />
                                <attribute name='lux_computergamesandorconsolessuminsured' />
                                <attribute name='lux_materialdamagelossofrentpayable' />
                                <attribute name='lux_cigarettescigarsortobaccoproductssuminsur' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_fineartsuminsured' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplications' visible='false' link-type='outer' alias='appln'>
                                  <attribute name='lux_maintradeforthispremises' />
                                </link-entity>
                              </entity>
                            </fetch>";
            }
            else if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
            {
                entityName = "lux_commercialcombinedapplication";
                fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_commercialcombinedapplication'>
                                <attribute name='lux_commercialcombinedapplicationid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_generalcontentsdeclaredvalueincludingmach' />
                                <attribute name='lux_buildingsdeclaredvalue' />
                                <attribute name='lux_listhighvaluestock' />
                                <attribute name='lux_stockexcludinghighvaluestock' />
                                <attribute name='lux_computerandelectronicbusinessequipment' />
                                <attribute name='lux_winesfortifiedwinesspiritsfinesuminsured' />
                                <attribute name='lux_materialdamagecoverdetails' />
                                <attribute name='lux_powertoolssuminsured' />                                
                                <attribute name='lux_tenantsimprovementsdeclaredvalue' />
                                <attribute name='lux_nonferrousmetalssuminsured' />
                                <attribute name='lux_mobilephonessuminsured' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_computerequipmentsuminsured' />
                                <attribute name='lux_audiovideoequipmentsuminsured' />
                                <attribute name='lux_alcoholsuminsured' />
                                <attribute name='lux_computergamesandorconsolessuminsured' />
                                <attribute name='lux_materialdamagelossofrentpayable' />
                                <attribute name='lux_cigarettescigarsortobaccoproductssuminsur' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_fineartsuminsured' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplications' visible='false' link-type='outer' alias='appln'>
                                  <attribute name='lux_maintradeforthispremises' />
                                </link-entity>
                              </entity>
                            </fetch>";
            }
            else if (Product.Get(executionContext).ToString() == "Pubs & Restaurants" || Product.Get(executionContext).ToString() == "Hotels and Guesthouses")
            {
                entityName = "lux_pubsrestaurantspropertyownersapplicatio";
                fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_pubsrestaurantspropertyownersapplicatio'>
                                <attribute name='lux_pubsrestaurantspropertyownersapplicatioid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_generalcontentsdeclaredvalueincludingmach' />
                                <attribute name='lux_buildingsdeclaredvalue' />
                                <attribute name='lux_listhighvaluestock' />
                                <attribute name='lux_stockexcludinghighvaluestock' />
                                <attribute name='lux_computerandelectronicbusinessequipment' />
                                <attribute name='lux_winesfortifiedwinesspiritsfinesuminsured' />
                                <attribute name='lux_materialdamagecoverdetails' />
                                <attribute name='lux_powertoolssuminsured' />                                
                                <attribute name='lux_tenantsimprovementsdeclaredvalue' />
                                <attribute name='lux_nonferrousmetalssuminsured' />
                                <attribute name='lux_mobilephonessuminsured' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_computerequipmentsuminsured' />
                                <attribute name='lux_audiovideoequipmentsuminsured' />
                                <attribute name='lux_alcoholsuminsured' />
                                <attribute name='lux_computergamesandorconsolessuminsured' />
                                <attribute name='lux_materialdamagelossofrentpayable' />
                                <attribute name='lux_cigarettescigarsortobaccoproductssuminsur' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_fineartsuminsured' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplications' visible='false' link-type='outer' alias='appln'>
                                  <attribute name='lux_maintradeforthispremises' />
                                </link-entity>
                              </entity>
                            </fetch>";
            }
            else if (Product.Get(executionContext).ToString() == "Contractors Combined")
            {
                entityName = "lux_contractorscombined";
                fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_contractorscombined'>
                                <attribute name='lux_contractorscombinedid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_generalcontentsdeclaredvalueincludingmach' />
                                <attribute name='lux_buildingsdeclaredvalue' />
                                <attribute name='lux_listhighvaluestock' />
                                <attribute name='lux_stockexcludinghighvaluestock' />
                                <attribute name='lux_computerandelectronicbusinessequipment' />
                                <attribute name='lux_winesfortifiedwinesspiritsfinesuminsured' />
                                <attribute name='lux_materialdamagecoverdetails' />
                                <attribute name='lux_powertoolssuminsured' />                                
                                <attribute name='lux_tenantsimprovementsdeclaredvalue' />
                                <attribute name='lux_nonferrousmetalssuminsured' />
                                <attribute name='lux_mobilephonessuminsured' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_computerequipmentsuminsured' />
                                <attribute name='lux_audiovideoequipmentsuminsured' />
                                <attribute name='lux_alcoholsuminsured' />
                                <attribute name='lux_computergamesandorconsolessuminsured' />
                                <attribute name='lux_materialdamagelossofrentpayable' />
                                <attribute name='lux_cigarettescigarsortobaccoproductssuminsur' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_fineartsuminsured' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplications' visible='false' link-type='outer' alias='appln'>
                                  <attribute name='lux_contractorsprimarytrade' />
                                  <attribute name='lux_ismaterialdamagecoverrequired' />
                                </link-entity>
                              </entity>
                            </fetch>";
            }

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                decimal TotalMDPremium = 0;

                decimal BuildingPremium = 0;
                decimal ContentsPremium = 0;
                decimal TenentsPremium = 0;
                decimal StockPremium = 0;
                decimal TargetStockPremium = 0;
                decimal ComputerEquipmentPremium = 0;
                decimal LossofRentPremium = 0;

                decimal TotalBuildingPremium = 0;
                decimal TotalContentsPremium = 0;
                decimal TotalTenentsPremium = 0;
                decimal TotalStockPremium = 0;
                decimal TotalTargetStockPremium = 0;
                decimal TotalComputerEquipmentPremium = 0;
                decimal TotalLossofRentPremium = 0;

                decimal TotalBuildingFireRate = 0;
                decimal TotalBuildingPerilsRate = 0;
                decimal TotalContentsFireRate = 0;
                decimal TotalContentsTheftRate = 0;
                decimal TotalContentsPerilsRate = 0;
                decimal TotalStockRate = 0;
                decimal TotalTargetStockRate = 0;
                decimal TotalComputerEquipmentRate = 0;
                decimal TotalLORRate = 0;

                var item2 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                var dateDiffDays = (item2.GetAttributeValue<DateTime>("lux_renewaldate") - item2.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                if (dateDiffDays == 364 || dateDiffDays == 365 || dateDiffDays == 366)
                {
                    dateDiffDays = 365;
                }

                var quotationDate = Convert.ToDateTime((item2.Contains("lux_quotationdate") ? item2.GetAttributeValue<DateTime>("lux_quotationdate") : item2.GetAttributeValue<DateTime>("lux_inceptiondate")), System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                var inceptionDate = Convert.ToDateTime(item2.GetAttributeValue<DateTime>("lux_inceptiondate"), System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                var PremiseCount = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count();

                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    var premise_data = item;
                    decimal StockRate = 0;
                    decimal BuildingFireRate = 0;
                    decimal BuildingPerilsRate = 0;
                    decimal ContentsFireRate = 0;
                    decimal ContentsPerilsRate = 0;
                    decimal LORRate = 0;

                    var Buildings = premise_data.GetAttributeValue<Money>("lux_buildingsdeclaredvalue");
                    var Contents = premise_data.GetAttributeValue<Money>("lux_generalcontentsdeclaredvalueincludingmach");
                    var Tenents = premise_data.GetAttributeValue<Money>("lux_tenantsimprovementsdeclaredvalue");
                    var covers = premise_data.GetAttributeValue<OptionSetValueCollection>("lux_materialdamagecoverdetails");
                    if (Product.Get(executionContext).ToString() != "Contractors Combined")
                    {
                        if (item.Attributes.Contains("appln.lux_maintradeforthispremises"))
                        {
                            var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                  <filter type='or'>
                                                    <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                    <condition attribute='lux_enddate' operator='null' />
                                                  </filter>
                                                  <condition attribute='lux_name' operator='eq' uiname='' value='{item2.FormattedValues["lux_maintradeforthispremises"].ToString()}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                            if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                            {
                                var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];

                                var item5 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                                item5["lux_maintradeforthispremises"] = new EntityReference("lux_propertyownersrate", FireData.Id);
                                service.Update(item5);

                                if (Product.Get(executionContext).ToString() == "Pubs & Restaurants" || Product.Get(executionContext).ToString() == "Hotels and Guesthouses")
                                {
                                    StockRate = 0.3M;
                                }
                                else if (Product.Get(executionContext).ToString() == "Retail")
                                {
                                    StockRate = 0.3M;
                                }
                                else if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
                                {
                                    if (FireData.FormattedValues["lux_tradesector"].ToString().Contains("Leisure"))
                                    {
                                        StockRate = 0.3M;
                                    }
                                    else if (FireData.FormattedValues["lux_tradesector"].ToString().Contains("Manufacturer's") && item.FormattedValues["appln.lux_maintradeforthispremises"].ToString() != "Fabric Manufacturing")
                                    {
                                        StockRate = 0.3M;
                                    }
                                    else if (item.FormattedValues["appln.lux_maintradeforthispremises"].ToString() == "Fabric Manufacturing")
                                    {
                                        StockRate = 0.5M;
                                    }
                                    else if (FireData.FormattedValues["lux_tradesector"].ToString().Contains("Wholesaler's") && item.FormattedValues["appln.lux_maintradeforthispremises"].ToString() != "Furnishing Fabric Wholesalers" && item.FormattedValues["appln.lux_maintradeforthispremises"].ToString() != "Mineral Wholesale")
                                    {
                                        StockRate = 0.3M;
                                    }
                                    else if (item.FormattedValues["appln.lux_maintradeforthispremises"].ToString() == "Furnishing Fabric Wholesalers")
                                    {
                                        StockRate = 0.5M;
                                    }
                                    else if (item.FormattedValues["appln.lux_maintradeforthispremises"].ToString() == "Mineral Wholesale")
                                    {
                                        StockRate = 0.5M;
                                    }
                                    else
                                    {
                                        StockRate = FireData.GetAttributeValue<decimal>("lux_theftstockrate");
                                    }
                                }
                                else
                                {
                                    StockRate = FireData.GetAttributeValue<decimal>("lux_theftstockrate");
                                }

                                BuildingFireRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                ContentsFireRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                LORRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                TotalContentsTheftRate = FireData.GetAttributeValue<decimal>("lux_theftcontentsrate");

                                if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                                {
                                    BuildingFireRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                    ContentsFireRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                    LORRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");

                                    if (BuildingFireRate < 0.10M)
                                    {
                                        BuildingFireRate = 0.10M;
                                        ContentsFireRate = 0.10M;
                                        LORRate = 0.10M;
                                    }
                                }
                                else if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                                {
                                    BuildingFireRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                    ContentsFireRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                    LORRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");

                                    if (inceptionDate >= new DateTime(2025, 08, 01))
                                    {
                                        if (BuildingFireRate < 0.10M)
                                        {
                                            BuildingFireRate = 0.10M;
                                            ContentsFireRate = 0.10M;
                                            LORRate = 0.10M;
                                        }
                                    }
                                }
                                else
                                {
                                    if (item2.Attributes.Contains("lux_policy"))
                                    {
                                        var Policy = service.Retrieve("lux_policy", item2.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                        if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                        {
                                            if (quotationDate < new DateTime(2023, 02, 15))
                                            {
                                                BuildingFireRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                                ContentsFireRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                                LORRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                            }
                                            else
                                            {
                                                if (BuildingFireRate < 0.10M)
                                                {
                                                    BuildingFireRate = 0.10M;
                                                    ContentsFireRate = 0.10M;
                                                    LORRate = 0.10M;
                                                }

                                                if (item2.FormattedValues["lux_maintradeforthispremises"].ToString() == "Offices")
                                                {
                                                    BuildingFireRate = 0.09M;
                                                    ContentsFireRate = 0.09M;
                                                    LORRate = 0.09M;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            BuildingFireRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                            ContentsFireRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                            LORRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");

                                            if (inceptionDate >= new DateTime(2025, 08, 01))
                                            {
                                                if (BuildingFireRate < 0.10M)
                                                {
                                                    BuildingFireRate = 0.10M;
                                                    ContentsFireRate = 0.10M;
                                                    LORRate = 0.10M;
                                                }

                                                if (item2.FormattedValues["lux_maintradeforthispremises"].ToString() == "Offices")
                                                {
                                                    BuildingFireRate = 0.09M;
                                                    ContentsFireRate = 0.09M;
                                                    LORRate = 0.09M;
                                                }
                                            }
                                        }
                                    }
                                }

                                if (Product.Get(executionContext).ToString() == "Pubs & Restaurants" || Product.Get(executionContext).ToString() == "Hotels and Guesthouses")
                                {
                                    if (item2.GetAttributeValue<OptionSetValue>("lux_pubsrestaurantproducttype").Value == 972970002)
                                    {
                                        BuildingFireRate = 0.14M;
                                        ContentsFireRate = 0.14M;
                                        LORRate = 0.14M;
                                    }
                                }
                                if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
                                {
                                    if (BuildingFireRate < 0.10M)
                                    {
                                        BuildingFireRate = 0.10M;
                                        ContentsFireRate = 0.10M;
                                        LORRate = 0.10M;
                                    }

                                    if (FireData.FormattedValues["lux_tradesector"].ToString().Contains("Wholesaler's") || FireData.FormattedValues["lux_tradesector"].ToString().Contains("Business") || FireData.FormattedValues["lux_tradesector"].ToString().Contains("Leisure"))
                                    {
                                        if (FireData.GetAttributeValue<int>("lux_mdbi") == 2)
                                        {
                                            BuildingFireRate = 0.10M;
                                            ContentsFireRate = 0.10M;
                                            LORRate = 0.10M;
                                        }
                                        else if (FireData.GetAttributeValue<int>("lux_mdbi") == 3)
                                        {
                                            BuildingFireRate = 0.125M;
                                            ContentsFireRate = 0.125M;
                                            LORRate = 0.125M;
                                        }
                                        else if (FireData.GetAttributeValue<int>("lux_mdbi") == 4)
                                        {
                                            BuildingFireRate = 0.175M;
                                            ContentsFireRate = 0.175M;
                                            LORRate = 0.175M;
                                        }
                                        else if (FireData.GetAttributeValue<int>("lux_mdbi") == 5)
                                        {
                                            BuildingFireRate = 0.225M;
                                            ContentsFireRate = 0.225M;
                                            LORRate = 0.225M;
                                        }
                                        else if (FireData.GetAttributeValue<int>("lux_mdbi") == 6)
                                        {
                                            BuildingFireRate = 0.00M;
                                            ContentsFireRate = 0.00M;
                                            LORRate = 0.00M;
                                        }
                                    }

                                    if (FireData.FormattedValues["lux_tradesector"].ToString().Contains("Manufacturer's"))
                                    {
                                        if (FireData.GetAttributeValue<int>("lux_mdbi") == 2)
                                        {
                                            BuildingFireRate = 0.10M;
                                            ContentsFireRate = 0.10M;
                                            LORRate = 0.10M;
                                        }
                                        else if (FireData.GetAttributeValue<int>("lux_mdbi") == 3)
                                        {
                                            BuildingFireRate = 0.15M;
                                            ContentsFireRate = 0.15M;
                                            LORRate = 0.15M;
                                        }
                                        else if (FireData.GetAttributeValue<int>("lux_mdbi") == 4)
                                        {
                                            BuildingFireRate = 0.20M;
                                            ContentsFireRate = 0.20M;
                                            LORRate = 0.20M;
                                        }
                                        else if (FireData.GetAttributeValue<int>("lux_mdbi") == 5)
                                        {
                                            BuildingFireRate = 0.25M;
                                            ContentsFireRate = 0.25M;
                                            LORRate = 0.25M;
                                        }
                                        else if (FireData.GetAttributeValue<int>("lux_mdbi") == 6)
                                        {
                                            BuildingFireRate = 0.00M;
                                            ContentsFireRate = 0.00M;
                                            LORRate = 0.00M;
                                        }
                                    }
                                }

                                if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001 && item2.FormattedValues["lux_maintradeforthispremises"].ToString() == "Offices")
                                {
                                    BuildingFireRate = 0.09M;
                                    ContentsFireRate = 0.09M;
                                    LORRate = 0.09M;
                                }

                                if (inceptionDate >= new DateTime(2025, 08, 01))
                                {
                                    if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003 && item2.FormattedValues["lux_maintradeforthispremises"].ToString() == "Offices")
                                    {
                                        BuildingFireRate = 0.09M;
                                        ContentsFireRate = 0.09M;
                                        LORRate = 0.09M;
                                    }
                                }
                            }
                        }
                    }
                    else if (Product.Get(executionContext).ToString() == "Contractors Combined")
                    {
                        if (item.Attributes.Contains("appln.lux_contractorsprimarytrade"))
                        {
                            var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_contractorstrade'>
                                                    <attribute name='lux_contractorstradeid' />
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_tradecategory' />
                                                    <attribute name='lux_plrate' />
                                                    <attribute name='lux_materialdamagefirerate' />
                                                    <attribute name='lux_elrate' />
                                                    <attribute name='lux_carrate' />
                                                    <attribute name='lux_businessinterruptionrate' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                      <filter type='or'>
                                                        <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                        <condition attribute='lux_enddate' operator='null' />
                                                      </filter>
                                                      <condition attribute='lux_contractorstradeid' operator='eq' uiname='' uitype='lux_contractorstrade' value='{((EntityReference)((item.GetAttributeValue<AliasedValue>("appln.lux_contractorsprimarytrade")).Value)).Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                            if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                            {
                                var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];
                                StockRate = Convert.ToDecimal(0.4);
                                BuildingFireRate = FireData.GetAttributeValue<decimal>("lux_materialdamagefirerate");
                                ContentsFireRate = FireData.GetAttributeValue<decimal>("lux_materialdamagefirerate");
                                LORRate = FireData.GetAttributeValue<decimal>("lux_materialdamagefirerate");
                            }
                        }
                    }
                    if (covers != null)
                    {
                        var TotalSumInsuredFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_totalsuminsuredrate'>
                                                    <attribute name='lux_5m25m' />
                                                    <attribute name='lux_50m100m' />
                                                    <attribute name='lux_25m50m' />
                                                    <attribute name='lux_100m200m' />
                                                    <attribute name='lux_05m' />
                                                    <attribute name='lux_totalsuminsuredrateid' />
                                                    <attribute name='lux_peril' />
                                                    <order attribute='lux_05m' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                      <filter type='or'>
                                                        <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                        <condition attribute='lux_enddate' operator='null' />
                                                      </filter>";
                        if (covers != null)
                        {
                            TotalSumInsuredFetch += $@"<condition attribute='lux_peril' operator='contain-values'>";
                            foreach (var cover in covers)
                            {
                                TotalSumInsuredFetch += $@"<value>" + cover.Value + "</value>";
                            }
                            TotalSumInsuredFetch += $@"</condition>";
                        }
                        TotalSumInsuredFetch += $@"</filter>
                                                  </entity>
                                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(TotalSumInsuredFetch)).Entities.Count > 0)
                        {
                            var SI_data = service.RetrieveMultiple(new FetchExpression(TotalSumInsuredFetch)).Entities;
                            var SI_field = "lux_05m";
                            if (Buildings != null)
                            {
                                if (Buildings.Value < 5000000)
                                {
                                    SI_field = "lux_05m";
                                }
                                else if (Buildings.Value >= 5000000 && Buildings.Value < 25000000)
                                {
                                    SI_field = "lux_5m25m";
                                }
                                else if (Buildings.Value >= 25000000 && Buildings.Value < 50000000)
                                {
                                    SI_field = "lux_25m50m";
                                }
                                else if (Buildings.Value >= 50000000 && Buildings.Value < 100000000)
                                {
                                    SI_field = "lux_50m100m";
                                }
                                else if (Buildings.Value >= 100000000 && Buildings.Value < 200000000)
                                {
                                    SI_field = "lux_100m200m";
                                }
                            }
                            BuildingPerilsRate = SI_data.Sum(x => x.GetAttributeValue<decimal>(SI_field)) * 100;

                            SI_field = "lux_05m";
                            if (Contents != null)
                            {
                                if (Contents.Value < 5000000)
                                {
                                    SI_field = "lux_05m";
                                }
                                else if (Contents.Value >= 5000000 && Contents.Value < 25000000)
                                {
                                    SI_field = "lux_5m25m";
                                }
                                else if (Contents.Value >= 25000000 && Contents.Value < 50000000)
                                {
                                    SI_field = "lux_25m50m";
                                }
                                else if (Contents.Value >= 50000000 && Contents.Value < 100000000)
                                {
                                    SI_field = "lux_50m100m";
                                }
                                else if (Contents.Value >= 100000000 && Contents.Value < 200000000)
                                {
                                    SI_field = "lux_100m200m";
                                }
                            }

                            ContentsPerilsRate = SI_data.Sum(x => x.GetAttributeValue<decimal>(SI_field)) * 100;
                        }

                        if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                        {
                            if (BuildingPerilsRate < 0.049M)
                            {
                                BuildingPerilsRate = 0.049M;
                            }

                            if (ContentsPerilsRate < 0.049M)
                            {
                                ContentsPerilsRate = 0.049M;
                            }
                        }
                        else if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                        {
                            if (inceptionDate >= new DateTime(2025, 08, 01))
                            {
                                if (BuildingPerilsRate < 0.049M)
                                {
                                    BuildingPerilsRate = 0.049M;
                                }

                                if (ContentsPerilsRate < 0.049M)
                                {
                                    ContentsPerilsRate = 0.049M;
                                }
                            }
                        }
                        else
                        {
                            if (item2.Attributes.Contains("lux_policy"))
                            {
                                var Policy = service.Retrieve("lux_policy", item2.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                {
                                    if (quotationDate > new DateTime(2023, 02, 15))
                                    {
                                        if (BuildingPerilsRate < 0.049M)
                                        {
                                            BuildingPerilsRate = 0.049M;
                                        }

                                        if (ContentsPerilsRate < 0.049M)
                                        {
                                            ContentsPerilsRate = 0.049M;
                                        }
                                    }
                                }
                                else
                                {
                                    if (inceptionDate >= new DateTime(2025, 08, 01))
                                    {
                                        if (BuildingPerilsRate < 0.049M)
                                        {
                                            BuildingPerilsRate = 0.049M;
                                        }

                                        if (ContentsPerilsRate < 0.049M)
                                        {
                                            ContentsPerilsRate = 0.049M;
                                        }
                                    }
                                }
                            }
                        }

                        var BuildingRate = BuildingFireRate + BuildingPerilsRate;
                        BuildingPremium = (Buildings != null ? Buildings.Value : 0) * BuildingRate / 100;

                        TotalBuildingPremium += BuildingPremium;
                        TotalBuildingFireRate += BuildingFireRate;
                        TotalBuildingPerilsRate += BuildingPerilsRate;

                        var ContentsRate = ContentsFireRate + ContentsPerilsRate;

                        if ((Contents.Value != 0 && item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001))
                        {
                            ContentsPremium = Contents.Value * ContentsRate / 100;
                            decimal TheftContentPremium = 0;

                            if (TotalContentsTheftRate != 0)
                            {
                                if (Contents.Value <= 10000)
                                {
                                    TheftContentPremium = Contents.Value * TotalContentsTheftRate / 100;
                                }
                                else
                                {
                                    if (Contents.Value <= 30000)
                                    {
                                        TheftContentPremium = 10000 * TotalContentsTheftRate / 100;
                                        var remainingContent = Contents.Value - 10000;
                                        TheftContentPremium += remainingContent * (TotalContentsTheftRate * 75 / 100) / 100;
                                    }
                                    else if (Contents.Value <= 50000)
                                    {
                                        TheftContentPremium = 10000 * TotalContentsTheftRate / 100;
                                        TheftContentPremium += 20000 * (TotalContentsTheftRate * 75 / 100) / 100;

                                        var remainingContent1 = Contents.Value - 30000;
                                        TheftContentPremium += remainingContent1 * (TotalContentsTheftRate * 50 / 100) / 100;
                                    }
                                    else if (Contents.Value > 50000)
                                    {
                                        TheftContentPremium = 10000 * TotalContentsTheftRate / 100;
                                        TheftContentPremium += 20000 * (TotalContentsTheftRate * 75 / 100) / 100;
                                        TheftContentPremium += 20000 * (TotalContentsTheftRate * 50 / 100) / 100;

                                        var remainingContent1 = Contents.Value - 50000;
                                        TheftContentPremium += remainingContent1 * (TotalContentsTheftRate * 25 / 100) / 100;
                                    }
                                }
                            }
                            ContentsPremium = ContentsPremium + TheftContentPremium;
                        }
                        else if (Contents.Value != 0 && item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                        {
                            if (inceptionDate >= new DateTime(2025, 08, 01))
                            {
                                ContentsPremium = Contents.Value * ContentsRate / 100;
                                decimal TheftContentPremium = 0;

                                if (TotalContentsTheftRate != 0)
                                {
                                    if (Contents.Value <= 10000)
                                    {
                                        TheftContentPremium = Contents.Value * TotalContentsTheftRate / 100;
                                    }
                                    else
                                    {
                                        if (Contents.Value <= 30000)
                                        {
                                            TheftContentPremium = 10000 * TotalContentsTheftRate / 100;
                                            var remainingContent = Contents.Value - 10000;
                                            TheftContentPremium += remainingContent * (TotalContentsTheftRate * 75 / 100) / 100;
                                        }
                                        else if (Contents.Value <= 50000)
                                        {
                                            TheftContentPremium = 10000 * TotalContentsTheftRate / 100;
                                            TheftContentPremium += 20000 * (TotalContentsTheftRate * 75 / 100) / 100;

                                            var remainingContent1 = Contents.Value - 30000;
                                            TheftContentPremium += remainingContent1 * (TotalContentsTheftRate * 50 / 100) / 100;
                                        }
                                        else if (Contents.Value > 50000)
                                        {
                                            TheftContentPremium = 10000 * TotalContentsTheftRate / 100;
                                            TheftContentPremium += 20000 * (TotalContentsTheftRate * 75 / 100) / 100;
                                            TheftContentPremium += 20000 * (TotalContentsTheftRate * 50 / 100) / 100;

                                            var remainingContent1 = Contents.Value - 50000;
                                            TheftContentPremium += remainingContent1 * (TotalContentsTheftRate * 25 / 100) / 100;
                                        }
                                    }
                                }
                                ContentsPremium = ContentsPremium + TheftContentPremium;
                            }
                            else
                            {
                                if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
                                {
                                    if (Contents.Value != 0)
                                    {
                                        if (Contents.Value <= 20000)
                                        {
                                            ContentsPremium = Contents.Value * ContentsRate / 100;
                                        }
                                        else
                                        {
                                            if (Contents.Value <= 60000)
                                            {
                                                ContentsPremium = 20000 * ContentsRate / 100;
                                                var remainingContent = Contents.Value - 20000;
                                                ContentsPremium += remainingContent * (ContentsRate * 75 / 100) / 100;
                                            }
                                            else if (Contents.Value <= 100000)
                                            {
                                                ContentsPremium = 20000 * ContentsRate / 100;
                                                ContentsPremium += 40000 * (ContentsRate * 75 / 100) / 100;

                                                var remainingContent1 = Contents.Value - 60000;
                                                ContentsPremium += remainingContent1 * (ContentsRate * 50 / 100) / 100;
                                            }
                                            else if (Contents.Value > 100000)
                                            {
                                                ContentsPremium = 20000 * ContentsRate / 100;
                                                ContentsPremium += 40000 * (ContentsRate * 75 / 100) / 100;
                                                ContentsPremium += 40000 * (ContentsRate * 50 / 100) / 100;

                                                var remainingContent1 = Contents.Value - 100000;
                                                ContentsPremium += remainingContent1 * (ContentsRate * 25 / 100) / 100;
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    if (Contents.Value != 0)
                                    {
                                        if (Contents.Value <= 10000)
                                        {
                                            ContentsPremium = Contents.Value * ContentsRate / 100;
                                        }
                                        else
                                        {
                                            if (Contents.Value <= 30000)
                                            {
                                                ContentsPremium = 10000 * ContentsRate / 100;
                                                var remainingContent = Contents.Value - 10000;
                                                ContentsPremium += remainingContent * (ContentsRate * 75 / 100) / 100;
                                            }
                                            else if (Contents.Value <= 50000)
                                            {
                                                ContentsPremium = 10000 * ContentsRate / 100;
                                                ContentsPremium += 20000 * (ContentsRate * 75 / 100) / 100;

                                                var remainingContent1 = Contents.Value - 30000;
                                                ContentsPremium += remainingContent1 * (ContentsRate * 50 / 100) / 100;
                                            }
                                            else if (Contents.Value > 50000)
                                            {
                                                ContentsPremium = 10000 * ContentsRate / 100;
                                                ContentsPremium += 20000 * (ContentsRate * 75 / 100) / 100;
                                                ContentsPremium += 20000 * (ContentsRate * 50 / 100) / 100;

                                                var remainingContent1 = Contents.Value - 50000;
                                                ContentsPremium += remainingContent1 * (ContentsRate * 25 / 100) / 100;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (Contents.Value != 0 && item2.Attributes.Contains("lux_policy"))
                            {
                                var Policy = service.Retrieve("lux_policy", item2.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                {
                                    if (quotationDate < new DateTime(2023, 02, 15))
                                    {
                                        if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
                                        {
                                            if (Contents.Value != 0)
                                            {
                                                if (Contents.Value <= 20000)
                                                {
                                                    ContentsPremium = Contents.Value * ContentsRate / 100;
                                                }
                                                else
                                                {
                                                    if (Contents.Value <= 60000)
                                                    {
                                                        ContentsPremium = 20000 * ContentsRate / 100;
                                                        var remainingContent = Contents.Value - 20000;
                                                        ContentsPremium += remainingContent * (ContentsRate * 75 / 100) / 100;
                                                    }
                                                    else if (Contents.Value <= 100000)
                                                    {
                                                        ContentsPremium = 20000 * ContentsRate / 100;
                                                        ContentsPremium += 40000 * (ContentsRate * 75 / 100) / 100;

                                                        var remainingContent1 = Contents.Value - 60000;
                                                        ContentsPremium += remainingContent1 * (ContentsRate * 50 / 100) / 100;
                                                    }
                                                    else if (Contents.Value > 100000)
                                                    {
                                                        ContentsPremium = 20000 * ContentsRate / 100;
                                                        ContentsPremium += 40000 * (ContentsRate * 75 / 100) / 100;
                                                        ContentsPremium += 40000 * (ContentsRate * 50 / 100) / 100;

                                                        var remainingContent1 = Contents.Value - 100000;
                                                        ContentsPremium += remainingContent1 * (ContentsRate * 25 / 100) / 100;
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if (Contents.Value != 0)
                                            {
                                                if (Contents.Value <= 10000)
                                                {
                                                    ContentsPremium = Contents.Value * ContentsRate / 100;
                                                }
                                                else
                                                {
                                                    if (Contents.Value <= 30000)
                                                    {
                                                        ContentsPremium = 10000 * ContentsRate / 100;
                                                        var remainingContent = Contents.Value - 10000;
                                                        ContentsPremium += remainingContent * (ContentsRate * 75 / 100) / 100;
                                                    }
                                                    else if (Contents.Value <= 50000)
                                                    {
                                                        ContentsPremium = 10000 * ContentsRate / 100;
                                                        ContentsPremium += 20000 * (ContentsRate * 75 / 100) / 100;

                                                        var remainingContent1 = Contents.Value - 30000;
                                                        ContentsPremium += remainingContent1 * (ContentsRate * 50 / 100) / 100;
                                                    }
                                                    else if (Contents.Value > 50000)
                                                    {
                                                        ContentsPremium = 10000 * ContentsRate / 100;
                                                        ContentsPremium += 20000 * (ContentsRate * 75 / 100) / 100;
                                                        ContentsPremium += 20000 * (ContentsRate * 50 / 100) / 100;

                                                        var remainingContent1 = Contents.Value - 50000;
                                                        ContentsPremium += remainingContent1 * (ContentsRate * 25 / 100) / 100;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        ContentsPremium = Contents.Value * ContentsRate / 100;
                                        decimal TheftContentPremium = 0;

                                        if (TotalContentsTheftRate != 0)
                                        {
                                            if (Contents.Value <= 10000)
                                            {
                                                TheftContentPremium = Contents.Value * TotalContentsTheftRate / 100;
                                            }
                                            else
                                            {
                                                if (Contents.Value <= 30000)
                                                {
                                                    TheftContentPremium = 10000 * TotalContentsTheftRate / 100;
                                                    var remainingContent = Contents.Value - 10000;
                                                    TheftContentPremium += remainingContent * (TotalContentsTheftRate * 75 / 100) / 100;
                                                }
                                                else if (Contents.Value <= 50000)
                                                {
                                                    TheftContentPremium = 10000 * TotalContentsTheftRate / 100;
                                                    TheftContentPremium += 20000 * (TotalContentsTheftRate * 75 / 100) / 100;

                                                    var remainingContent1 = Contents.Value - 30000;
                                                    TheftContentPremium += remainingContent1 * (TotalContentsTheftRate * 50 / 100) / 100;
                                                }
                                                else if (Contents.Value > 50000)
                                                {
                                                    TheftContentPremium = 10000 * TotalContentsTheftRate / 100;
                                                    TheftContentPremium += 20000 * (TotalContentsTheftRate * 75 / 100) / 100;
                                                    TheftContentPremium += 20000 * (TotalContentsTheftRate * 50 / 100) / 100;

                                                    var remainingContent1 = Contents.Value - 50000;
                                                    TheftContentPremium += remainingContent1 * (TotalContentsTheftRate * 25 / 100) / 100;
                                                }
                                            }
                                        }
                                        ContentsPremium = ContentsPremium + TheftContentPremium;
                                    }
                                }
                                else
                                {
                                    if (inceptionDate >= new DateTime(2025, 08, 01))
                                    {
                                        ContentsPremium = Contents.Value * ContentsRate / 100;
                                        decimal TheftContentPremium = 0;

                                        if (TotalContentsTheftRate != 0)
                                        {
                                            if (Contents.Value <= 10000)
                                            {
                                                TheftContentPremium = Contents.Value * TotalContentsTheftRate / 100;
                                            }
                                            else
                                            {
                                                if (Contents.Value <= 30000)
                                                {
                                                    TheftContentPremium = 10000 * TotalContentsTheftRate / 100;
                                                    var remainingContent = Contents.Value - 10000;
                                                    TheftContentPremium += remainingContent * (TotalContentsTheftRate * 75 / 100) / 100;
                                                }
                                                else if (Contents.Value <= 50000)
                                                {
                                                    TheftContentPremium = 10000 * TotalContentsTheftRate / 100;
                                                    TheftContentPremium += 20000 * (TotalContentsTheftRate * 75 / 100) / 100;

                                                    var remainingContent1 = Contents.Value - 30000;
                                                    TheftContentPremium += remainingContent1 * (TotalContentsTheftRate * 50 / 100) / 100;
                                                }
                                                else if (Contents.Value > 50000)
                                                {
                                                    TheftContentPremium = 10000 * TotalContentsTheftRate / 100;
                                                    TheftContentPremium += 20000 * (TotalContentsTheftRate * 75 / 100) / 100;
                                                    TheftContentPremium += 20000 * (TotalContentsTheftRate * 50 / 100) / 100;

                                                    var remainingContent1 = Contents.Value - 50000;
                                                    TheftContentPremium += remainingContent1 * (TotalContentsTheftRate * 25 / 100) / 100;
                                                }
                                            }
                                        }
                                        ContentsPremium = ContentsPremium + TheftContentPremium;
                                    }
                                    else
                                    {
                                        if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
                                        {
                                            if (Contents.Value != 0)
                                            {
                                                if (Contents.Value <= 20000)
                                                {
                                                    ContentsPremium = Contents.Value * ContentsRate / 100;
                                                }
                                                else
                                                {
                                                    if (Contents.Value <= 60000)
                                                    {
                                                        ContentsPremium = 20000 * ContentsRate / 100;
                                                        var remainingContent = Contents.Value - 20000;
                                                        ContentsPremium += remainingContent * (ContentsRate * 75 / 100) / 100;
                                                    }
                                                    else if (Contents.Value <= 100000)
                                                    {
                                                        ContentsPremium = 20000 * ContentsRate / 100;
                                                        ContentsPremium += 40000 * (ContentsRate * 75 / 100) / 100;

                                                        var remainingContent1 = Contents.Value - 60000;
                                                        ContentsPremium += remainingContent1 * (ContentsRate * 50 / 100) / 100;
                                                    }
                                                    else if (Contents.Value > 100000)
                                                    {
                                                        ContentsPremium = 20000 * ContentsRate / 100;
                                                        ContentsPremium += 40000 * (ContentsRate * 75 / 100) / 100;
                                                        ContentsPremium += 40000 * (ContentsRate * 50 / 100) / 100;

                                                        var remainingContent1 = Contents.Value - 100000;
                                                        ContentsPremium += remainingContent1 * (ContentsRate * 25 / 100) / 100;
                                                    }
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if (Contents.Value != 0)
                                            {
                                                if (Contents.Value <= 10000)
                                                {
                                                    ContentsPremium = Contents.Value * ContentsRate / 100;
                                                }
                                                else
                                                {
                                                    if (Contents.Value <= 30000)
                                                    {
                                                        ContentsPremium = 10000 * ContentsRate / 100;
                                                        var remainingContent = Contents.Value - 10000;
                                                        ContentsPremium += remainingContent * (ContentsRate * 75 / 100) / 100;
                                                    }
                                                    else if (Contents.Value <= 50000)
                                                    {
                                                        ContentsPremium = 10000 * ContentsRate / 100;
                                                        ContentsPremium += 20000 * (ContentsRate * 75 / 100) / 100;

                                                        var remainingContent1 = Contents.Value - 30000;
                                                        ContentsPremium += remainingContent1 * (ContentsRate * 50 / 100) / 100;
                                                    }
                                                    else if (Contents.Value > 50000)
                                                    {
                                                        ContentsPremium = 10000 * ContentsRate / 100;
                                                        ContentsPremium += 20000 * (ContentsRate * 75 / 100) / 100;
                                                        ContentsPremium += 20000 * (ContentsRate * 50 / 100) / 100;

                                                        var remainingContent1 = Contents.Value - 50000;
                                                        ContentsPremium += remainingContent1 * (ContentsRate * 25 / 100) / 100;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        TenentsPremium = Tenents.Value * ContentsRate / 100;

                        TotalContentsPremium += ContentsPremium;
                        TotalContentsFireRate += ContentsFireRate;
                        TotalContentsPerilsRate += ContentsPerilsRate;
                        TotalTenentsPremium += TenentsPremium;

                        var Stock = premise_data.GetAttributeValue<Money>("lux_stockexcludinghighvaluestock");
                        var TargetStock = premise_data.GetAttributeValue<OptionSetValueCollection>("lux_listhighvaluestock");

                        if (Stock != null)
                        {
                            if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                            {
                                if (Stock.Value <= 20000)
                                {
                                    StockPremium = Stock.Value * StockRate / 100;
                                }
                                else
                                {
                                    if (Stock.Value <= 60000)
                                    {
                                        StockPremium = 20000 * StockRate / 100;
                                        var remainingContent = Stock.Value - 20000;
                                        StockPremium += remainingContent * (StockRate * 75 / 100) / 100;
                                    }
                                    else if (Stock.Value <= 100000)
                                    {
                                        StockPremium = 20000 * StockRate / 100;
                                        StockPremium += 40000 * (StockRate * 75 / 100) / 100;

                                        var remainingContent1 = Stock.Value - 60000;
                                        StockPremium += remainingContent1 * (StockRate * 50 / 100) / 100;
                                    }
                                    else if (Stock.Value > 100000)
                                    {
                                        StockPremium = 20000 * StockRate / 100;
                                        StockPremium += 40000 * (StockRate * 75 / 100) / 100;
                                        StockPremium += 40000 * (StockRate * 50 / 100) / 100;

                                        var remainingContent1 = Stock.Value - 100000;
                                        StockPremium += remainingContent1 * (StockRate * 25 / 100) / 100;
                                    }
                                }
                                TotalStockPremium += StockPremium;
                                TotalStockRate += StockRate;
                            }
                            else if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                            {
                                if (inceptionDate >= new DateTime(2025, 08, 01))
                                {
                                    if (Stock.Value <= 20000)
                                    {
                                        StockPremium = Stock.Value * StockRate / 100;
                                    }
                                    else
                                    {
                                        if (Stock.Value <= 60000)
                                        {
                                            StockPremium = 20000 * StockRate / 100;
                                            var remainingContent = Stock.Value - 20000;
                                            StockPremium += remainingContent * (StockRate * 75 / 100) / 100;
                                        }
                                        else if (Stock.Value <= 100000)
                                        {
                                            StockPremium = 20000 * StockRate / 100;
                                            StockPremium += 40000 * (StockRate * 75 / 100) / 100;

                                            var remainingContent1 = Stock.Value - 60000;
                                            StockPremium += remainingContent1 * (StockRate * 50 / 100) / 100;
                                        }
                                        else if (Stock.Value > 100000)
                                        {
                                            StockPremium = 20000 * StockRate / 100;
                                            StockPremium += 40000 * (StockRate * 75 / 100) / 100;
                                            StockPremium += 40000 * (StockRate * 50 / 100) / 100;

                                            var remainingContent1 = Stock.Value - 100000;
                                            StockPremium += remainingContent1 * (StockRate * 25 / 100) / 100;
                                        }
                                    }
                                    TotalStockPremium += StockPremium;
                                    TotalStockRate += StockRate;
                                }
                                else
                                {
                                    decimal StockTier1 = Stock.Value * Convert.ToDecimal(0.5) * Convert.ToDecimal(StockRate) / 100;
                                    decimal StockTier2 = Stock.Value * Convert.ToDecimal(0.25) * (StockRate * Convert.ToDecimal(0.5)) / 100;
                                    decimal StockTier3 = Stock.Value * Convert.ToDecimal(0.125) * (StockRate * Convert.ToDecimal(0.2)) / 100;
                                    decimal StockTier4 = Stock.Value * Convert.ToDecimal(0.125) * (StockRate * Convert.ToDecimal(0.1)) / 100;

                                    StockPremium = StockTier1 + StockTier2 + StockTier3 + StockTier4;

                                    TotalStockPremium += StockPremium;
                                    TotalStockRate += StockRate;
                                }
                            }
                            else
                            {
                                if (item2.Attributes.Contains("lux_policy"))
                                {
                                    var Policy = service.Retrieve("lux_policy", item2.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                    if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                    {
                                        if (quotationDate < new DateTime(2023, 02, 15))
                                        {
                                            decimal StockTier1 = Stock.Value * Convert.ToDecimal(0.5) * Convert.ToDecimal(StockRate) / 100;
                                            decimal StockTier2 = Stock.Value * Convert.ToDecimal(0.25) * (StockRate * Convert.ToDecimal(0.5)) / 100;
                                            decimal StockTier3 = Stock.Value * Convert.ToDecimal(0.125) * (StockRate * Convert.ToDecimal(0.2)) / 100;
                                            decimal StockTier4 = Stock.Value * Convert.ToDecimal(0.125) * (StockRate * Convert.ToDecimal(0.1)) / 100;

                                            StockPremium = StockTier1 + StockTier2 + StockTier3 + StockTier4;

                                            TotalStockPremium += StockPremium;
                                            TotalStockRate += StockRate;
                                        }
                                        else
                                        {
                                            if (Stock.Value <= 20000)
                                            {
                                                StockPremium = Stock.Value * StockRate / 100;
                                            }
                                            else
                                            {
                                                if (Stock.Value <= 60000)
                                                {
                                                    StockPremium = 20000 * StockRate / 100;
                                                    var remainingContent = Stock.Value - 20000;
                                                    StockPremium += remainingContent * (StockRate * 75 / 100) / 100;
                                                }
                                                else if (Stock.Value <= 100000)
                                                {
                                                    StockPremium = 20000 * StockRate / 100;
                                                    StockPremium += 40000 * (StockRate * 75 / 100) / 100;

                                                    var remainingContent1 = Stock.Value - 60000;
                                                    StockPremium += remainingContent1 * (StockRate * 50 / 100) / 100;
                                                }
                                                else if (Stock.Value > 100000)
                                                {
                                                    StockPremium = 20000 * StockRate / 100;
                                                    StockPremium += 40000 * (StockRate * 75 / 100) / 100;
                                                    StockPremium += 40000 * (StockRate * 50 / 100) / 100;

                                                    var remainingContent1 = Stock.Value - 100000;
                                                    StockPremium += remainingContent1 * (StockRate * 25 / 100) / 100;
                                                }
                                            }
                                            TotalStockPremium += StockPremium;
                                            TotalStockRate += StockRate;
                                        }
                                    }
                                    else
                                    {
                                        if (inceptionDate >= new DateTime(2025, 08, 01))
                                        {
                                            if (Stock.Value <= 20000)
                                            {
                                                StockPremium = Stock.Value * StockRate / 100;
                                            }
                                            else
                                            {
                                                if (Stock.Value <= 60000)
                                                {
                                                    StockPremium = 20000 * StockRate / 100;
                                                    var remainingContent = Stock.Value - 20000;
                                                    StockPremium += remainingContent * (StockRate * 75 / 100) / 100;
                                                }
                                                else if (Stock.Value <= 100000)
                                                {
                                                    StockPremium = 20000 * StockRate / 100;
                                                    StockPremium += 40000 * (StockRate * 75 / 100) / 100;

                                                    var remainingContent1 = Stock.Value - 60000;
                                                    StockPremium += remainingContent1 * (StockRate * 50 / 100) / 100;
                                                }
                                                else if (Stock.Value > 100000)
                                                {
                                                    StockPremium = 20000 * StockRate / 100;
                                                    StockPremium += 40000 * (StockRate * 75 / 100) / 100;
                                                    StockPremium += 40000 * (StockRate * 50 / 100) / 100;

                                                    var remainingContent1 = Stock.Value - 100000;
                                                    StockPremium += remainingContent1 * (StockRate * 25 / 100) / 100;
                                                }
                                            }
                                            TotalStockPremium += StockPremium;
                                            TotalStockRate += StockRate;
                                        }
                                        else
                                        {
                                            decimal StockTier1 = Stock.Value * Convert.ToDecimal(0.5) * Convert.ToDecimal(StockRate) / 100;
                                            decimal StockTier2 = Stock.Value * Convert.ToDecimal(0.25) * (StockRate * Convert.ToDecimal(0.5)) / 100;
                                            decimal StockTier3 = Stock.Value * Convert.ToDecimal(0.125) * (StockRate * Convert.ToDecimal(0.2)) / 100;
                                            decimal StockTier4 = Stock.Value * Convert.ToDecimal(0.125) * (StockRate * Convert.ToDecimal(0.1)) / 100;

                                            StockPremium = StockTier1 + StockTier2 + StockTier3 + StockTier4;

                                            TotalStockPremium += StockPremium;
                                            TotalStockRate += StockRate;
                                        }
                                    }
                                }
                            }
                        }

                        if (TargetStock != null)
                        {
                            decimal WineSumInsured = premise_data.Attributes.Contains("lux_winesfortifiedwinesspiritsfinesuminsured") ? premise_data.GetAttributeValue<Money>("lux_winesfortifiedwinesspiritsfinesuminsured").Value : 0;
                            decimal NonFerrusInsured = premise_data.Attributes.Contains("lux_nonferrousmetalssuminsured") ? premise_data.GetAttributeValue<Money>("lux_nonferrousmetalssuminsured").Value : 0;
                            decimal MobileInsured = premise_data.Attributes.Contains("lux_mobilephonessuminsured") ? premise_data.GetAttributeValue<Money>("lux_mobilephonessuminsured").Value : 0;
                            decimal ComputerSumInsured = premise_data.Attributes.Contains("lux_computerequipmentsuminsured") ? premise_data.GetAttributeValue<Money>("lux_computerequipmentsuminsured").Value : 0;
                            decimal AlcoholSumInsured = premise_data.Attributes.Contains("lux_alcoholsuminsured") ? premise_data.GetAttributeValue<Money>("lux_alcoholsuminsured").Value : 0;
                            decimal AudioSumInsured = premise_data.Attributes.Contains("lux_audiovideoequipmentsuminsured") ? premise_data.GetAttributeValue<Money>("lux_audiovideoequipmentsuminsured").Value : 0;
                            decimal CigarettesSumInsured = premise_data.Attributes.Contains("lux_cigarettescigarsortobaccoproductssuminsur") ? premise_data.GetAttributeValue<Money>("lux_cigarettescigarsortobaccoproductssuminsur").Value : 0;
                            decimal ComputerGamesInsured = premise_data.Attributes.Contains("lux_computergamesandorconsolessuminsured") ? premise_data.GetAttributeValue<Money>("lux_computergamesandorconsolessuminsured").Value : 0;
                            decimal JewelleryInsured = premise_data.Attributes.Contains("lux_jewellerywatchessuminsured") ? premise_data.GetAttributeValue<Money>("lux_jewellerywatchessuminsured").Value : 0;
                            decimal PowerToolsSumInsured = premise_data.Attributes.Contains("lux_powertoolssuminsured") ? premise_data.GetAttributeValue<Money>("lux_powertoolssuminsured").Value : 0;
                            decimal FineArtSumInsured = premise_data.Attributes.Contains("lux_fineartsuminsured") ? premise_data.GetAttributeValue<Money>("lux_fineartsuminsured").Value : 0;
                            var TargetStockSI = WineSumInsured + NonFerrusInsured + MobileInsured + ComputerSumInsured + AlcoholSumInsured + AudioSumInsured + CigarettesSumInsured + ComputerGamesInsured + JewelleryInsured + PowerToolsSumInsured + FineArtSumInsured;

                            if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                            {
                                if (TargetStockSI <= 20000)
                                {
                                    TargetStockPremium = TargetStockSI * StockRate / 100;
                                }
                                else
                                {
                                    if (TargetStockSI <= 60000)
                                    {
                                        TargetStockPremium = 20000 * StockRate / 100;
                                        var remainingContent = TargetStockSI - 20000;
                                        TargetStockPremium += remainingContent * (StockRate * 75 / 100) / 100;
                                    }
                                    else if (TargetStockSI <= 100000)
                                    {
                                        TargetStockPremium = 20000 * StockRate / 100;
                                        TargetStockPremium += 40000 * (StockRate * 75 / 100) / 100;

                                        var remainingContent1 = TargetStockSI - 60000;
                                        TargetStockPremium += remainingContent1 * (StockRate * 50 / 100) / 100;
                                    }
                                    else if (TargetStockSI > 100000)
                                    {
                                        TargetStockPremium = 20000 * StockRate / 100;
                                        TargetStockPremium += 40000 * (StockRate * 75 / 100) / 100;
                                        TargetStockPremium += 40000 * (StockRate * 50 / 100) / 100;

                                        var remainingContent1 = TargetStockSI - 100000;
                                        TargetStockPremium += remainingContent1 * (StockRate * 25 / 100) / 100;
                                    }
                                }
                                TotalTargetStockPremium += TargetStockPremium;
                                TotalTargetStockRate += Convert.ToDecimal(2);
                            }
                            else if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                            {
                                if (inceptionDate >= new DateTime(2025, 08, 01))
                                {
                                    if (TargetStockSI <= 20000)
                                    {
                                        TargetStockPremium = TargetStockSI * StockRate / 100;
                                    }
                                    else
                                    {
                                        if (TargetStockSI <= 60000)
                                        {
                                            TargetStockPremium = 20000 * StockRate / 100;
                                            var remainingContent = TargetStockSI - 20000;
                                            TargetStockPremium += remainingContent * (StockRate * 75 / 100) / 100;
                                        }
                                        else if (TargetStockSI <= 100000)
                                        {
                                            TargetStockPremium = 20000 * StockRate / 100;
                                            TargetStockPremium += 40000 * (StockRate * 75 / 100) / 100;

                                            var remainingContent1 = TargetStockSI - 60000;
                                            TargetStockPremium += remainingContent1 * (StockRate * 50 / 100) / 100;
                                        }
                                        else if (TargetStockSI > 100000)
                                        {
                                            TargetStockPremium = 20000 * StockRate / 100;
                                            TargetStockPremium += 40000 * (StockRate * 75 / 100) / 100;
                                            TargetStockPremium += 40000 * (StockRate * 50 / 100) / 100;

                                            var remainingContent1 = TargetStockSI - 100000;
                                            TargetStockPremium += remainingContent1 * (StockRate * 25 / 100) / 100;
                                        }
                                    }
                                    TotalTargetStockPremium += TargetStockPremium;
                                    TotalTargetStockRate += Convert.ToDecimal(2);
                                }
                                else
                                {
                                    decimal StockTier1 = TargetStockSI * Convert.ToDecimal(0.5) * Convert.ToDecimal(2) / 100;
                                    decimal StockTier2 = TargetStockSI * Convert.ToDecimal(0.25) * Convert.ToDecimal(1) / 100;
                                    decimal StockTier3 = TargetStockSI * Convert.ToDecimal(0.125) * Convert.ToDecimal(0.7) / 100;
                                    decimal StockTier4 = TargetStockSI * Convert.ToDecimal(0.125) * Convert.ToDecimal(0.7) / 100;

                                    TargetStockPremium = StockTier1 + StockTier2 + StockTier3 + StockTier4;

                                    TotalTargetStockPremium += TargetStockPremium;
                                    TotalTargetStockRate += Convert.ToDecimal(2);
                                }
                            }
                            else
                            {
                                if (item2.Attributes.Contains("lux_policy"))
                                {
                                    var Policy = service.Retrieve("lux_policy", item2.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                    if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                    {
                                        if (quotationDate < new DateTime(2023, 02, 15))
                                        {
                                            decimal StockTier1 = TargetStockSI * Convert.ToDecimal(0.5) * Convert.ToDecimal(2) / 100;
                                            decimal StockTier2 = TargetStockSI * Convert.ToDecimal(0.25) * Convert.ToDecimal(1) / 100;
                                            decimal StockTier3 = TargetStockSI * Convert.ToDecimal(0.125) * Convert.ToDecimal(0.7) / 100;
                                            decimal StockTier4 = TargetStockSI * Convert.ToDecimal(0.125) * Convert.ToDecimal(0.7) / 100;

                                            TargetStockPremium = StockTier1 + StockTier2 + StockTier3 + StockTier4;

                                            TotalTargetStockPremium += TargetStockPremium;
                                            TotalTargetStockRate += Convert.ToDecimal(2);
                                        }
                                        else
                                        {
                                            if (TargetStockSI <= 20000)
                                            {
                                                TargetStockPremium = TargetStockSI * StockRate / 100;
                                            }
                                            else
                                            {
                                                if (TargetStockSI <= 60000)
                                                {
                                                    TargetStockPremium = 20000 * StockRate / 100;
                                                    var remainingContent = TargetStockSI - 20000;
                                                    TargetStockPremium += remainingContent * (StockRate * 75 / 100) / 100;
                                                }
                                                else if (TargetStockSI <= 100000)
                                                {
                                                    TargetStockPremium = 20000 * StockRate / 100;
                                                    TargetStockPremium += 40000 * (StockRate * 75 / 100) / 100;

                                                    var remainingContent1 = TargetStockSI - 60000;
                                                    TargetStockPremium += remainingContent1 * (StockRate * 50 / 100) / 100;
                                                }
                                                else if (TargetStockSI > 100000)
                                                {
                                                    TargetStockPremium = 20000 * StockRate / 100;
                                                    TargetStockPremium += 40000 * (StockRate * 75 / 100) / 100;
                                                    TargetStockPremium += 40000 * (StockRate * 50 / 100) / 100;

                                                    var remainingContent1 = TargetStockSI - 100000;
                                                    TargetStockPremium += remainingContent1 * (StockRate * 25 / 100) / 100;
                                                }
                                            }
                                            TotalTargetStockPremium += TargetStockPremium;
                                            TotalTargetStockRate += Convert.ToDecimal(2);
                                        }
                                    }
                                    else
                                    {
                                        if (inceptionDate >= new DateTime(2025, 08, 01))
                                        {
                                            if (TargetStockSI <= 20000)
                                            {
                                                TargetStockPremium = TargetStockSI * StockRate / 100;
                                            }
                                            else
                                            {
                                                if (TargetStockSI <= 60000)
                                                {
                                                    TargetStockPremium = 20000 * StockRate / 100;
                                                    var remainingContent = TargetStockSI - 20000;
                                                    TargetStockPremium += remainingContent * (StockRate * 75 / 100) / 100;
                                                }
                                                else if (TargetStockSI <= 100000)
                                                {
                                                    TargetStockPremium = 20000 * StockRate / 100;
                                                    TargetStockPremium += 40000 * (StockRate * 75 / 100) / 100;

                                                    var remainingContent1 = TargetStockSI - 60000;
                                                    TargetStockPremium += remainingContent1 * (StockRate * 50 / 100) / 100;
                                                }
                                                else if (TargetStockSI > 100000)
                                                {
                                                    TargetStockPremium = 20000 * StockRate / 100;
                                                    TargetStockPremium += 40000 * (StockRate * 75 / 100) / 100;
                                                    TargetStockPremium += 40000 * (StockRate * 50 / 100) / 100;

                                                    var remainingContent1 = TargetStockSI - 100000;
                                                    TargetStockPremium += remainingContent1 * (StockRate * 25 / 100) / 100;
                                                }
                                            }
                                            TotalTargetStockPremium += TargetStockPremium;
                                            TotalTargetStockRate += Convert.ToDecimal(2);
                                        }
                                        else
                                        {
                                            decimal StockTier1 = TargetStockSI * Convert.ToDecimal(0.5) * Convert.ToDecimal(2) / 100;
                                            decimal StockTier2 = TargetStockSI * Convert.ToDecimal(0.25) * Convert.ToDecimal(1) / 100;
                                            decimal StockTier3 = TargetStockSI * Convert.ToDecimal(0.125) * Convert.ToDecimal(0.7) / 100;
                                            decimal StockTier4 = TargetStockSI * Convert.ToDecimal(0.125) * Convert.ToDecimal(0.7) / 100;

                                            TargetStockPremium = StockTier1 + StockTier2 + StockTier3 + StockTier4;

                                            TotalTargetStockPremium += TargetStockPremium;
                                            TotalTargetStockRate += Convert.ToDecimal(2);
                                        }
                                    }
                                }
                            }
                        }

                        var ComputerEquipment = premise_data.GetAttributeValue<Money>("lux_computerandelectronicbusinessequipment");
                        if (ComputerEquipment != null)
                        {
                            ComputerEquipmentPremium = ComputerEquipment.Value * Convert.ToDecimal(0.5) / 100;

                            TotalComputerEquipmentPremium += ComputerEquipmentPremium;
                            TotalComputerEquipmentRate += Convert.ToDecimal(0.5);
                        }

                        var LossofRent = premise_data.GetAttributeValue<Money>("lux_materialdamagelossofrentpayable");
                        if (LossofRent != null)
                        {
                            LossofRentPremium = LossofRent.Value * Convert.ToDecimal(LORRate) / 100;

                            TotalLossofRentPremium += LossofRentPremium;
                            TotalLORRate += LORRate;
                        }

                        var totalPremium = BuildingPremium + ContentsPremium + TenentsPremium + StockPremium + TargetStockPremium + ComputerEquipmentPremium + LossofRentPremium;
                        totalPremium = totalPremium * dateDiffDays / 365;

                        var item1 = service.Retrieve(entityName, item.Id, new ColumnSet(true));
                        if (totalPremium < Convert.ToDecimal(50))
                        {
                            totalPremium = Convert.ToDecimal(50);
                            item1["lux_materialdamagepremium"] = new Money(50);
                        }
                        else
                        {
                            item1["lux_materialdamagepremium"] = new Money(totalPremium);
                        }
                        item1["lux_buildingsfirerate"] = BuildingFireRate;
                        item1["lux_buildingsperilsrate"] = BuildingPerilsRate;
                        item1["lux_contentsfirerate"] = ContentsFireRate;
                        item1["lux_contentsperilsrate"] = ContentsPerilsRate;
                        item1["lux_stockrate"] = StockRate;
                        item1["lux_targetstockrate"] = Convert.ToDecimal(3);
                        item1["lux_computerequipmentrate"] = Convert.ToDecimal(0.5);
                        item1["lux_lossofrentpayablerate"] = LORRate;
                        service.Update(item1);

                        TotalMDPremium += totalPremium;
                    }
                    else
                    {
                        TotalMDPremium += 50;

                        var item1 = service.Retrieve(entityName, item.Id, new ColumnSet(true));
                        item1["lux_materialdamagepremium"] = new Money(50);
                        item1["lux_buildingsfirerate"] = Convert.ToDecimal(0);
                        item1["lux_buildingsperilsrate"] = Convert.ToDecimal(0);
                        item1["lux_contentsfirerate"] = Convert.ToDecimal(0);
                        item1["lux_contentsperilsrate"] = Convert.ToDecimal(0);
                        item1["lux_stockrate"] = Convert.ToDecimal(0);
                        item1["lux_targetstockrate"] = Convert.ToDecimal(0);
                        item1["lux_computerequipmentrate"] = Convert.ToDecimal(0);
                        item1["lux_lossofrentpayablerate"] = Convert.ToDecimal(0);
                        service.Update(item1);
                    }
                }

                if (TotalMDPremium < 100)
                {
                    item2["lux_retailmdpremium"] = new Money(100);
                }
                else
                {
                    item2["lux_retailmdpremium"] = new Money(TotalMDPremium);
                }
                item2["lux_buildingpremium"] = new Money(TotalBuildingPremium * dateDiffDays / 365);
                item2["lux_contentspremium"] = new Money(TotalContentsPremium * dateDiffDays / 365);
                item2["lux_tenentspremium"] = new Money(TotalTenentsPremium * dateDiffDays / 365);
                item2["lux_stockpremium"] = Convert.ToDecimal(TotalStockPremium * dateDiffDays / 365);
                item2["lux_targetstockpremium"] = Convert.ToDecimal(TotalTargetStockPremium * dateDiffDays / 365);
                item2["lux_computerequipmentpremium"] = Convert.ToDecimal(TotalComputerEquipmentPremium * dateDiffDays / 365);
                item2["lux_lossofrentpremium"] = Convert.ToDecimal(TotalLossofRentPremium * dateDiffDays / 365);

                item2["lux_buildingfirerate"] = Convert.ToDecimal(TotalBuildingFireRate / PremiseCount);
                item2["lux_buildingperilsrate"] = Convert.ToDecimal(TotalBuildingPerilsRate / PremiseCount);
                item2["lux_contentsfirerate"] = Convert.ToDecimal(TotalContentsFireRate / PremiseCount);
                item2["lux_contentsperilsrate"] = Convert.ToDecimal(TotalContentsPerilsRate / PremiseCount);
                item2["lux_stockrate"] = Convert.ToDecimal(TotalStockRate / PremiseCount);
                item2["lux_targetstockrate"] = Convert.ToDecimal(TotalTargetStockRate / PremiseCount);
                item2["lux_computerequipmentrate"] = Convert.ToDecimal(TotalComputerEquipmentRate / PremiseCount);
                item2["lux_lossofrentrate"] = Convert.ToDecimal(TotalLORRate / PremiseCount);
                service.Update(item2);
            }
            else
            {
                var item2 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                item2["lux_retailmdpremium"] = new Money(0);
                item2["lux_buildingpremium"] = new Money(0);
                item2["lux_contentspremium"] = new Money(0);
                item2["lux_tenentspremium"] = new Money(0);
                item2["lux_stockpremium"] = Convert.ToDecimal(0);
                item2["lux_targetstockpremium"] = Convert.ToDecimal(0);
                item2["lux_computerequipmentpremium"] = Convert.ToDecimal(0);
                item2["lux_lossofrentpremium"] = Convert.ToDecimal(0);
                item2["lux_buildingfirerate"] = Convert.ToDecimal(0);
                item2["lux_buildingperilsrate"] = Convert.ToDecimal(0);
                item2["lux_contentsfirerate"] = Convert.ToDecimal(0);
                item2["lux_contentsperilsrate"] = Convert.ToDecimal(0);
                item2["lux_stockrate"] = Convert.ToDecimal(0);
                item2["lux_targetstockrate"] = Convert.ToDecimal(0);
                item2["lux_computerequipmentrate"] = Convert.ToDecimal(0);
                item2["lux_lossofrentrate"] = Convert.ToDecimal(0);
                service.Update(item2);
            }

            if (Product.Get(executionContext).ToString() == "Contractors Combined")
            {
                var item2 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                if (item2.GetAttributeValue<bool>("lux_ismaterialdamagecoverrequired") == false)
                {
                    item2["lux_retailmdpremium"] = new Money(0);
                    item2["lux_buildingpremium"] = new Money(0);
                    item2["lux_contentspremium"] = new Money(0);
                    item2["lux_tenentspremium"] = new Money(0);
                    item2["lux_stockpremium"] = Convert.ToDecimal(0);
                    item2["lux_targetstockpremium"] = Convert.ToDecimal(0);
                    item2["lux_computerequipmentpremium"] = Convert.ToDecimal(0);
                    item2["lux_lossofrentpremium"] = Convert.ToDecimal(0);
                    item2["lux_buildingfirerate"] = Convert.ToDecimal(0);
                    item2["lux_buildingperilsrate"] = Convert.ToDecimal(0);
                    item2["lux_contentsfirerate"] = Convert.ToDecimal(0);
                    item2["lux_contentsperilsrate"] = Convert.ToDecimal(0);
                    item2["lux_stockrate"] = Convert.ToDecimal(0);
                    item2["lux_targetstockrate"] = Convert.ToDecimal(0);
                    item2["lux_computerequipmentrate"] = Convert.ToDecimal(0);
                    item2["lux_lossofrentrate"] = Convert.ToDecimal(0);
                    service.Update(item2);
                }
            }
        }
    }
}