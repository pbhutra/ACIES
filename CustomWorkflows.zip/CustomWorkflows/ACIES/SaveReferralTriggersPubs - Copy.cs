﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Net;
using System.ServiceModel.Description;
using System.Linq;

namespace CustomWorkflows
{
    public class SaveReferralTriggersPubsCopy : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference applnref = PropertyOwnersApplication.Get<EntityReference>(executionContext);
            Entity appln = new Entity(applnref.LogicalName, applnref.Id);
            appln = service.Retrieve("lux_propertyownersapplications", applnref.Id, new ColumnSet(true));

            if (appln.Attributes.Contains("lux_declarationsquestion1"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_declarationsquestion1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion1") == false)
                    {
                        var FieldName1 = "The Proposers any Director or Partner in the company:";
                        FieldName1 += "a. Has never been convicted";
                        FieldName1 += "b. Has never been charged(but not yet tried)";
                        FieldName1 += "c. Has never been given an official police caution in respect of any criminal offence other than a than a(road traffic) motoring offence";
                        FieldName1 += "d. Has never been given an official police caution in respect of any criminal offence other than an offence that is now considered 'spent' under the Rehabilitation of Offenders Act 1974";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_declarationsquestion1";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_declarationanswer1") ? appln.Attributes["lux_declarationanswer1"] : "";
                        refer["lux_suppliedvalue"] = "Disagree";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion1") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_declarationsquestion2"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_declarationsquestion2' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion2") == false)
                    {
                        var FieldName1 = "The Proposers, any Director or Partner in the company:";
                        FieldName1 += "a. Has never been declared bankrupt (other than a bankruptcy that has been discharged) or insolvent";
                        FieldName1 += "b. Is not subject to any current bankruptcy or insolvency proceedings";
                        FieldName1 += "c. Has no outstanding County Court Judgement(s) or Sheriff Court Decree(s)";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_declarationsquestion2";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_declarationanswer2") ? appln.Attributes["lux_declarationanswer2"] : "";
                        refer["lux_suppliedvalue"] = "Disagree";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion2") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_declarationsquestion3"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_declarationsquestion3' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion3") == false)
                    {
                        var FieldName1 = "The Proposers any Director or Partner in the company have never been prosecuted or received notice of intended prosecution under:";
                        FieldName1 += "a. The Consumer Protection Act 1987";
                        FieldName1 += "b. The Food Safety Act 1990";
                        FieldName1 += "c. The Health & Safety Act 1974";
                        FieldName1 += "d. Any welfare or environmental protection legislation";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_declarationsquestion3";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_declarationanswer3") ? appln.Attributes["lux_declarationanswer3"] : "";
                        refer["lux_suppliedvalue"] = "Disagree";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion3") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_declarationsquestion4"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_declarationsquestion4' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion4") == false)
                    {
                        var FieldName1 = "The Proposers any Director or Partner in the company have not had:";
                        FieldName1 += "a. an insurance application refused or declined";
                        FieldName1 += "b. an insurance cancelled or renewal refused";
                        FieldName1 += "c. any increased or specific terms applied to any business insurance";
                        FieldName1 += "d. avioided any of your insurance policies for non-disclosure or misrepresentation of any material fact";
                        FieldName1 += "e. refused to pay a claim or restricted cover as a result of a policy terms or condition or risk improvement requirements.";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_declarationsquestion4";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_declarationanswer4") ? appln.Attributes["lux_declarationanswer4"] : "";
                        refer["lux_suppliedvalue"] = "Disagree";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion4") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_claimmadewithinthelast5years"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_claimmadewithinthelast5years' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == true)
                    {
                        var FieldName1 = "Has your business been involved in any losses, claims or incidents that may result in a claim within the last 5 years";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_claimmadewithinthelast5years";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_datethebusinessstarted"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_datethebusinessstarted' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if ((DateTime.Now.Year - 1) <= appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").Year)
                    {
                        var FieldName1 = "Date the business started";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_datethebusinessstarted";
                        refer["lux_additionalinfo"] = "Trading less than 12 months";
                        refer["lux_suppliedvalue"] = appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").ToShortDateString();
                        service.Create(refer);
                    }
                }
                else
                {
                    if ((DateTime.Now.Year - 1) > appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").Year)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                    else if ((DateTime.Now.Year - 1) <= appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").Year)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").ToShortDateString();
                        reff["lux_additionalinfo"] = "Trading less than 12 months";
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_anyheatworkawayundertaken"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_anyheatworkawayundertaken' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_anyheatworkawayundertaken") == true)
                    {
                        var FieldName1 = "Any heat work away undertaken";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_anyheatworkawayundertaken";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_anyheatworkawayundertaken") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_bonafidesubcontractorswageroll"))
            {
                var workawayWageroll = appln.Attributes.Contains("lux_workawaywageroll") ? appln.GetAttributeValue<Money>("lux_workawaywageroll").Value : 0;
                var bonafideWageroll = appln.Attributes.Contains("lux_bonafidesubcontractorswageroll") ? appln.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value : 0;
                decimal heat = 0;
                if (appln.Attributes.Contains("lux_anyheatworkawayundertaken"))
                {
                    if (appln.GetAttributeValue<bool>("lux_anyheatworkawayundertaken") == true)
                        heat = appln.Attributes.Contains("lux_heatworkawaywageroll") ? appln.GetAttributeValue<Money>("lux_heatworkawaywageroll").Value : 0;
                }
                var TotalTurnover = workawayWageroll + bonafideWageroll + heat;

                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_bonafidesubcontractorswageroll' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (TotalTurnover * 25 / 100 < appln.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value)
                    {
                        var FieldName1 = "Bonafide Subcontractors Wageroll";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_bonafidesubcontractorswageroll";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_bonafidesubcontractorswageroll"];
                        refer["lux_additionalinfo"] = (bonafideWageroll * 100 / TotalTurnover).ToString("#.##") + "%";
                        if (appln.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value > TotalTurnover * 80 / 100)
                        {
                            refer["lux_refertohcc"] = true;
                            refer["lux_additionalinfo"] = "Refer Risk to HCC for Approval as Bonafide Wageroll is: " + (bonafideWageroll * 100 / TotalTurnover).ToString("#.##") + "%";
                        }
                        service.Create(refer);
                    }
                }
                else
                {
                    if (TotalTurnover * 25 / 100 >= appln.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (TotalTurnover * 25 / 100 < appln.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_bonafidesubcontractorswageroll"];
                        reff["lux_additionalinfo"] = (bonafideWageroll * 100 / TotalTurnover).ToString("#.##") + "%";
                        if (appln.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value > TotalTurnover * 80 / 100)
                        {
                            reff["lux_refertohcc"] = true;
                            reff["lux_additionalinfo"] = "Refer Risk to HCC for Approval as Bonafide Wageroll is: " + (bonafideWageroll * 100 / TotalTurnover).ToString("#.##") + "%";
                        }
                        else
                        {
                            reff["lux_refertohcc"] = false;
                            reff["lux_additionalinfo"] = (bonafideWageroll * 100 / TotalTurnover).ToString("#.##") + "%";
                        }
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_northamericaandcanadaturnover"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_northamericaandcanadaturnover' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_northamericaandcanadaturnover").Value > 0)
                    {
                        var FieldName1 = "North America and Canada Turnover";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_northamericaandcanadaturnover";
                        refer["lux_additionalinfo"] = "Refer Risk to HCC for Approval";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_northamericaandcanadaturnover"];
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_northamericaandcanadaturnover").Value <= 0)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<Money>("lux_northamericaandcanadaturnover").Value > 0)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_northamericaandcanadaturnover"];
                        reff["lux_additionalinfo"] = "Refer Risk to HCC for Approval";
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_ukturnover"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_ukturnover' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_turnover").Value * 50 / 100 > appln.GetAttributeValue<Money>("lux_ukturnover").Value)
                    {
                        var FieldName1 = "UK Turnover";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_ukturnover";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ukturnoverpercentage") ? appln.Attributes["lux_ukturnoverpercentage"] : "";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_ukturnover"];
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_turnover").Value * 50 / 100 <= appln.GetAttributeValue<Money>("lux_ukturnover").Value)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<Money>("lux_turnover").Value * 50 / 100 > appln.GetAttributeValue<Money>("lux_ukturnover").Value)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_additionalinfo"] = appln.Attributes.Contains("lux_ukturnoverpercentage") ? appln.Attributes["lux_ukturnoverpercentage"] : "";
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_northamericaandcanadaturnover"];
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_moneyonpremisesduringhours"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_moneyonpremisesduringhours' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<OptionSetValue>("lux_moneyonpremisesduringhours").Value > 972970003)
                    {
                        var FieldName1 = "Money on Premises during business hours";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_moneyonpremisesduringhours";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_moneyonpremisesduringhours"];
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<OptionSetValue>("lux_moneyonpremisesduringhours").Value <= 972970003)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<OptionSetValue>("lux_moneyonpremisesduringhours").Value > 972970003)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_moneyonpremisesduringhours"];
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_moneyinspecifiedsafe"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_moneyinspecifiedsafe' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_moneyinspecifiedsafe").Value > 10000)
                    {
                        var FieldName1 = "Money in safe outside business hours";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_moneyinspecifiedsafe";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_moneyinspecifiedsafe"];
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_moneyinspecifiedsafe").Value <= 10000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<Money>("lux_moneyinspecifiedsafe").Value > 10000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_moneyinspecifiedsafe"];
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_allriskitems"))
            {
                var AllRiskfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_allriskitem'>
                                                <attribute name='lux_typeofequipment' />
                                                <attribute name='lux_territoriallimit' />
                                                <attribute name='lux_suminsured' />
                                                <attribute name='lux_excess' />
                                                <attribute name='lux_allriskitemid' />
                                                <order attribute='lux_typeofequipment' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                                </filter>
                                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_application' link-type='inner' alias='aa'>
                                                  <filter type='and'>
                                                    <condition attribute='lux_allriskitems' operator='eq' value='1' />
                                                  </filter>
                                                </link-entity>
                                              </entity>
                                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.Count > 0)
                {
                    var CheckAmt = service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.Where(x => x.GetAttributeValue<Money>("lux_suminsured").Value > 10000).Count();
                    var items = service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.Where(x => x.GetAttributeValue<Money>("lux_suminsured").Value > 10000).Select(y => y.FormattedValues["lux_typeofequipment"]).ToArray();

                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_referral'>
                                                    <attribute name='lux_suppliedvalue' />
                                                    <attribute name='lux_fieldname' />
                                                    <attribute name='lux_approve' />
                                                    <attribute name='lux_additionalinfo' />
                                                    <attribute name='lux_referralid' />
                                                    <order attribute='lux_suppliedvalue' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_allriskitems' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                    {
                        if (CheckAmt > 0 && appln.GetAttributeValue<bool>("lux_allriskitems") == true)
                        {
                            var FieldName1 = "All Risk Items";
                            Entity refer = new Entity("lux_referral");
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_allriskitems";
                            refer["lux_suppliedvalue"] = String.Join(",", items);
                            service.Create(refer);
                        }
                    }
                    else
                    {
                        if (CheckAmt == 0 || appln.GetAttributeValue<bool>("lux_allriskitems") == false)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                        }
                        else if (CheckAmt > 0 && appln.GetAttributeValue<bool>("lux_allriskitems") == true)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            reff["lux_suppliedvalue"] = String.Join(",", items);
                            service.Update(reff);
                        }
                    }
                }
            }

            if (appln.Attributes.Contains("lux_employersliabilitypolicypremium"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_employersliabilitypolicypremium' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    var ELPremium = appln.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value;
                    if (ELPremium > 15000)
                    {
                        var FieldName1 = "Employer's Liability Premium";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_employersliabilitypolicypremium";
                        refer["lux_suppliedvalue"] = appln.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value.ToString();
                        refer["lux_additionalinfo"] = "Liability Survey Required";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value <= 15000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_publicproductsliabilitypremium"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_publicproductsliabilitypremium' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    var PLPremium = appln.GetAttributeValue<Money>("lux_publicproductsliabilitypremium").Value;
                    if (PLPremium > 15000)
                    {
                        var FieldName1 = "PL/Products Premium";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_publicproductsliabilitypremium";
                        refer["lux_suppliedvalue"] = appln.GetAttributeValue<Money>("lux_publicproductsliabilitypremium").Value.ToString();
                        refer["lux_additionalinfo"] = "Liability Survey Required";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_publicproductsliabilitypremium").Value <= 15000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_turnover"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_turnover' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_turnover").Value > 20000000)
                    {
                        var FieldName1 = "Total Turnover";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_turnover";
                        refer["lux_additionalinfo"] = "Refer Risk to HCC for Approval";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_turnover"];
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_turnover").Value <= 20000000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<Money>("lux_turnover").Value > 20000000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_additionalinfo"] = "Refer Risk to HCC for Approval";
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_turnover"];
                        service.Update(reff);
                    }
                }
            }

            if (appln.Attributes.Contains("lux_manualwageroll"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_manualwageroll' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_manualwageroll").Value > 5000000)
                    {
                        var FieldName1 = "Manual Wageroll";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_manualwageroll";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_manualwageroll"];
                        refer["lux_additionalinfo"] = "Refer Risk to HCC for Approval";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_manualwageroll").Value <= 5000000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<Money>("lux_manualwageroll").Value > 5000000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_manualwageroll"];
                        reff["lux_additionalinfo"] = "Refer Risk to HCC for Approval";
                        reff["lux_refertohcc"] = true;
                        service.Update(reff);
                    }
                }
            }

            var InceptionDate = appln.GetAttributeValue<DateTime>("lux_inceptiondate");
            var RenewalDate = appln.GetAttributeValue<DateTime>("lux_renewaldate");

            if (appln.Attributes.Contains("lux_renewaldate"))
            {
                var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_referral'>
                                            <attribute name='lux_suppliedvalue' />
                                            <attribute name='lux_fieldname' />
                                            <attribute name='lux_approve' />
                                            <attribute name='lux_additionalinfo' />
                                            <attribute name='lux_referralid' />
                                            <order attribute='lux_suppliedvalue' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                              <condition attribute='lux_fieldschemaname' operator='eq' value='lux_renewaldate' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                {
                    if ((RenewalDate - InceptionDate).Days < 364 || (RenewalDate - InceptionDate).Days > 540)
                    {
                        var FieldName1 = "Renewal Date";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_renewaldate";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_renewaldate"];
                        refer["lux_additionalinfo"] = "ARAG: PERIOD OF INSURANCES BOUND: 12 months(plus odd time not exceeding 18 months in total)";
                        service.Create(refer);
                    }
                }
                else
                {
                    if ((RenewalDate - InceptionDate).Days >= 364 && (RenewalDate - InceptionDate).Days <= 540)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch2)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_inceptiondate"))
            {
                var fetch3 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_referral'>
                                            <attribute name='lux_suppliedvalue' />
                                            <attribute name='lux_fieldname' />
                                            <attribute name='lux_approve' />
                                            <attribute name='lux_additionalinfo' />
                                            <attribute name='lux_referralid' />
                                            <order attribute='lux_suppliedvalue' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                              <condition attribute='lux_fieldschemaname' operator='eq' value='lux_inceptiondate' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch3)).Entities.Count == 0)
                {
                    if ((InceptionDate - DateTime.Now).Days > 60)
                    {
                        var FieldName1 = "Renewal Date";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_inceptiondate";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_inceptiondate"];
                        refer["lux_additionalinfo"] = "ARAG: MAXIMUM ADVANCE PERIOD FOR INCEPTION DATES: 60 days";
                        service.Create(refer);
                    }
                }
                else
                {
                    if ((InceptionDate - DateTime.Now).Days <= 60)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch3)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }

            var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_pubsrestaurantspropertyownersapplicatio'>
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_pubsrestaurantspropertyownersapplicatioid' />
                                <attribute name='lux_isthebuildingoflistedstatus' />
                                <attribute name='lux_locatedinareawithhistoryorflooding' />                                
                                <attribute name='lux_isthereanatm' />
                                <attribute name='lux_istheatmwithinanalarmedareainsidethepremi' />
                                <attribute name='lux_isthealarmundersolecontrolofthebusiness' />
                                <attribute name='lux_insuredisthesoleoccupant' />
                                <attribute name='lux_anybuildingsshowanysignofsubsidence' />
                                <attribute name='lux_signofsubsidencedetails' />
                                <attribute name='lux_hastherebeensubsidenceinthevicinity' />
                                <attribute name='lux_subsidencevicinitydetails' />
                                <attribute name='lux_listedbuildinggrades' />
                                <attribute name='lux_hasthereeverbeenaconsultingengineers' />
                                <attribute name='lux_consultingengineersreportdetails' />
                                <attribute name='lux_typesofconstruction' />
                                <attribute name='lux_doesthepremiseshaveaflatroof' />
                                <attribute name='lux_flatroofpercentage' />                               
                                <attribute name='lux_isthereanydeepfatfrying' />  
                                <attribute name='lux_icow' />
                                <attribute name='lux_bookdebts' />
                                <attribute name='lux_additionalincreasedcostofworking' />
                                <attribute name='lux_meetsminimumstandardofphysicalsecurity' />
                                <attribute name='lux_totalmdsuminsuredwithupliftedamount' />
                                <order attribute='lux_locationnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
            {
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch1)).Entities)
                {
                    if (item.Attributes.Contains("lux_insuredisthesoleoccupant"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_pubsrestaurants' operator='eq' uiname='' uitype='lux_pubsrestaurantspropertyownersapplicatio' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_insuredisthesoleoccupant' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_insuredisthesoleoccupant") == false)
                            {
                                var FieldName1 = "Insured is the sole occupant";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_insuredisthesoleoccupant";
                                refer["lux_suppliedvalue"] = "No";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_insuredisthesoleoccupant") == true)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_locatedinareawithhistoryorflooding"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_pubsrestaurants' operator='eq' uiname='' uitype='lux_pubsrestaurantspropertyownersapplicatio' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_locatedinareawithhistoryorflooding' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_locatedinareawithhistoryorflooding") == true)
                            {
                                var FieldName1 = "Located in Area with history or flooding";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_locatedinareawithhistoryorflooding";
                                refer["lux_suppliedvalue"] = "Yes";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_locatedinareawithhistoryorflooding") == false)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_isthebuildingoflistedstatus"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_pubsrestaurants' operator='eq' uiname='' uitype='lux_pubsrestaurantspropertyownersapplicatio' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isthebuildingoflistedstatus' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_isthebuildingoflistedstatus") == true)
                            {
                                var FieldName1 = "Is the Building of Listed Status";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_isthebuildingoflistedstatus";
                                refer["lux_suppliedvalue"] = "Yes";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_isthebuildingoflistedstatus") == false)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_listedbuildinggrades"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_pubsrestaurants' operator='eq' uiname='' uitype='lux_pubsrestaurantspropertyownersapplicatio' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_listedbuildinggrades' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {

                            if (item.GetAttributeValue<OptionSetValue>("lux_listedbuildinggrades").Value != 972970001 && item.GetAttributeValue<OptionSetValue>("lux_listedbuildinggrades").Value != 972970004)
                            {
                                var FieldName1 = "Listed Buidling Grades";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_listedbuildinggrades";
                                refer["lux_suppliedvalue"] = GetOptionSetTextUsingValue("lux_pubsrestaurantspropertyownersapplicatio", "lux_listedbuildinggrades", item.GetAttributeValue<OptionSetValue>("lux_listedbuildinggrades").Value, service);
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<OptionSetValue>("lux_listedbuildinggrades").Value == 972970001 || item.GetAttributeValue<OptionSetValue>("lux_listedbuildinggrades").Value == 972970004)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                            else if (item.GetAttributeValue<OptionSetValue>("lux_listedbuildinggrades").Value != 972970001 && item.GetAttributeValue<OptionSetValue>("lux_listedbuildinggrades").Value != 972970004)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                reff["lux_suppliedvalue"] = GetOptionSetTextUsingValue("lux_pubsrestaurantspropertyownersapplicatio", "lux_listedbuildinggrades", item.GetAttributeValue<OptionSetValue>("lux_listedbuildinggrades").Value, service);
                                service.Update(reff);
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_istheatmwithinanalarmedareainsidethepremi"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_pubsrestaurants' operator='eq' uiname='' uitype='lux_pubsrestaurantspropertyownersapplicatio' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_istheatmwithinanalarmedareainsidethepremi' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_istheatmwithinanalarmedareainsidethepremi") == false && item.GetAttributeValue<bool>("lux_isthereanatm") == true)
                            {
                                var FieldName1 = "Is the ATM within an alarmed area inside the premises?";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_istheatmwithinanalarmedareainsidethepremi";
                                refer["lux_suppliedvalue"] = "No";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_istheatmwithinanalarmedareainsidethepremi") == true || item.GetAttributeValue<bool>("lux_isthereanatm") == false)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_isthealarmundersolecontrolofthebusiness"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_pubsrestaurants' operator='eq' uiname='' uitype='lux_pubsrestaurantspropertyownersapplicatio' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isthealarmundersolecontrolofthebusiness' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_isthealarmundersolecontrolofthebusiness") == false)
                            {
                                var FieldName1 = "Is the alarm under sole control of the business";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_isthealarmundersolecontrolofthebusiness";
                                refer["lux_suppliedvalue"] = "No";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_isthealarmundersolecontrolofthebusiness") == true)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_anybuildingsshowanysignofsubsidence"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_pubsrestaurants' operator='eq' uiname='' uitype='lux_pubsrestaurantspropertyownersapplicatio' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_anybuildingsshowanysignofsubsidence' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_anybuildingsshowanysignofsubsidence") == true)
                            {
                                var FieldName1 = "Do any of the buildings show any sign of Subsidence, movement or cracking?";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_anybuildingsshowanysignofsubsidence";
                                if (item.Attributes.Contains("lux_signofsubsidencedetails"))
                                {
                                    refer["lux_additionalinfo"] = item.Attributes["lux_signofsubsidencedetails"];
                                }
                                refer["lux_suppliedvalue"] = "Yes";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_anybuildingsshowanysignofsubsidence") == false)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_hastherebeensubsidenceinthevicinity"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_pubsrestaurants' operator='eq' uiname='' uitype='lux_pubsrestaurantspropertyownersapplicatio' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_hastherebeensubsidenceinthevicinity' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_hastherebeensubsidenceinthevicinity") == true)
                            {
                                var FieldName1 = "Has there been subsidence in the vicinity of any of the premises?";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_hastherebeensubsidenceinthevicinity";
                                if (item.Attributes.Contains("lux_subsidencevicinitydetails"))
                                {
                                    refer["lux_additionalinfo"] = item.Attributes["lux_subsidencevicinitydetails"];
                                }
                                refer["lux_suppliedvalue"] = "Yes";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_hastherebeensubsidenceinthevicinity") == false)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_hasthereeverbeenaconsultingengineers"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_pubsrestaurants' operator='eq' uiname='' uitype='lux_pubsrestaurantspropertyownersapplicatio' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_hasthereeverbeenaconsultingengineers' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_hasthereeverbeenaconsultingengineers") == true)
                            {
                                var FieldName1 = "Has there ever been a consulting engineers report for any of the premises?";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_hasthereeverbeenaconsultingengineers";
                                if (item.Attributes.Contains("lux_consultingengineersreportdetails"))
                                {
                                    refer["lux_additionalinfo"] = item.Attributes["lux_consultingengineersreportdetails"];
                                }
                                refer["lux_suppliedvalue"] = "Yes";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_hasthereeverbeenaconsultingengineers") == false)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_typesofconstruction"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_pubsrestaurants' operator='eq' uiname='' uitype='lux_pubsrestaurantspropertyownersapplicatio' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_typesofconstruction' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.Attributes.Contains("lux_typesofconstruction") && item.GetAttributeValue<OptionSetValue>("lux_typesofconstruction").Value == 972970002)
                            {
                                var FieldName1 = "Building construction";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_typesofconstruction";
                                refer["lux_suppliedvalue"] = "Non-Standard";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.Attributes.Contains("lux_typesofconstruction") && item.GetAttributeValue<OptionSetValue>("lux_typesofconstruction").Value != 972970002)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_flatroofpercentage"))
                    {
                        var percent = item.Attributes["lux_flatroofpercentage"].ToString().Replace("%", "");
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_pubsrestaurants' operator='eq' uiname='' uitype='lux_pubsrestaurantspropertyownersapplicatio' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_flatroofpercentage' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_doesthepremiseshaveaflatroof") == true && Convert.ToDecimal(percent) > 25)
                            {
                                var FieldName1 = "Flat roof Percentage";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_flatroofpercentage";
                                refer["lux_suppliedvalue"] = item.Attributes.Contains("lux_flatroofpercentage") ? item.Attributes["lux_flatroofpercentage"].ToString() : "0%";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_doesthepremiseshaveaflatroof") == false || Convert.ToDecimal(percent) <= 25)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                            else if (item.GetAttributeValue<bool>("lux_doesthepremiseshaveaflatroof") == true && Convert.ToDecimal(percent) > 25)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                reff["lux_suppliedvalue"] = item.Attributes.Contains("lux_flatroofpercentage") ? item.Attributes["lux_flatroofpercentage"].ToString() : "0%";
                                service.Update(reff);
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_isthereanydeepfatfrying"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_pubsrestaurants' operator='eq' uiname='' uitype='lux_pubsrestaurantspropertyownersapplicatio' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isthereanydeepfatfrying' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_isthereanydeepfatfrying") == true)
                            {
                                var FieldName1 = "Any Deep Fat Frying Equipment Used?";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_isthereanydeepfatfrying";
                                refer["lux_suppliedvalue"] = "Yes";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_isthereanydeepfatfrying") == false)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (appln.Attributes.Contains("lux_icow"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_pubsrestaurants' operator='eq' uiname='' uitype='lux_pubsrestaurantspropertyownersapplicatio' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_icow' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (appln.GetAttributeValue<Money>("lux_icow").Value > 100000)
                            {
                                var FieldName1 = "Increased cost of working";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_icow";
                                refer["lux_suppliedvalue"] = appln.FormattedValues["lux_icow"];
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (appln.GetAttributeValue<Money>("lux_icow").Value <= 100000)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                            else if (appln.GetAttributeValue<Money>("lux_icow").Value > 100000)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                reff["lux_suppliedvalue"] = appln.FormattedValues["lux_icow"];
                                service.Update(reff);
                            }
                        }
                    }
                    if (appln.Attributes.Contains("lux_additionalincreasedcostofworking"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_pubsrestaurants' operator='eq' uiname='' uitype='lux_pubsrestaurantspropertyownersapplicatio' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_additionalincreasedcostofworking' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (appln.GetAttributeValue<Money>("lux_additionalincreasedcostofworking").Value > 100000)
                            {
                                var FieldName1 = "Additional increased cost of working";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_additionalincreasedcostofworking";
                                refer["lux_suppliedvalue"] = appln.FormattedValues["lux_additionalincreasedcostofworking"];
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (appln.GetAttributeValue<Money>("lux_additionalincreasedcostofworking").Value <= 100000)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                            else if (appln.GetAttributeValue<Money>("lux_additionalincreasedcostofworking").Value > 100000)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                reff["lux_suppliedvalue"] = appln.FormattedValues["lux_additionalincreasedcostofworking"];
                                service.Update(reff);
                            }
                        }
                    }
                    if (appln.Attributes.Contains("lux_bookdebts"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_pubsrestaurants' operator='eq' uiname='' uitype='lux_pubsrestaurantspropertyownersapplicatio' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_bookdebts' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (appln.GetAttributeValue<Money>("lux_bookdebts").Value > 100000)
                            {
                                var FieldName1 = "Book Debts";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_bookdebts";
                                refer["lux_suppliedvalue"] = appln.FormattedValues["lux_bookdebts"];
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (appln.GetAttributeValue<Money>("lux_bookdebts").Value <= 100000)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                            else if (appln.GetAttributeValue<Money>("lux_bookdebts").Value > 100000)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                reff["lux_suppliedvalue"] = appln.FormattedValues["lux_bookdebts"];
                                service.Update(reff);
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_meetsminimumstandardofphysicalsecurity"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_pubsrestaurants' operator='eq' uiname='' uitype='lux_pubsrestaurantspropertyownersapplicatio' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_meetsminimumstandardofphysicalsecurity' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_meetsminimumstandardofphysicalsecurity") == false)
                            {
                                var FieldName1 = "Meets minimum standard of physical security";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_meetsminimumstandardofphysicalsecurity";
                                refer["lux_suppliedvalue"] = "No";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_meetsminimumstandardofphysicalsecurity") == true)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }

                    if (item.Attributes.Contains("lux_totalmdsuminsuredwithupliftedamount"))
                    {
                        var totalMDSI = item.GetAttributeValue<Money>("lux_totalmdsuminsuredwithupliftedamount").Value;
                        var totalBISI = appln.Attributes.Contains("lux_totalbisuminsured") ? appln.GetAttributeValue<Money>("lux_totalbisuminsured").Value : 0;

                        var totalSI = totalMDSI + totalBISI;
                        var thresholdAmt = 0;

                        var ProductType = appln.GetAttributeValue<OptionSetValue>("lux_pubsrestaurantproducttype").Value;
                        if (ProductType == 972970001)
                        {
                            thresholdAmt = 1500000;
                        }
                        else if (ProductType == 972970002)
                        {
                            thresholdAmt = 2000000;
                        }
                        else if (ProductType == 972970003)
                        {
                            thresholdAmt = 1000000;
                        }

                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_pubsrestaurants' operator='eq' uiname='Test Address TE5 5ST' uitype='lux_pubsrestaurantspropertyownersapplicatio' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_totalmdsuminsuredwithupliftedamount' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (totalSI > thresholdAmt)
                            {
                                var FieldName1 = "Total Sum Insured exceeds Authority";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_totalmdsuminsuredwithupliftedamount";
                                refer["lux_suppliedvalue"] = "£" + Convert.ToInt32(totalSI).ToString();
                                refer["lux_additionalinfo"] = "Refer Risk to HCC for Approval";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (totalSI <= thresholdAmt)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                            else if (totalSI > thresholdAmt)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                reff["lux_suppliedvalue"] = "£" + Convert.ToInt32(totalSI).ToString();
                                reff["lux_additionalinfo"] = "Refer Risk to HCC for Approval";
                                service.Update(reff);
                            }
                        }
                    }
                }
            }
        }

        public string GetOptionSetTextUsingValue(string entityName, string fieldName, int optionSetValue, IOrganizationService service)
        {
            var attReq = new RetrieveAttributeRequest();
            attReq.EntityLogicalName = entityName;
            attReq.LogicalName = fieldName;
            attReq.RetrieveAsIfPublished = true;
            var attResponse = (RetrieveAttributeResponse)service.Execute(attReq);
            var attMetadata = (EnumAttributeMetadata)attResponse.AttributeMetadata;
            return attMetadata.OptionSet.Options.Where(x => x.Value == optionSetValue).FirstOrDefault().Label.UserLocalizedLabel.Label;
        }

        public IDictionary<int, string> GetGlobalOptionSetValues(IOrganizationService service, string optionSetLogicalName)
        {
            IDictionary<int, string> optionSet = new Dictionary<int, string>();
            if (string.IsNullOrEmpty(optionSetLogicalName))
                return null;
            var retrieveAttributeRequest = new RetrieveOptionSetRequest
            {
                Name = optionSetLogicalName
            };
            var retrieveAttributeResponse = (RetrieveOptionSetResponse)service.Execute(retrieveAttributeRequest);
            var retrievedPicklistAttributeMetadata = (OptionSetMetadata)retrieveAttributeResponse.OptionSetMetadata;
            for (int i = 0; i < retrievedPicklistAttributeMetadata.Options.Count(); i++)
            {
                optionSet.Add(new KeyValuePair<int, string>(retrievedPicklistAttributeMetadata.Options[i].Value.Value,
                    retrievedPicklistAttributeMetadata.Options[i].Label.LocalizedLabels[0].Label));
            }
            return optionSet;
        }

        public static string RetrieveAttributeDisplayName(string EntitySchemaName, string AttributeSchemaName, IOrganizationService service)
        {
            RetrieveAttributeRequest retrieveAttributeRequest = new RetrieveAttributeRequest
            {
                EntityLogicalName = EntitySchemaName,
                LogicalName = AttributeSchemaName,
                RetrieveAsIfPublished = true
            };
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            AttributeMetadata retrievedAttributeMetadata = (AttributeMetadata)retrieveAttributeResponse.AttributeMetadata;
            return retrievedAttributeMetadata.DisplayName.UserLocalizedLabel.Label;
        }
    }
}
