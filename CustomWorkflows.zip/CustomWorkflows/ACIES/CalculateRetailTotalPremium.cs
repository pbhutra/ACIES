﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculateRetailTotalPremium : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Input("Product")]
        public InArgument<string> Product { get; set; }

        [Input("Broker")]
        [ReferenceTarget("account")]
        public InArgument<EntityReference> Broker { get; set; }

        [RequiredArgument]
        [Input("ProductRequired")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> ProductRequired { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = "";
            var entityName = "";
            if (Product.Get(executionContext).ToString() == "Retail")
            {
                entityName = "lux_propertyownersretail";
                fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersretail'>
                                <attribute name='lux_propertyownersretailid' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_businessinterruptionpremium' />
                                <attribute name='lux_materialdamagepremium' />
                                <attribute name='lux_terrorismpremium' />
                                <attribute name='lux_totalmdsuminsured' />                                
                                <attribute name='lux_totalsuminsured' />
                                <attribute name='lux_totalmdsuminsuredwithupliftedamount' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplications' visible='false' link-type='outer' alias='poa'>
                                  <attribute name='lux_levelofcommission' />
                                  <attribute name='lux_employersliabilitypremium' />
                                  <attribute name='lux_specifiedallriskpremium' />
                                  <attribute name='lux_goodsintransitpremium' />
                                  <attribute name='lux_publicproductsliabilitypremium' />
                                  <attribute name='lux_retailmoneypremium' />
                                  <attribute name='lux_alterationmaintenancerepairwageroll' />
                                  <attribute name='lux_allotherswageroll' />  
                                  <attribute name='lux_inceptiondate' />
                                  <attribute name='lux_retailbipremium' />
                                  <attribute name='lux_retailmdpremium' />
                                  <attribute name='lux_totalbisuminsured' />
                                  <attribute name='lux_contractorspremium' />
                                  <attribute name='lux_legrosspremium' />
                                  <attribute name='lux_lenetpremium' />
                                  <attribute name='lux_islocationallimitrequired' />
                                  <attribute name='lux_maximumlocationallimit' />
                                </link-entity>
                              </entity>
                            </fetch>";
            }
            else if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
            {
                entityName = "lux_commercialcombinedapplication";
                fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_commercialcombinedapplication'>
                                <attribute name='lux_commercialcombinedapplicationid' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_businessinterruptionpremium' />
                                <attribute name='lux_materialdamagepremium' />
                                <attribute name='lux_terrorismpremium' /> 
                                <attribute name='lux_totalmdsuminsured' />
                                <attribute name='lux_totalsuminsured' />
                                <attribute name='lux_totalmdsuminsuredwithupliftedamount' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplications' visible='false' link-type='outer' alias='poa'>
                                  <attribute name='lux_levelofcommission' />
                                  <attribute name='lux_employersliabilitypremium' />
                                  <attribute name='lux_specifiedallriskpremium' />
                                  <attribute name='lux_goodsintransitpremium' />
                                  <attribute name='lux_publicproductsliabilitypremium' />
                                  <attribute name='lux_retailmoneypremium' />
                                  <attribute name='lux_alterationmaintenancerepairwageroll' />
                                  <attribute name='lux_allotherswageroll' />
                                  <attribute name='lux_retailbipremium' />
                                  <attribute name='lux_inceptiondate' />
                                  <attribute name='lux_totalbisuminsured' />
                                  <attribute name='lux_retailmdpremium' />
                                  <attribute name='lux_contractorspremium' />
                                  <attribute name='lux_legrosspremium' />
                                  <attribute name='lux_lenetpremium' />
                                  <attribute name='lux_islocationallimitrequired' />
                                  <attribute name='lux_maximumlocationallimit' />
                                </link-entity>
                              </entity>
                            </fetch>";
            }
            else if (Product.Get(executionContext).ToString() == "Contractors Combined")
            {
                entityName = "lux_contractorscombined";
                fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_contractorscombined'>
                                <attribute name='lux_contractorscombinedid' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_businessinterruptionpremium' />
                                <attribute name='lux_materialdamagepremium' />
                                <attribute name='lux_terrorismpremium' /> 
                                <attribute name='lux_totalmdsuminsured' />
                                <attribute name='lux_totalsuminsured' />
                                <attribute name='lux_totalmdsuminsuredwithupliftedamount' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplications' visible='false' link-type='outer' alias='poa'>
                                  <attribute name='lux_levelofcommission' />
                                  <attribute name='lux_employersliabilitypremium' />
                                  <attribute name='lux_specifiedallriskpremium' />
                                  <attribute name='lux_goodsintransitpremium' />
                                  <attribute name='lux_publicproductsliabilitypremium' />
                                  <attribute name='lux_retailmoneypremium' />
                                  <attribute name='lux_alterationmaintenancerepairwageroll' />
                                  <attribute name='lux_allotherswageroll' />
                                  <attribute name='lux_inceptiondate' />
                                  <attribute name='lux_retailbipremium' />
                                  <attribute name='lux_totalbisuminsured' />
                                  <attribute name='lux_retailmdpremium' />                                  
                                  <attribute name='lux_contractorspremium' />
                                  <attribute name='lux_legrosspremium' />
                                  <attribute name='lux_lenetpremium' />
                                  <attribute name='lux_islocationallimitrequired' />
                                  <attribute name='lux_maximumlocationallimit' />
                                </link-entity>
                              </entity>
                            </fetch>";
            }
            else if (Product.Get(executionContext).ToString() == "Pubs & Restaurants" || Product.Get(executionContext).ToString() == "Hotels and Guesthouses")
            {
                entityName = "lux_pubsrestaurantspropertyownersapplicatio";
                fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_pubsrestaurantspropertyownersapplicatio'>
                                <attribute name='lux_pubsrestaurantspropertyownersapplicatioid' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_businessinterruptionpremium' />
                                <attribute name='lux_materialdamagepremium' />
                                <attribute name='lux_terrorismpremium' />
                                <attribute name='lux_totalmdsuminsured' />
                                <attribute name='lux_totalsuminsured' />
                                <attribute name='lux_totalmdsuminsuredwithupliftedamount' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplications' visible='false' link-type='outer' alias='poa'>
                                  <attribute name='lux_levelofcommission' />
                                  <attribute name='lux_employersliabilitypremium' />
                                  <attribute name='lux_specifiedallriskpremium' />
                                  <attribute name='lux_goodsintransitpremium' />
                                  <attribute name='lux_publicproductsliabilitypremium' />
                                  <attribute name='lux_retailmoneypremium' />
                                  <attribute name='lux_alterationmaintenancerepairwageroll' />
                                  <attribute name='lux_allotherswageroll' />
                                  <attribute name='lux_retailbipremium' />
                                  <attribute name='lux_inceptiondate' />
                                  <attribute name='lux_totalbisuminsured' />                                  
                                  <attribute name='lux_retailmdpremium' />
                                  <attribute name='lux_contractorspremium' />
                                  <attribute name='lux_legrosspremium' />
                                  <attribute name='lux_lenetpremium' />
                                  <attribute name='lux_islocationallimitrequired' />
                                  <attribute name='lux_maximumlocationallimit' />
                                </link-entity>
                              </entity>
                            </fetch>";
            }

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var premises = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                bool IsLocationalLimit = premises[0].Contains("poa.lux_islocationallimitrequired") ? ((bool)((premises[0].GetAttributeValue<AliasedValue>("poa.lux_islocationallimitrequired")).Value)) : false;
                decimal MaximumLocationalLimit = premises[0].Contains("poa.lux_maximumlocationallimit") ? ((Money)((premises[0].GetAttributeValue<AliasedValue>("poa.lux_maximumlocationallimit")).Value)).Value : 0;

                foreach (var item1 in premises)
                {
                    decimal TotalMDSumInsured = item1.Contains("lux_totalmdsuminsuredwithupliftedamount") ? item1.GetAttributeValue<Money>("lux_totalmdsuminsuredwithupliftedamount").Value : 0;
                    decimal TotalBISumInsured = premises[0].Contains("poa.lux_totalbisuminsured") ? ((Money)((premises[0].GetAttributeValue<AliasedValue>("poa.lux_totalbisuminsured")).Value)).Value : 0;
                    Entity premise = service.Retrieve(entityName, item1.Id, new ColumnSet());
                    premise["lux_bisuminsured"] = new Money(TotalBISumInsured);

                    if (IsLocationalLimit == true)
                    {
                        TotalBISumInsured = MaximumLocationalLimit;
                    }
                    premise["lux_totalsuminsured"] = new Money(TotalMDSumInsured + TotalBISumInsured);
                    premise["lux_maximumlocationallimit"] = new Money(MaximumLocationalLimit);
                    service.Update(premise);
                }
            }

            var applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                  <attribute name='lux_levelofcommission' />
                                  <attribute name='lux_employersliabilitypremium' />
                                  <attribute name='lux_specifiedallriskpremium' />
                                  <attribute name='lux_goodsintransitpremium' />
                                  <attribute name='lux_publicproductsliabilitypremium' />
                                  <attribute name='lux_retailmoneypremium' />
                                  <attribute name='lux_alterationmaintenancerepairwageroll' />
                                  <attribute name='lux_allotherswageroll' />
                                  <attribute name='lux_retailbipremium' />
                                  <attribute name='lux_totalbisuminsured' />                                                
                                  <attribute name='lux_applicationtype' />                     
                                  <attribute name='lux_retailmdpremium' />
                                  <attribute name='lux_contractorspremium' />
                                  <attribute name='lux_inceptiondate' />
                                  <attribute name='lux_quotationdate' />
                                  <attribute name='lux_technicalnetpremium' />
                                  <attribute name='lux_legrosspremium' />
                                  <attribute name='lux_lenetpremium' />
                                  <attribute name='lux_isquotereferred' />
                                  <order attribute='lux_name' descending='false' />
                                  <filter type='and'>
                                    <condition attribute='statecode' operator='eq' value='0' />
                                    <condition attribute='lux_propertyownersapplicationsid' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                  </filter>
                              </entity>
                            </fetch>";

            var item = service.RetrieveMultiple(new FetchExpression(applnfetch)).Entities[0];

            var IsQuoteReferred = item.Attributes.Contains("lux_isquotereferred") ? item.GetAttributeValue<bool>("lux_isquotereferred") : false;

            decimal TotalMDPremium = item.Contains("lux_retailmdpremium") ? item.GetAttributeValue<Money>("lux_retailmdpremium").Value : 0;
            decimal TotalBIPremium = item.Contains("lux_retailbipremium") ? item.GetAttributeValue<Money>("lux_retailbipremium").Value : 0;
            decimal TotalMoneyPremium = item.Contains("lux_retailmoneypremium") ? item.GetAttributeValue<Money>("lux_retailmoneypremium").Value : 0;
            decimal TotalAllRiskPremium = item.Contains("lux_specifiedallriskpremium") ? item.GetAttributeValue<Money>("lux_specifiedallriskpremium").Value : 0;
            decimal TotalGITPremium = item.Contains("lux_goodsintransitpremium") ? item.GetAttributeValue<Money>("lux_goodsintransitpremium").Value : 0;

            decimal TotalELPremium = item.Contains("lux_employersliabilitypremium") ? item.GetAttributeValue<Money>("lux_employersliabilitypremium").Value : 0;
            decimal TotalPLPremium = item.Contains("lux_publicproductsliabilitypremium") ? item.GetAttributeValue<Money>("lux_publicproductsliabilitypremium").Value : 0;
            decimal TotalCARPremium = item.Contains("lux_contractorspremium") ? item.GetAttributeValue<Money>("lux_contractorspremium").Value : 0;

            decimal TotalLENetPremium = item.Contains("lux_lenetpremium") ? item.GetAttributeValue<Money>("lux_lenetpremium").Value : 0;
            decimal TotalLEGrossPremium = item.Contains("lux_legrosspremium") ? item.GetAttributeValue<Money>("lux_legrosspremium").Value : 0;

            var inceptionDate = Convert.ToDateTime(item.FormattedValues["lux_inceptiondate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
            var quotationDate = item.Attributes.Contains("lux_quotationdate") ? item.GetAttributeValue<DateTime>("lux_quotationdate") : inceptionDate;
            var ApplicationType = item.Attributes.Contains("lux_applicationtype") ? item.FormattedValues["lux_applicationtype"] : "New Business";

            var TotalPropertyPremium = TotalMDPremium + TotalBIPremium + TotalMoneyPremium + TotalAllRiskPremium + TotalGITPremium;
            var TotalLiabilityPremium = TotalELPremium + TotalPLPremium + TotalCARPremium;
            var TotalPremium = TotalPropertyPremium + TotalLiabilityPremium;

            decimal Fee = 0;

            var FeeFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='lux_adminfeerule'>
                                        <attribute name='lux_to' />
                                        <attribute name='lux_from' />
                                        <attribute name='lux_fee' />
                                        <attribute name='lux_adminfeeruleid' />
                                        <order attribute='lux_to' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='statecode' operator='eq' value='0' />
                                          <condition attribute='lux_from' operator='le' value='{TotalPremium + TotalLEGrossPremium}' />
                                          <filter type='or'>
                                            <condition attribute='lux_to' operator='ge' value='{TotalPremium + TotalLEGrossPremium}' />
                                            <condition attribute='lux_to' operator='null' />
                                          </filter>
                                        </filter>
                                      </entity>
                                    </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(FeeFetch)).Entities.Count > 0)
            {
                Fee = service.RetrieveMultiple(new FetchExpression(FeeFetch)).Entities[0].GetAttributeValue<Money>("lux_fee").Value;
            }

            decimal BrokerComm = 25;
            decimal aciesComm = 10;
            decimal LiabilityaciesComm = 5;

            var BrokerFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_brokercommission'>
                                            <attribute name='createdon' />
                                            <attribute name='lux_product' />
                                            <attribute name='lux_commission' />
                                            <attribute name='lux_renewalcommission' />
                                            <attribute name='lux_brokercommissionid' />
                                            <order attribute='createdon' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <filter type='or'>
                                                <condition attribute='lux_effectivefrom' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", inceptionDate)}' />
                                                <condition attribute='lux_effectivefrom' operator='null' />
                                              </filter>
                                              <filter type='or'>
                                                <condition attribute='lux_effectiveto' operator='on-or-after' value= '{String.Format("{0:MM/dd/yyyy}", inceptionDate)}' />
                                                <condition attribute='lux_effectiveto' operator='null' />
                                              </filter>
                                              <condition attribute='lux_broker' operator='eq' uiname='' uitype='account' value='{Broker.Get(executionContext).Id}' />
                                              <condition attribute='lux_product' operator='eq' uiname='' uitype='product' value='{ProductRequired.Get(executionContext).Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";
            if (service.RetrieveMultiple(new FetchExpression(BrokerFetch)).Entities.Count > 0)
            {
                var BrokerCommission = service.RetrieveMultiple(new FetchExpression(BrokerFetch)).Entities[0];
                BrokerComm = BrokerCommission.GetAttributeValue<decimal>("lux_commission");

                if (BrokerCommission.Attributes.Contains("lux_renewalcommission"))
                {
                    if (ApplicationType == "Renewal")
                    {
                        BrokerComm = BrokerCommission.GetAttributeValue<decimal>("lux_renewalcommission");
                    }
                    else if (ApplicationType == "MTA" || ApplicationType == "Cancellation")
                    {
                        if (item.Attributes.Contains("lux_policy"))
                        {
                            var Policy = service.Retrieve("lux_policy", item.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                            if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
                            {
                                BrokerComm = BrokerCommission.GetAttributeValue<decimal>("lux_renewalcommission");
                            }
                        }
                    }
                }

                aciesComm = 35 - BrokerComm;
                if (inceptionDate >= new DateTime(2023, 11, 01) && Product.Get(executionContext).ToString() == "Contractors Combined")
                {
                    aciesComm = 30 - BrokerComm;
                }
                LiabilityaciesComm = 30 - BrokerComm;
            }

            if (inceptionDate >= new DateTime(2023, 11, 01) && Product.Get(executionContext).ToString() == "Contractors Combined")
            {
                aciesComm = 30 - BrokerComm;
            }

            Entity appln = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet());
            appln["lux_totalpremium"] = new Money(TotalPremium + TotalLEGrossPremium);

            appln["lux_brokercommission"] = Convert.ToDouble(BrokerComm) + "%";
            appln["lux_aciestechnicalcommission"] = Convert.ToDouble(aciesComm) + "%";

            if (!item.Attributes.Contains("lux_technicalnetpremium") || IsQuoteReferred == true)
            {
                appln["lux_policybrokercommission"] = Convert.ToDouble(BrokerComm) + "%";
                appln["lux_policyaciescommission"] = Convert.ToDouble(aciesComm) + "%";
            }

            var LEBrokerComm = TotalLEGrossPremium * BrokerComm / 100;
            var LeGrossComm = TotalLEGrossPremium - TotalLENetPremium - LEBrokerComm;

            appln["lux_brokercommissionamount"] = new Money(TotalPremium * BrokerComm / 100 + LEBrokerComm);
            appln["lux_legrosscommission"] = new Money(LeGrossComm);
            appln["lux_aciestechnicalcommissionamount"] = new Money(TotalPremium * aciesComm / 100);
            appln["lux_technicalnetpremium"] = new Money(TotalPremium + TotalLENetPremium - TotalPremium * BrokerComm / 100 - TotalPremium * aciesComm / 100);

            if (inceptionDate >= new DateTime(2023, 11, 01))
            {
                if (Product.Get(executionContext).ToString() == "Contractors Combined")
                {
                    appln["lux_totaltechnicalcommission"] = "30%";
                    if (!item.Attributes.Contains("lux_technicalnetpremium"))
                    {
                        appln["lux_policytotalcommission"] = "30%";
                    }
                }
                appln["lux_aciestechnicalcommissionliability"] = Convert.ToDouble(LiabilityaciesComm) + "%";
                if (!item.Attributes.Contains("lux_technicalnetpremium"))
                {
                    appln["lux_policyaciescommissionliability"] = Convert.ToDouble(LiabilityaciesComm) + "%";
                }
                appln["lux_aciestechnicalcommissionamountliability"] = new Money(TotalLiabilityPremium * LiabilityaciesComm / 100);
                appln["lux_aciestechnicalcommissionamount"] = new Money(TotalPropertyPremium * aciesComm / 100 + TotalLiabilityPremium * LiabilityaciesComm / 100);
                appln["lux_technicalnetpremium"] = new Money(TotalPremium + TotalLENetPremium - TotalPremium * BrokerComm / 100 - TotalPropertyPremium * aciesComm / 100 - TotalLiabilityPremium * LiabilityaciesComm / 100);
            }

            appln["lux_fees"] = new Money(Fee);
            service.Update(appln);
        }
    }
}