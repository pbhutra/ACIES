﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using msdyncrmWorkflowTools;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomWorkflows
{
    public class CloneChildren : CodeActivity
    {
        #region "Parameter Definition"

        [RequiredArgument]
        [Input("Source Record URL")]
        [ReferenceTarget("")]
        public InArgument<String> SourceRecordUrl { get; set; }

        [RequiredArgument]
        [Input("Target Record URL")]
        [ReferenceTarget("")]
        public InArgument<String> TargetRecordUrl { get; set; }

        [RequiredArgument]
        [Input("Relationship Name")]
        [ReferenceTarget("")]
        public InArgument<String> RelationshipName { get; set; }

        [RequiredArgument]
        [Input("New Parent Field Name")]
        [ReferenceTarget("")]
        public InArgument<String> NewParentFieldNameToUpdate { get; set; }

        [Input("Old Parent Field Name")]
        [ReferenceTarget("")]
        public InArgument<String> OldParentFieldNameToUpdate { get; set; }

        [Input("Prefix")]
        [Default("")]
        public InArgument<String> Prefix { get; set; }

        [Input("Fields to Ignore")]
        [Default("")]
        public InArgument<String> FieldstoIgnore { get; set; }

        [Input("OldApplication")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> OldPropertyOwnersApplication { get; set; }

        [Input("NewApplication")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> NewPropertyOwnersApplication { get; set; }

        [Input("Product")]
        [ReferenceTarget("")]
        public InArgument<String> Product { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            #region "Load CRM Service from context"

            Common objCommon = new Common(executionContext);
            objCommon.tracingService.Trace("Load CRM Service from context --- OK");
            #endregion

            #region "Read Parameters"

            String _relationshipName = this.RelationshipName.Get(executionContext);
            if (_relationshipName == null || _relationshipName == "")
            {
                return;
            }

            String _newParentFieldName = this.NewParentFieldNameToUpdate.Get(executionContext);
            if (_newParentFieldName == null || _newParentFieldName == "")
            {
                return;
            }

            String _source = this.SourceRecordUrl.Get(executionContext);
            if (_source == null || _source == "")
            {
                return;
            }

            string[] urlParts = _source.Split("?".ToArray());
            string[] urlParams = urlParts[1].Split("&".ToCharArray());
            string parentObjectTypeCode = urlParams[0].Replace("etc=", "");
            string parentEntityName = objCommon.sGetEntityNameFromCode(parentObjectTypeCode, objCommon.service);
            string parentId = urlParams[1].Replace("id=", "");
            objCommon.tracingService.Trace("ObjectTypeCode=" + parentObjectTypeCode + "--ParentId=" + parentId);

            String _destination = this.TargetRecordUrl.Get(executionContext);
            if (_destination == null || _destination == "")
            {
                return;
            }
            string[] destinationUrlParts = _destination.Split("?".ToArray());
            string[] destinationUrlParams = destinationUrlParts[1].Split("&".ToCharArray());
            string destinationObjectTypeCode = destinationUrlParams[0].Replace("etc=", "");
            string destinationEntityName = objCommon.sGetEntityNameFromCode(destinationObjectTypeCode, objCommon.service);
            string destinationId = destinationUrlParams[1].Replace("id=", "");
            objCommon.tracingService.Trace("ObjectTypeCode=" + destinationObjectTypeCode + "--ParentId=" + destinationId);


            //Optional
            String _oldParentFieldName = this.OldParentFieldNameToUpdate.Get(executionContext);
            string prefix = this.Prefix.Get(executionContext);
            string fieldstoIgnore = this.FieldstoIgnore.Get(executionContext);

            #endregion

            var tools = new msdyncrmWorkflowTools_Class(objCommon.service);

            var children = tools.GetChildRecords(_relationshipName, parentId);

            objCommon.tracingService.Trace(children.Entities.ToList().OrderBy(t => t.GetAttributeValue<DateTime>("createdon")).ToString());

            foreach (var item in children.Entities.ToList().OrderBy(t => t.GetAttributeValue<DateTime>("createdon")))
            {
                var oldRecord = objCommon.service.Retrieve(item.LogicalName, item.Id, new ColumnSet(true));

                var newRecordId = objCommon.CloneRecord(item.LogicalName, item.Id.ToString(), fieldstoIgnore, prefix);
                Entity update1 = objCommon.service.Retrieve(item.LogicalName, newRecordId, new ColumnSet(true));

                Entity update = new Entity(item.LogicalName);
                update.Id = newRecordId;
                update.Attributes.Add(_newParentFieldName, new EntityReference(destinationEntityName, new Guid(destinationId)));
                if (!string.IsNullOrEmpty(_oldParentFieldName) && _oldParentFieldName != _newParentFieldName)
                {
                    update.Attributes.Add(_oldParentFieldName, null);
                }

                if (update1.Contains("lux_isnewmtapremise"))
                {
                    update.Attributes.Add("lux_isnewmtapremise", false);
                }

                if (Product.Get(executionContext).ToString() == "Property Owners" || Product.Get(executionContext).ToString() == "Unoccupied")
                {
                    if (oldRecord.Attributes.Contains("lux_buildingmobidocpremium"))
                    {
                        update.Attributes.Add("lux_parentbuildingpolicypremium", oldRecord.GetAttributeValue<Money>("lux_buildingmobidocpremium"));
                    }
                    else if (oldRecord.Attributes.Contains("lux_buildingpolicypremium"))
                    {
                        update.Attributes.Add("lux_parentbuildingpolicypremium", oldRecord.GetAttributeValue<Money>("lux_buildingpolicypremium"));
                    }

                    if (oldRecord.Attributes.Contains("lux_totalpolicymobidocpremium"))
                    {
                        update.Attributes.Add("lux_parenttotalpolicypremium", oldRecord.GetAttributeValue<Money>("lux_totalpolicymobidocpremium"));
                    }

                    if (oldRecord.Attributes.Contains("lux_totalaciesmobidocpremium"))
                    {
                        update.Attributes.Add("lux_parenttotalaciescommission", oldRecord.GetAttributeValue<Money>("lux_totalaciesmobidocpremium"));
                    }

                    if (oldRecord.Attributes.Contains("lux_suminsuredwithupliftedamount"))
                    {
                        update.Attributes.Add("lux_parenttotalsuminsured", oldRecord.GetAttributeValue<Money>("lux_suminsuredwithupliftedamount"));
                    }
                }
                else if (Product.Get(executionContext).ToString() == "Retail")
                {
                    if (oldRecord.Attributes.Contains("lux_totalsuminsured"))
                    {
                        update.Attributes.Add("lux_parenttotalsuminsured", oldRecord.GetAttributeValue<Money>("lux_totalsuminsured"));
                    }
                }
                else if (Product.Get(executionContext).ToString() == "Pubs & Restaurants" || Product.Get(executionContext).ToString() == "Hotels and Guesthouses")
                {
                    if (oldRecord.Attributes.Contains("lux_totalsuminsured"))
                    {
                        update.Attributes.Add("lux_parenttotalsuminsured", oldRecord.GetAttributeValue<Money>("lux_totalsuminsured"));
                    }
                }
                else if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
                {
                    if (oldRecord.Attributes.Contains("lux_totalsuminsured"))
                    {
                        update.Attributes.Add("lux_parenttotalsuminsured", oldRecord.GetAttributeValue<Money>("lux_totalsuminsured"));
                    }
                }

                objCommon.tracingService.Trace(newRecordId.ToString());
                objCommon.service.Update(update);
            }

            if (Product.Get(executionContext).ToString() == "Property Owners" || Product.Get(executionContext).ToString() == "Unoccupied")
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_propertyownerspremise' />
                                    <attribute name='lux_referralid' />
                                    <attribute name='lux_refertohcc' />
                                    <attribute name='lux_premisetype' />
                                    <attribute name='lux_premiselevel' />
                                    <attribute name='lux_name' />
                                    <attribute name='lux_furtherreferraldate' />
                                    <attribute name='lux_furtherreferral' />
                                    <attribute name='lux_fieldschemaname' />
                                    <attribute name='lux_declined' />
                                    <attribute name='lux_userapproval' />
                                    <attribute name='lux_approvaldeclinecomment' />
                                    <attribute name='lux_approvaldate' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{OldPropertyOwnersApplication.Get(executionContext).Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (objCommon.service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    foreach (var item1 in objCommon.service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", NewPropertyOwnersApplication.Get(executionContext).Id);
                        refer["lux_fieldname"] = item1.Attributes.Contains("lux_fieldname") ? item1.Attributes["lux_fieldname"].ToString() : "";
                        if (item1.Attributes["lux_fieldname"].ToString().Contains("Flood Score"))
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() + "1" : "";
                        }
                        else if (item1.Attributes["lux_fieldname"].ToString().Contains("Subsidence Score"))
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() + "1" : "";
                        }
                        else
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() : "";
                        }
                        refer["lux_suppliedvalue"] = item1.Attributes.Contains("lux_suppliedvalue") ? item1.Attributes["lux_suppliedvalue"].ToString() : "";
                        refer["lux_approve"] = true;
                        if (item1.Attributes.Contains("lux_userapproval"))
                        {
                            refer["lux_userapproval"] = new EntityReference("systemuser", item1.GetAttributeValue<EntityReference>("lux_userapproval").Id);
                        }
                        refer["lux_approvaldate"] = item1.Attributes.Contains("lux_approvaldate") ? Convert.ToDateTime(item1.Attributes["lux_approvaldate"]) : DateTime.Now;
                        refer["lux_additionalinfo"] = item1.Attributes.Contains("lux_additionalinfo") ? item1.Attributes["lux_additionalinfo"].ToString() : "";
                        refer["lux_refertohcc"] = item1.Attributes.Contains("lux_refertohcc") ? item1.GetAttributeValue<bool>("lux_refertohcc") : false;
                        refer["lux_premiselevel"] = item1.Attributes.Contains("lux_premiselevel") ? item1.GetAttributeValue<bool>("lux_premiselevel") : false;
                        if (item1.Attributes.Contains("lux_premisetype"))
                        {
                            refer["lux_premisetype"] = new OptionSetValue(item1.GetAttributeValue<OptionSetValue>("lux_premisetype").Value);
                        }
                        refer["lux_name"] = item1.Attributes.Contains("lux_name") ? item1.Attributes["lux_name"].ToString() : "";
                        refer["lux_furtherreferral"] = item1.Attributes.Contains("lux_furtherreferral") ? item1.GetAttributeValue<bool>("lux_furtherreferral") : false;
                        if (item1.Attributes.Contains("lux_furtherreferraldate"))
                        {
                            refer["lux_furtherreferraldate"] = Convert.ToDateTime(item1.Attributes["lux_furtherreferraldate"]);
                        }
                        refer["lux_declined"] = item1.Attributes.Contains("lux_declined") ? item1.GetAttributeValue<bool>("lux_declined") : false;
                        refer["lux_approvaldeclinecomment"] = item1.Attributes.Contains("lux_approvaldeclinecomment") ? item1.Attributes["lux_approvaldeclinecomment"].ToString() : "";
                        var referid = objCommon.service.Create(refer);
                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                              <entity name='lux_premisereferral'>
                                                                <attribute name='lux_premisereferralid' />
                                                                <attribute name='lux_name' />
                                                                <attribute name='createdon' />
                                                                <attribute name='lux_suppliedvalue' />
                                                                <attribute name='lux_riskpremise' />
                                                                <attribute name='lux_riskpostcode' />
                                                                <attribute name='lux_referral' />
                                                                <attribute name='lux_fieldname' />
                                                                <attribute name='lux_application' />
                                                                <attribute name='lux_additionalinfo' />
                                                                <order attribute='lux_name' descending='false' />
                                                                <filter type='and'>
                                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                                  <condition attribute='lux_riskpremise' operator='not-null' />
                                                                  <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{item1.Id}' />
                                                                </filter>
                                                              </entity>
                                                            </fetch>";

                        if (objCommon.service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                        {
                            foreach (var premref in objCommon.service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                            {
                                Entity premise = objCommon.service.Retrieve("lux_propertyownerspremise", premref.GetAttributeValue<EntityReference>("lux_riskpremise").Id, new ColumnSet("lux_locationnumber"));
                                var locationNumber = premise.Attributes["lux_locationnumber"].ToString();
                                var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_propertyownerspremise'>
                                                    <attribute name='lux_riskpostcode' />
                                                    <attribute name='lux_riskaddress' />
                                                    <attribute name='lux_locationnumber' />
                                                    <attribute name='lux_propertyownerspremiseid' />
                                                    <order attribute='lux_riskpostcode' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_locationnumber' operator='eq' value='{locationNumber}' />
                                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{NewPropertyOwnersApplication.Get(executionContext).Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";
                                if (objCommon.service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
                                {
                                    Entity premiserefer = new Entity("lux_premisereferral");
                                    premiserefer["lux_riskpremise"] = new EntityReference("lux_propertyownerspremise", objCommon.service.RetrieveMultiple(new FetchExpression(fetch1)).Entities[0].Id);
                                    premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", NewPropertyOwnersApplication.Get(executionContext).Id);
                                    premiserefer["lux_riskpostcode"] = premref.Attributes.Contains("lux_riskpostcode") ? premref.Attributes["lux_riskpostcode"].ToString() : "";
                                    premiserefer["lux_referral"] = new EntityReference("lux_referral", referid);
                                    premiserefer["lux_fieldname"] = premref.Attributes.Contains("lux_fieldname") ? premref.Attributes["lux_fieldname"].ToString() : "";
                                    premiserefer["lux_suppliedvalue"] = premref.Attributes.Contains("lux_suppliedvalue") ? premref.Attributes["lux_suppliedvalue"].ToString() : "";
                                    premiserefer["lux_additionalinfo"] = premref.Attributes.Contains("lux_additionalinfo") ? premref.Attributes["lux_additionalinfo"].ToString() : "";
                                    objCommon.service.Create(premiserefer);

                                    objCommon.tracingService.Trace("Premise Refer Created!!");
                                }
                            }
                        }
                    }
                }
            }
            else if (Product.Get(executionContext).ToString() == "Retail")
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_propertyownerspremise' />
                                    <attribute name='lux_referralid' />
                                    <attribute name='lux_retailproduct' />
                                    <attribute name='lux_refertohcc' />
                                    <attribute name='lux_premisetype' />
                                    <attribute name='lux_premiselevel' />
                                    <attribute name='lux_name' />
                                    <attribute name='lux_furtherreferraldate' />
                                    <attribute name='lux_furtherreferral' />
                                    <attribute name='lux_fieldschemaname' />
                                    <attribute name='lux_declined' />
                                    <attribute name='lux_userapproval' />
                                    <attribute name='lux_approvaldeclinecomment' />
                                    <attribute name='lux_approvaldate' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{OldPropertyOwnersApplication.Get(executionContext).Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (objCommon.service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    foreach (var item1 in objCommon.service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", NewPropertyOwnersApplication.Get(executionContext).Id);
                        refer["lux_fieldname"] = item1.Attributes.Contains("lux_fieldname") ? item1.Attributes["lux_fieldname"].ToString() : "";
                        if (item1.Attributes["lux_fieldname"].ToString().Contains("Flood Score"))
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() + "1" : "";
                        }
                        else if (item1.Attributes["lux_fieldname"].ToString().Contains("Subsidence Score"))
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() + "1" : "";
                        }
                        else
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() : "";
                        }
                        refer["lux_suppliedvalue"] = item1.Attributes.Contains("lux_suppliedvalue") ? item1.Attributes["lux_suppliedvalue"].ToString() : "";
                        refer["lux_approve"] = true;
                        if (item1.Attributes.Contains("lux_userapproval"))
                        {
                            refer["lux_userapproval"] = new EntityReference("systemuser", item1.GetAttributeValue<EntityReference>("lux_userapproval").Id);
                        }
                        refer["lux_approvaldate"] = item1.Attributes.Contains("lux_approvaldate") ? Convert.ToDateTime(item1.Attributes["lux_approvaldate"]) : DateTime.Now;
                        refer["lux_additionalinfo"] = item1.Attributes.Contains("lux_additionalinfo") ? item1.Attributes["lux_additionalinfo"].ToString() : "";
                        refer["lux_refertohcc"] = item1.Attributes.Contains("lux_refertohcc") ? item1.GetAttributeValue<bool>("lux_refertohcc") : false;
                        refer["lux_premiselevel"] = item1.Attributes.Contains("lux_premiselevel") ? item1.GetAttributeValue<bool>("lux_premiselevel") : false;
                        if (item1.Attributes.Contains("lux_premisetype"))
                        {
                            refer["lux_premisetype"] = new OptionSetValue(item1.GetAttributeValue<OptionSetValue>("lux_premisetype").Value);
                        }
                        refer["lux_name"] = item1.Attributes.Contains("lux_name") ? item1.Attributes["lux_name"].ToString() : "";
                        refer["lux_furtherreferral"] = item1.Attributes.Contains("lux_furtherreferral") ? item1.GetAttributeValue<bool>("lux_furtherreferral") : false;
                        if (item1.Attributes.Contains("lux_furtherreferraldate"))
                        {
                            refer["lux_furtherreferraldate"] = Convert.ToDateTime(item1.Attributes["lux_furtherreferraldate"]);
                        }
                        refer["lux_declined"] = item1.Attributes.Contains("lux_declined") ? item1.GetAttributeValue<bool>("lux_declined") : false;
                        refer["lux_approvaldeclinecomment"] = item1.Attributes.Contains("lux_approvaldeclinecomment") ? item1.Attributes["lux_approvaldeclinecomment"].ToString() : "";
                        var referid = objCommon.service.Create(refer);

                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                              <entity name='lux_premisereferral'>
                                                                <attribute name='lux_premisereferralid' />
                                                                <attribute name='lux_name' />
                                                                <attribute name='createdon' />
                                                                <attribute name='lux_suppliedvalue' />
                                                                <attribute name='lux_retailproduct' />
                                                                <attribute name='lux_riskpostcode' />
                                                                <attribute name='lux_referral' />
                                                                <attribute name='lux_fieldname' />
                                                                <attribute name='lux_application' />
                                                                <attribute name='lux_additionalinfo' />
                                                                <order attribute='lux_name' descending='false' />
                                                                <filter type='and'>
                                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                                  <condition attribute='lux_retailproduct' operator='not-null' />
                                                                  <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{item1.Id}' />
                                                                </filter>
                                                              </entity>
                                                            </fetch>";

                        if (objCommon.service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                        {
                            foreach (var premref in objCommon.service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                            {
                                Entity premise = objCommon.service.Retrieve("lux_propertyownersretail", premref.GetAttributeValue<EntityReference>("lux_retailproduct").Id, new ColumnSet("lux_locationnumber"));
                                var locationNumber = premise.Attributes["lux_locationnumber"].ToString();

                                var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_propertyownersretail'>
                                                    <attribute name='lux_riskpostcode' />
                                                    <attribute name='lux_riskaddress' />
                                                    <attribute name='lux_locationnumber' />
                                                    <attribute name='lux_propertyownersretailid' />
                                                    <order attribute='lux_riskpostcode' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_locationnumber' operator='eq' value='{locationNumber}' />
                                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{NewPropertyOwnersApplication.Get(executionContext).Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";
                                if (objCommon.service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
                                {
                                    Entity premiserefer = new Entity("lux_premisereferral");
                                    premiserefer["lux_retailproduct"] = new EntityReference("lux_propertyownersretail", objCommon.service.RetrieveMultiple(new FetchExpression(fetch1)).Entities[0].Id);
                                    premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", NewPropertyOwnersApplication.Get(executionContext).Id);
                                    premiserefer["lux_riskpostcode"] = premref.Attributes.Contains("lux_riskpostcode") ? premref.Attributes["lux_riskpostcode"].ToString() : "";
                                    premiserefer["lux_referral"] = new EntityReference("lux_referral", referid);
                                    premiserefer["lux_fieldname"] = premref.Attributes.Contains("lux_fieldname") ? premref.Attributes["lux_fieldname"].ToString() : "";
                                    premiserefer["lux_suppliedvalue"] = premref.Attributes.Contains("lux_suppliedvalue") ? premref.Attributes["lux_suppliedvalue"].ToString() : "";
                                    premiserefer["lux_additionalinfo"] = premref.Attributes.Contains("lux_additionalinfo") ? premref.Attributes["lux_additionalinfo"].ToString() : "";
                                    objCommon.service.Create(premiserefer);
                                }
                            }
                        }
                    }
                }
            }
            else if (Product.Get(executionContext).ToString() == "Pubs & Restaurants" || Product.Get(executionContext).ToString() == "Hotels and Guesthouses")
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_propertyownerspremise' />
                                    <attribute name='lux_referralid' />
                                    <attribute name='lux_retailproduct' />
                                    <attribute name='lux_refertohcc' />
                                    <attribute name='lux_premisetype' />
                                    <attribute name='lux_premiselevel' />
                                    <attribute name='lux_name' />
                                    <attribute name='lux_furtherreferraldate' />
                                    <attribute name='lux_furtherreferral' />
                                    <attribute name='lux_fieldschemaname' />
                                    <attribute name='lux_declined' />
                                    <attribute name='lux_userapproval' />
                                    <attribute name='lux_approvaldeclinecomment' />
                                    <attribute name='lux_approvaldate' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{OldPropertyOwnersApplication.Get(executionContext).Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (objCommon.service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    foreach (var item1 in objCommon.service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", NewPropertyOwnersApplication.Get(executionContext).Id);
                        refer["lux_fieldname"] = item1.Attributes.Contains("lux_fieldname") ? item1.Attributes["lux_fieldname"].ToString() : "";
                        if (item1.Attributes["lux_fieldname"].ToString().Contains("Flood Score"))
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() + "1" : "";
                        }
                        else if (item1.Attributes["lux_fieldname"].ToString().Contains("Subsidence Score"))
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() + "1" : "";
                        }
                        else
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() : "";
                        }
                        refer["lux_suppliedvalue"] = item1.Attributes.Contains("lux_suppliedvalue") ? item1.Attributes["lux_suppliedvalue"].ToString() : "";
                        refer["lux_approve"] = true;
                        if (item1.Attributes.Contains("lux_userapproval"))
                        {
                            refer["lux_userapproval"] = new EntityReference("systemuser", item1.GetAttributeValue<EntityReference>("lux_userapproval").Id);
                        }
                        refer["lux_approvaldate"] = item1.Attributes.Contains("lux_approvaldate") ? Convert.ToDateTime(item1.Attributes["lux_approvaldate"]) : DateTime.Now;
                        refer["lux_additionalinfo"] = item1.Attributes.Contains("lux_additionalinfo") ? item1.Attributes["lux_additionalinfo"].ToString() : "";
                        refer["lux_refertohcc"] = item1.Attributes.Contains("lux_refertohcc") ? item1.GetAttributeValue<bool>("lux_refertohcc") : false;
                        refer["lux_premiselevel"] = item1.Attributes.Contains("lux_premiselevel") ? item1.GetAttributeValue<bool>("lux_premiselevel") : false;
                        if (item1.Attributes.Contains("lux_premisetype"))
                        {
                            refer["lux_premisetype"] = new OptionSetValue(item1.GetAttributeValue<OptionSetValue>("lux_premisetype").Value);
                        }
                        refer["lux_name"] = item1.Attributes.Contains("lux_name") ? item1.Attributes["lux_name"].ToString() : "";
                        refer["lux_furtherreferral"] = item1.Attributes.Contains("lux_furtherreferral") ? item1.GetAttributeValue<bool>("lux_furtherreferral") : false;
                        if (item1.Attributes.Contains("lux_furtherreferraldate"))
                        {
                            refer["lux_furtherreferraldate"] = Convert.ToDateTime(item1.Attributes["lux_furtherreferraldate"]);
                        }
                        refer["lux_declined"] = item1.Attributes.Contains("lux_declined") ? item1.GetAttributeValue<bool>("lux_declined") : false;
                        refer["lux_approvaldeclinecomment"] = item1.Attributes.Contains("lux_approvaldeclinecomment") ? item1.Attributes["lux_approvaldeclinecomment"].ToString() : "";
                        var referid = objCommon.service.Create(refer);

                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                              <entity name='lux_premisereferral'>
                                                                <attribute name='lux_premisereferralid' />
                                                                <attribute name='lux_name' />
                                                                <attribute name='createdon' />
                                                                <attribute name='lux_suppliedvalue' />
                                                                <attribute name='lux_pubsrestaurants' />
                                                                <attribute name='lux_riskpostcode' />
                                                                <attribute name='lux_referral' />
                                                                <attribute name='lux_fieldname' />
                                                                <attribute name='lux_application' />
                                                                <attribute name='lux_additionalinfo' />
                                                                <order attribute='lux_name' descending='false' />
                                                                <filter type='and'>
                                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                                  <condition attribute='lux_pubsrestaurants' operator='not-null' />
                                                                  <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{item1.Id}' />
                                                                </filter>
                                                              </entity>
                                                            </fetch>";

                        if (objCommon.service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                        {
                            foreach (var premref in objCommon.service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                            {
                                Entity premise = objCommon.service.Retrieve("lux_pubsrestaurantspropertyownersapplicatio", premref.GetAttributeValue<EntityReference>("lux_pubsrestaurants").Id, new ColumnSet("lux_locationnumber"));
                                var locationNumber = premise.Attributes["lux_locationnumber"].ToString();

                                var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_pubsrestaurantspropertyownersapplicatio'>
                                                    <attribute name='lux_riskpostcode' />
                                                    <attribute name='lux_riskaddress' />
                                                    <attribute name='lux_locationnumber' />
                                                    <attribute name='lux_pubsrestaurantspropertyownersapplicatioid' />
                                                    <order attribute='lux_riskpostcode' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_locationnumber' operator='eq' value='{locationNumber}' />
                                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{NewPropertyOwnersApplication.Get(executionContext).Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";
                                if (objCommon.service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
                                {
                                    Entity premiserefer = new Entity("lux_premisereferral");
                                    premiserefer["lux_pubsrestaurants"] = new EntityReference("lux_pubsrestaurantspropertyownersapplicatio", objCommon.service.RetrieveMultiple(new FetchExpression(fetch1)).Entities[0].Id);
                                    premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", NewPropertyOwnersApplication.Get(executionContext).Id);
                                    premiserefer["lux_riskpostcode"] = premref.Attributes.Contains("lux_riskpostcode") ? premref.Attributes["lux_riskpostcode"].ToString() : "";
                                    premiserefer["lux_referral"] = new EntityReference("lux_referral", referid);
                                    premiserefer["lux_fieldname"] = premref.Attributes.Contains("lux_fieldname") ? premref.Attributes["lux_fieldname"].ToString() : "";
                                    premiserefer["lux_suppliedvalue"] = premref.Attributes.Contains("lux_suppliedvalue") ? premref.Attributes["lux_suppliedvalue"].ToString() : "";
                                    premiserefer["lux_additionalinfo"] = premref.Attributes.Contains("lux_additionalinfo") ? premref.Attributes["lux_additionalinfo"].ToString() : "";
                                    objCommon.service.Create(premiserefer);
                                }
                            }
                        }
                    }
                }
            }
            else if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_propertyownerspremise' />
                                    <attribute name='lux_referralid' />
                                    <attribute name='lux_retailproduct' />
                                    <attribute name='lux_refertohcc' />
                                    <attribute name='lux_premisetype' />
                                    <attribute name='lux_premiselevel' />
                                    <attribute name='lux_name' />
                                    <attribute name='lux_furtherreferraldate' />
                                    <attribute name='lux_furtherreferral' />
                                    <attribute name='lux_fieldschemaname' />
                                    <attribute name='lux_declined' />
                                    <attribute name='lux_userapproval' />
                                    <attribute name='lux_approvaldeclinecomment' />
                                    <attribute name='lux_approvaldate' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{OldPropertyOwnersApplication.Get(executionContext).Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (objCommon.service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    foreach (var item1 in objCommon.service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", NewPropertyOwnersApplication.Get(executionContext).Id);
                        refer["lux_fieldname"] = item1.Attributes.Contains("lux_fieldname") ? item1.Attributes["lux_fieldname"].ToString() : "";
                        if (item1.Attributes["lux_fieldname"].ToString().Contains("Flood Score"))
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() + "1" : "";
                        }
                        else if (item1.Attributes["lux_fieldname"].ToString().Contains("Subsidence Score"))
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() + "1" : "";
                        }
                        else
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() : "";
                        }
                        refer["lux_suppliedvalue"] = item1.Attributes.Contains("lux_suppliedvalue") ? item1.Attributes["lux_suppliedvalue"].ToString() : "";
                        refer["lux_approve"] = true;
                        if (item1.Attributes.Contains("lux_userapproval"))
                        {
                            refer["lux_userapproval"] = new EntityReference("systemuser", item1.GetAttributeValue<EntityReference>("lux_userapproval").Id);
                        }
                        refer["lux_approvaldate"] = item1.Attributes.Contains("lux_approvaldate") ? Convert.ToDateTime(item1.Attributes["lux_approvaldate"]) : DateTime.Now;
                        refer["lux_additionalinfo"] = item1.Attributes.Contains("lux_additionalinfo") ? item1.Attributes["lux_additionalinfo"].ToString() : "";
                        refer["lux_refertohcc"] = item1.Attributes.Contains("lux_refertohcc") ? item1.GetAttributeValue<bool>("lux_refertohcc") : false;
                        refer["lux_premiselevel"] = item1.Attributes.Contains("lux_premiselevel") ? item1.GetAttributeValue<bool>("lux_premiselevel") : false;
                        if (item1.Attributes.Contains("lux_premisetype"))
                        {
                            refer["lux_premisetype"] = new OptionSetValue(item1.GetAttributeValue<OptionSetValue>("lux_premisetype").Value);
                        }
                        refer["lux_name"] = item1.Attributes.Contains("lux_name") ? item1.Attributes["lux_name"].ToString() : "";
                        refer["lux_furtherreferral"] = item1.Attributes.Contains("lux_furtherreferral") ? item1.GetAttributeValue<bool>("lux_furtherreferral") : false;
                        if (item1.Attributes.Contains("lux_furtherreferraldate"))
                        {
                            refer["lux_furtherreferraldate"] = Convert.ToDateTime(item1.Attributes["lux_furtherreferraldate"]);
                        }
                        refer["lux_declined"] = item1.Attributes.Contains("lux_declined") ? item1.GetAttributeValue<bool>("lux_declined") : false;
                        refer["lux_approvaldeclinecomment"] = item1.Attributes.Contains("lux_approvaldeclinecomment") ? item1.Attributes["lux_approvaldeclinecomment"].ToString() : "";
                        var referid = objCommon.service.Create(refer);

                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                              <entity name='lux_premisereferral'>
                                                                <attribute name='lux_premisereferralid' />
                                                                <attribute name='lux_name' />
                                                                <attribute name='createdon' />
                                                                <attribute name='lux_suppliedvalue' />
                                                                <attribute name='lux_commercialcombined' />
                                                                <attribute name='lux_riskpostcode' />
                                                                <attribute name='lux_referral' />
                                                                <attribute name='lux_fieldname' />
                                                                <attribute name='lux_application' />
                                                                <attribute name='lux_additionalinfo' />
                                                                <order attribute='lux_name' descending='false' />
                                                                <filter type='and'>
                                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                                  <condition attribute='lux_commercialcombined' operator='not-null' />
                                                                  <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{item1.Id}' />
                                                                </filter>
                                                              </entity>
                                                            </fetch>";

                        if (objCommon.service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                        {
                            foreach (var premref in objCommon.service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                            {
                                Entity premise = objCommon.service.Retrieve("lux_commercialcombinedapplication", premref.GetAttributeValue<EntityReference>("lux_commercialcombined").Id, new ColumnSet("lux_locationnumber"));
                                var locationNumber = premise.Attributes["lux_locationnumber"].ToString();

                                var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_commercialcombinedapplication'>
                                                    <attribute name='lux_riskpostcode' />
                                                    <attribute name='lux_riskaddress' />
                                                    <attribute name='lux_locationnumber' />
                                                    <attribute name='lux_commercialcombinedapplicationid' />
                                                    <order attribute='lux_riskpostcode' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_locationnumber' operator='eq' value='{locationNumber}' />
                                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{NewPropertyOwnersApplication.Get(executionContext).Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";
                                if (objCommon.service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
                                {
                                    Entity premiserefer = new Entity("lux_premisereferral");
                                    premiserefer["lux_commercialcombined"] = new EntityReference("lux_commercialcombinedapplication", objCommon.service.RetrieveMultiple(new FetchExpression(fetch1)).Entities[0].Id);
                                    premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", NewPropertyOwnersApplication.Get(executionContext).Id);
                                    premiserefer["lux_riskpostcode"] = premref.Attributes.Contains("lux_riskpostcode") ? premref.Attributes["lux_riskpostcode"].ToString() : "";
                                    premiserefer["lux_referral"] = new EntityReference("lux_referral", referid);
                                    premiserefer["lux_fieldname"] = premref.Attributes.Contains("lux_fieldname") ? premref.Attributes["lux_fieldname"].ToString() : "";
                                    premiserefer["lux_suppliedvalue"] = premref.Attributes.Contains("lux_suppliedvalue") ? premref.Attributes["lux_suppliedvalue"].ToString() : "";
                                    premiserefer["lux_additionalinfo"] = premref.Attributes.Contains("lux_additionalinfo") ? premref.Attributes["lux_additionalinfo"].ToString() : "";
                                    objCommon.service.Create(premiserefer);
                                }
                            }
                        }
                    }
                }
            }
            else if (Product.Get(executionContext).ToString() == "Contractors Combined")
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_propertyownerspremise' />
                                    <attribute name='lux_referralid' />
                                    <attribute name='lux_retailproduct' />
                                    <attribute name='lux_refertohcc' />
                                    <attribute name='lux_premisetype' />
                                    <attribute name='lux_premiselevel' />
                                    <attribute name='lux_name' />
                                    <attribute name='lux_furtherreferraldate' />
                                    <attribute name='lux_furtherreferral' />
                                    <attribute name='lux_fieldschemaname' />
                                    <attribute name='lux_declined' />
                                    <attribute name='lux_userapproval' />
                                    <attribute name='lux_approvaldeclinecomment' />
                                    <attribute name='lux_approvaldate' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{OldPropertyOwnersApplication.Get(executionContext).Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (objCommon.service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    foreach (var item1 in objCommon.service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", NewPropertyOwnersApplication.Get(executionContext).Id);
                        refer["lux_fieldname"] = item1.Attributes.Contains("lux_fieldname") ? item1.Attributes["lux_fieldname"].ToString() : "";
                        if (item1.Attributes["lux_fieldname"].ToString().Contains("Flood Score"))
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() + "1" : "";
                        }
                        else if (item1.Attributes["lux_fieldname"].ToString().Contains("Subsidence Score"))
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() + "1" : "";
                        }
                        else
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() : "";
                        }
                        refer["lux_suppliedvalue"] = item1.Attributes.Contains("lux_suppliedvalue") ? item1.Attributes["lux_suppliedvalue"].ToString() : "";
                        refer["lux_approve"] = true;
                        if (item1.Attributes.Contains("lux_userapproval"))
                        {
                            refer["lux_userapproval"] = new EntityReference("systemuser", item1.GetAttributeValue<EntityReference>("lux_userapproval").Id);
                        }
                        refer["lux_approvaldate"] = item1.Attributes.Contains("lux_approvaldate") ? Convert.ToDateTime(item1.Attributes["lux_approvaldate"]) : DateTime.Now;
                        refer["lux_additionalinfo"] = item1.Attributes.Contains("lux_additionalinfo") ? item1.Attributes["lux_additionalinfo"].ToString() : "";
                        refer["lux_refertohcc"] = item1.Attributes.Contains("lux_refertohcc") ? item1.GetAttributeValue<bool>("lux_refertohcc") : false;
                        refer["lux_premiselevel"] = item1.Attributes.Contains("lux_premiselevel") ? item1.GetAttributeValue<bool>("lux_premiselevel") : false;
                        if (item1.Attributes.Contains("lux_premisetype"))
                        {
                            refer["lux_premisetype"] = new OptionSetValue(item1.GetAttributeValue<OptionSetValue>("lux_premisetype").Value);
                        }
                        refer["lux_name"] = item1.Attributes.Contains("lux_name") ? item1.Attributes["lux_name"].ToString() : "";
                        refer["lux_furtherreferral"] = item1.Attributes.Contains("lux_furtherreferral") ? item1.GetAttributeValue<bool>("lux_furtherreferral") : false;
                        if (item1.Attributes.Contains("lux_furtherreferraldate"))
                        {
                            refer["lux_furtherreferraldate"] = Convert.ToDateTime(item1.Attributes["lux_furtherreferraldate"]);
                        }
                        refer["lux_declined"] = item1.Attributes.Contains("lux_declined") ? item1.GetAttributeValue<bool>("lux_declined") : false;
                        refer["lux_approvaldeclinecomment"] = item1.Attributes.Contains("lux_approvaldeclinecomment") ? item1.Attributes["lux_approvaldeclinecomment"].ToString() : "";
                        var referid = objCommon.service.Create(refer);

                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                              <entity name='lux_premisereferral'>
                                                                <attribute name='lux_premisereferralid' />
                                                                <attribute name='lux_name' />
                                                                <attribute name='createdon' />
                                                                <attribute name='lux_suppliedvalue' />
                                                                <attribute name='lux_contractorscombined' />
                                                                <attribute name='lux_riskpostcode' />
                                                                <attribute name='lux_referral' />
                                                                <attribute name='lux_fieldname' />
                                                                <attribute name='lux_application' />
                                                                <attribute name='lux_additionalinfo' />
                                                                <order attribute='lux_name' descending='false' />
                                                                <filter type='and'>
                                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                                  <condition attribute='lux_contractorscombined' operator='not-null' />
                                                                  <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{item1.Id}' />
                                                                </filter>
                                                              </entity>
                                                            </fetch>";

                        if (objCommon.service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                        {
                            foreach (var premref in objCommon.service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                            {
                                Entity premise = objCommon.service.Retrieve("lux_contractorscombined", premref.GetAttributeValue<EntityReference>("lux_contractorscombined").Id, new ColumnSet("lux_locationnumber"));
                                var locationNumber = premise.Attributes["lux_locationnumber"].ToString();

                                var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_contractorscombined'>
                                                    <attribute name='lux_riskpostcode' />
                                                    <attribute name='lux_riskaddress' />
                                                    <attribute name='lux_locationnumber' />
                                                    <attribute name='lux_contractorscombinedid' />
                                                    <order attribute='lux_riskpostcode' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_locationnumber' operator='eq' value='{locationNumber}' />
                                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{NewPropertyOwnersApplication.Get(executionContext).Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";
                                if (objCommon.service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
                                {
                                    Entity premiserefer = new Entity("lux_premisereferral");
                                    premiserefer["lux_contractorscombined"] = new EntityReference("lux_contractorscombined", objCommon.service.RetrieveMultiple(new FetchExpression(fetch1)).Entities[0].Id);
                                    premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", NewPropertyOwnersApplication.Get(executionContext).Id);
                                    premiserefer["lux_riskpostcode"] = premref.Attributes.Contains("lux_riskpostcode") ? premref.Attributes["lux_riskpostcode"].ToString() : "";
                                    premiserefer["lux_referral"] = new EntityReference("lux_referral", referid);
                                    premiserefer["lux_fieldname"] = premref.Attributes.Contains("lux_fieldname") ? premref.Attributes["lux_fieldname"].ToString() : "";
                                    premiserefer["lux_suppliedvalue"] = premref.Attributes.Contains("lux_suppliedvalue") ? premref.Attributes["lux_suppliedvalue"].ToString() : "";
                                    premiserefer["lux_additionalinfo"] = premref.Attributes.Contains("lux_additionalinfo") ? premref.Attributes["lux_additionalinfo"].ToString() : "";
                                    objCommon.service.Create(premiserefer);
                                }
                            }
                        }
                    }
                }
            }
            if (Product.Get(executionContext).ToString() == "Terrorism")
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <attribute name='lux_retailproduct' />
                                    <attribute name='lux_refertohcc' />
                                    <attribute name='lux_premisetype' />
                                    <attribute name='lux_premiselevel' />
                                    <attribute name='lux_name' />
                                    <attribute name='lux_furtherreferraldate' />
                                    <attribute name='lux_furtherreferral' />
                                    <attribute name='lux_fieldschemaname' />
                                    <attribute name='lux_declined' />
                                    <attribute name='lux_userapproval' />
                                    <attribute name='lux_approvaldeclinecomment' />
                                    <attribute name='lux_approvaldate' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{OldPropertyOwnersApplication.Get(executionContext).Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (objCommon.service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    foreach (var item1 in objCommon.service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", NewPropertyOwnersApplication.Get(executionContext).Id);
                        refer["lux_fieldname"] = item1.Attributes.Contains("lux_fieldname") ? item1.Attributes["lux_fieldname"].ToString() : "";
                        if (item1.Attributes["lux_fieldname"].ToString().Contains("Flood Score"))
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() + "1" : "";
                        }
                        else if (item1.Attributes["lux_fieldname"].ToString().Contains("Subsidence Score"))
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() + "1" : "";
                        }
                        else
                        {
                            refer["lux_fieldschemaname"] = item1.Attributes.Contains("lux_fieldschemaname") ? item1.Attributes["lux_fieldschemaname"].ToString() : "";
                        }
                        refer["lux_suppliedvalue"] = item1.Attributes.Contains("lux_suppliedvalue") ? item1.Attributes["lux_suppliedvalue"].ToString() : "";
                        refer["lux_approve"] = true;
                        if (item1.Attributes.Contains("lux_userapproval"))
                        {
                            refer["lux_userapproval"] = new EntityReference("systemuser", item1.GetAttributeValue<EntityReference>("lux_userapproval").Id);
                        }
                        refer["lux_approvaldate"] = item1.Attributes.Contains("lux_approvaldate") ? Convert.ToDateTime(item1.Attributes["lux_approvaldate"]) : DateTime.Now;
                        refer["lux_additionalinfo"] = item1.Attributes.Contains("lux_additionalinfo") ? item1.Attributes["lux_additionalinfo"].ToString() : "";
                        refer["lux_refertohcc"] = item1.Attributes.Contains("lux_refertohcc") ? item1.GetAttributeValue<bool>("lux_refertohcc") : false;
                        refer["lux_premiselevel"] = item1.Attributes.Contains("lux_premiselevel") ? item1.GetAttributeValue<bool>("lux_premiselevel") : false;
                        if (item1.Attributes.Contains("lux_premisetype"))
                        {
                            refer["lux_premisetype"] = new OptionSetValue(item1.GetAttributeValue<OptionSetValue>("lux_premisetype").Value);
                        }
                        refer["lux_name"] = item1.Attributes.Contains("lux_name") ? item1.Attributes["lux_name"].ToString() : "";
                        refer["lux_furtherreferral"] = item1.Attributes.Contains("lux_furtherreferral") ? item1.GetAttributeValue<bool>("lux_furtherreferral") : false;
                        if (item1.Attributes.Contains("lux_furtherreferraldate"))
                        {
                            refer["lux_furtherreferraldate"] = Convert.ToDateTime(item1.Attributes["lux_furtherreferraldate"]);
                        }
                        refer["lux_declined"] = item1.Attributes.Contains("lux_declined") ? item1.GetAttributeValue<bool>("lux_declined") : false;
                        refer["lux_approvaldeclinecomment"] = item1.Attributes.Contains("lux_approvaldeclinecomment") ? item1.Attributes["lux_approvaldeclinecomment"].ToString() : "";
                        var referid = objCommon.service.Create(refer);
                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                              <entity name='lux_premisereferral'>
                                                                <attribute name='lux_premisereferralid' />
                                                                <attribute name='lux_name' />
                                                                <attribute name='createdon' />
                                                                <attribute name='lux_suppliedvalue' />
                                                                <attribute name='lux_terrorismproduct' />
                                                                <attribute name='lux_riskpostcode' />
                                                                <attribute name='lux_referral' />
                                                                <attribute name='lux_fieldname' />
                                                                <attribute name='lux_application' />
                                                                <attribute name='lux_additionalinfo' />
                                                                <order attribute='lux_name' descending='false' />
                                                                <filter type='and'>
                                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                                  <condition attribute='lux_terrorismproduct' operator='not-null' />
                                                                  <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{item1.Id}' />
                                                                </filter>
                                                              </entity>
                                                            </fetch>";

                        if (objCommon.service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                        {
                            foreach (var premref in objCommon.service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                            {
                                Entity premise = objCommon.service.Retrieve("lux_terrorismpremise", premref.GetAttributeValue<EntityReference>("lux_terrorismproduct").Id, new ColumnSet("lux_locationnumber"));
                                var locationNumber = premise.Attributes["lux_locationnumber"].ToString();
                                var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_terrorismpremise'>
                                                    <attribute name='lux_riskpostcode' />
                                                    <attribute name='lux_riskaddress' />
                                                    <attribute name='lux_locationnumber' />
                                                    <attribute name='lux_terrorismpremiseid' />
                                                    <order attribute='lux_riskpostcode' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_locationnumber' operator='eq' value='{locationNumber}' />
                                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{NewPropertyOwnersApplication.Get(executionContext).Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";
                                if (objCommon.service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
                                {
                                    Entity premiserefer = new Entity("lux_premisereferral");
                                    premiserefer["lux_terrorismproduct"] = new EntityReference("lux_terrorismpremise", objCommon.service.RetrieveMultiple(new FetchExpression(fetch1)).Entities[0].Id);
                                    premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", NewPropertyOwnersApplication.Get(executionContext).Id);
                                    premiserefer["lux_riskpostcode"] = premref.Attributes.Contains("lux_riskpostcode") ? premref.Attributes["lux_riskpostcode"].ToString() : "";
                                    premiserefer["lux_referral"] = new EntityReference("lux_referral", referid);
                                    premiserefer["lux_fieldname"] = premref.Attributes.Contains("lux_fieldname") ? premref.Attributes["lux_fieldname"].ToString() : "";
                                    premiserefer["lux_suppliedvalue"] = premref.Attributes.Contains("lux_suppliedvalue") ? premref.Attributes["lux_suppliedvalue"].ToString() : "";
                                    premiserefer["lux_additionalinfo"] = premref.Attributes.Contains("lux_additionalinfo") ? premref.Attributes["lux_additionalinfo"].ToString() : "";
                                    objCommon.service.Create(premiserefer);

                                    objCommon.tracingService.Trace("Premise Refer Created!!");
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
