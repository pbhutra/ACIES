﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System.Activities;

namespace CustomWorkflows
{
    public class GetNotApprovedReferralCount : CodeActivity
    {
        #region "Parameter Definition"

        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Input("Tradesman Application")]
        [ReferenceTarget("lux_tradesman")]
        public InArgument<EntityReference> TradesmanApplication { get; set; }

        [Output("Record Count")]
        public OutArgument<int> RecordCount { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            if (TradesmanApplication.Get(executionContext) == null)
            {
                EntityReference appref = PropertyOwnersApplication.Get<EntityReference>(executionContext);

                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_referral'>
                                <attribute name='lux_suppliedvalue' />
                                <attribute name='lux_fieldname' />
                                <attribute name='lux_approve' />
                                <attribute name='lux_additionalinfo' />
                                <attribute name='lux_propertyownerspremise' />
                                <attribute name='lux_referralid' />
                                <order attribute='lux_suppliedvalue' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appref.Id}' />
                                  <condition attribute='lux_approve' operator='ne' value='1' />
                                </filter>
                              </entity>
                            </fetch>";

                var count = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count;
                RecordCount.Set(executionContext, count);
            }
            else
            {
                EntityReference appref = TradesmanApplication.Get<EntityReference>(executionContext);

                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_referral'>
                                <attribute name='lux_suppliedvalue' />
                                <attribute name='lux_fieldname' />
                                <attribute name='lux_approve' />
                                <attribute name='lux_additionalinfo' />
                                <attribute name='lux_referralid' />
                                <order attribute='lux_suppliedvalue' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appref.Id}' />
                                  <condition attribute='lux_approve' operator='ne' value='1' />
                                </filter>
                              </entity>
                            </fetch>";

                var count = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count;
                RecordCount.Set(executionContext, count);
            }
        }
    }
}

