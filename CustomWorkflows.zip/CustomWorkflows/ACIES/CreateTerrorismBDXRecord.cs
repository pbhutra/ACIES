﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace CustomWorkflows
{
    public class CreateTerrorismBDXRecord : CodeActivity
    {
        [Input("Policy")]
        [ReferenceTarget("lux_policy")]
        [RequiredArgument]
        public InArgument<EntityReference> Policy { get; set; }

        [Input("Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        [RequiredArgument]
        public InArgument<EntityReference> Application { get; set; }

        [RequiredArgument]
        [Input("Product")]
        public InArgument<string> Product { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            var ProductName = Product.Get<string>(executionContext).ToString();

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference policyref = Policy.Get<EntityReference>(executionContext);
            Entity policy = service.Retrieve("lux_policy", policyref.Id, new ColumnSet(true));

            EntityReference appref = Application.Get<EntityReference>(executionContext);
            Entity appln = service.Retrieve("lux_propertyownersapplications", appref.Id, new ColumnSet(true));

            if (ProductName.Contains("Property Owners") || ProductName.Contains("Unoccupied"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_propertyownerspremise'>
                                    <attribute name='lux_subsidencescore' />
                                    <attribute name='lux_securityrating' />
                                    <attribute name='lux_riskpostcode' />
                                    <attribute name='lux_locationnumber' />
                                    <attribute name='lux_propertyownerspremiseid' />
                                    <order attribute='lux_locationnumber' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    var firstLocationNumber = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Attributes.Contains("lux_locationnumber") ? service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].GetAttributeValue<int>("lux_locationnumber") : 1;
                    foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        var item = service.Retrieve("lux_propertyownerspremise", item1.Id, new ColumnSet(true));
                        var LocationNo = item.Attributes.Contains("lux_locationnumber") ? item.GetAttributeValue<int>("lux_locationnumber") : 1;

                        Entity bdx = new Entity("lux_terrorism");
                        bdx["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", appref.Id);
                        bdx["lux_policy"] = new EntityReference("lux_policy", policyref.Id);
                        bdx["lux_policynumber"] = policy.Attributes.Contains("lux_policynumber") ? policy.Attributes["lux_policynumber"].ToString() : "";
                        bdx["lux_inceptiondate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_expirydate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_name"] = appln.Attributes.Contains("lux_insuredtitle") ? appln.Attributes["lux_insuredtitle"] : "";

                        if (policy.Attributes.Contains("lux_policytype") && policy.FormattedValues["lux_policytype"] == "New Business")
                        {
                            bdx["lux_transactiontype"] = "New";
                        }
                        else
                        {
                            bdx["lux_transactiontype"] = "Renewal";
                        }
                        bdx["lux_locationid"] = LocationNo;
                        bdx["lux_riskaddress"] = (item.Attributes.Contains("lux_housenumber") ? item.Attributes["lux_housenumber"] + ", " : "") + (item.Attributes.Contains("lux_riskaddress") ? item.Attributes["lux_riskaddress"] + ", " : "") + (item.Attributes.Contains("lux_citycounty") ? item.Attributes["lux_citycounty"] : "");
                        bdx["lux_riskpostcode"] = item.Attributes.Contains("lux_riskpostcode") == true ? item.Attributes["lux_riskpostcode"] : "";
                        bdx["lux_businessinterruption"] = new Money(0);

                        var Building = item.Attributes.Contains("lux_declaredvalueforrebuildingthisproperty") == true ? item.GetAttributeValue<Money>("lux_declaredvalueforrebuildingthisproperty").Value : 0;
                        var CommunalContent = item.Attributes.Contains("lux_totalcontentsofcommunalareas") == true ? item.GetAttributeValue<Money>("lux_totalcontentsofcommunalareas").Value : 0;
                        var LandlordContent = item.Attributes.Contains("lux_landlordscontentsinresidentialareas") == true ? item.GetAttributeValue<Money>("lux_landlordscontentsinresidentialareas").Value : 0;
                        var Content = CommunalContent + LandlordContent;
                        var LORPayable = item.Attributes.Contains("lux_lossofannualrentalincome") == true ? item.GetAttributeValue<Money>("lux_lossofannualrentalincome").Value : 0;
                        var TotalInsurableValues = Building + Content + LORPayable;

                        bdx["lux_buildingssuminsured"] = new Money(Building);
                        bdx["lux_contentssuminsured"] = new Money(Content);

                        if (item.GetAttributeValue<OptionSetValue>("lux_basisofcover").Value == 972970001)
                        {
                            var indexingValue = item.Attributes.Contains("lux_indexlinkingdayone") ? item.FormattedValues["lux_indexlinkingdayone"].ToString() : "";
                            if (indexingValue != "")
                            {
                                var indexed = Convert.ToDecimal(indexingValue.Replace("%", ""));
                                var Amount = Building + Content;
                                var upliftedAmount = Amount + Amount * indexed / 100 + LORPayable;

                                bdx["lux_dayoneupliftamount"] = indexingValue;
                                bdx["lux_totalsuminsured"] = new Money(upliftedAmount);

                                bdx["lux_buildingssuminsured"] = new Money(Building + Building * indexed / 100);
                                bdx["lux_contentssuminsured"] = new Money(Content + Content * indexed / 100);
                            }
                        }
                        else
                        {
                            bdx["lux_totalsuminsured"] = new Money(TotalInsurableValues);
                        }

                        if (LocationNo == firstLocationNumber)
                        {
                            if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "MTA")
                            {
                                var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_propertyownersapplications'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_terrorismquotedpremium' />
                                                        <attribute name='lux_terrorismquotedpremiumipt' />
                                                        <attribute name='lux_terrorismmtapremium' />
                                                        <attribute name='lux_terrorismmtaipt' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='statuscode' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970006' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                                var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001);
                                var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);

                                var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_terrorismquotedpremium") ? x.GetAttributeValue<Money>("lux_terrorismquotedpremium").Value : 0);
                                var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_terrorismmtapremium") ? x.GetAttributeValue<Money>("lux_terrorismmtapremium").Value : 0);

                                bdx["lux_premium"] = new Money(MainGWPAmt + MTAGWPAmt);
                                bdx["lux_ipt"] = new Money((MainGWPAmt + MTAGWPAmt) * 12 / 100);
                                var Notes = "MTA - " + (appln.Attributes.Contains("lux_mtareason") ? appln.Attributes["lux_mtareason"].ToString() : "");
                                var endFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_applicationendorsements'>
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_endorsementnumber' />
                                                    <attribute name='lux_applicationendorsementsid' />
                                                    <attribute name='lux_endorsementhtml' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_endorsementnumber' operator='like' value='%TER%' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(endFetch)).Entities.Count > 0)
                                {
                                    foreach (var endItem in service.RetrieveMultiple(new FetchExpression(endFetch)).Entities)
                                    {
                                        var endHtml = Regex.Replace(endItem.Attributes["lux_endorsementhtml"].ToString(), @"<[^>]+>|&nbsp;", "").Trim();
                                        Notes += "\n\nEndorsement - " + endItem.Attributes["lux_endorsementnumber"] + " - " + endItem.Attributes["lux_name"] + "\n\n" + endHtml;
                                    }
                                }
                                bdx["lux_notesmtascancellationsendorsements"] = Notes;
                            }
                            else if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "Cancellation")
                            {
                                var MTAGWPAmt = appln.Attributes.Contains("lux_terrorismmtapremium") ? appln.GetAttributeValue<Money>("lux_terrorismmtapremium").Value : 0;
                                bdx["lux_premium"] = new Money(MTAGWPAmt);
                                bdx["lux_ipt"] = new Money((MTAGWPAmt) * 12 / 100);
                                var Notes = "Cancellation - " + (appln.Attributes.Contains("lux_reasonforcancellation") ? appln.FormattedValues["lux_reasonforcancellation"].ToString() : "");
                                var endFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_applicationendorsements'>
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_endorsementnumber' />
                                                    <attribute name='lux_applicationendorsementsid' />
                                                    <attribute name='lux_endorsementhtml' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_endorsementnumber' operator='like' value='%TER%' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(endFetch)).Entities.Count > 0)
                                {
                                    foreach (var endItem in service.RetrieveMultiple(new FetchExpression(endFetch)).Entities)
                                    {
                                        var endHtml = Regex.Replace(endItem.Attributes["lux_endorsementhtml"].ToString(), @"<[^>]+>|&nbsp;", "").Trim();
                                        Notes += "\n\nEndorsement - " + endItem.Attributes["lux_endorsementnumber"] + " - " + endItem.Attributes["lux_name"] + "\n\n" + endHtml;
                                    }
                                }
                                bdx["lux_notesmtascancellationsendorsements"] = Notes;
                            }
                            else
                            {
                                var GWPAmt = appln.Attributes.Contains("lux_terrorismquotedpremium") ? appln.GetAttributeValue<Money>("lux_terrorismquotedpremium").Value : 0;
                                bdx["lux_premium"] = new Money(GWPAmt);
                                bdx["lux_ipt"] = new Money(GWPAmt * 12 / 100);
                                var Notes = "";
                                var endFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_applicationendorsements'>
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_endorsementnumber' />
                                                    <attribute name='lux_applicationendorsementsid' />
                                                    <attribute name='lux_endorsementhtml' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_endorsementnumber' operator='like' value='%TER%' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(endFetch)).Entities.Count > 0)
                                {
                                    foreach (var endItem in service.RetrieveMultiple(new FetchExpression(endFetch)).Entities)
                                    {
                                        var endHtml = Regex.Replace(endItem.Attributes["lux_endorsementhtml"].ToString(), @"<[^>]+>|&nbsp;", "").Trim();
                                        Notes += "\n\nEndorsement - " + endItem.Attributes["lux_endorsementnumber"] + " - " + endItem.Attributes["lux_name"] + "\n\n" + endHtml;
                                    }
                                }
                                bdx["lux_notesmtascancellationsendorsements"] = Notes;
                            }
                        }
                        service.Create(bdx);
                    }
                }
            }
            else if (ProductName.Contains("Retail"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_propertyownersretail'>
                                    <attribute name='lux_propertyownersretailid' />
                                    <attribute name='lux_name' />
                                    <attribute name='lux_riskpostcode' />                                
                                    <attribute name='lux_locationnumber' />
                                    <attribute name='createdon' />
                                    <order attribute='lux_locationnumber' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    var firstLocationNumber = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Attributes.Contains("lux_locationnumber") ? service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].GetAttributeValue<int>("lux_locationnumber") : 1;
                    foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        var item = service.Retrieve("lux_propertyownersretail", item1.Id, new ColumnSet(true));
                        var LocationNo = item.Attributes.Contains("lux_locationnumber") ? item.GetAttributeValue<int>("lux_locationnumber") : 1;

                        Entity bdx = new Entity("lux_terrorism");
                        bdx["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", appref.Id);
                        bdx["lux_policy"] = new EntityReference("lux_policy", policyref.Id);
                        bdx["lux_policynumber"] = policy.Attributes.Contains("lux_policynumber") ? policy.Attributes["lux_policynumber"].ToString() : "";
                        bdx["lux_inceptiondate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_expirydate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_name"] = appln.Attributes.Contains("lux_insuredtitle") ? appln.Attributes["lux_insuredtitle"] : "";

                        if (policy.Attributes.Contains("lux_policytype") && policy.FormattedValues["lux_policytype"] == "New Business")
                        {
                            bdx["lux_transactiontype"] = "New";
                        }
                        else
                        {
                            bdx["lux_transactiontype"] = "Renewal";
                        }
                        bdx["lux_locationid"] = LocationNo;
                        bdx["lux_riskaddress"] = (item.Attributes.Contains("lux_housenumber") ? item.Attributes["lux_housenumber"] + ", " : "") + (item.Attributes.Contains("lux_riskaddress") ? item.Attributes["lux_riskaddress"] + ", " : "") + (item.Attributes.Contains("lux_citycounty") ? item.Attributes["lux_citycounty"] : "");
                        bdx["lux_riskpostcode"] = item.Attributes.Contains("lux_riskpostcode") == true ? item.Attributes["lux_riskpostcode"] : "";
                        bdx["lux_businessinterruption"] = new Money(0);

                        var Building = item.Attributes.Contains("lux_buildingsdeclaredvalue") == true ? item.GetAttributeValue<Money>("lux_buildingsdeclaredvalue").Value : 0;
                        var Content = item.Attributes.Contains("lux_generalcontentsdeclaredvalueincludingmach") == true ? item.GetAttributeValue<Money>("lux_generalcontentsdeclaredvalueincludingmach").Value : 0;
                        var Tenents = item.Attributes.Contains("lux_tenantsimprovementsdeclaredvalue") == true ? item.GetAttributeValue<Money>("lux_tenantsimprovementsdeclaredvalue").Value : 0;
                        var ComputerEquipment = item.Attributes.Contains("lux_computerandelectronicbusinessequipment") == true ? item.GetAttributeValue<Money>("lux_computerandelectronicbusinessequipment").Value : 0;
                        var LossofRent = item.Attributes.Contains("lux_materialdamagelossofrentpayable") == true ? item.GetAttributeValue<Money>("lux_materialdamagelossofrentpayable").Value : 0;
                        var Stock = item.Attributes.Contains("lux_stockexcludinghighvaluestock") == true ? item.GetAttributeValue<Money>("lux_stockexcludinghighvaluestock").Value : 0;

                        decimal Ciggerates = item.Attributes.Contains("lux_cigarettescigarsortobaccoproductssuminsur") == true ? item.GetAttributeValue<Money>("lux_cigarettescigarsortobaccoproductssuminsur").Value : 0;
                        decimal Wines = item.Attributes.Contains("lux_winesfortifiedwinesspiritsfinesuminsured") == true ? item.GetAttributeValue<Money>("lux_winesfortifiedwinesspiritsfinesuminsured").Value : 0;
                        decimal NonFerrus = item.Attributes.Contains("lux_nonferrousmetalssuminsured") ? item.GetAttributeValue<Money>("lux_nonferrousmetalssuminsured").Value : 0;
                        decimal Mobile = item.Attributes.Contains("lux_mobilephonessuminsured") ? item.GetAttributeValue<Money>("lux_mobilephonessuminsured").Value : 0;
                        decimal Computer = item.Attributes.Contains("lux_computerequipmentsuminsured") ? item.GetAttributeValue<Money>("lux_computerequipmentsuminsured").Value : 0;
                        decimal Alcohol = item.Attributes.Contains("lux_alcoholsuminsured") ? item.GetAttributeValue<Money>("lux_alcoholsuminsured").Value : 0;
                        decimal Audio = item.Attributes.Contains("lux_audiovideoequipmentsuminsured") ? item.GetAttributeValue<Money>("lux_audiovideoequipmentsuminsured").Value : 0;
                        decimal ComputerGames = item.Attributes.Contains("lux_computergamesandorconsolessuminsured") ? item.GetAttributeValue<Money>("lux_computergamesandorconsolessuminsured").Value : 0;
                        decimal Jewellery = item.Attributes.Contains("lux_jewellerywatchessuminsured") ? item.GetAttributeValue<Money>("lux_jewellerywatchessuminsured").Value : 0;
                        decimal PowerTools = item.Attributes.Contains("lux_powertoolssuminsured") ? item.GetAttributeValue<Money>("lux_powertoolssuminsured").Value : 0;
                        decimal FineArt = item.Attributes.Contains("lux_fineartsuminsured") ? item.GetAttributeValue<Money>("lux_fineartsuminsured").Value : 0;
                        var TargetStock = Wines + NonFerrus + Mobile + Computer + Alcohol + Audio + Ciggerates + Computer + Jewellery + PowerTools + FineArt;

                        var TotalInsurableValues = Building + Content + Tenents + ComputerEquipment + LossofRent + Stock + TargetStock;

                        bdx["lux_buildingssuminsured"] = new Money(Building);
                        bdx["lux_contentssuminsured"] = new Money(Content);

                        if (item.GetAttributeValue<bool>("lux_isdayoneupliftcoverrequired") == true)
                        {
                            var indexingValue = item.Attributes.Contains("lux_dayoneupliftcover") ? item.FormattedValues["lux_dayoneupliftcover"].ToString() : "";
                            if (indexingValue != "")
                            {
                                var indexed = Convert.ToDecimal(indexingValue.Replace("%", ""));
                                var Amount = Building + Tenents + Content;
                                var upliftedAmount = Amount + Amount * indexed / 100 + Stock + TargetStock + ComputerEquipment + LossofRent;

                                bdx["lux_dayoneupliftamount"] = indexingValue;
                                bdx["lux_totalsuminsured"] = new Money(upliftedAmount);

                                bdx["lux_buildingssuminsured"] = new Money(Building + Building * indexed / 100);
                                bdx["lux_contentssuminsured"] = new Money(Content + Content * indexed / 100);
                            }
                            else
                            {
                                bdx["lux_totalsuminsured"] = new Money(TotalInsurableValues);
                            }
                        }
                        else
                        {
                            bdx["lux_totalsuminsured"] = new Money(TotalInsurableValues);
                        }

                        if (LocationNo == firstLocationNumber)
                        {
                            if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "MTA")
                            {
                                var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_propertyownersapplications'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_terrorismquotedpremium' />
                                                        <attribute name='lux_terrorismquotedpremiumipt' />
                                                        <attribute name='lux_terrorismmtapremium' />
                                                        <attribute name='lux_terrorismmtaipt' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='statuscode' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970006' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                                var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001);
                                var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);

                                var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_terrorismquotedpremium") ? x.GetAttributeValue<Money>("lux_terrorismquotedpremium").Value : 0);
                                var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_terrorismmtapremium") ? x.GetAttributeValue<Money>("lux_terrorismmtapremium").Value : 0);

                                bdx["lux_premium"] = new Money(MainGWPAmt + MTAGWPAmt);
                                bdx["lux_ipt"] = new Money((MainGWPAmt + MTAGWPAmt) * 12 / 100);
                                var Notes = "MTA - " + (appln.Attributes.Contains("lux_mtareason") ? appln.Attributes["lux_mtareason"].ToString() : "");
                                var endFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_applicationendorsements'>
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_endorsementnumber' />
                                                    <attribute name='lux_applicationendorsementsid' />
                                                    <attribute name='lux_endorsementhtml' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_endorsementnumber' operator='like' value='%TER%' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(endFetch)).Entities.Count > 0)
                                {
                                    foreach (var endItem in service.RetrieveMultiple(new FetchExpression(endFetch)).Entities)
                                    {
                                        var endHtml = Regex.Replace(endItem.Attributes["lux_endorsementhtml"].ToString(), @"<[^>]+>|&nbsp;", "").Trim();
                                        Notes += "\n\nEndorsement - " + endItem.Attributes["lux_endorsementnumber"] + " - " + endItem.Attributes["lux_name"] + "\n\n" + endHtml;
                                    }
                                }
                                bdx["lux_notesmtascancellationsendorsements"] = Notes;
                            }
                            else if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "Cancellation")
                            {
                                var MTAGWPAmt = appln.Attributes.Contains("lux_terrorismmtapremium") ? appln.GetAttributeValue<Money>("lux_terrorismmtapremium").Value : 0;
                                bdx["lux_premium"] = new Money(MTAGWPAmt);
                                bdx["lux_ipt"] = new Money((MTAGWPAmt) * 12 / 100);
                                var Notes = "Cancellation - " + (appln.Attributes.Contains("lux_reasonforcancellation") ? appln.FormattedValues["lux_reasonforcancellation"].ToString() : "");
                                var endFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_applicationendorsements'>
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_endorsementnumber' />
                                                    <attribute name='lux_applicationendorsementsid' />
                                                    <attribute name='lux_endorsementhtml' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_endorsementnumber' operator='like' value='%TER%' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(endFetch)).Entities.Count > 0)
                                {
                                    foreach (var endItem in service.RetrieveMultiple(new FetchExpression(endFetch)).Entities)
                                    {
                                        var endHtml = Regex.Replace(endItem.Attributes["lux_endorsementhtml"].ToString(), @"<[^>]+>|&nbsp;", "").Trim();
                                        Notes += "\n\nEndorsement - " + endItem.Attributes["lux_endorsementnumber"] + " - " + endItem.Attributes["lux_name"] + "\n\n" + endHtml;
                                    }
                                }
                                bdx["lux_notesmtascancellationsendorsements"] = Notes;
                            }
                            else
                            {
                                var GWPAmt = appln.Attributes.Contains("lux_terrorismquotedpremium") ? appln.GetAttributeValue<Money>("lux_terrorismquotedpremium").Value : 0;
                                bdx["lux_premium"] = new Money(GWPAmt);
                                bdx["lux_ipt"] = new Money(GWPAmt * 12 / 100);
                                var Notes = "";
                                var endFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_applicationendorsements'>
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_endorsementnumber' />
                                                    <attribute name='lux_applicationendorsementsid' />
                                                    <attribute name='lux_endorsementhtml' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_endorsementnumber' operator='like' value='%TER%' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(endFetch)).Entities.Count > 0)
                                {
                                    foreach (var endItem in service.RetrieveMultiple(new FetchExpression(endFetch)).Entities)
                                    {
                                        var endHtml = Regex.Replace(endItem.Attributes["lux_endorsementhtml"].ToString(), @"<[^>]+>|&nbsp;", "").Trim();
                                        Notes += "\n\nEndorsement - " + endItem.Attributes["lux_endorsementnumber"] + " - " + endItem.Attributes["lux_name"] + "\n\n" + endHtml;
                                    }
                                }
                                bdx["lux_notesmtascancellationsendorsements"] = Notes;
                            }
                        }
                        service.Create(bdx);
                    }
                }
            }
            else if (ProductName.Contains("Pubs & Restaurants") || ProductName.Contains("Hotels and Guesthouses"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_pubsrestaurantspropertyownersapplicatio'>
                                    <attribute name='lux_pubsrestaurantspropertyownersapplicatioid' />
                                    <attribute name='lux_name' />
                                    <attribute name='createdon' />
                                    <attribute name='lux_riskpostcode' />                                    
                                    <attribute name='lux_locationnumber' />
                                    <attribute name='createdon' />
                                    <order attribute='lux_locationnumber' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    var firstLocationNumber = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Attributes.Contains("lux_locationnumber") ? service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].GetAttributeValue<int>("lux_locationnumber") : 1;
                    foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        var item = service.Retrieve("lux_pubsrestaurantspropertyownersapplicatio", item1.Id, new ColumnSet(true));
                        var LocationNo = item.Attributes.Contains("lux_locationnumber") ? item.GetAttributeValue<int>("lux_locationnumber") : 1;

                        Entity bdx = new Entity("lux_terrorism");
                        bdx["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", appref.Id);
                        bdx["lux_policy"] = new EntityReference("lux_policy", policyref.Id);
                        bdx["lux_policynumber"] = policy.Attributes.Contains("lux_policynumber") ? policy.Attributes["lux_policynumber"].ToString() : "";
                        bdx["lux_inceptiondate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_expirydate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_name"] = appln.Attributes.Contains("lux_insuredtitle") ? appln.Attributes["lux_insuredtitle"] : "";

                        if (policy.Attributes.Contains("lux_policytype") && policy.FormattedValues["lux_policytype"] == "New Business")
                        {
                            bdx["lux_transactiontype"] = "New";
                        }
                        else
                        {
                            bdx["lux_transactiontype"] = "Renewal";
                        }
                        bdx["lux_locationid"] = LocationNo;
                        bdx["lux_riskaddress"] = (item.Attributes.Contains("lux_housenumber") ? item.Attributes["lux_housenumber"] + ", " : "") + (item.Attributes.Contains("lux_riskaddress") ? item.Attributes["lux_riskaddress"] + ", " : "") + (item.Attributes.Contains("lux_citycounty") ? item.Attributes["lux_citycounty"] : "");
                        bdx["lux_riskpostcode"] = item.Attributes.Contains("lux_riskpostcode") == true ? item.Attributes["lux_riskpostcode"] : "";
                        bdx["lux_businessinterruption"] = new Money(0);

                        var Building = item.Attributes.Contains("lux_buildingsdeclaredvalue") == true ? item.GetAttributeValue<Money>("lux_buildingsdeclaredvalue").Value : 0;
                        var Content = item.Attributes.Contains("lux_generalcontentsdeclaredvalueincludingmach") == true ? item.GetAttributeValue<Money>("lux_generalcontentsdeclaredvalueincludingmach").Value : 0;
                        var Tenents = item.Attributes.Contains("lux_tenantsimprovementsdeclaredvalue") == true ? item.GetAttributeValue<Money>("lux_tenantsimprovementsdeclaredvalue").Value : 0;
                        var ComputerEquipment = item.Attributes.Contains("lux_computerandelectronicbusinessequipment") == true ? item.GetAttributeValue<Money>("lux_computerandelectronicbusinessequipment").Value : 0;
                        var LossofRent = item.Attributes.Contains("lux_materialdamagelossofrentpayable") == true ? item.GetAttributeValue<Money>("lux_materialdamagelossofrentpayable").Value : 0;
                        var Stock = item.Attributes.Contains("lux_stockexcludinghighvaluestock") == true ? item.GetAttributeValue<Money>("lux_stockexcludinghighvaluestock").Value : 0;

                        decimal Ciggerates = item.Attributes.Contains("lux_cigarettescigarsortobaccoproductssuminsur") == true ? item.GetAttributeValue<Money>("lux_cigarettescigarsortobaccoproductssuminsur").Value : 0;
                        decimal Wines = item.Attributes.Contains("lux_winesfortifiedwinesspiritsfinesuminsured") == true ? item.GetAttributeValue<Money>("lux_winesfortifiedwinesspiritsfinesuminsured").Value : 0;
                        decimal NonFerrus = item.Attributes.Contains("lux_nonferrousmetalssuminsured") ? item.GetAttributeValue<Money>("lux_nonferrousmetalssuminsured").Value : 0;
                        decimal Mobile = item.Attributes.Contains("lux_mobilephonessuminsured") ? item.GetAttributeValue<Money>("lux_mobilephonessuminsured").Value : 0;
                        decimal Computer = item.Attributes.Contains("lux_computerequipmentsuminsured") ? item.GetAttributeValue<Money>("lux_computerequipmentsuminsured").Value : 0;
                        decimal Alcohol = item.Attributes.Contains("lux_alcoholsuminsured") ? item.GetAttributeValue<Money>("lux_alcoholsuminsured").Value : 0;
                        decimal Audio = item.Attributes.Contains("lux_audiovideoequipmentsuminsured") ? item.GetAttributeValue<Money>("lux_audiovideoequipmentsuminsured").Value : 0;
                        decimal ComputerGames = item.Attributes.Contains("lux_computergamesandorconsolessuminsured") ? item.GetAttributeValue<Money>("lux_computergamesandorconsolessuminsured").Value : 0;
                        decimal Jewellery = item.Attributes.Contains("lux_jewellerywatchessuminsured") ? item.GetAttributeValue<Money>("lux_jewellerywatchessuminsured").Value : 0;
                        decimal PowerTools = item.Attributes.Contains("lux_powertoolssuminsured") ? item.GetAttributeValue<Money>("lux_powertoolssuminsured").Value : 0;
                        decimal FineArt = item.Attributes.Contains("lux_fineartsuminsured") ? item.GetAttributeValue<Money>("lux_fineartsuminsured").Value : 0;
                        var TargetStock = Wines + NonFerrus + Mobile + Computer + Alcohol + Audio + Ciggerates + Computer + Jewellery + PowerTools + FineArt;

                        var TotalInsurableValues = Building + Content + Tenents + ComputerEquipment + LossofRent + Stock + TargetStock;

                        bdx["lux_buildingssuminsured"] = new Money(Building);
                        bdx["lux_contentssuminsured"] = new Money(Content);

                        if (item.GetAttributeValue<bool>("lux_isdayoneupliftcoverrequired") == true)
                        {
                            var indexingValue = item.Attributes.Contains("lux_dayoneupliftcover") ? item.FormattedValues["lux_dayoneupliftcover"].ToString() : "";
                            if (indexingValue != "")
                            {
                                var indexed = Convert.ToDecimal(indexingValue.Replace("%", ""));
                                var Amount = Building + Tenents + Content;
                                var upliftedAmount = Amount + Amount * indexed / 100 + Stock + TargetStock + ComputerEquipment + LossofRent;

                                bdx["lux_dayoneupliftamount"] = indexingValue;
                                bdx["lux_totalsuminsured"] = new Money(upliftedAmount);

                                bdx["lux_buildingssuminsured"] = new Money(Building + Building * indexed / 100);
                                bdx["lux_contentssuminsured"] = new Money(Content + Content * indexed / 100);
                            }
                            else
                            {
                                bdx["lux_totalsuminsured"] = new Money(TotalInsurableValues);
                            }
                        }
                        else
                        {
                            bdx["lux_totalsuminsured"] = new Money(TotalInsurableValues);
                        }

                        if (LocationNo == firstLocationNumber)
                        {
                            if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "MTA")
                            {
                                var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_propertyownersapplications'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_terrorismquotedpremium' />
                                                        <attribute name='lux_terrorismquotedpremiumipt' />
                                                        <attribute name='lux_terrorismmtapremium' />
                                                        <attribute name='lux_terrorismmtaipt' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='statuscode' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970006' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                                var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001);
                                var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);

                                var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_terrorismquotedpremium") ? x.GetAttributeValue<Money>("lux_terrorismquotedpremium").Value : 0);
                                var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_terrorismmtapremium") ? x.GetAttributeValue<Money>("lux_terrorismmtapremium").Value : 0);

                                bdx["lux_premium"] = new Money(MainGWPAmt + MTAGWPAmt);
                                bdx["lux_ipt"] = new Money((MainGWPAmt + MTAGWPAmt) * 12 / 100);
                                var Notes = "MTA - " + (appln.Attributes.Contains("lux_mtareason") ? appln.Attributes["lux_mtareason"].ToString() : "");
                                var endFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_applicationendorsements'>
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_endorsementnumber' />
                                                    <attribute name='lux_applicationendorsementsid' />
                                                    <attribute name='lux_endorsementhtml' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_endorsementnumber' operator='like' value='%TER%' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(endFetch)).Entities.Count > 0)
                                {
                                    foreach (var endItem in service.RetrieveMultiple(new FetchExpression(endFetch)).Entities)
                                    {
                                        var endHtml = Regex.Replace(endItem.Attributes["lux_endorsementhtml"].ToString(), @"<[^>]+>|&nbsp;", "").Trim();
                                        Notes += "\n\nEndorsement - " + endItem.Attributes["lux_endorsementnumber"] + " - " + endItem.Attributes["lux_name"] + "\n\n" + endHtml;
                                    }
                                }
                                bdx["lux_notesmtascancellationsendorsements"] = Notes;
                            }
                            else if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "Cancellation")
                            {
                                var MTAGWPAmt = appln.Attributes.Contains("lux_terrorismmtapremium") ? appln.GetAttributeValue<Money>("lux_terrorismmtapremium").Value : 0;
                                bdx["lux_premium"] = new Money(MTAGWPAmt);
                                bdx["lux_ipt"] = new Money((MTAGWPAmt) * 12 / 100);
                                var Notes = "Cancellation - " + (appln.Attributes.Contains("lux_reasonforcancellation") ? appln.FormattedValues["lux_reasonforcancellation"].ToString() : "");
                                var endFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_applicationendorsements'>
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_endorsementnumber' />
                                                    <attribute name='lux_applicationendorsementsid' />
                                                    <attribute name='lux_endorsementhtml' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_endorsementnumber' operator='like' value='%TER%' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(endFetch)).Entities.Count > 0)
                                {
                                    foreach (var endItem in service.RetrieveMultiple(new FetchExpression(endFetch)).Entities)
                                    {
                                        var endHtml = Regex.Replace(endItem.Attributes["lux_endorsementhtml"].ToString(), @"<[^>]+>|&nbsp;", "").Trim();
                                        Notes += "\n\nEndorsement - " + endItem.Attributes["lux_endorsementnumber"] + " - " + endItem.Attributes["lux_name"] + "\n\n" + endHtml;
                                    }
                                }
                                bdx["lux_notesmtascancellationsendorsements"] = Notes;
                            }
                            else
                            {
                                var GWPAmt = appln.Attributes.Contains("lux_terrorismquotedpremium") ? appln.GetAttributeValue<Money>("lux_terrorismquotedpremium").Value : 0;
                                bdx["lux_premium"] = new Money(GWPAmt);
                                bdx["lux_ipt"] = new Money(GWPAmt * 12 / 100);
                                var Notes = "";
                                var endFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_applicationendorsements'>
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_endorsementnumber' />
                                                    <attribute name='lux_applicationendorsementsid' />
                                                    <attribute name='lux_endorsementhtml' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_endorsementnumber' operator='like' value='%TER%' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(endFetch)).Entities.Count > 0)
                                {
                                    foreach (var endItem in service.RetrieveMultiple(new FetchExpression(endFetch)).Entities)
                                    {
                                        var endHtml = Regex.Replace(endItem.Attributes["lux_endorsementhtml"].ToString(), @"<[^>]+>|&nbsp;", "").Trim();
                                        Notes += "\n\nEndorsement - " + endItem.Attributes["lux_endorsementnumber"] + " - " + endItem.Attributes["lux_name"] + "\n\n" + endHtml;
                                    }
                                }
                                bdx["lux_notesmtascancellationsendorsements"] = Notes;
                            }
                        }
                        service.Create(bdx);
                    }
                }
            }
            else if (ProductName.Contains("Commercial Combined") || ProductName.Contains("Office"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                   <entity name='lux_commercialcombinedapplication'>
                                    <attribute name='lux_commercialcombinedapplicationid' />
                                    <attribute name='lux_name' />
                                    <attribute name='lux_riskpostcode' />                                  
                                    <attribute name='lux_locationnumber' />
                                    <attribute name='createdon' />
                                    <order attribute='lux_locationnumber' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    var firstLocationNumber = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Attributes.Contains("lux_locationnumber") ? service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].GetAttributeValue<int>("lux_locationnumber") : 1;
                    foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        var item = service.Retrieve("lux_commercialcombinedapplication", item1.Id, new ColumnSet(true));
                        var LocationNo = item.Attributes.Contains("lux_locationnumber") ? item.GetAttributeValue<int>("lux_locationnumber") : 1;

                        Entity bdx = new Entity("lux_terrorism");
                        bdx["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", appref.Id);
                        bdx["lux_policy"] = new EntityReference("lux_policy", policyref.Id);
                        bdx["lux_policynumber"] = policy.Attributes.Contains("lux_policynumber") ? policy.Attributes["lux_policynumber"].ToString() : "";
                        bdx["lux_inceptiondate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_expirydate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_name"] = appln.Attributes.Contains("lux_insuredtitle") ? appln.Attributes["lux_insuredtitle"] : "";

                        if (policy.Attributes.Contains("lux_policytype") && policy.FormattedValues["lux_policytype"] == "New Business")
                        {
                            bdx["lux_transactiontype"] = "New";
                        }
                        else
                        {
                            bdx["lux_transactiontype"] = "Renewal";
                        }
                        bdx["lux_locationid"] = LocationNo;
                        bdx["lux_riskaddress"] = (item.Attributes.Contains("lux_housenumber") ? item.Attributes["lux_housenumber"] + ", " : "") + (item.Attributes.Contains("lux_riskaddress") ? item.Attributes["lux_riskaddress"] + ", " : "") + (item.Attributes.Contains("lux_citycounty") ? item.Attributes["lux_citycounty"] : "");
                        bdx["lux_riskpostcode"] = item.Attributes.Contains("lux_riskpostcode") == true ? item.Attributes["lux_riskpostcode"] : "";
                        bdx["lux_businessinterruption"] = new Money(0);

                        var Building = item.Attributes.Contains("lux_buildingsdeclaredvalue") == true ? item.GetAttributeValue<Money>("lux_buildingsdeclaredvalue").Value : 0;
                        var Content = item.Attributes.Contains("lux_generalcontentsdeclaredvalueincludingmach") == true ? item.GetAttributeValue<Money>("lux_generalcontentsdeclaredvalueincludingmach").Value : 0;
                        var Tenents = item.Attributes.Contains("lux_tenantsimprovementsdeclaredvalue") == true ? item.GetAttributeValue<Money>("lux_tenantsimprovementsdeclaredvalue").Value : 0;
                        var ComputerEquipment = item.Attributes.Contains("lux_computerandelectronicbusinessequipment") == true ? item.GetAttributeValue<Money>("lux_computerandelectronicbusinessequipment").Value : 0;
                        var LossofRent = item.Attributes.Contains("lux_materialdamagelossofrentpayable") == true ? item.GetAttributeValue<Money>("lux_materialdamagelossofrentpayable").Value : 0;
                        var Stock = item.Attributes.Contains("lux_stockexcludinghighvaluestock") == true ? item.GetAttributeValue<Money>("lux_stockexcludinghighvaluestock").Value : 0;

                        decimal Ciggerates = item.Attributes.Contains("lux_cigarettescigarsortobaccoproductssuminsur") == true ? item.GetAttributeValue<Money>("lux_cigarettescigarsortobaccoproductssuminsur").Value : 0;
                        decimal Wines = item.Attributes.Contains("lux_winesfortifiedwinesspiritsfinesuminsured") == true ? item.GetAttributeValue<Money>("lux_winesfortifiedwinesspiritsfinesuminsured").Value : 0;
                        decimal NonFerrus = item.Attributes.Contains("lux_nonferrousmetalssuminsured") ? item.GetAttributeValue<Money>("lux_nonferrousmetalssuminsured").Value : 0;
                        decimal Mobile = item.Attributes.Contains("lux_mobilephonessuminsured") ? item.GetAttributeValue<Money>("lux_mobilephonessuminsured").Value : 0;
                        decimal Computer = item.Attributes.Contains("lux_computerequipmentsuminsured") ? item.GetAttributeValue<Money>("lux_computerequipmentsuminsured").Value : 0;
                        decimal Alcohol = item.Attributes.Contains("lux_alcoholsuminsured") ? item.GetAttributeValue<Money>("lux_alcoholsuminsured").Value : 0;
                        decimal Audio = item.Attributes.Contains("lux_audiovideoequipmentsuminsured") ? item.GetAttributeValue<Money>("lux_audiovideoequipmentsuminsured").Value : 0;
                        decimal ComputerGames = item.Attributes.Contains("lux_computergamesandorconsolessuminsured") ? item.GetAttributeValue<Money>("lux_computergamesandorconsolessuminsured").Value : 0;
                        decimal Jewellery = item.Attributes.Contains("lux_jewellerywatchessuminsured") ? item.GetAttributeValue<Money>("lux_jewellerywatchessuminsured").Value : 0;
                        decimal PowerTools = item.Attributes.Contains("lux_powertoolssuminsured") ? item.GetAttributeValue<Money>("lux_powertoolssuminsured").Value : 0;
                        decimal FineArt = item.Attributes.Contains("lux_fineartsuminsured") ? item.GetAttributeValue<Money>("lux_fineartsuminsured").Value : 0;
                        var TargetStock = Wines + NonFerrus + Mobile + Computer + Alcohol + Audio + Ciggerates + Computer + Jewellery + PowerTools + FineArt;

                        var TotalInsurableValues = Building + Content + Tenents + ComputerEquipment + LossofRent + Stock + TargetStock;

                        bdx["lux_buildingssuminsured"] = new Money(Building);
                        bdx["lux_contentssuminsured"] = new Money(Content);

                        if (item.GetAttributeValue<bool>("lux_isdayoneupliftcoverrequired") == true)
                        {
                            var indexingValue = item.Attributes.Contains("lux_dayoneupliftcover") ? item.FormattedValues["lux_dayoneupliftcover"].ToString() : "";
                            if (indexingValue != "")
                            {
                                var indexed = Convert.ToDecimal(indexingValue.Replace("%", ""));
                                var Amount = Building + Tenents + Content;
                                var upliftedAmount = Amount + Amount * indexed / 100 + Stock + TargetStock + ComputerEquipment + LossofRent;

                                bdx["lux_dayoneupliftamount"] = indexingValue;
                                bdx["lux_totalsuminsured"] = new Money(upliftedAmount);

                                bdx["lux_buildingssuminsured"] = new Money(Building + Building * indexed / 100);
                                bdx["lux_contentssuminsured"] = new Money(Content + Content * indexed / 100);
                            }
                            else
                            {
                                bdx["lux_totalsuminsured"] = new Money(TotalInsurableValues);
                            }
                        }
                        else
                        {
                            bdx["lux_totalsuminsured"] = new Money(TotalInsurableValues);
                        }

                        if (LocationNo == firstLocationNumber)
                        {
                            if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "MTA")
                            {
                                var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_propertyownersapplications'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_terrorismquotedpremium' />
                                                        <attribute name='lux_terrorismquotedpremiumipt' />
                                                        <attribute name='lux_terrorismmtapremium' />
                                                        <attribute name='lux_terrorismmtaipt' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='statuscode' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970006' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                                var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001);
                                var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);

                                var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_terrorismquotedpremium") ? x.GetAttributeValue<Money>("lux_terrorismquotedpremium").Value : 0);
                                var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_terrorismmtapremium") ? x.GetAttributeValue<Money>("lux_terrorismmtapremium").Value : 0);

                                bdx["lux_premium"] = new Money(MainGWPAmt + MTAGWPAmt);
                                bdx["lux_ipt"] = new Money((MainGWPAmt + MTAGWPAmt) * 12 / 100);
                                var Notes = "MTA - " + (appln.Attributes.Contains("lux_mtareason") ? appln.Attributes["lux_mtareason"].ToString() : "");
                                var endFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_applicationendorsements'>
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_endorsementnumber' />
                                                    <attribute name='lux_applicationendorsementsid' />
                                                    <attribute name='lux_endorsementhtml' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_endorsementnumber' operator='like' value='%TER%' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(endFetch)).Entities.Count > 0)
                                {
                                    foreach (var endItem in service.RetrieveMultiple(new FetchExpression(endFetch)).Entities)
                                    {
                                        var endHtml = Regex.Replace(endItem.Attributes["lux_endorsementhtml"].ToString(), @"<[^>]+>|&nbsp;", "").Trim();
                                        Notes += "\n\nEndorsement - " + endItem.Attributes["lux_endorsementnumber"] + " - " + endItem.Attributes["lux_name"] + "\n\n" + endHtml;
                                    }
                                }
                                bdx["lux_notesmtascancellationsendorsements"] = Notes;
                            }
                            else if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "Cancellation")
                            {
                                var MTAGWPAmt = appln.Attributes.Contains("lux_terrorismmtapremium") ? appln.GetAttributeValue<Money>("lux_terrorismmtapremium").Value : 0;
                                bdx["lux_premium"] = new Money(MTAGWPAmt);
                                bdx["lux_ipt"] = new Money((MTAGWPAmt) * 12 / 100);
                                var Notes = "Cancellation - " + (appln.Attributes.Contains("lux_reasonforcancellation") ? appln.FormattedValues["lux_reasonforcancellation"].ToString() : "");
                                var endFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_applicationendorsements'>
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_endorsementnumber' />
                                                    <attribute name='lux_applicationendorsementsid' />
                                                    <attribute name='lux_endorsementhtml' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_endorsementnumber' operator='like' value='%TER%' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(endFetch)).Entities.Count > 0)
                                {
                                    foreach (var endItem in service.RetrieveMultiple(new FetchExpression(endFetch)).Entities)
                                    {
                                        var endHtml = Regex.Replace(endItem.Attributes["lux_endorsementhtml"].ToString(), @"<[^>]+>|&nbsp;", "").Trim();
                                        Notes += "\n\nEndorsement - " + endItem.Attributes["lux_endorsementnumber"] + " - " + endItem.Attributes["lux_name"] + "\n\n" + endHtml;
                                    }
                                }
                                bdx["lux_notesmtascancellationsendorsements"] = Notes;
                            }
                            else
                            {
                                var GWPAmt = appln.Attributes.Contains("lux_terrorismquotedpremium") ? appln.GetAttributeValue<Money>("lux_terrorismquotedpremium").Value : 0;
                                bdx["lux_premium"] = new Money(GWPAmt);
                                bdx["lux_ipt"] = new Money(GWPAmt * 12 / 100);
                                var Notes = "";
                                var endFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_applicationendorsements'>
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_endorsementnumber' />
                                                    <attribute name='lux_applicationendorsementsid' />
                                                    <attribute name='lux_endorsementhtml' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_endorsementnumber' operator='like' value='%TER%' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(endFetch)).Entities.Count > 0)
                                {
                                    foreach (var endItem in service.RetrieveMultiple(new FetchExpression(endFetch)).Entities)
                                    {
                                        var endHtml = Regex.Replace(endItem.Attributes["lux_endorsementhtml"].ToString(), @"<[^>]+>|&nbsp;", "").Trim();
                                        Notes += "\n\nEndorsement - " + endItem.Attributes["lux_endorsementnumber"] + " - " + endItem.Attributes["lux_name"] + "\n\n" + endHtml;
                                    }
                                }
                                bdx["lux_notesmtascancellationsendorsements"] = Notes;
                            }
                        }
                        service.Create(bdx);
                    }
                }
            }
            else if (ProductName.Contains("Terrorism"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                   <entity name='lux_terrorismpremise'>
                                    <attribute name='lux_terrorismpremiseid' />
                                    <attribute name='lux_name' />
                                    <attribute name='lux_riskpostcode' />                                  
                                    <attribute name='lux_locationnumber' />
                                    <attribute name='createdon' />
                                    <order attribute='lux_locationnumber' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    var firstLocationNumber = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Attributes.Contains("lux_locationnumber") ? service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].GetAttributeValue<int>("lux_locationnumber") : 1;
                    foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        var item = service.Retrieve("lux_terrorismpremise", item1.Id, new ColumnSet(true));
                        var LocationNo = item.Attributes.Contains("lux_locationnumber") ? item.GetAttributeValue<int>("lux_locationnumber") : 1;

                        Entity bdx = new Entity("lux_terrorism");
                        bdx["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", appref.Id);
                        bdx["lux_policy"] = new EntityReference("lux_policy", policyref.Id);
                        bdx["lux_policynumber"] = policy.Attributes.Contains("lux_policynumber") ? policy.Attributes["lux_policynumber"].ToString() : "";
                        bdx["lux_inceptiondate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_expirydate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_name"] = appln.Attributes.Contains("lux_insuredtitle") ? appln.Attributes["lux_insuredtitle"] : "";

                        if (policy.Attributes.Contains("lux_policytype") && policy.FormattedValues["lux_policytype"] == "New Business")
                        {
                            bdx["lux_transactiontype"] = "New";
                        }
                        else
                        {
                            bdx["lux_transactiontype"] = "Renewal";
                        }
                        bdx["lux_locationid"] = LocationNo;
                        bdx["lux_riskaddress"] = (item.Attributes.Contains("lux_housenumber") ? item.Attributes["lux_housenumber"] + ", " : "") + (item.Attributes.Contains("lux_riskaddress") ? item.Attributes["lux_riskaddress"] + ", " : "") + (item.Attributes.Contains("lux_citycounty") ? item.Attributes["lux_citycounty"] : "");
                        bdx["lux_riskpostcode"] = item.Attributes.Contains("lux_riskpostcode") == true ? item.Attributes["lux_riskpostcode"] : "";
                        bdx["lux_businessinterruption"] = new Money(0);

                        var Building = item.Attributes.Contains("lux_declaredvalueforrebuildingthisproperty") == true ? item.GetAttributeValue<Money>("lux_declaredvalueforrebuildingthisproperty").Value : 0;
                        var Content = item.Attributes.Contains("lux_landlordscontentsinresidentialareas") == true ? item.GetAttributeValue<Money>("lux_landlordscontentsinresidentialareas").Value : 0;
                        var Stock = item.Attributes.Contains("lux_stockincludingtargetstock") == true ? item.GetAttributeValue<Money>("lux_stockincludingtargetstock").Value : 0;
                        var LORPayable = item.Attributes.Contains("lux_lossofannualrentalincome") == true ? item.GetAttributeValue<Money>("lux_lossofannualrentalincome").Value : 0;
                        var TotalInsurableValues = Building + Content + Stock + LORPayable;

                        bdx["lux_buildingssuminsured"] = new Money(Building);
                        bdx["lux_contentssuminsured"] = new Money(Content);

                        if (item.GetAttributeValue<OptionSetValue>("lux_basisofcover").Value == 972970001)
                        {
                            var indexingValue = item.Attributes.Contains("lux_indexlinkingdayone") ? item.FormattedValues["lux_indexlinkingdayone"].ToString() : "";
                            if (indexingValue != "")
                            {
                                var indexed = Convert.ToDecimal(indexingValue.Replace("%", ""));
                                var Amount = Building + Content;
                                var upliftedAmount = Amount + Amount * indexed / 100 + Stock + LORPayable;

                                bdx["lux_dayoneupliftamount"] = indexingValue;
                                bdx["lux_totalsuminsured"] = new Money(upliftedAmount);

                                bdx["lux_buildingssuminsured"] = new Money(Building + Building * indexed / 100);
                                bdx["lux_contentssuminsured"] = new Money(Content + Content * indexed / 100);
                            }
                        }
                        else
                        {
                            bdx["lux_totalsuminsured"] = new Money(TotalInsurableValues);
                        }

                        if (LocationNo == firstLocationNumber)
                        {
                            if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "MTA")
                            {
                                var Applnfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_propertyownersapplications'>
                                                        <attribute name='lux_name' />
                                                        <attribute name='createdon' />
                                                        <attribute name='lux_terrorismquotedpremium' />
                                                        <attribute name='lux_terrorismquotedpremiumipt' />
                                                        <attribute name='lux_terrorismmtapremium' />
                                                        <attribute name='lux_terrorismmtaipt' />
                                                        <attribute name='lux_applicationtype' />
                                                        <attribute name='statuscode' />
                                                        <order attribute='lux_inceptiondate' descending='true' />
                                                        <order attribute='lux_quotenumber' descending='true' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='statuscode' operator='eq' value='972970006' />
                                                          <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{policy.Id}' />
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

                                var mainRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001);
                                var mtaRecord = service.RetrieveMultiple(new FetchExpression(Applnfetch)).Entities.Where(x => x.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002);

                                var MainGWPAmt = mainRecord.Sum(x => x.Attributes.Contains("lux_terrorismquotedpremium") ? x.GetAttributeValue<Money>("lux_terrorismquotedpremium").Value : 0);
                                var MTAGWPAmt = mtaRecord.Sum(x => x.Attributes.Contains("lux_terrorismmtapremium") ? x.GetAttributeValue<Money>("lux_terrorismmtapremium").Value : 0);

                                bdx["lux_premium"] = new Money(MainGWPAmt + MTAGWPAmt);
                                bdx["lux_ipt"] = new Money((MainGWPAmt + MTAGWPAmt) * 12 / 100);
                                var Notes = "MTA - " + (appln.Attributes.Contains("lux_mtareason") ? appln.Attributes["lux_mtareason"].ToString() : "");
                                var endFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_applicationendorsements'>
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_endorsementnumber' />
                                                    <attribute name='lux_applicationendorsementsid' />
                                                    <attribute name='lux_endorsementhtml' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_endorsementnumber' operator='like' value='%TER%' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(endFetch)).Entities.Count > 0)
                                {
                                    foreach (var endItem in service.RetrieveMultiple(new FetchExpression(endFetch)).Entities)
                                    {
                                        var endHtml = Regex.Replace(endItem.Attributes["lux_endorsementhtml"].ToString(), @"<[^>]+>|&nbsp;", "").Trim();
                                        Notes += "\n\nEndorsement - " + endItem.Attributes["lux_endorsementnumber"] + " - " + endItem.Attributes["lux_name"] + "\n\n" + endHtml;
                                    }
                                }
                                bdx["lux_notesmtascancellationsendorsements"] = Notes;
                            }
                            else if (appln.Attributes.Contains("lux_applicationtype") && appln.FormattedValues["lux_applicationtype"] == "Cancellation")
                            {
                                var MTAGWPAmt = appln.Attributes.Contains("lux_terrorismmtapremium") ? appln.GetAttributeValue<Money>("lux_terrorismmtapremium").Value : 0;
                                bdx["lux_premium"] = new Money(MTAGWPAmt);
                                bdx["lux_ipt"] = new Money((MTAGWPAmt) * 12 / 100);
                                var Notes = "Cancellation - " + (appln.Attributes.Contains("lux_reasonforcancellation") ? appln.FormattedValues["lux_reasonforcancellation"].ToString() : "");
                                var endFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_applicationendorsements'>
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_endorsementnumber' />
                                                    <attribute name='lux_applicationendorsementsid' />
                                                    <attribute name='lux_endorsementhtml' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_endorsementnumber' operator='like' value='%TER%' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(endFetch)).Entities.Count > 0)
                                {
                                    foreach (var endItem in service.RetrieveMultiple(new FetchExpression(endFetch)).Entities)
                                    {
                                        var endHtml = Regex.Replace(endItem.Attributes["lux_endorsementhtml"].ToString(), @"<[^>]+>|&nbsp;", "").Trim();
                                        Notes += "\n\nEndorsement - " + endItem.Attributes["lux_endorsementnumber"] + " - " + endItem.Attributes["lux_name"] + "\n\n" + endHtml;
                                    }
                                }
                                bdx["lux_notesmtascancellationsendorsements"] = Notes;
                            }
                            else
                            {
                                var GWPAmt = appln.Attributes.Contains("lux_terrorismquotedpremium") ? appln.GetAttributeValue<Money>("lux_terrorismquotedpremium").Value : 0;
                                bdx["lux_premium"] = new Money(GWPAmt);
                                bdx["lux_ipt"] = new Money(GWPAmt * 12 / 100);
                                var Notes = "";
                                var endFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_applicationendorsements'>
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_endorsementnumber' />
                                                    <attribute name='lux_applicationendorsementsid' />
                                                    <attribute name='lux_endorsementhtml' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_endorsementnumber' operator='like' value='%TER%' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(endFetch)).Entities.Count > 0)
                                {
                                    foreach (var endItem in service.RetrieveMultiple(new FetchExpression(endFetch)).Entities)
                                    {
                                        var endHtml = Regex.Replace(endItem.Attributes["lux_endorsementhtml"].ToString(), @"<[^>]+>|&nbsp;", "").Trim();
                                        Notes += "\n\nEndorsement - " + endItem.Attributes["lux_endorsementnumber"] + " - " + endItem.Attributes["lux_name"] + "\n\n" + endHtml;
                                    }
                                }
                                bdx["lux_notesmtascancellationsendorsements"] = Notes;
                            }
                        }
                        service.Create(bdx);
                    }
                }
            }
        }
    }
}