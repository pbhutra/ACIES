﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Net;
using System.ServiceModel.Description;
using System.Linq;

namespace CustomWorkflows
{
    public class SaveReferralTriggerscopy : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        //[Input("Property Owners Premise")]
        //[ReferenceTarget("lux_propertyownerspremise")]
        //public InArgument<EntityReference> PropertyOwnersPremise { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference applnref = PropertyOwnersApplication.Get<EntityReference>(executionContext);
            Entity appln = new Entity(applnref.LogicalName, applnref.Id);
            appln = service.Retrieve("lux_propertyownersapplications", applnref.Id, new ColumnSet(true));

            if (appln.Attributes.Contains("lux_declarationsquestion1"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_declarationsquestion1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion1") == false)
                    {
                        var FieldName1 = "The Proposers any Director or Partner in the company:";
                        FieldName1 += "a. Has never been convicted";
                        FieldName1 += "b. Has never been charged(but not yet tried)";
                        FieldName1 += "c. Has never been given an official police caution in respect of any criminal offence other than a than a(road traffic) motoring offence";
                        FieldName1 += "d. Has never been given an official police caution in respect of any criminal offence other than an offence that is now considered 'spent' under the Rehabilitation of Offenders Act 1974";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_declarationsquestion1";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_declarationanswer1") ? appln.Attributes["lux_declarationanswer1"] : "";
                        refer["lux_suppliedvalue"] = "Disagree";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion1") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_declarationsquestion2"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_declarationsquestion2' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion2") == false)
                    {
                        var FieldName1 = "The Proposers, any Director or Partner in the company:";
                        FieldName1 += "a. Has never been declared bankrupt (other than a bankruptcy that has been discharged) or insolvent";
                        FieldName1 += "b. Is not subject to any current bankruptcy or insolvency proceedings";
                        FieldName1 += "c. Has no outstanding County Court Judgement(s) or Sheriff Court Decree(s)";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_declarationsquestion2";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_declarationanswer2") ? appln.Attributes["lux_declarationanswer2"] : "";
                        refer["lux_suppliedvalue"] = "Disagree";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion2") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_declarationsquestion3"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_declarationsquestion3' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion3") == false)
                    {
                        var FieldName1 = "The Proposers any Director or Partner in the company have never been prosecuted or received notice of intended prosecution under:";
                        FieldName1 += "a. The Consumer Protection Act 1987";
                        FieldName1 += "b. The Food Safety Act 1990";
                        FieldName1 += "c. The Health & Safety Act 1974";
                        FieldName1 += "d. Any welfare or environmental protection legislation";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_declarationsquestion3";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_declarationanswer3") ? appln.Attributes["lux_declarationanswer3"] : "";
                        refer["lux_suppliedvalue"] = "Disagree";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion3") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_declarationsquestion4"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_declarationsquestion4' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion4") == false)
                    {
                        var FieldName1 = "The Proposers any Director or Partner in the company have not had:";
                        FieldName1 += "a. an insurance application refused or declined";
                        FieldName1 += "b. an insurance cancelled or renewal refused";
                        FieldName1 += "c. any increased or specific terms applied to any business insurance";
                        FieldName1 += "d. avioided any of your insurance policies for non-disclosure or misrepresentation of any material fact";
                        FieldName1 += "e. refused to pay a claim or restricted cover as a result of a policy terms or condition or risk improvement requirements.";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_declarationsquestion4";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_declarationanswer4") ? appln.Attributes["lux_declarationanswer4"] : "";
                        refer["lux_suppliedvalue"] = "Disagree";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion4") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_claimmadewithinthelast5years"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_claimmadewithinthelast5years' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == true)
                    {
                        var FieldName1 = "Has your business been involved in any losses, claims or incidents that may result in a claim within the last 5 years";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_claimmadewithinthelast5years";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_datethebusinessstarted"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_datethebusinessstarted' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if ((DateTime.Now.Year - 1) <= appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").Year)
                    {
                        var FieldName1 = "Date the business started";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_datethebusinessstarted";
                        refer["lux_additionalinfo"] = "Trading less than 12 months";
                        refer["lux_suppliedvalue"] = appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").ToShortDateString();
                        service.Create(refer);
                    }
                }
                else
                {
                    if ((DateTime.Now.Year - 1) > appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").Year)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                    else if ((DateTime.Now.Year - 1) <= appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").Year)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").ToShortDateString();
                        reff["lux_additionalinfo"] = "Trading less than 12 months";
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_propertyownersliabilitylimitofindemnity"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_propertyownersliabilitylimitofindemnity' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<OptionSetValue>("lux_propertyownersliabilitylimitofindemnity").Value == 972970003)
                    {
                        var FieldName1 = "Property Owners Liability limit of indemnity requirement";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_propertyownersliabilitylimitofindemnity";
                        refer["lux_suppliedvalue"] = "£10m";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<OptionSetValue>("lux_propertyownersliabilitylimitofindemnity").Value != 972970003)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }

            if (appln.Attributes.Contains("lux_employersliabilitypolicypremium"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_employersliabilitypolicypremium' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value > 15000)
                    {
                        var FieldName1 = "Employer's Liability Premium";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_employersliabilitypolicypremium";
                        refer["lux_suppliedvalue"] = appln.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value.ToString();
                        refer["lux_additionalinfo"] = "Liability Survey Required";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value <= 15000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }

            var InceptionDate = appln.GetAttributeValue<DateTime>("lux_inceptiondate");
            var RenewalDate = appln.GetAttributeValue<DateTime>("lux_renewaldate");

            if (appln.Attributes.Contains("lux_renewaldate"))
            {
                var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_referral'>
                                            <attribute name='lux_suppliedvalue' />
                                            <attribute name='lux_fieldname' />
                                            <attribute name='lux_approve' />
                                            <attribute name='lux_additionalinfo' />
                                            <attribute name='lux_referralid' />
                                            <order attribute='lux_suppliedvalue' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                              <condition attribute='lux_fieldschemaname' operator='eq' value='lux_renewaldate' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                {
                    if ((RenewalDate - InceptionDate).Days < 364 || (RenewalDate - InceptionDate).Days > 540)
                    {
                        var FieldName1 = "Renewal Date";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_renewaldate";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_renewaldate"];
                        refer["lux_additionalinfo"] = "ARAG: PERIOD OF INSURANCES BOUND: 12 months(plus odd time not exceeding 18 months in total)";
                        service.Create(refer);
                    }
                }
                else
                {
                    if ((RenewalDate - InceptionDate).Days >= 364 && (RenewalDate - InceptionDate).Days <= 540)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch2)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_inceptiondate"))
            {
                var fetch3 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_referral'>
                                            <attribute name='lux_suppliedvalue' />
                                            <attribute name='lux_fieldname' />
                                            <attribute name='lux_approve' />
                                            <attribute name='lux_additionalinfo' />
                                            <attribute name='lux_referralid' />
                                            <order attribute='lux_suppliedvalue' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                              <condition attribute='lux_fieldschemaname' operator='eq' value='lux_inceptiondate' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch3)).Entities.Count == 0)
                {
                    if ((InceptionDate - DateTime.Now).Days > 60)
                    {
                        var FieldName1 = "Renewal Date";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_inceptiondate";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_inceptiondate"];
                        refer["lux_additionalinfo"] = "ARAG: MAXIMUM ADVANCE PERIOD FOR INCEPTION DATES: 60 days";
                        service.Create(refer);
                    }
                }
                else
                {
                    if ((InceptionDate - DateTime.Now).Days <= 60)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch3)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }

            var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownerspremise'>
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_tenanttype' />
                                <attribute name='lux_ispropertyunoccupiedformorethan60days' />
                                <attribute name='lux_ispropertyinanareasusceptibletoflooding' />
                                <attribute name='lux_ispropertyinanareasusceptibletosubsidence' />
                                <attribute name='lux_anylistedbuildingorbuildingpreservation' />
                                <attribute name='lux_anycompositepanelsinconstruction' />
                                <attribute name='lux_compositepanel' />
                                <attribute name='lux_propertyownerspremiseid' />
                                <attribute name='lux_isthepropertyinagoodstateofrepair' />
                                <attribute name='lux_isthepropertytoundergoamajorrefurbishment' />
                                <attribute name='lux_majorrefurbishmentdetails' />
                                <attribute name='lux_electricalinspectioninthelast5years' />
                                <attribute name='lux_plannedbuildingmaintenanceprograminplace' />
                                <attribute name='lux_occupancytype' />
                                <attribute name='lux_anybuildingsshowanysignofsubsidence' />
                                <attribute name='lux_signofsubsidencedetails' />
                                <attribute name='lux_hastherebeensubsidenceinthevicinity' />
                                <attribute name='lux_subsidencevicinitydetails' />
                                <attribute name='lux_hasthereeverbeenaconsultingengineers' />
                                <attribute name='lux_consultingengineersreportdetails' />
                                <attribute name='lux_buildingconstruction' />
                                <attribute name='lux_doesthepremiseshaveaflatroof' />
                                <attribute name='lux_flatroofpercentage' />                                
                                <attribute name='lux_suminsuredwithupliftedamount' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
            {
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch1)).Entities)
                {
                    if (item.Attributes.Contains("lux_occupancytype"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownerspremise' operator='eq' uiname='' uitype='lux_propertyownerspremise' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_occupancytype' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.Attributes.Contains("lux_occupancytype") && item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970003) //Unoccupied
                            {
                                var FieldName1 = "Occupancy type";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_propertyownerspremise"] = new EntityReference("lux_propertyownerspremise", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_occupancytype";
                                refer["lux_suppliedvalue"] = "Unoccupied";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.Attributes.Contains("lux_occupancytype") && item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value != 972970003)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_ispropertyunoccupiedformorethan60days"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownerspremise' operator='eq' uiname='' uitype='lux_propertyownerspremise' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_ispropertyunoccupiedformorethan60days' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_ispropertyunoccupiedformorethan60days") == true)
                            {
                                var FieldName1 = "Is property unoccupied for more than 60 days";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_propertyownerspremise"] = new EntityReference("lux_propertyownerspremise", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_ispropertyunoccupiedformorethan60days";
                                refer["lux_suppliedvalue"] = "Yes";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_ispropertyunoccupiedformorethan60days") == false)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_ispropertyinanareasusceptibletoflooding"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownerspremise' operator='eq' uiname='' uitype='lux_propertyownerspremise' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_ispropertyinanareasusceptibletoflooding' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_ispropertyinanareasusceptibletoflooding") == true)
                            {
                                var FieldName1 = "Is property in an area susceptible to flooding";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_propertyownerspremise"] = new EntityReference("lux_propertyownerspremise", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_ispropertyinanareasusceptibletoflooding";
                                refer["lux_suppliedvalue"] = "Yes";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_ispropertyinanareasusceptibletoflooding") == false)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_ispropertyinanareasusceptibletosubsidence"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownerspremise' operator='eq' uiname='' uitype='lux_propertyownerspremise' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_ispropertyinanareasusceptibletosubsidence' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_ispropertyinanareasusceptibletosubsidence") == true)
                            {
                                var FieldName1 = "Is property in an area susceptible to subsidence";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_propertyownerspremise"] = new EntityReference("lux_propertyownerspremise", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_ispropertyinanareasusceptibletosubsidence";
                                refer["lux_suppliedvalue"] = "Yes";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_ispropertyinanareasusceptibletosubsidence") == false)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_anylistedbuildingorbuildingpreservation"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownerspremise' operator='eq' uiname='' uitype='lux_propertyownerspremise' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_anylistedbuildingorbuildingpreservation' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<OptionSetValue>("lux_anylistedbuildingorbuildingpreservation").Value != 972970001 && item.GetAttributeValue<OptionSetValue>("lux_anylistedbuildingorbuildingpreservation").Value != 972970002 && item.GetAttributeValue<OptionSetValue>("lux_anylistedbuildingorbuildingpreservation").Value != 972970005)
                            {
                                var FieldName1 = "Any listed building or building preservation notice";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_propertyownerspremise"] = new EntityReference("lux_propertyownerspremise", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_anylistedbuildingorbuildingpreservation";
                                refer["lux_suppliedvalue"] = GetOptionSetTextUsingValue("lux_propertyownerspremise", "lux_anylistedbuildingorbuildingpreservation", item.GetAttributeValue<OptionSetValue>("lux_anylistedbuildingorbuildingpreservation").Value, service);
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<OptionSetValue>("lux_anylistedbuildingorbuildingpreservation").Value == 972970001 || item.GetAttributeValue<OptionSetValue>("lux_anylistedbuildingorbuildingpreservation").Value == 972970002 || item.GetAttributeValue<OptionSetValue>("lux_anylistedbuildingorbuildingpreservation").Value == 972970005)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                            else if (item.GetAttributeValue<OptionSetValue>("lux_anylistedbuildingorbuildingpreservation").Value != 972970001 && item.GetAttributeValue<OptionSetValue>("lux_anylistedbuildingorbuildingpreservation").Value != 972970002 && item.GetAttributeValue<OptionSetValue>("lux_anylistedbuildingorbuildingpreservation").Value != 972970005)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                reff["lux_suppliedvalue"] = GetOptionSetTextUsingValue("lux_propertyownerspremise", "lux_anylistedbuildingorbuildingpreservation", item.GetAttributeValue<OptionSetValue>("lux_anylistedbuildingorbuildingpreservation").Value, service);
                                service.Update(reff);
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_anycompositepanelsinconstruction"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownerspremise' operator='eq' uiname='' uitype='lux_propertyownerspremise' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_anycompositepanelsinconstruction' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_anycompositepanelsinconstruction") == true)
                            {
                                var FieldName1 = "Any Composite panels in construction";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_propertyownerspremise"] = new EntityReference("lux_propertyownerspremise", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_anycompositepanelsinconstruction";
                                refer["lux_suppliedvalue"] = "Yes";
                                if (item.Attributes.Contains("lux_compositepanel"))
                                {
                                    refer["lux_additionalinfo"] = "Composite panel %: " + Math.Round(item.GetAttributeValue<decimal>("lux_compositepanel"), 2);
                                }
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_anycompositepanelsinconstruction") == false)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                            else if (item.GetAttributeValue<bool>("lux_anycompositepanelsinconstruction") == true)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (item.Attributes.Contains("lux_compositepanel"))
                                {
                                    reff["lux_additionalinfo"] = "Composite panel %: " + Math.Round(item.GetAttributeValue<decimal>("lux_compositepanel"), 2);
                                    service.Update(reff);
                                }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_isthepropertyinagoodstateofrepair"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownerspremise' operator='eq' uiname='' uitype='lux_propertyownerspremise' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isthepropertyinagoodstateofrepair' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_isthepropertyinagoodstateofrepair") == false)
                            {
                                var FieldName1 = "Is the property in a good state of repair and will remain so for the duration of this insurance";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_propertyownerspremise"] = new EntityReference("lux_propertyownerspremise", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_isthepropertyinagoodstateofrepair";
                                refer["lux_suppliedvalue"] = "No";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_isthepropertyinagoodstateofrepair") == true)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_isthepropertytoundergoamajorrefurbishment"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownerspremise' operator='eq' uiname='' uitype='lux_propertyownerspremise' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isthepropertytoundergoamajorrefurbishment' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_isthepropertytoundergoamajorrefurbishment") == true)
                            {
                                var FieldName1 = "Is the property to undergo a major refurbishment during this period of insurance";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_propertyownerspremise"] = new EntityReference("lux_propertyownerspremise", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_isthepropertytoundergoamajorrefurbishment";
                                if (item.Attributes.Contains("lux_majorrefurbishmentdetails"))
                                {
                                    refer["lux_additionalinfo"] = item.Attributes["lux_majorrefurbishmentdetails"];
                                }
                                refer["lux_suppliedvalue"] = "Yes";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_isthepropertytoundergoamajorrefurbishment") == false)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_plannedbuildingmaintenanceprograminplace"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownerspremise' operator='eq' uiname='' uitype='lux_propertyownerspremise' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_plannedbuildingmaintenanceprograminplace' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_plannedbuildingmaintenanceprograminplace") == false)
                            {
                                var FieldName1 = "Planned building maintenance program in place";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_propertyownerspremise"] = new EntityReference("lux_propertyownerspremise", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_plannedbuildingmaintenanceprograminplace";
                                refer["lux_suppliedvalue"] = "No";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_plannedbuildingmaintenanceprograminplace") == true)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_anybuildingsshowanysignofsubsidence"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownerspremise' operator='eq' uiname='' uitype='lux_propertyownerspremise' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_anybuildingsshowanysignofsubsidence' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_anybuildingsshowanysignofsubsidence") == true)
                            {
                                var FieldName1 = "Do any of the buildings show any sign of Subsidence, movement or cracking?";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_propertyownerspremise"] = new EntityReference("lux_propertyownerspremise", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_anybuildingsshowanysignofsubsidence";
                                if (item.Attributes.Contains("lux_signofsubsidencedetails"))
                                {
                                    refer["lux_additionalinfo"] = item.Attributes["lux_signofsubsidencedetails"];
                                }
                                refer["lux_suppliedvalue"] = "Yes";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_anybuildingsshowanysignofsubsidence") == false)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_hastherebeensubsidenceinthevicinity"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownerspremise' operator='eq' uiname='' uitype='lux_propertyownerspremise' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_hastherebeensubsidenceinthevicinity' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_hastherebeensubsidenceinthevicinity") == true)
                            {
                                var FieldName1 = "Has there been subsidence in the vicinity of any of the premises?";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_propertyownerspremise"] = new EntityReference("lux_propertyownerspremise", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_hastherebeensubsidenceinthevicinity";
                                if (item.Attributes.Contains("lux_subsidencevicinitydetails"))
                                {
                                    refer["lux_additionalinfo"] = item.Attributes["lux_subsidencevicinitydetails"];
                                }
                                refer["lux_suppliedvalue"] = "Yes";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_hastherebeensubsidenceinthevicinity") == false)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_hasthereeverbeenaconsultingengineers"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownerspremise' operator='eq' uiname='' uitype='lux_propertyownerspremise' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_hasthereeverbeenaconsultingengineers' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_hasthereeverbeenaconsultingengineers") == true)
                            {
                                var FieldName1 = "Has there ever been a consulting engineers report for any of the premises?";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_propertyownerspremise"] = new EntityReference("lux_propertyownerspremise", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_hasthereeverbeenaconsultingengineers";
                                if (item.Attributes.Contains("lux_consultingengineersreportdetails"))
                                {
                                    refer["lux_additionalinfo"] = item.Attributes["lux_consultingengineersreportdetails"];
                                }
                                refer["lux_suppliedvalue"] = "Yes";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_hasthereeverbeenaconsultingengineers") == false)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_tenanttype"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownerspremise' operator='eq' uiname='' uitype='lux_propertyownerspremise' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_tenanttype' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.Attributes.Contains("lux_occupancytype") && item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970002)
                            {
                                if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970003 || item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970004 || item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970006 || item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970007 || item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970008 || item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970009 || item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970011 || item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970012)
                                {
                                    var FieldName1 = "Tenant Type in Residential Parts";
                                    Entity refer = new Entity("lux_referral");
                                    refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                    refer["lux_propertyownerspremise"] = new EntityReference("lux_propertyownerspremise", item.Id);
                                    refer["lux_fieldname"] = FieldName1;
                                    refer["lux_fieldschemaname"] = "lux_tenanttype";
                                    refer["lux_suppliedvalue"] = GetOptionSetTextUsingValue("lux_propertyownerspremise", "lux_tenanttype", item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value, service);
                                    service.Create(refer);
                                }
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value != 972970003 && item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value != 972970004 && item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value != 972970006 && item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value != 972970007 && item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value != 972970008 && item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value != 972970009 && item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value != 972970011 && item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value != 972970012)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                            else
                            {
                                if (item.Attributes.Contains("lux_occupancytype") && item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970002)
                                {
                                    if (item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970003 || item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970004 || item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970006 || item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970007 || item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970008 || item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970009 || item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970011 || item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value == 972970012)
                                    {
                                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                        reff["lux_suppliedvalue"] = GetOptionSetTextUsingValue("lux_propertyownerspremise", "lux_tenanttype", item.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value, service);
                                        service.Update(reff);
                                    }
                                }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_buildingconstruction"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownerspremise' operator='eq' uiname='' uitype='lux_propertyownerspremise' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_buildingconstruction' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.Attributes.Contains("lux_buildingconstruction") && item.GetAttributeValue<OptionSetValue>("lux_buildingconstruction").Value == 972970002)
                            {
                                var FieldName1 = "Building construction";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_propertyownerspremise"] = new EntityReference("lux_propertyownerspremise", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_buildingconstruction";
                                refer["lux_suppliedvalue"] = "Non-Standard";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.Attributes.Contains("lux_buildingconstruction") && item.GetAttributeValue<OptionSetValue>("lux_buildingconstruction").Value != 972970002)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_flatroofpercentage"))
                    {
                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownerspremise' operator='eq' uiname='' uitype='lux_propertyownerspremise' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_flatroofpercentage' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (item.GetAttributeValue<bool>("lux_doesthepremiseshaveaflatroof") == true)
                            {
                                var FieldName1 = "Flat roof Percentage";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_propertyownerspremise"] = new EntityReference("lux_propertyownerspremise", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_flatroofpercentage";
                                refer["lux_suppliedvalue"] = item.Attributes.Contains("lux_flatroofpercentage") ? item.Attributes["lux_flatroofpercentage"].ToString() : "0%";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (item.GetAttributeValue<bool>("lux_doesthepremiseshaveaflatroof") == false)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                            else if (item.GetAttributeValue<bool>("lux_doesthepremiseshaveaflatroof") == true)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                reff["lux_suppliedvalue"] = item.Attributes.Contains("lux_flatroofpercentage") ? item.Attributes["lux_flatroofpercentage"].ToString() : "0%";
                                service.Update(reff);
                            }
                        }
                    }
                    if (item.Attributes.Contains("lux_suminsuredwithupliftedamount"))
                    {
                        var totalMDSI = item.GetAttributeValue<Money>("lux_suminsuredwithupliftedamount").Value;
                        var totalBISI = appln.Attributes.Contains("lux_totalbisuminsured") ? appln.GetAttributeValue<Money>("lux_totalbisuminsured").Value : 0;

                        var totalSI = totalMDSI + totalBISI;

                        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownerspremise' operator='eq' uiname='Test Address TE5 5ST' uitype='lux_propertyownerspremise' value='{item.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_suminsuredwithupliftedamount' />
                                    </filter>
                                  </entity>
                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                        {
                            if (totalSI > 2000000)
                            {
                                var FieldName1 = "Total Sum Insured exceeds Authority";
                                Entity refer = new Entity("lux_referral");
                                refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                                refer["lux_propertyownerspremise"] = new EntityReference("lux_propertyownerspremise", item.Id);
                                refer["lux_fieldname"] = FieldName1;
                                refer["lux_fieldschemaname"] = "lux_suminsuredwithupliftedamount";
                                refer["lux_suppliedvalue"] = "£" + Convert.ToInt32(totalSI).ToString();
                                refer["lux_additionalinfo"] = "Refer Risk to HCC for Approval";
                                service.Create(refer);
                            }
                        }
                        else
                        {
                            if (totalSI <= 2000000)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                            }
                            else if (totalSI > 2000000)
                            {
                                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                                reff["lux_suppliedvalue"] = "£" + Convert.ToInt32(totalSI).ToString();
                                reff["lux_additionalinfo"] = "Refer Risk to HCC for Approval";
                                service.Update(reff);
                            }
                        }
                    }
                }
            }
        }

        public string GetOptionSetTextUsingValue(string entityName, string fieldName, int optionSetValue, IOrganizationService service)
        {
            var attReq = new RetrieveAttributeRequest();
            attReq.EntityLogicalName = entityName;
            attReq.LogicalName = fieldName;
            attReq.RetrieveAsIfPublished = true;
            var attResponse = (RetrieveAttributeResponse)service.Execute(attReq);
            var attMetadata = (EnumAttributeMetadata)attResponse.AttributeMetadata;
            return attMetadata.OptionSet.Options.Where(x => x.Value == optionSetValue).FirstOrDefault().Label.UserLocalizedLabel.Label;
        }

        public IDictionary<int, string> GetGlobalOptionSetValues(IOrganizationService service, string optionSetLogicalName)
        {
            IDictionary<int, string> optionSet = new Dictionary<int, string>();
            if (string.IsNullOrEmpty(optionSetLogicalName))
                return null;
            var retrieveAttributeRequest = new RetrieveOptionSetRequest
            {
                Name = optionSetLogicalName
            };
            var retrieveAttributeResponse = (RetrieveOptionSetResponse)service.Execute(retrieveAttributeRequest);
            var retrievedPicklistAttributeMetadata = (OptionSetMetadata)retrieveAttributeResponse.OptionSetMetadata;
            for (int i = 0; i < retrievedPicklistAttributeMetadata.Options.Count(); i++)
            {
                optionSet.Add(new KeyValuePair<int, string>(retrievedPicklistAttributeMetadata.Options[i].Value.Value,
                    retrievedPicklistAttributeMetadata.Options[i].Label.LocalizedLabels[0].Label));
            }
            return optionSet;
        }

        public static string RetrieveAttributeDisplayName(string EntitySchemaName, string AttributeSchemaName, IOrganizationService service)
        {
            RetrieveAttributeRequest retrieveAttributeRequest = new RetrieveAttributeRequest
            {
                EntityLogicalName = EntitySchemaName,
                LogicalName = AttributeSchemaName,
                RetrieveAsIfPublished = true
            };
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            AttributeMetadata retrievedAttributeMetadata = (AttributeMetadata)retrieveAttributeResponse.AttributeMetadata;
            return retrievedAttributeMetadata.DisplayName.UserLocalizedLabel.Label;
        }
    }
}
