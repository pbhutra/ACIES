﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomWorkflows
{
    public class CalculateTradesmanPremium : CodeActivity
    {
        [RequiredArgument]
        [Input("Tradesman Application")]
        [ReferenceTarget("lux_tradesman")]
        public InArgument<EntityReference> TradesmanApplication { get; set; }

        [RequiredArgument]
        [Input("Product")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> Product { get; set; }

        [Input("Broker")]
        [ReferenceTarget("account")]
        public InArgument<EntityReference> Broker { get; set; }

        [RequiredArgument]
        [Input("CAR Rate")]
        [ReferenceTarget("lux_tradesmancarrate")]
        public InArgument<EntityReference> CARRate { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var request = new RetrieveCurrentOrganizationRequest();
            var organzationResponse = (RetrieveCurrentOrganizationResponse)service.Execute(request);
            var uriString = organzationResponse.Detail.UrlName;

            EntityReference applnref = TradesmanApplication.Get<EntityReference>(executionContext);
            Entity appln = new Entity(applnref.LogicalName, applnref.Id);
            appln = service.Retrieve("lux_tradesman", applnref.Id, new ColumnSet(true));

            var inceptionDate = Convert.ToDateTime(appln.FormattedValues["lux_inceptiondate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
            var quotationDate = appln.Attributes.Contains("lux_quotationdate") ? appln.GetAttributeValue<DateTime>("lux_quotationdate") : DateTime.UtcNow;
            var ApplicationType = appln.Attributes.Contains("lux_applicationtype") ? appln.FormattedValues["lux_applicationtype"].ToString() : "";

            var NoOfEmployess = appln.GetAttributeValue<int>("lux_noofemployees");
            if (NoOfEmployess > 9)
            {
                NoOfEmployess = 9;
            }
            var Turnover = appln.GetAttributeValue<Money>("lux_totalestimatedturnover").Value;
            var RatingGroup = appln.GetAttributeValue<OptionSetValue>("lux_ratinggroup").Value;
            var PLLimitofIndemnity = appln.GetAttributeValue<OptionSetValue>("lux_pllimitofindemnity").Value;

            var ELCover = appln.Attributes.Contains("lux_employersliability") ? appln.GetAttributeValue<bool>("lux_employersliability") : false;

            var ELfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                          <entity name='lux_tradesmanrating'>
                            <attribute name='lux_tradesmanratingid' />
                            <attribute name='lux_name' />
                            <attribute name='createdon' />
                            <attribute name='lux_ratinggroup' />
                            <attribute name='lux_plloi' />
                            <attribute name='lux_perman' />
                            <attribute name='lux_hccplpremium' />
                            <attribute name='lux_hcconlinepremium' />
                            <attribute name='lux_hccelpremium' />
                            <attribute name='lux_turnover' />
                            <attribute name='lux_turnoverfrom' />
                            <attribute name='lux_turnoverto' />
                            <attribute name='lux_noofemployess' />
                            <order attribute='lux_turnover' descending='true' />
                            <filter type='and'>
                              <condition attribute='lux_ratinggroup' operator='eq' value='{RatingGroup.ToString()}' />
                              <condition attribute='lux_noofemployess' operator='eq' value='{NoOfEmployess.ToString()}' />
                              <condition attribute='lux_plloi' operator='eq' value='{PLLimitofIndemnity.ToString()}' />
                            </filter>
                          </entity>
                        </fetch>";

            var PLfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                          <entity name='lux_tradesmanrating'>
                            <attribute name='lux_tradesmanratingid' />
                            <attribute name='lux_name' />
                            <attribute name='createdon' />
                            <attribute name='lux_ratinggroup' />
                            <attribute name='lux_plloi' />
                            <attribute name='lux_perman' />
                            <attribute name='lux_hccplpremium' />
                            <attribute name='lux_hcconlinepremium' />
                            <attribute name='lux_hccelpremium' />
                            <attribute name='lux_turnover' />
                            <attribute name='lux_turnoverfrom' />
                            <attribute name='lux_turnoverto' />
                            <attribute name='lux_noofemployess' />
                            <order attribute='lux_turnover' descending='true' />
                            <filter type='and'>
                              <filter type='or'>
                                <filter type='and'>
                                  <condition attribute='lux_turnoverfrom' operator='le' value='{Turnover}' />
                                  <condition attribute='lux_turnoverto' operator='ge' value='{Turnover}' />
                                </filter>
                                <filter type='and'>
                                  <condition attribute='lux_turnoverfrom' operator='le' value='{Turnover}' />
                                  <condition attribute='lux_turnoverto' operator='null' />
                                </filter>
                              </filter>
                              <condition attribute='lux_ratinggroup' operator='eq' value='{RatingGroup.ToString()}' />
                              <condition attribute='lux_plloi' operator='eq' value='{PLLimitofIndemnity.ToString()}' />
                            </filter>
                          </entity>
                        </fetch>";

            var CARfetch = "";
            if (CARRate.Get(executionContext) != null)
            {
                CARfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_tradesmancarrate'>
                                <attribute name='lux_tradesmancarrateid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_premium' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_tradesmancarrateid' operator='eq' uiname='Option A' uitype='lux_tradesmancarrate' value='{CARRate.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";
            }

            var LEfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_aragrate'>
                                <attribute name='createdon' />
                                <attribute name='lux_product' />
                                <attribute name='lux_netrate' />
                                <attribute name='lux_grossrate' />                                
                                <attribute name='lux_turnoverfrom' />
                                <attribute name='lux_turnoverto' />
                                <attribute name='lux_aragrateid' />
                                <order attribute='createdon' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_product' operator='eq' uiname='' uitype='product' value='{this.Product.Get(executionContext).Id}' />
                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                  <filter type='or'>
                                      <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                      <condition attribute='lux_enddate' operator='null' />
                                  </filter>
                                </filter>
                              </entity>
                            </fetch>";


            decimal ELPremium = 0;
            decimal PLPremium = 0;
            decimal CARPremium = 0;
            decimal LEGrossPremium = 0;
            decimal LENetPremium = 0;
            decimal Fee = 0;
            decimal BrokerComm = 25;
            decimal aciesComm = 5;
            decimal TotalPremium = 0;

            if (service.RetrieveMultiple(new FetchExpression(ELfetch)).Entities.Count > 0)
            {
                if (ELCover == true)
                {
                    var TradesManRatingsEntity = service.RetrieveMultiple(new FetchExpression(ELfetch)).Entities[0];
                    ELPremium = TradesManRatingsEntity.GetAttributeValue<Money>("lux_hccelpremium").Value;
                    if (inceptionDate >= new DateTime(2023, 11, 01))
                    {
                        ELPremium = 1.1M * ELPremium;
                    }

                    if (quotationDate >= new DateTime(2025, 01, 01))
                    {
                        if (ApplicationType == "New Business")
                        {
                            ELPremium = 1.06M * ELPremium;
                        }
                        else if (ApplicationType == "MTA" || ApplicationType == "Cancellation")
                        {
                            if (appln.Attributes.Contains("lux_policy"))
                            {
                                var Policy = service.Retrieve("lux_policy", appln.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                {
                                    ELPremium = 1.06M * ELPremium;
                                }
                            }
                        }
                    }
                }
                else
                {
                    ELPremium = 0;
                }
            }

            if (service.RetrieveMultiple(new FetchExpression(PLfetch)).Entities.Count > 0)
            {
                var TradesManRatingsEntity = service.RetrieveMultiple(new FetchExpression(PLfetch)).Entities[0];
                PLPremium = TradesManRatingsEntity.GetAttributeValue<Money>("lux_hccplpremium").Value;
                if (inceptionDate >= new DateTime(2023, 11, 01))
                {
                    PLPremium = 1.1M * PLPremium;
                }

                if (quotationDate >= new DateTime(2025, 01, 01))
                {
                    if (ApplicationType == "New Business")
                    {
                        PLPremium = 1.05M * PLPremium;
                    }
                    else if (ApplicationType == "MTA" || ApplicationType == "Cancellation")
                    {
                        if (appln.Attributes.Contains("lux_policy"))
                        {
                            var Policy = service.Retrieve("lux_policy", appln.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                            if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                            {
                                PLPremium = 1.05M * PLPremium;
                            }
                        }
                    }
                }
            }

            if (CARRate.Get(executionContext) != null)
            {
                if (service.RetrieveMultiple(new FetchExpression(CARfetch)).Entities.Count > 0)
                {
                    var TradesManRatingsEntity = service.RetrieveMultiple(new FetchExpression(CARfetch)).Entities[0];
                    CARPremium = TradesManRatingsEntity.GetAttributeValue<Money>("lux_premium").Value;
                }
            }

            if (service.RetrieveMultiple(new FetchExpression(LEfetch)).Entities.Count > 0)
            {
                var Rates = service.RetrieveMultiple(new FetchExpression(LEfetch)).Entities[0];
                LEGrossPremium = Rates.GetAttributeValue<Money>("lux_grossrate").Value;
                LENetPremium = Rates.GetAttributeValue<Money>("lux_netrate").Value;
            }

            TotalPremium = ELPremium + PLPremium + CARPremium;

            var FeeFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='lux_adminfeerule'>
                                        <attribute name='lux_to' />
                                        <attribute name='lux_from' />
                                        <attribute name='lux_fee' />
                                        <attribute name='lux_adminfeeruleid' />
                                        <order attribute='lux_to' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='statecode' operator='eq' value='0' />
                                          <condition attribute='lux_from' operator='le' value='{TotalPremium}' />
                                          <filter type='or'>
                                            <condition attribute='lux_to' operator='ge' value='{TotalPremium}' />
                                            <condition attribute='lux_to' operator='null' />
                                          </filter>
                                        </filter>
                                      </entity>
                                    </fetch>";
            if (service.RetrieveMultiple(new FetchExpression(FeeFetch)).Entities.Count > 0)
            {
                Fee = service.RetrieveMultiple(new FetchExpression(FeeFetch)).Entities[0].GetAttributeValue<Money>("lux_fee").Value;
            }

            var BrokerFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_brokercommission'>
                                            <attribute name='createdon' />
                                            <attribute name='lux_product' />
                                            <attribute name='lux_commission' />
                                            <attribute name='lux_brokercommissionid' />
                                            <order attribute='createdon' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <filter type='or'>
                                                <condition attribute='lux_effectivefrom' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", inceptionDate)}' />
                                                <condition attribute='lux_effectivefrom' operator='null' />
                                              </filter>
                                              <filter type='or'>
                                                <condition attribute='lux_effectiveto' operator='on-or-after' value= '{String.Format("{0:MM/dd/yyyy}", inceptionDate)}' />
                                                <condition attribute='lux_effectiveto' operator='null' />
                                              </filter>
                                              <condition attribute='lux_broker' operator='eq' uiname='' uitype='account' value='{Broker.Get(executionContext).Id}' />
                                              <condition attribute='lux_product' operator='eq' uiname='' uitype='product' value='{Product.Get(executionContext).Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";
            if (service.RetrieveMultiple(new FetchExpression(BrokerFetch)).Entities.Count > 0)
            {
                var BrokerCommission = service.RetrieveMultiple(new FetchExpression(BrokerFetch)).Entities[0];
                BrokerComm = BrokerCommission.GetAttributeValue<decimal>("lux_commission");

                if (BrokerCommission.Attributes.Contains("lux_renewalcommission"))
                {
                    if (ApplicationType == "Renewal")
                    {
                        BrokerComm = BrokerCommission.GetAttributeValue<decimal>("lux_renewalcommission");
                    }
                    else if (ApplicationType == "MTA" || ApplicationType == "Cancellation")
                    {
                        if (appln.Attributes.Contains("lux_policy"))
                        {
                            var Policy = service.Retrieve("lux_policy", appln.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                            if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
                            {
                                BrokerComm = BrokerCommission.GetAttributeValue<decimal>("lux_renewalcommission");
                            }
                        }
                    }
                }

                aciesComm = 30 - BrokerComm;
            }

            Entity trade = new Entity(applnref.LogicalName, applnref.Id);

            trade["lux_elpremium"] = new Money(ELPremium);
            trade["lux_plpremium"] = new Money(PLPremium);
            trade["lux_carpremium"] = new Money(CARPremium);
            trade["lux_legalexpensestechnicalgrosspremium"] = new Money(LEGrossPremium);
            trade["lux_legalexpensestechnicalnetpremium"] = new Money(LENetPremium);
            trade["lux_technicalpremiumbeforeipt"] = new Money(TotalPremium + LEGrossPremium);

            trade["lux_technicalbrokercommission"] = Convert.ToDouble(BrokerComm) + "%";
            trade["lux_technicalaciescommission"] = Convert.ToDouble(aciesComm) + "%";
            trade["lux_technicaltotalcommission"] = Convert.ToDouble(BrokerComm) + Convert.ToDouble(aciesComm) + "%";

            if (!appln.Attributes.Contains("lux_technicalnetpremium"))
            {
                trade["lux_policybrokercommission"] = Convert.ToDouble(BrokerComm) + "%";
                trade["lux_policyaciescommission"] = Convert.ToDouble(aciesComm) + "%";
                trade["lux_policytotalcommission"] = Convert.ToDouble(BrokerComm) + Convert.ToDouble(aciesComm) + "%";
            }

            var LEBrokerComm = LEGrossPremium * BrokerComm / 100;
            var LeGrossComm = LEGrossPremium - LENetPremium - LEBrokerComm;

            trade["lux_technicalbrokercommissionamount"] = new Money(TotalPremium * BrokerComm / 100 + LEBrokerComm);
            trade["lux_technicalaciescommissionamount"] = new Money(TotalPremium * aciesComm / 100);

            trade["lux_technicalacieslegalexpensecommissionamoun"] = new Money(LeGrossComm);

            trade["lux_technicalnetpremium"] = new Money(TotalPremium + LENetPremium - TotalPremium * BrokerComm / 100 - TotalPremium * aciesComm / 100);
            trade["lux_technicalpolicyfee"] = new Money(Fee);

            //if (uriString.ToLower().Contains("uat"))
            //{
            var SizeDiscountFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_sizediscount'>
                                            <attribute name='lux_effectiveto' />
                                            <attribute name='lux_effectivefrom' />
                                            <attribute name='lux_below500k' />
                                            <attribute name='lux_above5m' />
                                            <attribute name='lux_501k1m' />
                                            <attribute name='lux_20000015m' />
                                            <attribute name='lux_10000012m' />
                                            <order attribute='createdon' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <filter type='or'>
                                                <condition attribute='lux_effectivefrom' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                <condition attribute='lux_effectivefrom' operator='null' />
                                              </filter>
                                              <filter type='or'>
                                                <condition attribute='lux_effectiveto' operator='on-or-after' value= '{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                <condition attribute='lux_effectiveto' operator='null' />
                                              </filter>
                                              <condition attribute='lux_section' operator='eq' value='972970001' />
                                              <condition attribute='lux_product' operator='eq' uiname='' uitype='product' value='{this.Product.Get(executionContext).Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";

            tracingService.Trace(SizeDiscountFetch);

            if (service.RetrieveMultiple(new FetchExpression(SizeDiscountFetch)).Entities.Count > 0)
            {
                var SI_data = service.RetrieveMultiple(new FetchExpression(SizeDiscountFetch)).Entities;
                var SI_field = "";
                if (Turnover <= 500000)
                {
                    SI_field = "lux_below500k";
                }
                else if (Turnover > 500000 && Turnover <= 1000000)
                {
                    SI_field = "lux_501k1m";
                }
                else if (Turnover > 1000000 && Turnover <= 2000000)
                {
                    SI_field = "lux_10000012m";
                }
                else if (Turnover > 2000000 && Turnover <= 5000000)
                {
                    SI_field = "lux_20000015m";
                }
                else if (Turnover > 5000000)
                {
                    SI_field = "lux_above5m";
                }
                var discount = SI_data.FirstOrDefault().Attributes.Contains(SI_field) ? SI_data.FirstOrDefault().GetAttributeValue<decimal>(SI_field) : 0;

                trade["lux_carsizediscounts"] = discount.ToString("#.##") + "%";
                if (discount.ToString("#.##") == "")
                {
                    trade["lux_carsizediscounts"] = "0%";
                }
            }
            //}
            service.Update(trade);
        }
    }
}
