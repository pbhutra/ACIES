﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CustomWorkflows
{
    public class SetRiskPremiseNumbers : CodeActivity
    {
        #region "Parameter Definition"

        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Input("Commercial Combined")]
        [ReferenceTarget("lux_commercialcombinedapplication")]
        public InArgument<EntityReference> CommercialCombined { get; set; }

        [Input("Pubs")]
        [ReferenceTarget("lux_pubsrestaurantspropertyownersapplicatio")]
        public InArgument<EntityReference> Pubs { get; set; }

        [Input("Contractors Combined")]
        [ReferenceTarget("lux_contractorscombined")]
        public InArgument<EntityReference> ContractorsCombined { get; set; }

        [Input("Product")]
        public InArgument<string> Product { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference appref = PropertyOwnersApplication.Get<EntityReference>(executionContext);
            Entity application = service.Retrieve("lux_propertyownersapplications", appref.Id, new ColumnSet(true));
            var applicationType = application.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value;

            if (Product.Get(executionContext).ToString() == "Property Owners" || Product.Get(executionContext).ToString() == "Unoccupied")
            {
                var propertyownersFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_propertyownerspremise'>
                                            <attribute name='lux_riskpostcode' />
                                            <attribute name='lux_riskaddress' />
                                            <attribute name='lux_locationnumber' />
                                            <attribute name='lux_propertyownerspremiseid' />
                                            <order attribute='createdon' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{application.Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                var propertyowners = service.RetrieveMultiple(new FetchExpression(propertyownersFetch)).Entities;
                if (propertyowners.Count > 0)
                {
                    int premiseCount = 1;
                    foreach (var item in propertyowners)
                    {
                        Entity property = service.Retrieve("lux_propertyownerspremise", item.Id, new ColumnSet("lux_locationnumber"));
                        property["lux_locationnumber"] = premiseCount;
                        if (applicationType != 972970002)
                        {
                            property["lux_isnewmtapremise"] = false;
                        }
                        service.Update(property);
                        premiseCount++;
                    }
                }
            }
            else if (Product.Get(executionContext).ToString() == "Retail")
            {
                var propertyownersFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_propertyownersretail'>
                                            <attribute name='lux_riskpostcode' />
                                            <attribute name='lux_riskaddress' />
                                            <attribute name='lux_locationnumber' />
                                            <attribute name='lux_propertyownersretailid' />
                                            <order attribute='createdon' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{application.Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                var propertyowners = service.RetrieveMultiple(new FetchExpression(propertyownersFetch)).Entities;
                if (propertyowners.Count > 0)
                {
                    int premiseCount = 1;
                    foreach (var item in propertyowners)
                    {
                        Entity property = service.Retrieve("lux_propertyownersretail", item.Id, new ColumnSet("lux_locationnumber"));
                        property["lux_locationnumber"] = premiseCount;
                        if (applicationType != 972970002)
                        {
                            property["lux_isnewmtapremise"] = false;
                        }
                        service.Update(property);
                        premiseCount++;
                    }
                }
            }
            else if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
            {
                var propertyownersFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_commercialcombinedapplication'>
                                                <attribute name='lux_commercialcombinedapplicationid' />
                                                <attribute name='lux_name' />
                                                <attribute name='lux_locationnumber' />
                                                <attribute name='createdon' />
                                                <order attribute='createdon' descending='true' />
                                                <filter type='and'>
                                                  <condition attribute='lux_locationnumber' operator='not-null' />
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{application.Id}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                var propertyowners = service.RetrieveMultiple(new FetchExpression(propertyownersFetch)).Entities;
                if (propertyowners.Count > 0)
                {
                    var item = service.RetrieveMultiple(new FetchExpression(propertyownersFetch)).Entities[0];
                    int premiseCount = item.GetAttributeValue<int>("lux_locationnumber");
                    Entity property = service.Retrieve("lux_commercialcombinedapplication", CommercialCombined.Get(executionContext).Id, new ColumnSet("lux_locationnumber"));
                    property["lux_locationnumber"] = premiseCount + 1;
                    if (applicationType != 972970002)
                    {
                        property["lux_isnewmtapremise"] = false;
                    }
                    service.Update(property);
                }
                else
                {
                    Entity property = service.Retrieve("lux_commercialcombinedapplication", CommercialCombined.Get(executionContext).Id, new ColumnSet("lux_locationnumber"));
                    property["lux_locationnumber"] = 1;
                    service.Update(property);
                }
            }
            else if (Product.Get(executionContext).ToString() == "Pubs & Restaurants" || Product.Get(executionContext).ToString() == "Hotels and Guesthouses")
            {
                var propertyownersFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_pubsrestaurantspropertyownersapplicatio'>
                                                <attribute name='lux_name' />
                                                <attribute name='createdon' />
                                                <attribute name='lux_locationnumber' />
                                                <attribute name='lux_pubsrestaurantspropertyownersapplicatioid' />
                                                <order attribute='createdon' descending='true' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_locationnumber' operator='not-null' />
                                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{application.Id}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                var propertyowners = service.RetrieveMultiple(new FetchExpression(propertyownersFetch)).Entities;
                if (propertyowners.Count > 0)
                {
                    var item = service.RetrieveMultiple(new FetchExpression(propertyownersFetch)).Entities[0];
                    int premiseCount = item.GetAttributeValue<int>("lux_locationnumber");
                    Entity property = service.Retrieve("lux_pubsrestaurantspropertyownersapplicatio", Pubs.Get(executionContext).Id, new ColumnSet("lux_locationnumber"));
                    property["lux_locationnumber"] = premiseCount + 1;
                    if (applicationType != 972970002)
                    {
                        property["lux_isnewmtapremise"] = false;
                    }
                    service.Update(property);
                }
                else
                {
                    Entity property = service.Retrieve("lux_pubsrestaurantspropertyownersapplicatio", Pubs.Get(executionContext).Id, new ColumnSet("lux_locationnumber"));
                    property["lux_locationnumber"] = 1;
                    service.Update(property);
                }
            }
            else if (Product.Get(executionContext).ToString() == "Contractors Combined")
            {
                var propertyownersFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_contractorscombined'>
                                                <attribute name='lux_contractorscombinedid' />
                                                <attribute name='lux_name' />
                                                <attribute name='lux_locationnumber' />
                                                <attribute name='createdon' />
                                                <order attribute='createdon' descending='true' />
                                                <filter type='and'>
                                                  <condition attribute='lux_locationnumber' operator='not-null' />
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{application.Id}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                var propertyowners = service.RetrieveMultiple(new FetchExpression(propertyownersFetch)).Entities;
                if (propertyowners.Count > 0)
                {
                    var item = service.RetrieveMultiple(new FetchExpression(propertyownersFetch)).Entities[0];
                    int premiseCount = item.GetAttributeValue<int>("lux_locationnumber");
                    Entity property = service.Retrieve("lux_contractorscombined", ContractorsCombined.Get(executionContext).Id, new ColumnSet("lux_locationnumber"));
                    property["lux_locationnumber"] = premiseCount + 1;
                    service.Update(property);
                }
                else
                {
                    Entity property = service.Retrieve("lux_contractorscombined", ContractorsCombined.Get(executionContext).Id, new ColumnSet("lux_locationnumber"));
                    property["lux_locationnumber"] = 1;
                    service.Update(property);
                }
            }
        }
    }
}

