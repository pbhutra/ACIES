﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System.Activities;
using System.Net.Http;
using System.Threading.Tasks;
using System;
using System.Net.Http.Headers;
using System.Linq;

namespace CustomWorkflows
{
    public class CalculatePremiumConstruction : CodeActivity
    {
        [Input("Construction Quote")]
        [ReferenceTarget("lux_constructionquotes")]
        public InArgument<EntityReference> ConstructionQuote { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference constructionQuoteref = ConstructionQuote.Get<EntityReference>(executionContext);
            Entity constructionQuote = new Entity(constructionQuoteref.LogicalName, constructionQuoteref.Id);
            constructionQuote = service.Retrieve("lux_constructionquotes", constructionQuoteref.Id, new ColumnSet(true));
            var InceptionDate = constructionQuote.Attributes.Contains("lux_inceptiondate") ? constructionQuote.GetAttributeValue<DateTime>("lux_inceptiondate") : DateTime.UtcNow;
            var ExpiryDate = constructionQuote.Attributes.Contains("lux_expirydate") ? constructionQuote.GetAttributeValue<DateTime>("lux_expirydate") : DateTime.UtcNow;

            var dateDiffDays = (ExpiryDate - InceptionDate).Days;
            if (dateDiffDays == 364 || dateDiffDays == 365 || dateDiffDays == 366)
            {
                dateDiffDays = 365;
            }

            var ApplicationType = constructionQuote.Attributes.Contains("lux_applicationtype") ? constructionQuote.FormattedValues["lux_applicationtype"] : "";
            var PolicyType = constructionQuote.Attributes.Contains("lux_typeofpolicy2") ? constructionQuote.FormattedValues["lux_typeofpolicy2"] : "";
            var SingleContractDuration = constructionQuote.Attributes.Contains("lux_maintenancedurationmonths") ? constructionQuote.Attributes["lux_maintenancedurationmonths"].ToString().Replace("Months", "").Replace("months", "") : "";
            var AnnualContractDuration = constructionQuote.Attributes.Contains("lux_maximumcontractperiod") ? constructionQuote.FormattedValues["lux_maximumcontractperiod"].ToString().Replace("Months", "").Replace("months", "") : "";
            var TotalOwnPlantValue = constructionQuote.Attributes.Contains("lux_totalownplantvalue") ? constructionQuote.GetAttributeValue<Money>("lux_totalownplantvalue").Value : 0;
            var DSUSI = constructionQuote.GetAttributeValue<bool>("lux_dilayinstartupcoverrequired") == true ? constructionQuote.Attributes.Contains("lux_totaltsi") ? constructionQuote.GetAttributeValue<Money>("lux_totaltsi").Value : 0M : 0M;
            var DSUMonths = constructionQuote.GetAttributeValue<bool>("lux_dilayinstartupcoverrequired") == true ? constructionQuote.Attributes.Contains("lux_baseindemnityperiodinmonths") ? constructionQuote.FormattedValues["lux_baseindemnityperiodinmonths"].ToString().Replace("Months", "").Replace("months", "") : "" : "";
            var OtherItemsSI = constructionQuote.Attributes.Contains("lux_otheritems") ? constructionQuote.GetAttributeValue<Money>("lux_otheritems").Value : 0;
            var TempBuildingSI = constructionQuote.Attributes.Contains("lux_temporarybuildingssuminsured") ? constructionQuote.GetAttributeValue<Money>("lux_temporarybuildingssuminsured").Value : 0;
            var EmployeeToolsSI = constructionQuote.Attributes.Contains("lux_employeestoolstotalvalue") ? constructionQuote.GetAttributeValue<Money>("lux_employeestoolstotalvalue").Value : 0;
            var EmployeeToolsAnyOneEmp = constructionQuote.Attributes.Contains("lux_employeetoolsanyoneemployee") ? constructionQuote.GetAttributeValue<Money>("lux_employeetoolsanyoneemployee").Value : 0;
            var HiredinPlant = constructionQuote.Attributes.Contains("lux_annualhiringcharges") ? constructionQuote.GetAttributeValue<Money>("lux_annualhiringcharges").Value : 0;
            var OwnPlantValue = constructionQuote.Attributes.Contains("lux_totalownplantvalue") ? constructionQuote.GetAttributeValue<Money>("lux_totalownplantvalue").Value : 0;
            var BoundShare = constructionQuote.Attributes.Contains("lux_phoenixsharebound") ? constructionQuote.GetAttributeValue<decimal>("lux_phoenixsharebound") : 0;

            var Ratingfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_constructiontechnicalpremiumcalculation'>
                                <attribute name='lux_name' />
                                <attribute name='lux_ratingbasis' />
                                <attribute name='lux_rate' />
                                <attribute name='lux_constructionquote' />
                                <attribute name='lux_ratingfigures' />
                                <attribute name='lux_technicalpremiumcalculation' />
                                <attribute name='transactioncurrencyid' />
                                <attribute name='lux_constructiontechnicalpremiumcalculationid' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_constructionquote' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            var BaseRatefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_constructionbaserate'>
                                                        <attribute name='lux_ratingfield' />
                                                        <attribute name='lux_from' />
                                                        <attribute name='lux_to' />
                                                        <attribute name='lux_rate' />
                                                        <attribute name='lux_refer' />
                                                        <attribute name='lux_effectivefromdate' />
                                                        <attribute name='lux_validuntildate' />
                                                        <attribute name='lux_constructionbaserateid' />
                                                        <order attribute='lux_ratingfield' descending='false' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='lux_effectivefromdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", InceptionDate)}' />
                                                          <filter type='or'>
                                                             <condition attribute='lux_validuntildate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", InceptionDate)}' />
                                                             <condition attribute='lux_validuntildate' operator='null' />
                                                          </filter>
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

            var RatingMultiplierfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                      <entity name='lux_constructionratingmultiplier'>
                                                        <attribute name='lux_ratingfield' />
                                                        <attribute name='lux_from' />
                                                        <attribute name='lux_to' />
                                                        <attribute name='lux_ratingmultiplier' />
                                                        <attribute name='lux_refer' />
                                                        <attribute name='lux_effectivefromdate' />
                                                        <attribute name='lux_validuntildate' />
                                                        <attribute name='lux_constructionratingmultiplierid' />
                                                        <order attribute='lux_ratingfield' descending='false' />
                                                        <filter type='and'>
                                                          <condition attribute='statecode' operator='eq' value='0' />
                                                          <condition attribute='lux_effectivefromdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", InceptionDate)}' />
                                                          <filter type='or'>
                                                             <condition attribute='lux_validuntildate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", InceptionDate)}' />
                                                             <condition attribute='lux_validuntildate' operator='null' />
                                                          </filter>
                                                        </filter>
                                                      </entity>
                                                    </fetch>";

            var RateItem = service.RetrieveMultiple(new FetchExpression(Ratingfetch)).Entities;
            var BaseRateItem = service.RetrieveMultiple(new FetchExpression(BaseRatefetch)).Entities;
            var RatingMultiplierItem = service.RetrieveMultiple(new FetchExpression(RatingMultiplierfetch)).Entities;

            var EstimatedContractValue = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970001);
            var ContractingTurnover = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970002);
            var ExistingProperty = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970003);
            var ContractorsPlantEquipment = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970004);
            var HiredinPlantCharges = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970005);
            var Employeestoolsvalue = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970006);
            var TemporaryBuildings = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970007);
            var OtherItems = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970008);
            var DSU = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970009);
            var ThirdPartyLiability = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970010);
            var NonNegLiability = RateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_technicalpremiumcalculation").Value == 972970011);

            if (PolicyType == "CAR single project - CR")
            {
                var referralFlag = false;
                var declineFlag = false;
                var CompositeRate = constructionQuote.Attributes.Contains("lux_overallcompositerate") ? constructionQuote.GetAttributeValue<decimal>("lux_overallcompositerate") : 0M;

                var ContractValue = new Money(constructionQuote.Attributes.Contains("lux_estimatedcontractvalue") ? constructionQuote.GetAttributeValue<Money>("lux_estimatedcontractvalue").Value : 0);
                Entity estimatedContractValue = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (EstimatedContractValue != null)
                {
                    estimatedContractValue = service.Retrieve("lux_constructiontechnicalpremiumcalculation", EstimatedContractValue.Id, new ColumnSet(true));
                }
                estimatedContractValue.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970001);
                estimatedContractValue.Attributes["lux_name"] = "Estimated Contract Value";
                estimatedContractValue.Attributes["lux_ratingbasis"] = "on Estimated Contract Value";

                estimatedContractValue.Attributes["lux_ratingfigures"] = ContractValue;
                estimatedContractValue.Attributes["lux_rate"] = CompositeRate;
                estimatedContractValue.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                estimatedContractValue.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);
                //if (!estimatedContractValue.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if(ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    estimatedContractValue.Attributes["lux_grosspolicypremiumquoted"] = new Money(estimatedContractValue.GetAttributeValue<Money>("lux_ratingfigures").Value * Math.Round(estimatedContractValue.GetAttributeValue<decimal>("lux_rate"), 3) / 100);
                    estimatedContractValue.Attributes["lux_grosspolicypremiumbound"] = new Money(estimatedContractValue.GetAttributeValue<Money>("lux_ratingfigures").Value * (Math.Round(estimatedContractValue.GetAttributeValue<decimal>("lux_rate"), 3) / 100) * BoundShare / 100);
                }

                if (EstimatedContractValue != null)
                {
                    service.Update(estimatedContractValue);
                }
                else
                {
                    service.Create(estimatedContractValue);
                }



                if (ContractingTurnover != null)
                {
                    service.Delete("lux_constructiontechnicalpremiumcalculation", ContractingTurnover.Id);
                }



                Entity existingProperty = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (ExistingProperty != null)
                {
                    existingProperty = service.Retrieve("lux_constructiontechnicalpremiumcalculation", ExistingProperty.Id, new ColumnSet(true));
                }
                existingProperty.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970003);
                existingProperty.Attributes["lux_name"] = "Existing Property (if covered on Full Value/All Risks basis)";
                existingProperty.Attributes["lux_ratingbasis"] = "on Total Sum Insured";

                var AnnualExistingStructure = 0M;
                if (constructionQuote.Attributes.Contains("lux_existingstructure") && constructionQuote.GetAttributeValue<bool>("lux_existingstructure") == true)
                {
                    if (constructionQuote.Attributes.Contains("lux_existingstructures") && constructionQuote.GetAttributeValue<OptionSetValue>("lux_existingstructures").Value == 972970001)//Sublimit
                    {
                        AnnualExistingStructure = constructionQuote.Attributes.Contains("lux_sublimit") ? constructionQuote.GetAttributeValue<Money>("lux_sublimit").Value : 0M;
                    }
                    else if (constructionQuote.Attributes.Contains("lux_existingstructures") && constructionQuote.GetAttributeValue<OptionSetValue>("lux_existingstructures").Value == 972970002)//Full Cover
                    {
                        AnnualExistingStructure = constructionQuote.Attributes.Contains("lux_existingstructuretsi") ? constructionQuote.GetAttributeValue<Money>("lux_existingstructuretsi").Value : 0M;
                    }
                }

                existingProperty.Attributes["lux_ratingfigures"] = new Money(AnnualExistingStructure);

                var EPbaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970003 && ((Convert.ToDecimal(x.Attributes["lux_from"].ToString().Replace(",", "")) <= Convert.ToDecimal(SingleContractDuration) && Convert.ToDecimal((x.Attributes.Contains("lux_to") ? x.Attributes["lux_to"].ToString().Replace(",", "") : "0")) >= Convert.ToDecimal(SingleContractDuration)) || (Convert.ToDecimal(x.Attributes["lux_from"].ToString().Replace(",", "")) <= Convert.ToDecimal(SingleContractDuration) && !x.Attributes.Contains("lux_to"))));
                if (EPbaseRate != null)
                {
                    existingProperty.Attributes["lux_rate"] = EPbaseRate.GetAttributeValue<decimal>("lux_rate");

                    var existingPropertystatus = EPbaseRate.FormattedValues["lux_refer"].ToString();
                    if (existingPropertystatus == "Refer" || existingPropertystatus == "Decline")
                    {
                        referralFlag = true;
                        var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_existingProperty' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                        var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                        if (RateList.Entities.Count == 0)
                        {
                            Entity referral = new Entity("lux_constructionreferral");
                            referral["lux_fieldname"] = "Existing Property Base Rate Referral";
                            referral["lux_suppliedvalue"] = EPbaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_existingProperty";
                            if (existingPropertystatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Create(referral);
                        }
                        else
                        {
                            Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                            referral["lux_fieldname"] = "Existing Property Base Rate Referral";
                            referral["lux_suppliedvalue"] = EPbaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_existingProperty";
                            if (existingPropertystatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Update(referral);
                        }
                    }
                }
                else
                {
                    existingProperty.Attributes["lux_rate"] = 0M;
                }

                existingProperty.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                existingProperty.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!existingProperty.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    existingProperty.Attributes["lux_grosspolicypremiumquoted"] = new Money(existingProperty.GetAttributeValue<Money>("lux_ratingfigures").Value * existingProperty.GetAttributeValue<decimal>("lux_rate") / 100);
                    existingProperty.Attributes["lux_grosspolicypremiumbound"] = new Money(existingProperty.GetAttributeValue<Money>("lux_ratingfigures").Value * (existingProperty.GetAttributeValue<decimal>("lux_rate") / 100) * BoundShare / 100);
                }

                if (ExistingProperty != null)
                {
                    service.Update(existingProperty);
                }
                else
                {
                    service.Create(existingProperty);
                }



                Entity contractorsPlantEquipment = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (ContractorsPlantEquipment != null)
                {
                    contractorsPlantEquipment = service.Retrieve("lux_constructiontechnicalpremiumcalculation", ContractorsPlantEquipment.Id, new ColumnSet(true));
                }
                contractorsPlantEquipment.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970004);
                contractorsPlantEquipment.Attributes["lux_name"] = "Contractors Plant & Equipment Value";
                contractorsPlantEquipment.Attributes["lux_ratingbasis"] = "on current market value";

                contractorsPlantEquipment.Attributes["lux_ratingfigures"] = new Money(OwnPlantValue);

                var CPEBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970005);
                if (CPEBaseRate != null)
                {
                    contractorsPlantEquipment.Attributes["lux_rate"] = CPEBaseRate.GetAttributeValue<decimal>("lux_rate");

                    var cpestatus = CPEBaseRate.FormattedValues["lux_refer"].ToString();
                    if (cpestatus == "Refer" || cpestatus == "Decline")
                    {
                        referralFlag = true;
                        var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_cpe' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                        var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                        if (RateList.Entities.Count == 0)
                        {
                            Entity referral = new Entity("lux_constructionreferral");
                            referral["lux_fieldname"] = "Contractors Plant & Equipment Base Rate Referral";
                            referral["lux_suppliedvalue"] = CPEBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_cpe";
                            if (cpestatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Create(referral);
                        }
                        else
                        {
                            Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                            referral["lux_fieldname"] = "Contractors Plant & Equipment Base Rate Referral";
                            referral["lux_suppliedvalue"] = CPEBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_cpe";
                            if (cpestatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Update(referral);
                        }
                    }
                }
                else
                {
                    contractorsPlantEquipment.Attributes["lux_rate"] = 0M;
                }

                contractorsPlantEquipment.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                contractorsPlantEquipment.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!contractorsPlantEquipment.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    contractorsPlantEquipment.Attributes["lux_grosspolicypremiumquoted"] = new Money(contractorsPlantEquipment.GetAttributeValue<Money>("lux_ratingfigures").Value * contractorsPlantEquipment.GetAttributeValue<decimal>("lux_rate") / 100);
                    contractorsPlantEquipment.Attributes["lux_grosspolicypremiumbound"] = new Money(contractorsPlantEquipment.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * contractorsPlantEquipment.GetAttributeValue<decimal>("lux_rate") / 100);
                }

                if (ContractorsPlantEquipment != null)
                {
                    service.Update(contractorsPlantEquipment);
                }
                else
                {
                    service.Create(contractorsPlantEquipment);
                }



                Entity hiredinPlantCharges = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (HiredinPlantCharges != null)
                {
                    hiredinPlantCharges = service.Retrieve("lux_constructiontechnicalpremiumcalculation", HiredinPlantCharges.Id, new ColumnSet(true));
                }
                hiredinPlantCharges.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970005);
                hiredinPlantCharges.Attributes["lux_name"] = "Hired in Plant Charges";
                hiredinPlantCharges.Attributes["lux_ratingbasis"] = "on Estimated Hired-in Charges";

                hiredinPlantCharges.Attributes["lux_ratingfigures"] = new Money(HiredinPlant);

                var HIPBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970008);
                if (HIPBaseRate != null)
                {
                    hiredinPlantCharges.Attributes["lux_rate"] = HIPBaseRate.GetAttributeValue<decimal>("lux_rate");

                    var hipstatus = HIPBaseRate.FormattedValues["lux_refer"].ToString();
                    if (hipstatus == "Refer" || hipstatus == "Decline")
                    {
                        referralFlag = true;
                        var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_hip' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                        var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                        if (RateList.Entities.Count == 0)
                        {
                            Entity referral = new Entity("lux_constructionreferral");
                            referral["lux_fieldname"] = "Hired in Plant Charges Base Rate Referral";
                            referral["lux_suppliedvalue"] = HIPBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_hip";
                            if (hipstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Create(referral);
                        }
                        else
                        {
                            Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                            referral["lux_fieldname"] = "Hired in Plant Charges Base Rate Referral";
                            referral["lux_suppliedvalue"] = HIPBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_hip";
                            if (hipstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Update(referral);
                        }
                    }
                }
                else
                {
                    hiredinPlantCharges.Attributes["lux_rate"] = 0M;
                }

                hiredinPlantCharges.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                hiredinPlantCharges.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!hiredinPlantCharges.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    hiredinPlantCharges.Attributes["lux_grosspolicypremiumquoted"] = new Money(hiredinPlantCharges.GetAttributeValue<Money>("lux_ratingfigures").Value * hiredinPlantCharges.GetAttributeValue<decimal>("lux_rate") / 100);
                    hiredinPlantCharges.Attributes["lux_grosspolicypremiumbound"] = new Money(hiredinPlantCharges.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * hiredinPlantCharges.GetAttributeValue<decimal>("lux_rate") / 100);
                }

                if (HiredinPlantCharges != null)
                {
                    service.Update(hiredinPlantCharges);
                }
                else
                {
                    service.Create(hiredinPlantCharges);
                }



                Entity employeestoolsvalue = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (Employeestoolsvalue != null)
                {
                    employeestoolsvalue = service.Retrieve("lux_constructiontechnicalpremiumcalculation", Employeestoolsvalue.Id, new ColumnSet(true));
                }
                employeestoolsvalue.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970006);
                employeestoolsvalue.Attributes["lux_name"] = "Employees tools value";
                employeestoolsvalue.Attributes["lux_ratingbasis"] = "on current market value";

                employeestoolsvalue.Attributes["lux_ratingfigures"] = new Money(EmployeeToolsSI);

                var EPToolBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970009 && ((Convert.ToDecimal(x.Attributes["lux_from"].ToString().Replace(",", "")) <= EmployeeToolsAnyOneEmp && Convert.ToDecimal((x.Attributes.Contains("lux_to") ? x.Attributes["lux_to"].ToString().Replace(",", "") : "0")) >= EmployeeToolsAnyOneEmp) || (Convert.ToDecimal(x.Attributes["lux_from"].ToString().Replace(",", "")) <= EmployeeToolsAnyOneEmp && !x.Attributes.Contains("lux_to"))));
                if (EPToolBaseRate != null)
                {
                    employeestoolsvalue.Attributes["lux_rate"] = EPToolBaseRate.GetAttributeValue<decimal>("lux_rate");
                    var EPstatus = EPToolBaseRate.FormattedValues["lux_refer"].ToString();
                    if (EPstatus == "Refer" || EPstatus == "Decline")
                    {
                        referralFlag = true;
                        var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_ep' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                        var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                        if (RateList.Entities.Count == 0)
                        {
                            Entity referral = new Entity("lux_constructionreferral");
                            referral["lux_fieldname"] = "Employees tools Base Rate Referral";
                            referral["lux_suppliedvalue"] = EPToolBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_ep";
                            if (EPstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Create(referral);
                        }
                        else
                        {
                            Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                            referral["lux_fieldname"] = "Employees tools Base Rate Referral";
                            referral["lux_suppliedvalue"] = EPToolBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_ep";
                            if (EPstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Update(referral);
                        }
                    }
                }
                else
                {
                    employeestoolsvalue.Attributes["lux_rate"] = 0M;
                }

                employeestoolsvalue.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                employeestoolsvalue.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!employeestoolsvalue.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    employeestoolsvalue.Attributes["lux_grosspolicypremiumquoted"] = new Money(employeestoolsvalue.GetAttributeValue<Money>("lux_ratingfigures").Value * employeestoolsvalue.GetAttributeValue<decimal>("lux_rate") / 100);
                    employeestoolsvalue.Attributes["lux_grosspolicypremiumbound"] = new Money(employeestoolsvalue.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * employeestoolsvalue.GetAttributeValue<decimal>("lux_rate") / 100);
                }

                if (Employeestoolsvalue != null)
                {
                    service.Update(employeestoolsvalue);
                }
                else
                {
                    service.Create(employeestoolsvalue);
                }



                Entity temporaryBuildings = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (TemporaryBuildings != null)
                {
                    temporaryBuildings = service.Retrieve("lux_constructiontechnicalpremiumcalculation", TemporaryBuildings.Id, new ColumnSet(true));
                }
                temporaryBuildings.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970007);
                temporaryBuildings.Attributes["lux_name"] = "Temporary Buildings";
                temporaryBuildings.Attributes["lux_ratingbasis"] = "on current market value";

                temporaryBuildings.Attributes["lux_ratingfigures"] = new Money(TempBuildingSI);
                var tempBuildingBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970006);

                if (tempBuildingBaseRate != null)
                {
                    temporaryBuildings.Attributes["lux_rate"] = tempBuildingBaseRate.GetAttributeValue<decimal>("lux_rate");
                    var tempBuildingstatus = tempBuildingBaseRate.FormattedValues["lux_refer"].ToString();
                    if (tempBuildingstatus == "Refer" || tempBuildingstatus == "Decline")
                    {
                        referralFlag = true;
                        var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_tempbuilding' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                        var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                        if (RateList.Entities.Count == 0)
                        {
                            Entity referral = new Entity("lux_constructionreferral");
                            referral["lux_fieldname"] = "Temporary Buildings Base Rate Referral";
                            referral["lux_suppliedvalue"] = tempBuildingBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_tempbuilding";
                            if (tempBuildingstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Create(referral);
                        }
                        else
                        {
                            Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                            referral["lux_fieldname"] = "Temporary Buildings Base Rate Referral";
                            referral["lux_suppliedvalue"] = tempBuildingBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_tempbuilding";
                            if (tempBuildingstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Update(referral);
                        }
                    }
                }
                else
                {
                    temporaryBuildings.Attributes["lux_rate"] = 0M;
                }

                temporaryBuildings.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                temporaryBuildings.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!temporaryBuildings.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    temporaryBuildings.Attributes["lux_grosspolicypremiumquoted"] = new Money(temporaryBuildings.GetAttributeValue<Money>("lux_ratingfigures").Value * temporaryBuildings.GetAttributeValue<decimal>("lux_rate") / 100);
                    temporaryBuildings.Attributes["lux_grosspolicypremiumbound"] = new Money(temporaryBuildings.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * temporaryBuildings.GetAttributeValue<decimal>("lux_rate") / 100);
                }

                if (TemporaryBuildings != null)
                {
                    service.Update(temporaryBuildings);
                }
                else
                {
                    service.Create(temporaryBuildings);
                }



                Entity otherItems = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (OtherItems != null)
                {
                    otherItems = service.Retrieve("lux_constructiontechnicalpremiumcalculation", OtherItems.Id, new ColumnSet(true));
                }
                otherItems.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970008);
                otherItems.Attributes["lux_name"] = "Other Items";
                otherItems.Attributes["lux_ratingbasis"] = "on current market value";

                otherItems.Attributes["lux_ratingfigures"] = new Money(OtherItemsSI);

                var otherItemBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970007);

                if (otherItemBaseRate != null)
                {
                    otherItems.Attributes["lux_rate"] = otherItemBaseRate.GetAttributeValue<decimal>("lux_rate");
                    var otherItemstatus = otherItemBaseRate.FormattedValues["lux_refer"].ToString();
                    if (otherItemstatus == "Refer" || otherItemstatus == "Decline")
                    {
                        referralFlag = true;
                        var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_otheritem' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                        var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                        if (RateList.Entities.Count == 0)
                        {
                            Entity referral = new Entity("lux_constructionreferral");
                            referral["lux_fieldname"] = "Other Items Base Rate Referral";
                            referral["lux_suppliedvalue"] = otherItemBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_otheritem";
                            if (otherItemstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Create(referral);
                        }
                        else
                        {
                            Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                            referral["lux_fieldname"] = "Other Items Base Rate Referral";
                            referral["lux_suppliedvalue"] = otherItemBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_otheritem";
                            if (otherItemstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Update(referral);
                        }
                    }
                }
                else
                {
                    otherItems.Attributes["lux_rate"] = 0M;
                }

                otherItems.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                otherItems.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!otherItems.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    otherItems.Attributes["lux_grosspolicypremiumquoted"] = new Money(otherItems.GetAttributeValue<Money>("lux_ratingfigures").Value * otherItems.GetAttributeValue<decimal>("lux_rate") / 100);
                    otherItems.Attributes["lux_grosspolicypremiumbound"] = new Money(otherItems.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * otherItems.GetAttributeValue<decimal>("lux_rate") / 100);
                }

                if (OtherItems != null)
                {
                    service.Update(otherItems);
                }
                else
                {
                    service.Create(otherItems);
                }



                Entity dSU = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (DSU != null)
                {
                    dSU = service.Retrieve("lux_constructiontechnicalpremiumcalculation", DSU.Id, new ColumnSet(true));
                }
                dSU.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970009);
                dSU.Attributes["lux_name"] = "DSU";
                dSU.Attributes["lux_ratingbasis"] = "on Total Sum Insured";
                dSU.Attributes["lux_ratingfigures"] = new Money(DSUSI);

                if (constructionQuote.GetAttributeValue<bool>("lux_dilayinstartupcoverrequired") == true)
                {
                    var dsuBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970004 && ((Convert.ToDecimal(x.Attributes["lux_from"].ToString().Replace(",", "")) <= Convert.ToDecimal(DSUMonths) && Convert.ToDecimal((x.Attributes.Contains("lux_to") ? x.Attributes["lux_to"].ToString().Replace(",", "") : "0")) >= Convert.ToDecimal(DSUMonths)) || (Convert.ToDecimal(x.Attributes["lux_from"].ToString().Replace(",", "")) <= Convert.ToDecimal(DSUMonths) && !x.Attributes.Contains("lux_to"))));

                    if (dsuBaseRate != null)
                    {
                        dSU.Attributes["lux_rate"] = dsuBaseRate.GetAttributeValue<decimal>("lux_rate");
                        var dsustatus = dsuBaseRate.FormattedValues["lux_refer"].ToString();
                        if (dsustatus == "Refer" || dsustatus == "Decline")
                        {
                            referralFlag = true;
                            var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_dsu' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                            var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                            if (RateList.Entities.Count == 0)
                            {
                                Entity referral = new Entity("lux_constructionreferral");
                                referral["lux_fieldname"] = "DSU Base Rate Referral";
                                referral["lux_suppliedvalue"] = dsuBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                                referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                                referral["lux_fieldschemaname"] = "lux_dsu";
                                if (dsustatus == "Decline")
                                {
                                    referral["lux_declined"] = true;
                                    declineFlag = true;
                                }
                                service.Create(referral);
                            }
                            else
                            {
                                Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                                referral["lux_fieldname"] = "DSU Base Rate Referral";
                                referral["lux_suppliedvalue"] = dsuBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                                referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                                referral["lux_fieldschemaname"] = "lux_dsu";
                                if (dsustatus == "Decline")
                                {
                                    referral["lux_declined"] = true;
                                    declineFlag = true;
                                }
                                service.Update(referral);
                            }
                        }
                    }
                    else
                    {
                        dSU.Attributes["lux_ratingfigures"] = new Money(0);
                        dSU.Attributes["lux_rate"] = 0M;
                    }
                }
                else
                {
                    dSU.Attributes["lux_ratingfigures"] = new Money(0);
                    dSU.Attributes["lux_rate"] = 0M;
                }

                dSU.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                dSU.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!dSU.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    dSU.Attributes["lux_grosspolicypremiumquoted"] = new Money(dSU.GetAttributeValue<Money>("lux_ratingfigures").Value * dSU.GetAttributeValue<decimal>("lux_rate") / 100);
                    dSU.Attributes["lux_grosspolicypremiumbound"] = new Money(dSU.GetAttributeValue<Money>("lux_ratingfigures").Value * dSU.GetAttributeValue<decimal>("lux_rate") / 100);
                }

                if (DSU != null)
                {
                    service.Update(dSU);
                }
                else
                {
                    service.Create(dSU);
                }



                Entity thirdPartyLiability = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (ThirdPartyLiability != null)
                {
                    thirdPartyLiability = service.Retrieve("lux_constructiontechnicalpremiumcalculation", ThirdPartyLiability.Id, new ColumnSet(true));
                }
                thirdPartyLiability.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970010);
                thirdPartyLiability.Attributes["lux_name"] = "Third Party Liability";
                thirdPartyLiability.Attributes["lux_ratingbasis"] = "on Estimated Contract Value";
                thirdPartyLiability.Attributes["lux_ratingfigures"] = ContractValue;

                if (constructionQuote.GetAttributeValue<bool>("lux_thirdpartyliabilitycover") == true && constructionQuote.Attributes.Contains("lux_tpllimit") && constructionQuote.Attributes.Contains("lux_tplexposure") && constructionQuote.Attributes.Contains("lux_tplexcess"))
                {
                    var tplLimit = constructionQuote.GetAttributeValue<Money>("lux_tpllimit").Value;
                    var tplBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970011 && ((Convert.ToDecimal(x.Attributes["lux_from"].ToString().Replace(",", "")) <= Convert.ToDecimal(tplLimit) && Convert.ToDecimal((x.Attributes.Contains("lux_to") ? x.Attributes["lux_to"].ToString().Replace(",", "") : "0")) >= Convert.ToDecimal(tplLimit)) || (Convert.ToDecimal(x.Attributes["lux_from"].ToString().Replace(",", "")) <= Convert.ToDecimal(tplLimit) && !x.Attributes.Contains("lux_to"))));
                    var tplLimitPercent = 0M;
                    if (tplBaseRate != null)
                    {
                        tplLimitPercent = tplBaseRate.GetAttributeValue<decimal>("lux_rate");
                        var tplLimitstatus = tplBaseRate.FormattedValues["lux_refer"].ToString();
                        if (tplLimitstatus == "Refer" || tplLimitstatus == "Decline")
                        {
                            referralFlag = true;
                            var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_tpllimit' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                            var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                            if (RateList.Entities.Count == 0)
                            {
                                Entity referral = new Entity("lux_constructionreferral");
                                referral["lux_fieldname"] = "Third Party Liability Base Rate Referral";
                                referral["lux_suppliedvalue"] = tplBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                                referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                                referral["lux_fieldschemaname"] = "lux_tpllimit";
                                if (tplLimitstatus == "Decline")
                                {
                                    referral["lux_declined"] = true;
                                    declineFlag = true;
                                }
                                service.Create(referral);
                            }
                            else
                            {
                                Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                                referral["lux_fieldname"] = "Third Party Liability Base Rate Referral";
                                referral["lux_suppliedvalue"] = tplBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                                referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                                referral["lux_fieldschemaname"] = "lux_tpllimit";
                                if (tplLimitstatus == "Decline")
                                {
                                    referral["lux_declined"] = true;
                                    declineFlag = true;
                                }
                                service.Update(referral);
                            }
                        }
                    }

                    thirdPartyLiability.Attributes["lux_rate"] = CompositeRate * tplLimitPercent * (RatingMultiplierItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970001 && x.Attributes["lux_to"].ToString().Contains(constructionQuote.FormattedValues["lux_tplexposure"].ToString() + "_" + constructionQuote.FormattedValues["lux_tplexcess"].ToString().Replace("£", "").Replace(",", ""))) != null ? RatingMultiplierItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970001 && x.Attributes["lux_to"].ToString().Contains(constructionQuote.FormattedValues["lux_tplexposure"].ToString() + "_" + constructionQuote.FormattedValues["lux_tplexcess"].ToString().Replace("£", "").Replace(",", ""))).GetAttributeValue<decimal>("lux_ratingmultiplier") / 100 : 0M);
                    tracingService.Trace((CompositeRate * tplLimitPercent * (RatingMultiplierItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970001 && x.Attributes["lux_to"].ToString().Contains(constructionQuote.FormattedValues["lux_tplexposure"].ToString() + "_" + constructionQuote.FormattedValues["lux_tplexcess"].ToString().Replace("£", "").Replace(",", ""))) != null ? RatingMultiplierItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970001 && x.Attributes["lux_to"].ToString().Contains(constructionQuote.FormattedValues["lux_tplexposure"].ToString() + "_" + constructionQuote.FormattedValues["lux_tplexcess"].ToString().Replace("£", "").Replace(",", ""))).GetAttributeValue<decimal>("lux_ratingmultiplier") / 100 : 0M)).ToString());
                }
                else
                {
                    thirdPartyLiability.Attributes["lux_ratingfigures"] = new Money(0);
                    thirdPartyLiability.Attributes["lux_rate"] = 0M;
                }

                thirdPartyLiability.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                thirdPartyLiability.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!thirdPartyLiability.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    thirdPartyLiability.Attributes["lux_grosspolicypremiumquoted"] = new Money(thirdPartyLiability.GetAttributeValue<Money>("lux_ratingfigures").Value * Math.Round(thirdPartyLiability.GetAttributeValue<decimal>("lux_rate"), 4) / 100);
                    thirdPartyLiability.Attributes["lux_grosspolicypremiumbound"] = new Money(thirdPartyLiability.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * Math.Round(thirdPartyLiability.GetAttributeValue<decimal>("lux_rate"), 4) / 100);
                }

                if (ThirdPartyLiability != null)
                {
                    service.Update(thirdPartyLiability);
                }
                else
                {
                    service.Create(thirdPartyLiability);
                }



                Entity nonNegLiability = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (NonNegLiability != null)
                {
                    nonNegLiability = service.Retrieve("lux_constructiontechnicalpremiumcalculation", NonNegLiability.Id, new ColumnSet(true));
                }
                nonNegLiability.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970011);
                nonNegLiability.Attributes["lux_name"] = "Non-Neg Liability";
                nonNegLiability.Attributes["lux_ratingbasis"] = "on Estimated Contract Value";
                nonNegLiability.Attributes["lux_ratingfigures"] = ContractValue;

                if (constructionQuote.GetAttributeValue<bool>("lux_nonnegligentliability651cover") == true && constructionQuote.Attributes.Contains("lux_nonnegligentliability651limit") && constructionQuote.Attributes.Contains("lux_nonnegexposure") && constructionQuote.Attributes.Contains("lux_nonnegligentliability651excess"))
                {
                    var nonNegLimit = constructionQuote.GetAttributeValue<Money>("lux_nonnegligentliability651limit").Value;
                    var nonNegBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970012 && ((Convert.ToDecimal(x.Attributes["lux_from"].ToString().Replace(",", "")) <= Convert.ToDecimal(nonNegLimit) && Convert.ToDecimal((x.Attributes.Contains("lux_to") ? x.Attributes["lux_to"].ToString().Replace(",", "") : "0")) >= Convert.ToDecimal(nonNegLimit)) || (Convert.ToDecimal(x.Attributes["lux_from"].ToString().Replace(",", "")) <= Convert.ToDecimal(nonNegLimit) && !x.Attributes.Contains("lux_to"))));
                    var nonNegLimitPercent = 0M;
                    if (nonNegBaseRate != null)
                    {
                        nonNegLimitPercent = nonNegBaseRate.GetAttributeValue<decimal>("lux_rate");
                        var nonNegLimitstatus = nonNegBaseRate.FormattedValues["lux_refer"].ToString();
                        if (nonNegLimitstatus == "Refer" || nonNegLimitstatus == "Decline")
                        {
                            referralFlag = true;
                            var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_nonneglimit' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                            var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                            if (RateList.Entities.Count == 0)
                            {
                                Entity referral = new Entity("lux_constructionreferral");
                                referral["lux_fieldname"] = "Non-Neg Liability Base Rate Referral";
                                referral["lux_suppliedvalue"] = nonNegBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                                referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                                referral["lux_fieldschemaname"] = "lux_nonneglimit";
                                if (nonNegLimitstatus == "Decline")
                                {
                                    referral["lux_declined"] = true;
                                    declineFlag = true;
                                }
                                service.Create(referral);
                            }
                            else
                            {
                                Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                                referral["lux_fieldname"] = "Non-Neg Liability Base Rate Referral";
                                referral["lux_suppliedvalue"] = nonNegBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                                referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                                referral["lux_fieldschemaname"] = "lux_nonneglimit";
                                if (nonNegLimitstatus == "Decline")
                                {
                                    referral["lux_declined"] = true;
                                    declineFlag = true;
                                }
                                service.Update(referral);
                            }
                        }
                    }
                    nonNegLiability.Attributes["lux_rate"] = CompositeRate * nonNegLimitPercent * (RatingMultiplierItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970002 && x.Attributes["lux_to"].ToString().Contains(constructionQuote.FormattedValues["lux_nonnegexposure"].ToString() + "_" + constructionQuote.FormattedValues["lux_nonnegligentliability651excess"].ToString().Replace("£", "").Replace(",", ""))) != null ? RatingMultiplierItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970002 && x.Attributes["lux_to"].ToString().Contains(constructionQuote.FormattedValues["lux_nonnegexposure"].ToString() + "_" + constructionQuote.FormattedValues["lux_nonnegligentliability651excess"].ToString().Replace("£", "").Replace(",", ""))).GetAttributeValue<decimal>("lux_ratingmultiplier") / 100 : 0M);
                }
                else
                {
                    nonNegLiability.Attributes["lux_ratingfigures"] = new Money(0);
                    nonNegLiability.Attributes["lux_rate"] = 0M;
                }

                nonNegLiability.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                nonNegLiability.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!nonNegLiability.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    nonNegLiability.Attributes["lux_grosspolicypremiumquoted"] = new Money(nonNegLiability.GetAttributeValue<Money>("lux_ratingfigures").Value * Math.Round(nonNegLiability.GetAttributeValue<decimal>("lux_rate"), 3) / 100);
                    nonNegLiability.Attributes["lux_grosspolicypremiumbound"] = new Money(nonNegLiability.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * Math.Round(nonNegLiability.GetAttributeValue<decimal>("lux_rate"), 3) / 100);
                }

                if (NonNegLiability != null)
                {
                    service.Update(nonNegLiability);
                }
                else
                {
                    service.Create(nonNegLiability);
                }

                if (referralFlag == true || declineFlag == true)
                {
                    Entity application = service.Retrieve("lux_constructionquotes", constructionQuote.Id, new ColumnSet(false));
                    application["statuscode"] = new OptionSetValue(972970007);
                    if (declineFlag == true)
                    {
                        application["statuscode"] = new OptionSetValue(972970001);
                    }
                    service.Update(application);
                }
            }
            else if (PolicyType == "CAR annual programme - CA")
            {
                var referralFlag = false;
                var declineFlag = false;

                if (EstimatedContractValue != null)
                {
                    service.Delete("lux_constructiontechnicalpremiumcalculation", EstimatedContractValue.Id);
                }



                var FullCoverTurnover = new Money(constructionQuote.Attributes.Contains("lux_fullcoverturnover") ? constructionQuote.GetAttributeValue<Money>("lux_fullcoverturnover").Value : 0);
                Entity contractingTurnover = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (ContractingTurnover != null)
                {
                    contractingTurnover = service.Retrieve("lux_constructiontechnicalpremiumcalculation", ContractingTurnover.Id, new ColumnSet(true));
                }
                contractingTurnover.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970002);
                contractingTurnover.Attributes["lux_name"] = "Contracting Turnover";
                contractingTurnover.Attributes["lux_ratingbasis"] = "on full cover turnover";

                contractingTurnover.Attributes["lux_ratingfigures"] = FullCoverTurnover;
                contractingTurnover.Attributes["lux_rate"] = constructionQuote.Attributes.Contains("lux_overallcompositerate1") ? constructionQuote.GetAttributeValue<decimal>("lux_overallcompositerate1") : 0M;
                contractingTurnover.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                contractingTurnover.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!contractingTurnover.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    contractingTurnover.Attributes["lux_grosspolicypremiumquoted"] = new Money(contractingTurnover.GetAttributeValue<Money>("lux_ratingfigures").Value * Math.Round(contractingTurnover.GetAttributeValue<decimal>("lux_rate"), 3) / 100);
                    contractingTurnover.Attributes["lux_grosspolicypremiumbound"] = new Money(contractingTurnover.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * Math.Round(contractingTurnover.GetAttributeValue<decimal>("lux_rate"), 3) / 100);
                }

                if (ContractingTurnover != null)
                {
                    service.Update(contractingTurnover);
                }
                else
                {
                    service.Create(contractingTurnover);
                }



                Entity existingProperty = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (ExistingProperty != null)
                {
                    existingProperty = service.Retrieve("lux_constructiontechnicalpremiumcalculation", ExistingProperty.Id, new ColumnSet(true));
                }
                existingProperty.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970003);
                existingProperty.Attributes["lux_name"] = "Existing Property (if covered on Full Value/All Risks basis)";
                existingProperty.Attributes["lux_ratingbasis"] = "on Total Sum Insured";

                var AnnualExistingStructure = 0M;
                if (constructionQuote.Attributes.Contains("lux_existingstructure") && constructionQuote.GetAttributeValue<bool>("lux_existingstructure") == true)
                {
                    if (constructionQuote.Attributes.Contains("lux_existingstructures") && constructionQuote.GetAttributeValue<OptionSetValue>("lux_existingstructures").Value == 972970001)//Sublimit
                    {
                        AnnualExistingStructure = constructionQuote.Attributes.Contains("lux_sublimit") ? constructionQuote.GetAttributeValue<Money>("lux_sublimit").Value : 0M;
                    }
                    else if (constructionQuote.Attributes.Contains("lux_existingstructures") && constructionQuote.GetAttributeValue<OptionSetValue>("lux_existingstructures").Value == 972970002)//Full Cover
                    {
                        AnnualExistingStructure = constructionQuote.Attributes.Contains("lux_existingstructuretsi") ? constructionQuote.GetAttributeValue<Money>("lux_existingstructuretsi").Value : 0M;
                    }
                }

                existingProperty.Attributes["lux_ratingfigures"] = new Money(AnnualExistingStructure);

                var EPbaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970003 && ((Convert.ToDecimal(x.Attributes["lux_from"].ToString().Replace(",", "")) <= Convert.ToDecimal(AnnualContractDuration) && Convert.ToDecimal((x.Attributes.Contains("lux_to") ? x.Attributes["lux_to"].ToString().Replace(",", "") : "0")) >= Convert.ToDecimal(AnnualContractDuration)) || (Convert.ToDecimal(x.Attributes["lux_from"].ToString().Replace(",", "")) <= Convert.ToDecimal(AnnualContractDuration) && !x.Attributes.Contains("lux_to"))));
                if (EPbaseRate != null)
                {
                    existingProperty.Attributes["lux_rate"] = EPbaseRate.GetAttributeValue<decimal>("lux_rate");

                    var existingPropertystatus = EPbaseRate.FormattedValues["lux_refer"].ToString();
                    if (existingPropertystatus == "Refer" || existingPropertystatus == "Decline")
                    {
                        referralFlag = true;
                        var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_existingProperty' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                        var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                        if (RateList.Entities.Count == 0)
                        {
                            Entity referral = new Entity("lux_constructionreferral");
                            referral["lux_fieldname"] = "Existing Property Base Rate Referral";
                            referral["lux_suppliedvalue"] = EPbaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_existingProperty";
                            if (existingPropertystatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Create(referral);
                        }
                        else
                        {
                            Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                            referral["lux_fieldname"] = "Existing Property Base Rate Referral";
                            referral["lux_suppliedvalue"] = EPbaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_existingProperty";
                            if (existingPropertystatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Update(referral);
                        }
                    }
                }
                else
                {
                    existingProperty.Attributes["lux_rate"] = 0M;
                }
                existingProperty.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                existingProperty.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!existingProperty.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    existingProperty.Attributes["lux_grosspolicypremiumquoted"] = new Money(existingProperty.GetAttributeValue<Money>("lux_ratingfigures").Value * existingProperty.GetAttributeValue<decimal>("lux_rate") / 100);
                    existingProperty.Attributes["lux_grosspolicypremiumbound"] = new Money(existingProperty.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * existingProperty.GetAttributeValue<decimal>("lux_rate") / 100);
                }

                if (ExistingProperty != null)
                {
                    service.Update(existingProperty);
                }
                else
                {
                    service.Create(existingProperty);
                }



                Entity contractorsPlantEquipment = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (ContractorsPlantEquipment != null)
                {
                    contractorsPlantEquipment = service.Retrieve("lux_constructiontechnicalpremiumcalculation", ContractorsPlantEquipment.Id, new ColumnSet(true));
                }
                contractorsPlantEquipment.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970004);
                contractorsPlantEquipment.Attributes["lux_name"] = "Contractors Plant & Equipment Value";
                contractorsPlantEquipment.Attributes["lux_ratingbasis"] = "on current market value";

                contractorsPlantEquipment.Attributes["lux_ratingfigures"] = new Money(OwnPlantValue);

                var CPEBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970005);
                if (CPEBaseRate != null)
                {
                    contractorsPlantEquipment.Attributes["lux_rate"] = CPEBaseRate.GetAttributeValue<decimal>("lux_rate");

                    var cpestatus = CPEBaseRate.FormattedValues["lux_refer"].ToString();
                    if (cpestatus == "Refer" || cpestatus == "Decline")
                    {
                        referralFlag = true;
                        var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_cpe' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                        var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                        if (RateList.Entities.Count == 0)
                        {
                            Entity referral = new Entity("lux_constructionreferral");
                            referral["lux_fieldname"] = "Contractors Plant & Equipment Base Rate Referral";
                            referral["lux_suppliedvalue"] = CPEBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_cpe";
                            if (cpestatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Create(referral);
                        }
                        else
                        {
                            Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                            referral["lux_fieldname"] = "Contractors Plant & Equipment Base Rate Referral";
                            referral["lux_suppliedvalue"] = CPEBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_cpe";
                            if (cpestatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Update(referral);
                        }
                    }
                }
                else
                {
                    contractorsPlantEquipment.Attributes["lux_rate"] = 0M;
                }

                contractorsPlantEquipment.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                contractorsPlantEquipment.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!contractorsPlantEquipment.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    contractorsPlantEquipment.Attributes["lux_grosspolicypremiumquoted"] = new Money(contractorsPlantEquipment.GetAttributeValue<Money>("lux_ratingfigures").Value * contractorsPlantEquipment.GetAttributeValue<decimal>("lux_rate") / 100);
                    contractorsPlantEquipment.Attributes["lux_grosspolicypremiumbound"] = new Money(contractorsPlantEquipment.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * contractorsPlantEquipment.GetAttributeValue<decimal>("lux_rate") / 100);
                }

                if (ContractorsPlantEquipment != null)
                {
                    service.Update(contractorsPlantEquipment);
                }
                else
                {
                    service.Create(contractorsPlantEquipment);
                }



                Entity hiredinPlantCharges = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (HiredinPlantCharges != null)
                {
                    hiredinPlantCharges = service.Retrieve("lux_constructiontechnicalpremiumcalculation", HiredinPlantCharges.Id, new ColumnSet(true));
                }
                hiredinPlantCharges.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970005);
                hiredinPlantCharges.Attributes["lux_name"] = "Hired in Plant Charges";
                hiredinPlantCharges.Attributes["lux_ratingbasis"] = "on Estimated Hired-in Charges";

                hiredinPlantCharges.Attributes["lux_ratingfigures"] = new Money(HiredinPlant);

                var HIPBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970008);
                if (HIPBaseRate != null)
                {
                    hiredinPlantCharges.Attributes["lux_rate"] = HIPBaseRate.GetAttributeValue<decimal>("lux_rate");

                    var hipstatus = HIPBaseRate.FormattedValues["lux_refer"].ToString();
                    if (hipstatus == "Refer" || hipstatus == "Decline")
                    {
                        referralFlag = true;
                        var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_hip' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                        var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                        if (RateList.Entities.Count == 0)
                        {
                            Entity referral = new Entity("lux_constructionreferral");
                            referral["lux_fieldname"] = "Hired in Plant Charges Base Rate Referral";
                            referral["lux_suppliedvalue"] = HIPBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_hip";
                            if (hipstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Create(referral);
                        }
                        else
                        {
                            Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                            referral["lux_fieldname"] = "Hired in Plant Charges Base Rate Referral";
                            referral["lux_suppliedvalue"] = HIPBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_hip";
                            if (hipstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Update(referral);
                        }
                    }
                }
                else
                {
                    hiredinPlantCharges.Attributes["lux_rate"] = 0M;
                }

                hiredinPlantCharges.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                hiredinPlantCharges.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);


                //if (!hiredinPlantCharges.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    hiredinPlantCharges.Attributes["lux_grosspolicypremiumquoted"] = new Money(hiredinPlantCharges.GetAttributeValue<Money>("lux_ratingfigures").Value * hiredinPlantCharges.GetAttributeValue<decimal>("lux_rate") / 100);
                    hiredinPlantCharges.Attributes["lux_grosspolicypremiumbound"] = new Money(hiredinPlantCharges.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * hiredinPlantCharges.GetAttributeValue<decimal>("lux_rate") / 100);
                }

                if (HiredinPlantCharges != null)
                {
                    service.Update(hiredinPlantCharges);
                }
                else
                {
                    service.Create(hiredinPlantCharges);
                }



                Entity temporaryBuildings = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (TemporaryBuildings != null)
                {
                    temporaryBuildings = service.Retrieve("lux_constructiontechnicalpremiumcalculation", TemporaryBuildings.Id, new ColumnSet(true));
                }
                temporaryBuildings.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970007);
                temporaryBuildings.Attributes["lux_name"] = "Temporary Buildings";
                temporaryBuildings.Attributes["lux_ratingbasis"] = "on current market value";

                temporaryBuildings.Attributes["lux_ratingfigures"] = new Money(TempBuildingSI);
                var tempBuildingBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970006);

                if (tempBuildingBaseRate != null)
                {
                    temporaryBuildings.Attributes["lux_rate"] = tempBuildingBaseRate.GetAttributeValue<decimal>("lux_rate");
                    var tempBuildingstatus = tempBuildingBaseRate.FormattedValues["lux_refer"].ToString();
                    if (tempBuildingstatus == "Refer" || tempBuildingstatus == "Decline")
                    {
                        referralFlag = true;
                        var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_tempbuilding' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                        var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                        if (RateList.Entities.Count == 0)
                        {
                            Entity referral = new Entity("lux_constructionreferral");
                            referral["lux_fieldname"] = "Temporary Buildings Base Rate Referral";
                            referral["lux_suppliedvalue"] = tempBuildingBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_tempbuilding";
                            if (tempBuildingstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Create(referral);
                        }
                        else
                        {
                            Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                            referral["lux_fieldname"] = "Temporary Buildings Base Rate Referral";
                            referral["lux_suppliedvalue"] = tempBuildingBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_tempbuilding";
                            if (tempBuildingstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Update(referral);
                        }
                    }
                }
                else
                {
                    temporaryBuildings.Attributes["lux_rate"] = 0M;
                }

                temporaryBuildings.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                temporaryBuildings.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!temporaryBuildings.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    temporaryBuildings.Attributes["lux_grosspolicypremiumquoted"] = new Money(temporaryBuildings.GetAttributeValue<Money>("lux_ratingfigures").Value * temporaryBuildings.GetAttributeValue<decimal>("lux_rate") / 100);
                    temporaryBuildings.Attributes["lux_grosspolicypremiumbound"] = new Money(temporaryBuildings.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * temporaryBuildings.GetAttributeValue<decimal>("lux_rate") / 100);
                }

                if (TemporaryBuildings != null)
                {
                    service.Update(temporaryBuildings);
                }
                else
                {
                    service.Create(temporaryBuildings);
                }



                Entity employeestoolsvalue = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (Employeestoolsvalue != null)
                {
                    employeestoolsvalue = service.Retrieve("lux_constructiontechnicalpremiumcalculation", Employeestoolsvalue.Id, new ColumnSet(true));
                }
                employeestoolsvalue.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970006);
                employeestoolsvalue.Attributes["lux_name"] = "Employees tools value";
                employeestoolsvalue.Attributes["lux_ratingbasis"] = "on current market value";

                employeestoolsvalue.Attributes["lux_ratingfigures"] = new Money(EmployeeToolsSI);
                var EPToolBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970009 && ((Convert.ToDecimal(x.Attributes["lux_from"].ToString().Replace(",", "")) <= EmployeeToolsAnyOneEmp && Convert.ToDecimal((x.Attributes.Contains("lux_to") ? x.Attributes["lux_to"].ToString().Replace(",", "") : "0")) >= EmployeeToolsAnyOneEmp) || (Convert.ToDecimal(x.Attributes["lux_from"].ToString().Replace(",", "")) <= EmployeeToolsAnyOneEmp && !x.Attributes.Contains("lux_to"))));
                if (EPToolBaseRate != null)
                {
                    employeestoolsvalue.Attributes["lux_rate"] = EPToolBaseRate.GetAttributeValue<decimal>("lux_rate");
                    var EPstatus = EPToolBaseRate.FormattedValues["lux_refer"].ToString();
                    if (EPstatus == "Refer" || EPstatus == "Decline")
                    {
                        referralFlag = true;
                        var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_ep' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                        var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                        if (RateList.Entities.Count == 0)
                        {
                            Entity referral = new Entity("lux_constructionreferral");
                            referral["lux_fieldname"] = "Employees tools Base Rate Referral";
                            referral["lux_suppliedvalue"] = EPToolBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_ep";
                            if (EPstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Create(referral);
                        }
                        else
                        {
                            Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                            referral["lux_fieldname"] = "Employees tools Base Rate Referral";
                            referral["lux_suppliedvalue"] = EPToolBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_ep";
                            if (EPstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Update(referral);
                        }
                    }
                }
                else
                {
                    employeestoolsvalue.Attributes["lux_rate"] = 0M;
                }
                employeestoolsvalue.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                employeestoolsvalue.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!employeestoolsvalue.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    employeestoolsvalue.Attributes["lux_grosspolicypremiumquoted"] = new Money(employeestoolsvalue.GetAttributeValue<Money>("lux_ratingfigures").Value * employeestoolsvalue.GetAttributeValue<decimal>("lux_rate") / 100);
                    employeestoolsvalue.Attributes["lux_grosspolicypremiumbound"] = new Money(employeestoolsvalue.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * employeestoolsvalue.GetAttributeValue<decimal>("lux_rate") / 100);
                }

                if (Employeestoolsvalue != null)
                {
                    service.Update(employeestoolsvalue);
                }
                else
                {
                    service.Create(employeestoolsvalue);
                }



                Entity otherItems = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (OtherItems != null)
                {
                    otherItems = service.Retrieve("lux_constructiontechnicalpremiumcalculation", OtherItems.Id, new ColumnSet(true));
                }
                otherItems.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970008);
                otherItems.Attributes["lux_name"] = "Other Items";
                otherItems.Attributes["lux_ratingbasis"] = "on current market value";

                otherItems.Attributes["lux_ratingfigures"] = new Money(OtherItemsSI);
                var otherItemBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970007);

                if (otherItemBaseRate != null)
                {
                    otherItems.Attributes["lux_rate"] = otherItemBaseRate.GetAttributeValue<decimal>("lux_rate");
                    var otherItemstatus = otherItemBaseRate.FormattedValues["lux_refer"].ToString();
                    if (otherItemstatus == "Refer" || otherItemstatus == "Decline")
                    {
                        referralFlag = true;
                        var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_otheritem' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                        var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                        if (RateList.Entities.Count == 0)
                        {
                            Entity referral = new Entity("lux_constructionreferral");
                            referral["lux_fieldname"] = "Other Items Base Rate Referral";
                            referral["lux_suppliedvalue"] = otherItemBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_otheritem";
                            if (otherItemstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Create(referral);
                        }
                        else
                        {
                            Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                            referral["lux_fieldname"] = "Other Items Base Rate Referral";
                            referral["lux_suppliedvalue"] = otherItemBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_otheritem";
                            if (otherItemstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Update(referral);
                        }
                    }
                }
                else
                {
                    otherItems.Attributes["lux_rate"] = 0M;
                }
                otherItems.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                otherItems.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!otherItems.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    otherItems.Attributes["lux_grosspolicypremiumquoted"] = new Money(otherItems.GetAttributeValue<Money>("lux_ratingfigures").Value * otherItems.GetAttributeValue<decimal>("lux_rate") / 100);
                    otherItems.Attributes["lux_grosspolicypremiumbound"] = new Money(otherItems.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * otherItems.GetAttributeValue<decimal>("lux_rate") / 100);
                }

                if (OtherItems != null)
                {
                    service.Update(otherItems);
                }
                else
                {
                    service.Create(otherItems);
                }



                if (DSU != null)
                {
                    service.Delete("lux_constructiontechnicalpremiumcalculation", DSU.Id);
                }

                if (ThirdPartyLiability != null)
                {
                    service.Delete("lux_constructiontechnicalpremiumcalculation", ThirdPartyLiability.Id);
                }

                if (NonNegLiability != null)
                {
                    service.Delete("lux_constructiontechnicalpremiumcalculation", NonNegLiability.Id);
                }

                if (referralFlag == true || declineFlag == true)
                {
                    Entity application = service.Retrieve("lux_constructionquotes", constructionQuote.Id, new ColumnSet(false));
                    application["statuscode"] = new OptionSetValue(972970007);
                    if (declineFlag == true)
                    {
                        application["statuscode"] = new OptionSetValue(972970001);
                    }
                    service.Update(application);
                }
            }
            else if (PolicyType == "CPE annual programme - CP")
            {
                var referralFlag = false;
                var declineFlag = false;

                if (EstimatedContractValue != null)
                {
                    service.Delete("lux_constructiontechnicalpremiumcalculation", EstimatedContractValue.Id);
                }

                if (ContractingTurnover != null)
                {
                    service.Delete("lux_constructiontechnicalpremiumcalculation", ContractingTurnover.Id);
                }

                if (ExistingProperty != null)
                {
                    service.Delete("lux_constructiontechnicalpremiumcalculation", ExistingProperty.Id);
                }



                Entity contractorsPlantEquipment = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (ContractorsPlantEquipment != null)
                {
                    contractorsPlantEquipment = service.Retrieve("lux_constructiontechnicalpremiumcalculation", ContractorsPlantEquipment.Id, new ColumnSet(true));
                }
                contractorsPlantEquipment.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970004);
                contractorsPlantEquipment.Attributes["lux_name"] = "Contractors Plant & Equipment Value";
                contractorsPlantEquipment.Attributes["lux_ratingbasis"] = "on current market value";

                contractorsPlantEquipment.Attributes["lux_ratingfigures"] = new Money(OwnPlantValue);
                var CPEBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970005);
                if (CPEBaseRate != null)
                {
                    contractorsPlantEquipment.Attributes["lux_rate"] = CPEBaseRate.GetAttributeValue<decimal>("lux_rate");

                    var cpestatus = CPEBaseRate.FormattedValues["lux_refer"].ToString();
                    if (cpestatus == "Refer" || cpestatus == "Decline")
                    {
                        referralFlag = true;
                        var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_cpe' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                        var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                        if (RateList.Entities.Count == 0)
                        {
                            Entity referral = new Entity("lux_constructionreferral");
                            referral["lux_fieldname"] = "Contractors Plant & Equipment Base Rate Referral";
                            referral["lux_suppliedvalue"] = CPEBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_cpe";
                            if (cpestatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Create(referral);
                        }
                        else
                        {
                            Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                            referral["lux_fieldname"] = "Contractors Plant & Equipment Base Rate Referral";
                            referral["lux_suppliedvalue"] = CPEBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_cpe";
                            if (cpestatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Update(referral);
                        }
                    }
                }
                else
                {
                    contractorsPlantEquipment.Attributes["lux_rate"] = 0M;
                }
                contractorsPlantEquipment.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                contractorsPlantEquipment.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!contractorsPlantEquipment.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    contractorsPlantEquipment.Attributes["lux_grosspolicypremiumquoted"] = new Money(contractorsPlantEquipment.GetAttributeValue<Money>("lux_ratingfigures").Value * contractorsPlantEquipment.GetAttributeValue<decimal>("lux_rate") / 100);
                    contractorsPlantEquipment.Attributes["lux_grosspolicypremiumbound"] = new Money(contractorsPlantEquipment.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * contractorsPlantEquipment.GetAttributeValue<decimal>("lux_rate") / 100);
                }

                if (ContractorsPlantEquipment != null)
                {
                    service.Update(contractorsPlantEquipment);
                }
                else
                {
                    service.Create(contractorsPlantEquipment);
                }



                Entity hiredinPlantCharges = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (HiredinPlantCharges != null)
                {
                    hiredinPlantCharges = service.Retrieve("lux_constructiontechnicalpremiumcalculation", HiredinPlantCharges.Id, new ColumnSet(true));
                }
                hiredinPlantCharges.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970005);
                hiredinPlantCharges.Attributes["lux_name"] = "Hired in Plant Charges";
                hiredinPlantCharges.Attributes["lux_ratingbasis"] = "on Estimated Hired-in Charges";

                hiredinPlantCharges.Attributes["lux_ratingfigures"] = new Money(HiredinPlant);
                var HIPBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970008);
                if (HIPBaseRate != null)
                {
                    hiredinPlantCharges.Attributes["lux_rate"] = HIPBaseRate.GetAttributeValue<decimal>("lux_rate");

                    var hipstatus = HIPBaseRate.FormattedValues["lux_refer"].ToString();
                    if (hipstatus == "Refer" || hipstatus == "Decline")
                    {
                        referralFlag = true;
                        var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_hip' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                        var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                        if (RateList.Entities.Count == 0)
                        {
                            Entity referral = new Entity("lux_constructionreferral");
                            referral["lux_fieldname"] = "Hired in Plant Charges Base Rate Referral";
                            referral["lux_suppliedvalue"] = HIPBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_hip";
                            if (hipstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Create(referral);
                        }
                        else
                        {
                            Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                            referral["lux_fieldname"] = "Hired in Plant Charges Base Rate Referral";
                            referral["lux_suppliedvalue"] = HIPBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_hip";
                            if (hipstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Update(referral);
                        }
                    }
                }
                else
                {
                    hiredinPlantCharges.Attributes["lux_rate"] = 0M;
                }
                hiredinPlantCharges.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                hiredinPlantCharges.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!hiredinPlantCharges.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    hiredinPlantCharges.Attributes["lux_grosspolicypremiumquoted"] = new Money(hiredinPlantCharges.GetAttributeValue<Money>("lux_ratingfigures").Value * hiredinPlantCharges.GetAttributeValue<decimal>("lux_rate") / 100);
                    hiredinPlantCharges.Attributes["lux_grosspolicypremiumbound"] = new Money(hiredinPlantCharges.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * hiredinPlantCharges.GetAttributeValue<decimal>("lux_rate") / 100);
                }

                if (HiredinPlantCharges != null)
                {
                    service.Update(hiredinPlantCharges);
                }
                else
                {
                    service.Create(hiredinPlantCharges);
                }



                Entity temporaryBuildings = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (TemporaryBuildings != null)
                {
                    temporaryBuildings = service.Retrieve("lux_constructiontechnicalpremiumcalculation", TemporaryBuildings.Id, new ColumnSet(true));
                }
                temporaryBuildings.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970007);
                temporaryBuildings.Attributes["lux_name"] = "Temporary Buildings";
                temporaryBuildings.Attributes["lux_ratingbasis"] = "on current market value";

                temporaryBuildings.Attributes["lux_ratingfigures"] = new Money(TempBuildingSI);
                var tempBuildingBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970006);

                if (tempBuildingBaseRate != null)
                {
                    temporaryBuildings.Attributes["lux_rate"] = tempBuildingBaseRate.GetAttributeValue<decimal>("lux_rate");
                    var tempBuildingstatus = tempBuildingBaseRate.FormattedValues["lux_refer"].ToString();
                    if (tempBuildingstatus == "Refer" || tempBuildingstatus == "Decline")
                    {
                        referralFlag = true;
                        var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_tempbuilding' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                        var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                        if (RateList.Entities.Count == 0)
                        {
                            Entity referral = new Entity("lux_constructionreferral");
                            referral["lux_fieldname"] = "Temporary Buildings Base Rate Referral";
                            referral["lux_suppliedvalue"] = tempBuildingBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_tempbuilding";
                            if (tempBuildingstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Create(referral);
                        }
                        else
                        {
                            Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                            referral["lux_fieldname"] = "Temporary Buildings Base Rate Referral";
                            referral["lux_suppliedvalue"] = tempBuildingBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_tempbuilding";
                            if (tempBuildingstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Update(referral);
                        }
                    }
                }
                else
                {
                    temporaryBuildings.Attributes["lux_rate"] = 0M;
                }
                temporaryBuildings.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                temporaryBuildings.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!temporaryBuildings.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    temporaryBuildings.Attributes["lux_grosspolicypremiumquoted"] = new Money(temporaryBuildings.GetAttributeValue<Money>("lux_ratingfigures").Value * temporaryBuildings.GetAttributeValue<decimal>("lux_rate") / 100);
                    temporaryBuildings.Attributes["lux_grosspolicypremiumbound"] = new Money(temporaryBuildings.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * temporaryBuildings.GetAttributeValue<decimal>("lux_rate") / 100);
                }

                if (TemporaryBuildings != null)
                {
                    service.Update(temporaryBuildings);
                }
                else
                {
                    service.Create(temporaryBuildings);
                }



                Entity employeestoolsvalue = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (Employeestoolsvalue != null)
                {
                    employeestoolsvalue = service.Retrieve("lux_constructiontechnicalpremiumcalculation", Employeestoolsvalue.Id, new ColumnSet(true));
                }
                employeestoolsvalue.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970006);
                employeestoolsvalue.Attributes["lux_name"] = "Employees tools value";
                employeestoolsvalue.Attributes["lux_ratingbasis"] = "on current market value";

                employeestoolsvalue.Attributes["lux_ratingfigures"] = new Money(EmployeeToolsSI);
                var EPToolBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970009 && ((Convert.ToDecimal(x.Attributes["lux_from"].ToString().Replace(",", "")) <= EmployeeToolsAnyOneEmp && Convert.ToDecimal((x.Attributes.Contains("lux_to") ? x.Attributes["lux_to"].ToString().Replace(",", "") : "0")) >= EmployeeToolsAnyOneEmp) || (Convert.ToDecimal(x.Attributes["lux_from"].ToString().Replace(",", "")) <= EmployeeToolsAnyOneEmp && !x.Attributes.Contains("lux_to"))));
                if (EPToolBaseRate != null)
                {
                    employeestoolsvalue.Attributes["lux_rate"] = EPToolBaseRate.GetAttributeValue<decimal>("lux_rate");
                    var EPstatus = EPToolBaseRate.FormattedValues["lux_refer"].ToString();
                    if (EPstatus == "Refer" || EPstatus == "Decline")
                    {
                        referralFlag = true;
                        var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_ep' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                        var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                        if (RateList.Entities.Count == 0)
                        {
                            Entity referral = new Entity("lux_constructionreferral");
                            referral["lux_fieldname"] = "Employees tools Base Rate Referral";
                            referral["lux_suppliedvalue"] = EPToolBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_ep";
                            if (EPstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Create(referral);
                        }
                        else
                        {
                            Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                            referral["lux_fieldname"] = "Employees tools Base Rate Referral";
                            referral["lux_suppliedvalue"] = EPToolBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_ep";
                            if (EPstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Update(referral);
                        }
                    }
                }
                else
                {
                    employeestoolsvalue.Attributes["lux_rate"] = 0M;
                }
                employeestoolsvalue.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                employeestoolsvalue.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!employeestoolsvalue.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    employeestoolsvalue.Attributes["lux_grosspolicypremiumquoted"] = new Money(employeestoolsvalue.GetAttributeValue<Money>("lux_ratingfigures").Value * employeestoolsvalue.GetAttributeValue<decimal>("lux_rate") / 100);
                    employeestoolsvalue.Attributes["lux_grosspolicypremiumbound"] = new Money(employeestoolsvalue.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * employeestoolsvalue.GetAttributeValue<decimal>("lux_rate") / 100);
                }

                if (Employeestoolsvalue != null)
                {
                    service.Update(employeestoolsvalue);
                }
                else
                {
                    service.Create(employeestoolsvalue);
                }



                Entity otherItems = new Entity("lux_constructiontechnicalpremiumcalculation");
                if (OtherItems != null)
                {
                    otherItems = service.Retrieve("lux_constructiontechnicalpremiumcalculation", OtherItems.Id, new ColumnSet(true));
                }
                otherItems.Attributes["lux_technicalpremiumcalculation"] = new OptionSetValue(972970008);
                otherItems.Attributes["lux_name"] = "Other Items";
                otherItems.Attributes["lux_ratingbasis"] = "on current market value";

                otherItems.Attributes["lux_ratingfigures"] = new Money(OtherItemsSI);
                var otherItemBaseRate = BaseRateItem.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_ratingfield").Value == 972970007);

                if (otherItemBaseRate != null)
                {
                    otherItems.Attributes["lux_rate"] = otherItemBaseRate.GetAttributeValue<decimal>("lux_rate");
                    var otherItemstatus = otherItemBaseRate.FormattedValues["lux_refer"].ToString();
                    if (otherItemstatus == "Refer" || otherItemstatus == "Decline")
                    {
                        referralFlag = true;
                        var RateReferral = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_constructionreferral'>
                                                                    <attribute name='lux_suppliedvalue' />
                                                                    <attribute name='lux_fieldname' />
                                                                    <attribute name='lux_declined' />
                                                                    <attribute name='lux_approve' />
                                                                    <attribute name='lux_approvaldate' />
                                                                    <attribute name='lux_additionalinfo' />
                                                                    <attribute name='lux_userapproval' />
                                                                    <attribute name='lux_constructionreferralid' />
                                                                    <order attribute='lux_approvaldate' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_otheritem' />
                                                                      <condition attribute='lux_constructionquotes' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";

                        var RateList = service.RetrieveMultiple(new FetchExpression(RateReferral));
                        if (RateList.Entities.Count == 0)
                        {
                            Entity referral = new Entity("lux_constructionreferral");
                            referral["lux_fieldname"] = "Other Items Base Rate Referral";
                            referral["lux_suppliedvalue"] = otherItemBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_otheritem";
                            if (otherItemstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Create(referral);
                        }
                        else
                        {
                            Entity referral = new Entity("lux_constructionreferral", RateList.Entities.FirstOrDefault().Id);
                            referral["lux_fieldname"] = "Other Items Base Rate Referral";
                            referral["lux_suppliedvalue"] = otherItemBaseRate.GetAttributeValue<decimal>("lux_rate").ToString();
                            referral["lux_constructionquotes"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                            referral["lux_fieldschemaname"] = "lux_otheritem";
                            if (otherItemstatus == "Decline")
                            {
                                referral["lux_declined"] = true;
                                declineFlag = true;
                            }
                            service.Update(referral);
                        }
                    }
                }
                else
                {
                    otherItems.Attributes["lux_rate"] = 0M;
                }

                otherItems.Attributes["lux_constructionquote"] = new EntityReference("lux_constructionquotes", constructionQuote.Id);
                otherItems.Attributes["transactioncurrencyid"] = new EntityReference("transactioncurrency", constructionQuote.GetAttributeValue<EntityReference>("transactioncurrencyid").Id);

                //if (!otherItems.Attributes.Contains("lux_grosspolicypremiumquoted"))
                if (ApplicationType == "New Business" || ApplicationType == "Renewal")
                {
                    otherItems.Attributes["lux_grosspolicypremiumquoted"] = new Money(otherItems.GetAttributeValue<Money>("lux_ratingfigures").Value * otherItems.GetAttributeValue<decimal>("lux_rate") / 100);
                    otherItems.Attributes["lux_grosspolicypremiumbound"] = new Money(otherItems.GetAttributeValue<Money>("lux_ratingfigures").Value * BoundShare / 100 * otherItems.GetAttributeValue<decimal>("lux_rate") / 100);
                }

                if (OtherItems != null)
                {
                    service.Update(otherItems);
                }
                else
                {
                    service.Create(otherItems);
                }



                if (DSU != null)
                {
                    service.Delete("lux_constructiontechnicalpremiumcalculation", DSU.Id);
                }

                if (ThirdPartyLiability != null)
                {
                    service.Delete("lux_constructiontechnicalpremiumcalculation", ThirdPartyLiability.Id);
                }

                if (NonNegLiability != null)
                {
                    service.Delete("lux_constructiontechnicalpremiumcalculation", NonNegLiability.Id);
                }

                if (referralFlag == true || declineFlag == true)
                {
                    Entity application = service.Retrieve("lux_constructionquotes", constructionQuote.Id, new ColumnSet(false));
                    application["statuscode"] = new OptionSetValue(972970007);
                    if (declineFlag == true)
                    {
                        application["statuscode"] = new OptionSetValue(972970001);
                    }
                    service.Update(application);
                }
            }

            var FinalRatingfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_constructiontechnicalpremiumcalculation'>
                                <attribute name='lux_name' />
                                <attribute name='lux_ratingbasis' />
                                <attribute name='lux_rate' />
                                <attribute name='lux_constructionquote' />
                                <attribute name='lux_grosspolicypremiumquoted' />
                                <attribute name='lux_grosspolicypremiumbound' />
                                <attribute name='lux_nettechnicalpremium' />
                                <attribute name='lux_ratingfigures' />
                                <attribute name='lux_technicalpremiumcalculation' />
                                <attribute name='transactioncurrencyid' />
                                <attribute name='lux_constructiontechnicalpremiumcalculationid' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_constructionquote' operator='eq' uiname='' uitype='lux_constructionquotes' value='{constructionQuote.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            var FinalRateItem = service.RetrieveMultiple(new FetchExpression(FinalRatingfetch)).Entities;
            if (FinalRateItem.Count > 0)
            {
                var NetPremium = FinalRateItem.Sum(x => x.Attributes.Contains("lux_nettechnicalpremium") ? x.GetAttributeValue<Money>("lux_nettechnicalpremium").Value : 0);
                var GrossPremiumQuoted = FinalRateItem.Sum(x => x.Attributes.Contains("lux_grosspolicypremiumquoted") ? x.GetAttributeValue<Money>("lux_grosspolicypremiumquoted").Value : 0);
                var GrossPremiumBound = FinalRateItem.Sum(x => x.Attributes.Contains("lux_grosspolicypremiumbound") ? x.GetAttributeValue<Money>("lux_grosspolicypremiumbound").Value : 0);

                var QuoteRateDeviation = (GrossPremiumQuoted / NetPremium) - 1;
                var BoundRateDeviation = (GrossPremiumBound / NetPremium) - 1;

                Entity application = service.Retrieve("lux_constructionquotes", constructionQuote.Id, new ColumnSet(false));
                application["lux_nettechnicalpremium"] = new Money(FinalRateItem.Sum(x => x.Attributes.Contains("lux_nettechnicalpremium") ? x.GetAttributeValue<Money>("lux_nettechnicalpremium").Value : 0));
                application["lux_ecv"] = new Money(FinalRateItem.Sum(x => x.Attributes.Contains("lux_grosspolicypremiumbound") ? x.GetAttributeValue<Money>("lux_grosspolicypremiumbound").Value : 0));
                application["lux_grosspolicypremiumbound"] = new Money(FinalRateItem.Sum(x => x.Attributes.Contains("lux_grosspolicypremiumbound") ? x.GetAttributeValue<Money>("lux_grosspolicypremiumbound").Value : 0));
                application["lux_quoteratedeviation"] = QuoteRateDeviation * 100;
                application["lux_boundratedeviation"] = BoundRateDeviation * 100;
                service.Update(application);
            }
        }
    }
}
