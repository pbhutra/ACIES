﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Net;
using System.ServiceModel.Description;
using System.Linq;

namespace CustomWorkflows
{
    public class SaveHazardInformation : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Input("Product")]
        public InArgument<string> Product { get; set; }

        [Output("IsDeclined")]
        public OutArgument<bool> IsDeclined { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference applnref = PropertyOwnersApplication.Get<EntityReference>(executionContext);
            Entity appln = new Entity(applnref.LogicalName, applnref.Id);
            appln = service.Retrieve("lux_propertyownersapplications", applnref.Id, new ColumnSet(true));

            if (Product.Get(executionContext).ToString() == "Property Owners" || Product.Get(executionContext).ToString() == "Unoccupied")
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownerspremise'>
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_declaredvalueforrebuildingthisproperty' />
                                <attribute name='lux_buildingconstruction' />
                                <attribute name='lux_occupancytype' />
                                <attribute name='lux_totalsuminsuredforthislocation' />
                                <attribute name='lux_landlordscontentsinresidentialareas' />
                                <attribute name='lux_totalnumberofcommercialunitsatthisaddress' />
                                <attribute name='lux_commercialunit1' />
                                <attribute name='lux_commercialunit2' />
                                <attribute name='lux_commercialunit3' />
                                <attribute name='lux_commercialunit4' />
                                <attribute name='lux_commercialunit5' />
                                <attribute name='lux_commercialunit6' />
                                <attribute name='lux_commercialunit7' />
                                <attribute name='lux_commercialunit8' />
                                <attribute name='lux_commercialunit9' />
                                <attribute name='lux_commercialunit10' />
                                <attribute name='lux_commercialunit11' />
                                <attribute name='lux_commercialunit12' />
                                <attribute name='lux_commercialunit13' />
                                <attribute name='lux_commercialunit14' />
                                <attribute name='lux_commercialunit15' />
                                <attribute name='lux_commercialunit16' />
                                <attribute name='lux_commercialunit17' />
                                <attribute name='lux_commercialunit18' />
                                <attribute name='lux_commercialunit19' />
                                <attribute name='lux_commercialunit20' />
                                <attribute name='lux_lossofannualrentalincome' />
                                <attribute name='lux_materialdamagefirerate' />
                                <attribute name='lux_indemnityperiodrequired' />
                                <attribute name='lux_propertyownerspremiseid' />
                                <attribute name='lux_covers' />
                                <attribute name='lux_businessinterruptionperilsrate' />
                                <attribute name='lux_businessinterruptionpremium' />
                                <attribute name='lux_materialdamageperilsrate' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplication' visible='false' link-type='outer' alias='poa'>
                                  <attribute name='lux_levelofcommission' />
                                  <attribute name='lux_whatisyourtrade' />
                                  <attribute name='lux_iselcoverrequired' />
                                  <attribute name='lux_isanyworkawaycarriedoutotherthanforcollec' />
                                </link-entity>
                              </entity>
                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    int ELTotal = 0;
                    var ELAction = "";
                    var premiseCount = 0;

                    var ELCover = (bool)((service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].GetAttributeValue<AliasedValue>("poa.lux_iselcoverrequired")).Value);
                    var WorkAwayCover = (bool)((service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].GetAttributeValue<AliasedValue>("poa.lux_isanyworkawaycarriedoutotherthanforcollec")).Value);

                    foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        var premise_data = item;
                        Guid Trade = new Guid();
                        int MDBI = 0;
                        int Products = 0;
                        int WorkAway = 0;
                        int Theift = 0;
                        int EL = 0;

                        var MDBIAction = "";
                        var ProductsAction = "";
                        var WorkAwayAction = "";
                        var TheiftAction = "";
                        var ISMDDeclined = false;
                        var IsELDeclined = false;

                        if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970002) //residential
                        {
                            Trade = new Guid("a5b3a7d4-9481-eb11-b1b3-000d3a7ed67b");
                            if (item.Contains("poa.lux_whatisyourtrade"))
                            {
                                if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970001)
                                {
                                    Trade = new Guid("c2ada7d4-9481-eb11-b1b3-000d3a7ed67b");
                                }
                                else if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970002)
                                {
                                    Trade = new Guid("9fb3a7d4-9481-eb11-b1b3-000d3a7ed67b");
                                }
                                else if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970003)
                                {
                                    Trade = new Guid("a5b3a7d4-9481-eb11-b1b3-000d3a7ed67b");
                                }
                                else if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970004)
                                {
                                    Trade = new Guid("a5b3a7d4-9481-eb11-b1b3-000d3a7ed67b");
                                }
                                else if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970005)
                                {
                                    Trade = new Guid("a3b3a7d4-9481-eb11-b1b3-000d3a7ed67b");
                                }
                            }

                            var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_propertyownersrateid' operator='eq' uiname='' uitype='lux_propertyownersrate' value='{Trade}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                            if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                            {
                                var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];
                                MDBI = FireData.GetAttributeValue<int>("lux_mdbi");
                                Products = FireData.GetAttributeValue<int>("lux_prods");
                                EL = FireData.GetAttributeValue<int>("lux_el");
                                WorkAway = FireData.GetAttributeValue<int>("lux_workaway");
                                Theift = FireData.GetAttributeValue<int>("lux_theft");

                                if (FireData.GetAttributeValue<int>("lux_mdbi") >= 6)
                                {
                                    ISMDDeclined = true;
                                }
                                if (FireData.GetAttributeValue<int>("lux_el") >= 6)
                                {
                                    IsELDeclined = true;
                                }
                            }
                        }
                        else if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970001 || item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970004) //commercial
                        {
                            var numberofTrades = item.Attributes.Contains("lux_totalnumberofcommercialunitsatthisaddress") ? item.GetAttributeValue<int>("lux_totalnumberofcommercialunitsatthisaddress") : 0;
                            if (numberofTrades > 0 && item.Attributes.Contains("lux_commercialunit1"))
                            {
                                for (int i = 1; i <= numberofTrades; i++)
                                {
                                    var fieldName = "lux_commercialunit" + i;
                                    Trade = item.GetAttributeValue<EntityReference>(fieldName).Id;

                                    var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_propertyownersrateid' operator='eq' uiname='' uitype='lux_propertyownersrate' value='{Trade}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                                    if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                                    {
                                        var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];
                                        MDBI += FireData.GetAttributeValue<int>("lux_mdbi");
                                        Products += FireData.GetAttributeValue<int>("lux_prods");
                                        EL += FireData.GetAttributeValue<int>("lux_el");
                                        WorkAway += FireData.GetAttributeValue<int>("lux_workaway");
                                        Theift += FireData.GetAttributeValue<int>("lux_theft");

                                        if (FireData.GetAttributeValue<int>("lux_mdbi") >= 6)
                                        {
                                            ISMDDeclined = true;
                                        }
                                        if (FireData.GetAttributeValue<int>("lux_el") >= 6)
                                        {
                                            IsELDeclined = true;
                                        }
                                    }
                                }

                                MDBI = MDBI / numberofTrades;
                                Products = Products / numberofTrades;
                                EL = EL / numberofTrades;
                                WorkAway = WorkAway / numberofTrades;
                                Theift = Theift / numberofTrades;
                            }
                        }

                        var HazardFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_hazardgrouplogic'>
                                                <attribute name='lux_name' />
                                                <attribute name='createdon' />
                                                <attribute name='lux_producttype' />
                                                <attribute name='lux_action' />
                                                <attribute name='lux_hazardgrouplogicid' />
                                                <order attribute='lux_name' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                </filter>
                                              </entity>
                                            </fetch>";
                        if (service.RetrieveMultiple(new FetchExpression(HazardFetch)).Entities.Count > 0)
                        {
                            var records = service.RetrieveMultiple(new FetchExpression(HazardFetch)).Entities;
                            if (MDBI > 0 && MDBI < 8)
                                MDBIAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == MDBI.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970001))).FormattedValues["lux_action"];
                            if (Products > 0 && Products < 8)
                                ProductsAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == Products.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970002))).FormattedValues["lux_action"];
                            if (EL > 0 && EL < 8)
                                ELAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == EL.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970003))).FormattedValues["lux_action"];
                            if (WorkAway > 0 && WorkAway < 8)
                                WorkAwayAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == WorkAway.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970004))).FormattedValues["lux_action"];
                            if (Theift > 0 && Theift < 8)
                                TheiftAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == Theift.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970005))).FormattedValues["lux_action"];
                        }

                        var item1 = service.Retrieve("lux_propertyownerspremise", item.Id, new ColumnSet(false));
                        item1["lux_mdbihazardgroup"] = MDBI;
                        item1["lux_mdbiaction"] = MDBIAction;
                        service.Update(item1);

                        ELTotal += EL;
                        premiseCount++;

                        if (ISMDDeclined == true)
                        {
                            this.IsDeclined.Set(executionContext, true);
                        }
                    }

                    ELTotal = ELTotal / premiseCount;

                    var HazardFetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_hazardgrouplogic'>
                                                <attribute name='lux_name' />
                                                <attribute name='createdon' />
                                                <attribute name='lux_producttype' />
                                                <attribute name='lux_action' />
                                                <attribute name='lux_hazardgrouplogicid' />
                                                <order attribute='lux_name' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                </filter>
                                              </entity>
                                            </fetch>";
                    if (service.RetrieveMultiple(new FetchExpression(HazardFetch1)).Entities.Count > 0)
                    {
                        var records = service.RetrieveMultiple(new FetchExpression(HazardFetch1)).Entities;
                        if (ELTotal > 0 && ELTotal < 8)
                            ELAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == ELTotal.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970003))).FormattedValues["lux_action"];
                    }

                    Entity application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                    application["lux_elhazardgroup"] = ELTotal;
                    application["lux_elaction"] = ELAction;
                    service.Update(application);

                    if (ELAction == "Decline" && ELCover == true)
                    {
                        this.IsDeclined.Set(executionContext, true);
                    }
                }
            }
            else
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_title' />
                                <attribute name='lux_postcode' />
                                <attribute name='lux_phonenumber' />
                                <attribute name='lux_lastname' />
                                <attribute name='lux_insuredtitle' />
                                <attribute name='lux_firstname' />
                                <attribute name='lux_quotenumber' />
                                <attribute name='lux_propertyownersapplicationsid' />
                                <attribute name='lux_maintradeforthispremises' />
                                <attribute name='lux_iselcoverrequired' />
                                <attribute name='lux_isanyworkawaycarriedoutotherthanforcollec' />
                                <order attribute='lux_quotenumber' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplicationsid' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        var premise_data = item;
                        Guid Trade = new Guid();
                        int MDBI = 0;
                        int Products = 0;
                        int EL = 0;
                        int WorkAway = 0;
                        int Theift = 0;

                        var MDBIAction = "";
                        var ProductsAction = "";
                        var ELAction = "";
                        var WorkAwayAction = "";
                        var TheiftAction = "";

                        Trade = item.GetAttributeValue<EntityReference>("lux_maintradeforthispremises").Id;
                        var ELCover = item.GetAttributeValue<bool>("lux_iselcoverrequired");
                        var WorkAwayCover = item.GetAttributeValue<bool>("lux_isanyworkawaycarriedoutotherthanforcollec");

                        var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_propertyownersrateid' operator='eq' uiname='' uitype='lux_propertyownersrate' value='{Trade}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                        {
                            var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];
                            MDBI = FireData.GetAttributeValue<int>("lux_mdbi");
                            Products = FireData.GetAttributeValue<int>("lux_prods");
                            EL = FireData.GetAttributeValue<int>("lux_el");
                            WorkAway = FireData.GetAttributeValue<int>("lux_workaway");
                            Theift = FireData.GetAttributeValue<int>("lux_theft");
                        }

                        if (appln.Attributes.Contains("lux_workawaytrade") && (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office"))
                        {
                            var FireRateFetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_propertyownersrateid' operator='eq' uiname='Fish And Chip Shop' uitype='lux_propertyownersrate' value='{appln.GetAttributeValue<EntityReference>("lux_workawaytrade").Id}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                            if (service.RetrieveMultiple(new FetchExpression(FireRateFetch1)).Entities.Count > 0)
                            {
                                var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch1)).Entities[0];
                                WorkAway = FireData.GetAttributeValue<int>("lux_workaway");
                            }
                        }

                        var HazardFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_hazardgrouplogic'>
                                                <attribute name='lux_name' />
                                                <attribute name='createdon' />
                                                <attribute name='lux_producttype' />
                                                <attribute name='lux_action' />
                                                <attribute name='lux_hazardgrouplogicid' />
                                                <order attribute='lux_name' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                </filter>
                                              </entity>
                                            </fetch>";
                        if (service.RetrieveMultiple(new FetchExpression(HazardFetch)).Entities.Count > 0)
                        {
                            var records = service.RetrieveMultiple(new FetchExpression(HazardFetch)).Entities;
                            if (MDBI > 0 && MDBI < 8)
                                MDBIAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == MDBI.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970001))).FormattedValues["lux_action"];
                            if (Products > 0 && Products < 8)
                                ProductsAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == Products.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970002))).FormattedValues["lux_action"];
                            if (EL > 0 && EL < 8)
                                ELAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == EL.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970003))).FormattedValues["lux_action"];
                            if (WorkAway > 0 && WorkAway < 8)
                                WorkAwayAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == WorkAway.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970004))).FormattedValues["lux_action"];
                            if (Theift > 0 && Theift < 8)
                                TheiftAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == Theift.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970005))).FormattedValues["lux_action"];
                        }

                        Entity application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());

                        application["lux_mdbihazardgroup"] = MDBI;
                        application["lux_workawayhazardgroup"] = WorkAway;
                        application["lux_thefthazardgroup"] = Theift;
                        application["lux_mdbiaction"] = MDBIAction;
                        application["lux_workawayaction"] = WorkAwayAction;
                        application["lux_theftaction"] = TheiftAction;
                        application["lux_elhazardgroup"] = EL;
                        application["lux_elaction"] = ELAction;
                        application["lux_plproductshazardgroup"] = Products;
                        application["lux_plproductsaction"] = ProductsAction;
                        service.Update(application);

                        if (MDBIAction == "Decline")
                        {
                            this.IsDeclined.Set(executionContext, true);
                        }

                        if (ELAction == "Decline" && ELCover == true)
                        {
                            this.IsDeclined.Set(executionContext, true);
                        }

                        if (ProductsAction == "Decline")
                        {
                            this.IsDeclined.Set(executionContext, true);
                        }

                        if (WorkAwayAction == "Decline" && WorkAwayCover == true)
                        {
                            this.IsDeclined.Set(executionContext, true);
                        }

                        if (TheiftAction == "Decline")
                        {
                            this.IsDeclined.Set(executionContext, true);
                        }
                    }
                }
            }
        }
    }
}
