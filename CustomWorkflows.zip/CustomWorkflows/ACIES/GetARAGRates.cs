﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class GetARAGRates : CodeActivity
    {
        [Input("Rate")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> Product { get; set; }

        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Output("Rate")]
        [ReferenceTarget("lux_aragrate")]
        public OutArgument<EntityReference> Rate { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var productData = service.Retrieve("product", this.Product.Get(executionContext).Id, new ColumnSet(true));

            EntityReference applnref = PropertyOwnersApplication.Get<EntityReference>(executionContext);
            Entity appln = new Entity(applnref.LogicalName, applnref.Id);
            appln = service.Retrieve("lux_propertyownersapplications", applnref.Id, new ColumnSet(true));

            if (productData.Attributes["name"].ToString() != "Commercial Combined" && productData.Attributes["name"].ToString() != "Office")
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_aragrate'>
                                <attribute name='createdon' />
                                <attribute name='lux_product' />
                                <attribute name='lux_netrate' />
                                <attribute name='lux_grossrate' />                                
                                <attribute name='lux_turnoverfrom' />
                                <attribute name='lux_turnoverto' />
                                <attribute name='lux_aragrateid' />
                                <order attribute='createdon' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_product' operator='eq' uiname='Property Owners' uitype='product' value='{this.Product.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {

                    var Rates = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                    Rate.Set(executionContext, Rates.ToEntityReference());
                }
            }
            else
            {
                if (appln.Attributes.Contains("lux_turnover"))
                {
                    var Turnover = appln.GetAttributeValue<Money>("lux_turnover").Value;
                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_aragrate'>
                                    <attribute name='createdon' />
                                    <attribute name='lux_product' />
                                    <attribute name='lux_netrate' />
                                    <attribute name='lux_grossrate' />
                                    <attribute name='lux_aragrateid' />
                                    <order attribute='createdon' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <filter type='or'>
                                        <filter type='and'>
                                          <condition attribute='lux_turnoverfrom' operator='le' value='{Turnover}' />
                                          <condition attribute='lux_turnoverto' operator='ge' value='{Turnover}' />
                                        </filter>
                                        <filter type='and'>
                                          <condition attribute='lux_turnoverfrom' operator='le' value='{Turnover}' />
                                          <condition attribute='lux_turnoverto' operator='null' />
                                        </filter>
                                      </filter>
                                    </filter>
                                  </entity>
                                </fetch>";
                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                    {
                        var Rates = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        Rate.Set(executionContext, Rates.ToEntityReference());
                    }
                }
            }
        }
    }
}
