﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CustomWorkflows
{
    public class CreateMultiOccupancyDocs : CodeActivity
    {
        //[Input("Email Message")]
        //[ReferenceTarget("email")]
        //public InArgument<EntityReference> EmailMessage { get; set; }

        [Input("Product")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> Product { get; set; }

        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Output("IsResidentialTenant")]
        public OutArgument<bool> IsResidentialTenant { get; set; }

        //[Input("Sharepoint Policy Folder Name")]
        //public InArgument<string> SharepointPolicyFolder { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var productData = service.Retrieve("product", this.Product.Get(executionContext).Id, new ColumnSet(true));

            EntityReference applnref = PropertyOwnersApplication.Get<EntityReference>(executionContext);
            Entity appln = new Entity(applnref.LogicalName, applnref.Id);
            appln = service.Retrieve("lux_propertyownersapplications", applnref.Id, new ColumnSet(true));
            var IsResidential = false;

            if (productData.Attributes["name"].ToString() == "Property Owners")
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownerspremise'>
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_propertyownerspremiseid' />
                                <attribute name='lux_locationnumber' />  
                                <attribute name='lux_occupancytype' />
                                <attribute name='lux_otherpropertieswithsameaddress' />
                                <attribute name='lux_name' />
                                <order attribute='lux_locationnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id.ToString()}' />
                                </filter>
                              </entity>
                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        var Address = item.Attributes["lux_name"].ToString().ToLower().Trim();
                        var OtherPropertyWithSameAddress = item.Attributes.Contains("lux_otherpropertieswithsameaddress") ? item.GetAttributeValue<bool>("lux_otherpropertieswithsameaddress") : false;
                        var OccupancyType = item.Attributes.Contains("lux_occupancytype") ? item.FormattedValues["lux_occupancytype"].ToString() : "Residential";
                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Where(x => x.Attributes["lux_name"].ToString().ToLower().Trim() == Address).Count() > 1 && OtherPropertyWithSameAddress == false)
                        {
                            item.Attributes["lux_otherpropertieswithsameaddress"] = true;
                            service.Update(item);
                        }
                        else if (OtherPropertyWithSameAddress == true || !item.Attributes.Contains("lux_otherpropertieswithsameaddress"))
                        {
                            item.Attributes["lux_otherpropertieswithsameaddress"] = false;
                            service.Update(item);
                        }

                        if (OccupancyType.Contains("Residential"))
                        {
                            IsResidential = true;
                        }
                    }

                    IsResidentialTenant.Set(executionContext, IsResidential);

                    //foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    //{
                    //    var OccupancyType = item.Attributes.Contains("lux_occupancytype") ? item.FormattedValues["lux_occupancytype"].ToString() : "Residential";

                    //    if (OccupancyType.Contains("Residential"))
                    //    {
                    //        IsResidential = true;

                    //        Entity entity = new Entity("ptm_automergeworkingitems");
                    //        entity["ptm_name"] = "Create CPO - Insured Perils, Endorsements and Excesses Document";
                    //        entity["ptm_automergeaction"] = new OptionSetValue(956670000);
                    //        entity["ownerid"] = new EntityReference("systemuser", new Guid("16f70c4c-ae63-eb11-b0b0-000d3a7ed52b"));
                    //        entity["ptm_primaryrecordurl"] = "https://aciesmanagementholdings-uat.crm11.dynamics.com/main.aspx?etc=10245&id=" + item.Id + "&pagetype=entityrecord";
                    //        entity["ptm_templatetoexecute"] = new EntityReference("ptm_mscrmaddons_dcptemplates", new Guid("fd18bf57-26dd-ee11-904d-00224840d1c9"));
                    //        entity["ptm_saveas"] = new OptionSetValue(956670008);
                    //        entity["ptm_saveonlyintotemp"] = false;
                    //        entity["ptm_emailtoattacheid"] = new EntityReference("email", new Guid(EmailMessage.Get(executionContext).Id.ToString()));
                    //        entity["ptm_converttopdf"] = true;
                    //        entity["ptm_entitytoattachid"] = "https://aciesmanagementholdings-uat.crm11.dynamics.com/main.aspx?etc=10244&id=" + appln.Id.ToString() + "&pagetype=entityrecord";
                    //        if (!string.IsNullOrEmpty(SharepointPolicyFolder.Get(executionContext)))
                    //        {
                    //            entity["ptm_sharepointurl"] = SharepointPolicyFolder.Get(executionContext).ToString() + "/";
                    //            entity["ptm_direction"] = new OptionSetValue(956670001);
                    //        }

                    //        Guid entityId = service.Create(entity);

                    //        Entity dcpdoc = service.Retrieve("ptm_automergeworkingitems", entityId, new ColumnSet(true));
                    //        var returnValue = dcpdoc.Attributes.Contains("ptm_returnvalue") ? dcpdoc.Attributes["ptm_returnvalue"].ToString() : "";
                    //        while (!returnValue.Contains("AUTOMERGE"))
                    //        {
                    //            dcpdoc = service.Retrieve("ptm_automergeworkingitems", entityId, new ColumnSet(true));
                    //            returnValue = dcpdoc.Attributes.Contains("ptm_returnvalue") ? dcpdoc.Attributes["ptm_returnvalue"].ToString() : "";
                    //        }


                    //        Entity entity1 = new Entity("ptm_automergeworkingitems");
                    //        entity1["ptm_name"] = "MOBI remuneration and COI disclosure Document";
                    //        entity1["ptm_automergeaction"] = new OptionSetValue(956670000);
                    //        entity1["ownerid"] = new EntityReference("systemuser", new Guid("16f70c4c-ae63-eb11-b0b0-000d3a7ed52b"));
                    //        entity1["ptm_primaryrecordurl"] = "https://aciesmanagementholdings-uat.crm11.dynamics.com/main.aspx?etc=10245&id=" + item.Id + "&pagetype=entityrecord";
                    //        entity1["ptm_templatetoexecute"] = new EntityReference("ptm_mscrmaddons_dcptemplates", new Guid("22cb60bc-1cdd-ee11-904d-00224840d1c9"));
                    //        entity1["ptm_saveas"] = new OptionSetValue(956670008);
                    //        entity1["ptm_saveonlyintotemp"] = false;
                    //        entity1["ptm_emailtoattacheid"] = new EntityReference("email", new Guid(EmailMessage.Get(executionContext).Id.ToString()));
                    //        entity1["ptm_converttopdf"] = true;
                    //        entity1["ptm_entitytoattachid"] = "https://aciesmanagementholdings-uat.crm11.dynamics.com/main.aspx?etc=10244&id=" + appln.Id.ToString() + "&pagetype=entityrecord";
                    //        if (!string.IsNullOrEmpty(SharepointPolicyFolder.Get(executionContext)))
                    //        {
                    //            entity1["ptm_sharepointurl"] = SharepointPolicyFolder.Get(executionContext).ToString() + "/";
                    //            entity1["ptm_direction"] = new OptionSetValue(956670001);
                    //        }

                    //        Guid entity1Id = service.Create(entity1);
                    //        Entity dcpdoc1 = service.Retrieve("ptm_automergeworkingitems", entity1Id, new ColumnSet(true));
                    //        var returnValue1 = dcpdoc1.Attributes.Contains("ptm_returnvalue") ? dcpdoc1.Attributes["ptm_returnvalue"].ToString() : "";
                    //        while (!returnValue1.Contains("AUTOMERGE"))
                    //        {
                    //            dcpdoc1 = service.Retrieve("ptm_automergeworkingitems", entity1Id, new ColumnSet(true));
                    //            returnValue1 = dcpdoc1.Attributes.Contains("ptm_returnvalue") ? dcpdoc1.Attributes["ptm_returnvalue"].ToString() : "";
                    //        }
                    //    }
                    //}

                    //if (IsResidential == true)
                    //{
                    //    Entity entity = new Entity("ptm_automergeworkingitems");
                    //    entity["ptm_name"] = "Residential Property Owners Insurance Key Facts for Leaseholders";
                    //    entity["ptm_automergeaction"] = new OptionSetValue(956670000);
                    //    entity["ownerid"] = new EntityReference("systemuser", new Guid("16f70c4c-ae63-eb11-b0b0-000d3a7ed52b"));
                    //    entity["ptm_primaryrecordurl"] = "https://aciesmanagementholdings-uat.crm11.dynamics.com/main.aspx?etc=10244&id=" + appln.Id.ToString() + "&pagetype=entityrecord";
                    //    entity["ptm_templatetoexecute"] = new EntityReference("ptm_mscrmaddons_dcptemplates", new Guid("cfec307f-13dd-ee11-904d-00224840d45a"));
                    //    entity["ptm_saveas"] = new OptionSetValue(956670008);
                    //    entity["ptm_saveonlyintotemp"] = false;
                    //    entity["ptm_emailtoattacheid"] = new EntityReference("email", new Guid(EmailMessage.Get(executionContext).Id.ToString()));
                    //    entity["ptm_converttopdf"] = true;
                    //    entity["ptm_entitytoattachid"] = "https://aciesmanagementholdings-uat.crm11.dynamics.com/main.aspx?etc=10244&id=" + appln.Id.ToString() + "&pagetype=entityrecord";
                    //    if (!string.IsNullOrEmpty(SharepointPolicyFolder.Get(executionContext)))
                    //    {
                    //        entity["ptm_sharepointurl"] = SharepointPolicyFolder.Get(executionContext).ToString() + "/";
                    //        entity["ptm_direction"] = new OptionSetValue(956670001);
                    //    }

                    //    Guid entityId = service.Create(entity);

                    //    Entity dcpdoc = service.Retrieve("ptm_automergeworkingitems", entityId, new ColumnSet(true));
                    //    var returnValue = dcpdoc.Attributes.Contains("ptm_returnvalue") ? dcpdoc.Attributes["ptm_returnvalue"].ToString() : "";
                    //    while (!returnValue.Contains("AUTOMERGE"))
                    //    {
                    //        dcpdoc = service.Retrieve("ptm_automergeworkingitems", entityId, new ColumnSet(true));
                    //        returnValue = dcpdoc.Attributes.Contains("ptm_returnvalue") ? dcpdoc.Attributes["ptm_returnvalue"].ToString() : "";
                    //    }
                    //}
                }
            }
            else if (productData.Attributes["name"].ToString() == "Terrorism")
            {

            }
        }
    }
}
