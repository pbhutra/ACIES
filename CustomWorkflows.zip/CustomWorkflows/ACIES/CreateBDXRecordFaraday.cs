﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CustomWorkflows
{
    public class CreateBDXRecordFaraday : CodeActivity
    {
        [Input("Policy")]
        [ReferenceTarget("lux_policy")]
        [RequiredArgument]
        public InArgument<EntityReference> Policy { get; set; }

        [Input("Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        [RequiredArgument]
        public InArgument<EntityReference> Application { get; set; }

        [Input("Tradesman Application")]
        [ReferenceTarget("lux_tradesman")]
        [RequiredArgument]
        public InArgument<EntityReference> TradesmanApplication { get; set; }

        [RequiredArgument]
        [Input("Product")]
        public InArgument<string> Product { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            var ProductName = Product.Get<string>(executionContext).ToString();

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference policyref = Policy.Get<EntityReference>(executionContext);
            Entity policy = service.Retrieve("lux_policy", policyref.Id, new ColumnSet(true));

            if (!ProductName.Contains("Tradesman")) //Tradesman
            {
                EntityReference appref = Application.Get<EntityReference>(executionContext);
                Entity appln = service.Retrieve("lux_propertyownersapplications", appref.Id, new ColumnSet(true));
                bool isIsleofManPolicy = false;
                if (appln.Attributes.Contains("lux_isisleofmanrisk") && appln.GetAttributeValue<bool>("lux_isisleofmanrisk") == true)
                {
                    isIsleofManPolicy = true;
                }

                Entity bdx = new Entity("lux_faradaybdx");
                bdx["lux_application"] = new EntityReference("lux_propertyownersapplications", appref.Id);
                bdx["lux_policy"] = new EntityReference("lux_policy", policyref.Id);
                if (appln.GetAttributeValue<bool>("lux_iselcoverrequired") == true || (appln.GetAttributeValue<bool>("lux_ispublicandproductsliabilitycoverrequired") == true && !(ProductName.Contains("Property Owners") || ProductName.Contains("Unoccupied"))))
                {
                    if (appln.Attributes.Contains("lux_ernexempt") && appln.GetAttributeValue<bool>("lux_ernexempt") == false)
                    {
                        bdx["lux_erncodeelonly"] = appln.Attributes.Contains("lux_eltoernnumber") ? appln.Attributes["lux_eltoernnumber"].ToString() : "";
                    }
                    bdx["lux_ernexemptflag"] = appln.Attributes.Contains("lux_ernexempt") ? appln.GetAttributeValue<bool>("lux_ernexempt") : false;
                    if (appln.Attributes.Contains("lux_policyholdertype"))
                    {
                        bdx["lux_customerclassification"] = new OptionSetValue(appln.GetAttributeValue<OptionSetValue>("lux_policyholdertype").Value);
                    }

                    if (appln.Attributes.Contains("lux_policyholdertype"))
                    {
                        if (ProductName.Contains("Property Owners") || ProductName.Contains("Unoccupied") || ProductName.Contains("Retail") || ProductName.Contains("Contractors Combined") || ProductName.Contains("Commercial Combined") || ProductName.Contains("Office"))
                        {
                            bdx["lux_turnover"] = new Money(appln.Attributes.Contains("lux_turnover") ? appln.GetAttributeValue<Money>("lux_turnover").Value : 0);
                        }
                        else if (ProductName.Contains("Pubs & Restaurants") || ProductName.Contains("Hotels and Guesthouses"))
                        {
                            bdx["lux_turnover"] = new Money(appln.Attributes.Contains("lux_ukturnover") ? appln.GetAttributeValue<Money>("lux_ukturnover").Value : 0);
                        }
                    }
                    else
                    {
                        if (ProductName.Contains("Property Owners") || ProductName.Contains("Unoccupied"))
                        {
                            bdx["lux_turnover"] = new Money(appln.Attributes.Contains("lux_turnover") ? appln.GetAttributeValue<Money>("lux_turnover").Value : 0);
                        }
                        else if (ProductName.Contains("Pubs & Restaurants") || ProductName.Contains("Hotels and Guesthouses"))
                        {
                            bdx["lux_turnover"] = new Money(appln.Attributes.Contains("lux_ukturnover") ? appln.GetAttributeValue<Money>("lux_ukturnover").Value : 0);
                        }
                        else if (ProductName.Contains("Retail") || ProductName.Contains("Contractors Combined") || ProductName.Contains("Commercial Combined") || ProductName.Contains("Office"))
                        {
                            bdx["lux_turnover"] = new Money(appln.Attributes.Contains("lux_turnover") ? appln.GetAttributeValue<Money>("lux_turnover").Value : 0);
                        }
                    }

                    bdx["lux_entrynumber"] = "";
                    bdx["lux_entrydate"] = DateTime.UtcNow;
                    bdx["lux_certificateorpolicynumber"] = policy.Attributes.Contains("lux_policynumber") ? policy.Attributes["lux_policynumber"].ToString() : ""; ;
                    bdx["lux_name"] = appln.Attributes.Contains("lux_insuredtitle") ? appln.Attributes["lux_insuredtitle"] : "";
                    bdx["lux_parentorchild"] = false;
                    bdx["lux_coverholdertradecode"] = "";
                    if (ProductName.Contains("Property Owners") || ProductName.Contains("Unoccupied"))
                    {
                        if (appln.GetAttributeValue<OptionSetValue>("lux_rpocpoproducttype").Value == 972970001 || appln.GetAttributeValue<OptionSetValue>("lux_rpocpoproducttype").Value == 972970003)
                        {
                            bdx["lux_fdytradecode"] = appln.Attributes.Contains("lux_whatisyourtrade") ? appln.FormattedValues["lux_whatisyourtrade"] : "";
                        }
                        else if (appln.GetAttributeValue<OptionSetValue>("lux_rpocpoproducttype").Value == 972970002 || appln.GetAttributeValue<OptionSetValue>("lux_rpocpoproducttype").Value == 972970004)
                        {
                            bdx["lux_fdytradecode"] = appln.Attributes.Contains("lux_commercialtrades") ? appln.Attributes["lux_commercialtrades"] : "";
                        }
                        bdx["lux_tradeoroccupationdescriptionperpolicy"] = "Property Owners";
                    }
                    else
                    {
                        var trade = "";
                        if (appln.Attributes.Contains("lux_maintradeforthispremises"))
                        {
                            trade = appln.FormattedValues["lux_maintradeforthispremises"];
                        }
                        if (appln.Attributes.Contains("lux_secondarytradeofthebusiness"))
                        {
                            trade = trade + " ," + appln.FormattedValues["lux_secondarytradeofthebusiness"];
                        }
                        bdx["lux_fdytradecode"] = trade;
                        bdx["lux_tradeoroccupationdescriptionperpolicy"] = appln.Attributes.Contains("lux_businessdescription") ? appln.Attributes["lux_businessdescription"] : "";
                    }

                    bdx["lux_address"] = (appln.Attributes.Contains("lux_housenumber") ? appln.Attributes["lux_housenumber"] + ", " : "") + (appln.Attributes.Contains("lux_street") ? appln.Attributes["lux_street"] + ", " : "") + (appln.Attributes.Contains("lux_citycounty") ? appln.Attributes["lux_citycounty"] : "");
                    bdx["lux_postcode"] = appln.Attributes.Contains("lux_postcode") == true ? appln.Attributes["lux_postcode"] : "";
                    bdx["lux_referred"] = false;
                    bdx["lux_underwriter"] = true;
                    bdx["lux_liabilitysurvey"] = false;
                    bdx["lux_inceptiondate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                    bdx["lux_expirydate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                    bdx["lux_policyissuancedate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                    bdx["lux_currency"] = "GBP";
                    if (appln.Attributes.Contains("lux_limitofindemnity") && appln.GetAttributeValue<bool>("lux_iselcoverrequired") == true)
                    {
                        bdx["lux_ellimitofindemnity"] = new OptionSetValue(appln.GetAttributeValue<OptionSetValue>("lux_limitofindemnity").Value);
                    }
                    if (appln.Attributes.Contains("lux_pllimitofindemnity") && appln.GetAttributeValue<bool>("lux_ispublicandproductsliabilitycoverrequired") == true && !(ProductName.Contains("Property Owners") || ProductName.Contains("Unoccupied")))
                    {
                        bdx["lux_pllimitofindemnity"] = new OptionSetValue(appln.GetAttributeValue<OptionSetValue>("lux_pllimitofindemnity").Value);
                    }
                    if (appln.FormattedValues["lux_applicationtype"] == "New Business")
                    {
                        var GrossEL = appln.Attributes.Contains("lux_employersliabilitypolicypremium") ? appln.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0;
                        var GrossPL = appln.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? appln.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0;
                        var BrokerComm = appln.Attributes.Contains("lux_policybrokercommission") ? Convert.ToDecimal(appln.Attributes["lux_policybrokercommission"].ToString().Replace("%", "")) : 0;
                        var ACIESComm = appln.Attributes.Contains("lux_policyaciescommissionliability") ? Convert.ToDecimal(appln.Attributes["lux_policyaciescommissionliability"].ToString().Replace("%", "")) : 0;
                        if (ProductName.Contains("Contractors Combined"))
                        {
                            ACIESComm = appln.Attributes.Contains("lux_policyaciescommission") ? Convert.ToDecimal(appln.Attributes["lux_policyaciescommission"].ToString().Replace("%", "")) : 0;
                        }
                        var TotalComm = BrokerComm + ACIESComm;

                        bdx["lux_riskstatus"] = new OptionSetValue(972970001);
                        bdx["lux_premiumtransactiontype"] = new OptionSetValue(972970001);
                        bdx["lux_iptel"] = new Money(isIsleofManPolicy == false ? GrossEL * 12 / 100 : 0);
                        bdx["lux_iptpl"] = new Money(isIsleofManPolicy == false ? GrossPL * 12 / 100 : 0);
                        bdx["lux_grossel"] = new Money(GrossEL);
                        bdx["lux_grosspl"] = new Money(GrossPL);
                        bdx["lux_netel"] = new Money(GrossEL - GrossEL * TotalComm / 100);
                        bdx["lux_netpl"] = new Money(GrossPL - GrossPL * TotalComm / 100);
                        bdx["lux_netei"] = new Money(0);
                        bdx["lux_commissionel"] = new Money(GrossEL * TotalComm / 100);
                        bdx["lux_commissionpl"] = new Money(GrossPL * TotalComm / 100);
                        bdx["lux_otherfees"] = new Money(appln.Attributes.Contains("lux_policyfee") ? appln.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                    }
                    else if (appln.FormattedValues["lux_applicationtype"] == "Renewal")
                    {
                        var GrossEL = appln.Attributes.Contains("lux_employersliabilitypolicypremium") ? appln.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0;
                        var GrossPL = appln.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? appln.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0;
                        var BrokerComm = appln.Attributes.Contains("lux_policybrokercommission") ? Convert.ToDecimal(appln.Attributes["lux_policybrokercommission"].ToString().Replace("%", "")) : 0;
                        var ACIESComm = appln.Attributes.Contains("lux_policyaciescommissionliability") ? Convert.ToDecimal(appln.Attributes["lux_policyaciescommissionliability"].ToString().Replace("%", "")) : 0;
                        if (ProductName.Contains("Contractors Combined"))
                        {
                            ACIESComm = appln.Attributes.Contains("lux_policyaciescommission") ? Convert.ToDecimal(appln.Attributes["lux_policyaciescommission"].ToString().Replace("%", "")) : 0;
                        }
                        var TotalComm = BrokerComm + ACIESComm;

                        bdx["lux_riskstatus"] = new OptionSetValue(972970002);
                        bdx["lux_premiumtransactiontype"] = new OptionSetValue(972970001);
                        bdx["lux_iptel"] = new Money(isIsleofManPolicy == false ? GrossEL * 12 / 100 : 0);
                        bdx["lux_iptpl"] = new Money(isIsleofManPolicy == false ? GrossPL * 12 / 100 : 0);
                        bdx["lux_grossel"] = new Money(GrossEL);
                        bdx["lux_grosspl"] = new Money(GrossPL);
                        bdx["lux_netel"] = new Money(GrossEL - GrossEL * TotalComm / 100);
                        bdx["lux_netpl"] = new Money(GrossPL - GrossPL * TotalComm / 100);
                        bdx["lux_netei"] = new Money(0);
                        bdx["lux_commissionel"] = new Money(GrossEL * TotalComm / 100);
                        bdx["lux_commissionpl"] = new Money(GrossPL * TotalComm / 100);
                        bdx["lux_otherfees"] = new Money(appln.Attributes.Contains("lux_policyfee") ? appln.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                    }
                    else if (appln.FormattedValues["lux_applicationtype"] == "Cancellation")
                    {
                        var GrossEL = appln.Attributes.Contains("lux_employersliabilitymtapremium") ? appln.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0;
                        var GrossPL = appln.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? appln.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0;
                        var BrokerComm = appln.Attributes.Contains("lux_mtabrokercommissionpercentage") ? Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", "")) : 0;
                        var ACIESComm = appln.Attributes.Contains("lux_policyaciescommissionliability") ? Convert.ToDecimal(appln.Attributes["lux_policyaciescommissionliability"].ToString().Replace("%", "")) : 0;
                        if (ProductName.Contains("Contractors Combined"))
                        {
                            ACIESComm = appln.Attributes.Contains("lux_policyaciescommission") ? Convert.ToDecimal(appln.Attributes["lux_policyaciescommission"].ToString().Replace("%", "")) : 0;
                        }
                        var TotalComm = BrokerComm + ACIESComm;

                        bdx["lux_cancellationdate"] = Convert.ToDateTime(appln.Attributes.Contains("lux_mtadate") == true ? appln.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_cancellationreason"] = new OptionSetValue(appln.Attributes.Contains("lux_reasonforcancellation") ? appln.GetAttributeValue<OptionSetValueCollection>("lux_reasonforcancellation").FirstOrDefault().Value : 972970010);
                        bdx["lux_riskstatus"] = new OptionSetValue(972970003);
                        bdx["lux_premiumtransactiontype"] = new OptionSetValue(972970002);
                        bdx["lux_iptel"] = new Money(isIsleofManPolicy == false ? GrossEL * 12 / 100 : 0);
                        bdx["lux_iptpl"] = new Money(isIsleofManPolicy == false ? GrossPL * 12 / 100 : 0);
                        bdx["lux_grossel"] = new Money(GrossEL);
                        bdx["lux_grosspl"] = new Money(GrossPL);
                        bdx["lux_netel"] = new Money(GrossEL - GrossEL * TotalComm / 100);
                        bdx["lux_netpl"] = new Money(GrossPL - GrossPL * TotalComm / 100);
                        bdx["lux_netei"] = new Money(0);
                        bdx["lux_commissionel"] = new Money(GrossEL * TotalComm / 100);
                        bdx["lux_commissionpl"] = new Money(GrossPL * TotalComm / 100);
                        bdx["lux_otherfees"] = new Money(appln.Attributes.Contains("lux_mtapolicyfee") ? appln.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);
                    }
                    else if (appln.FormattedValues["lux_applicationtype"] == "MTA")
                    {
                        var GrossEL = appln.Attributes.Contains("lux_employersliabilitymtapremium") ? appln.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0;
                        var GrossPL = appln.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? appln.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0;
                        var BrokerComm = appln.Attributes.Contains("lux_mtabrokercommissionpercentage") ? Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", "")) : 0;
                        var ACIESComm = appln.Attributes.Contains("lux_policyaciescommissionliability") ? Convert.ToDecimal(appln.Attributes["lux_policyaciescommissionliability"].ToString().Replace("%", "")) : 0;
                        if (ProductName.Contains("Contractors Combined"))
                        {
                            ACIESComm = appln.Attributes.Contains("lux_policyaciescommission") ? Convert.ToDecimal(appln.Attributes["lux_policyaciescommission"].ToString().Replace("%", "")) : 0;
                        }
                        var TotalComm = BrokerComm + ACIESComm;

                        bdx["lux_riskstatus"] = new OptionSetValue(972970004);
                        if (GrossEL + GrossPL >= 0)
                        {
                            bdx["lux_premiumtransactiontype"] = new OptionSetValue(972970003);
                        }
                        else if (GrossEL + GrossPL < 0)
                        {
                            bdx["lux_premiumtransactiontype"] = new OptionSetValue(972970002);
                        }

                        bdx["lux_mtadate"] = Convert.ToDateTime(appln.Attributes.Contains("lux_mtadate") == true ? appln.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_iptel"] = new Money(isIsleofManPolicy == false ? GrossEL * 12 / 100 : 0);
                        bdx["lux_iptpl"] = new Money(isIsleofManPolicy == false ? GrossPL * 12 / 100 : 0);
                        bdx["lux_grossel"] = new Money(GrossEL);
                        bdx["lux_grosspl"] = new Money(GrossPL);
                        bdx["lux_netel"] = new Money(GrossEL - GrossEL * TotalComm / 100);
                        bdx["lux_netpl"] = new Money(GrossPL - GrossPL * TotalComm / 100);
                        bdx["lux_netei"] = new Money(0);
                        bdx["lux_commissionel"] = new Money(GrossEL * TotalComm / 100);
                        bdx["lux_commissionpl"] = new Money(GrossPL * TotalComm / 100);
                        bdx["lux_otherfees"] = new Money(appln.Attributes.Contains("lux_mtapolicyfee") ? appln.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);
                    }
                    bdx["lux_premiumbasis"] = new OptionSetValue(972970001);
                    bdx["lux_wageroll"] = new Money(appln.Attributes.Contains("lux_totalwageroll") ? appln.GetAttributeValue<Money>("lux_totalwageroll").Value : 0);
                    //bdx["lux_rateincrease"] = new decimal(0.1);
                    service.Create(bdx);
                }
            }
            else
            {
                EntityReference tradesmanref = TradesmanApplication.Get<EntityReference>(executionContext);
                Entity appln = service.Retrieve("lux_tradesman", tradesmanref.Id, new ColumnSet(true));

                bool isIsleofManPolicy = false;
                if (appln.Attributes.Contains("lux_isisleofmanrisk") && appln.GetAttributeValue<bool>("lux_isisleofmanrisk") == true)
                {
                    isIsleofManPolicy = true;
                }

                Entity bdx = new Entity("lux_faradaybdx");
                bdx["lux_tradesman"] = new EntityReference("lux_tradesman", tradesmanref.Id);
                bdx["lux_policy"] = new EntityReference("lux_policy", policyref.Id);

                if (appln.GetAttributeValue<bool>("lux_employersliability") == true || appln.GetAttributeValue<bool>("lux_publicliability") == true)
                {
                    if (appln.Attributes.Contains("lux_ernexempt") && appln.GetAttributeValue<bool>("lux_ernexempt") == false)
                    {
                        bdx["lux_erncodeelonly"] = appln.Attributes.Contains("lux_eltoernnumber") ? appln.Attributes["lux_eltoernnumber"].ToString() : "";
                    }
                    bdx["lux_ernexemptflag"] = appln.Attributes.Contains("lux_ernexempt") ? appln.GetAttributeValue<bool>("lux_ernexempt") : false;

                    if (appln.Attributes.Contains("lux_policyholdertype"))
                    {
                        bdx["lux_customerclassification"] = new OptionSetValue(appln.GetAttributeValue<OptionSetValue>("lux_policyholdertype").Value);
                    }

                    bdx["lux_entrynumber"] = "";
                    bdx["lux_entrydate"] = DateTime.UtcNow;
                    bdx["lux_certificateorpolicynumber"] = policy.Attributes.Contains("lux_policynumber") ? policy.Attributes["lux_policynumber"].ToString() : "";
                    bdx["lux_name"] = appln.Attributes.Contains("lux_insuredtitle") ? appln.Attributes["lux_insuredtitle"] : "";
                    bdx["lux_parentorchild"] = false;
                    bdx["lux_coverholdertradecode"] = "";

                    var trade = "";
                    if (appln.Attributes.Contains("lux_whatisyourtrade"))
                    {
                        trade = appln.FormattedValues["lux_whatisyourtrade"];
                        bdx["lux_fdytradecode"] = trade;
                        bdx["lux_tradeoroccupationdescriptionperpolicy"] = trade;
                    }

                    bdx["lux_address"] = (appln.Attributes.Contains("lux_housenumber") ? appln.Attributes["lux_housenumber"] + ", " : "") + (appln.Attributes.Contains("lux_street") ? appln.Attributes["lux_street"] + ", " : "") + (appln.Attributes.Contains("lux_citycounty") ? appln.Attributes["lux_citycounty"] : "");
                    bdx["lux_postcode"] = appln.Attributes.Contains("lux_postcode") == true ? appln.Attributes["lux_postcode"] : "";
                    bdx["lux_referred"] = false;
                    bdx["lux_underwriter"] = true;
                    bdx["lux_liabilitysurvey"] = false;
                    bdx["lux_inceptiondate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                    bdx["lux_expirydate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policyenddate") == true ? policy.FormattedValues["lux_policyenddate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                    bdx["lux_policyissuancedate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                    bdx["lux_currency"] = "GBP";

                    if (appln.FormattedValues["lux_applicationtype"] == "New Business")
                    {
                        var GrossEL = appln.Attributes.Contains("lux_elpolicypremium") ? appln.GetAttributeValue<Money>("lux_elpolicypremium").Value : 0;
                        var GrossPL = appln.Attributes.Contains("lux_plpolicypremium") ? appln.GetAttributeValue<Money>("lux_plpolicypremium").Value : 0;
                        var BrokerComm = appln.Attributes.Contains("lux_policybrokercommission") ? Convert.ToDecimal(appln.Attributes["lux_policybrokercommission"].ToString().Replace("%", "")) : 0;
                        var ACIESComm = appln.Attributes.Contains("lux_policyaciescommission") ? Convert.ToDecimal(appln.Attributes["lux_policyaciescommission"].ToString().Replace("%", "")) : 0;
                        var TotalComm = BrokerComm + ACIESComm;

                        bdx["lux_riskstatus"] = new OptionSetValue(972970001);
                        bdx["lux_premiumtransactiontype"] = new OptionSetValue(972970001);
                        bdx["lux_iptel"] = new Money(isIsleofManPolicy == false ? GrossEL * 12 / 100 : 0);
                        bdx["lux_iptpl"] = new Money(isIsleofManPolicy == false ? GrossPL * 12 / 100 : 0);
                        bdx["lux_grossel"] = new Money(GrossEL);
                        bdx["lux_grosspl"] = new Money(GrossPL);
                        bdx["lux_netel"] = new Money(GrossEL - GrossEL * TotalComm / 100);
                        bdx["lux_netpl"] = new Money(GrossPL - GrossPL * TotalComm / 100);
                        bdx["lux_netei"] = new Money(0);
                        bdx["lux_commissionel"] = new Money(GrossEL * TotalComm / 100);
                        bdx["lux_commissionpl"] = new Money(GrossPL * TotalComm / 100);
                        bdx["lux_otherfees"] = new Money(appln.Attributes.Contains("lux_policyfee") ? appln.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                    }
                    else if (appln.FormattedValues["lux_applicationtype"] == "Renewal")
                    {
                        var GrossEL = appln.Attributes.Contains("lux_elpolicypremium") ? appln.GetAttributeValue<Money>("lux_elpolicypremium").Value : 0;
                        var GrossPL = appln.Attributes.Contains("lux_plpolicypremium") ? appln.GetAttributeValue<Money>("lux_plpolicypremium").Value : 0;
                        var BrokerComm = appln.Attributes.Contains("lux_policybrokercommission") ? Convert.ToDecimal(appln.Attributes["lux_policybrokercommission"].ToString().Replace("%", "")) : 0;
                        var ACIESComm = appln.Attributes.Contains("lux_policyaciescommission") ? Convert.ToDecimal(appln.Attributes["lux_policyaciescommission"].ToString().Replace("%", "")) : 0;
                        var TotalComm = BrokerComm + ACIESComm;

                        bdx["lux_riskstatus"] = new OptionSetValue(972970002);
                        bdx["lux_premiumtransactiontype"] = new OptionSetValue(972970001);
                        bdx["lux_iptel"] = new Money(isIsleofManPolicy == false ? GrossEL * 12 / 100 : 0);
                        bdx["lux_iptpl"] = new Money(isIsleofManPolicy == false ? GrossPL * 12 / 100 : 0);
                        bdx["lux_grossel"] = new Money(GrossEL);
                        bdx["lux_grosspl"] = new Money(GrossPL);
                        bdx["lux_netel"] = new Money(GrossEL - GrossEL * TotalComm / 100);
                        bdx["lux_netpl"] = new Money(GrossPL - GrossPL * TotalComm / 100);
                        bdx["lux_netei"] = new Money(0);
                        bdx["lux_commissionel"] = new Money(GrossEL * TotalComm / 100);
                        bdx["lux_commissionpl"] = new Money(GrossPL * TotalComm / 100);
                        bdx["lux_otherfees"] = new Money(appln.Attributes.Contains("lux_policyfee") ? appln.GetAttributeValue<Money>("lux_policyfee").Value : 0);
                    }
                    else if (appln.FormattedValues["lux_applicationtype"] == "Cancellation")
                    {
                        var GrossEL = appln.Attributes.Contains("lux_employersliabilitymtapremium") ? appln.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0;
                        var GrossPL = appln.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? appln.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0;
                        var BrokerComm = appln.Attributes.Contains("lux_mtabrokercommissionpercentage") ? Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", "")) : 0;
                        var ACIESComm = appln.Attributes.Contains("lux_policyaciescommission") ? Convert.ToDecimal(appln.Attributes["lux_policyaciescommission"].ToString().Replace("%", "")) : 0;
                        var TotalComm = BrokerComm + ACIESComm;

                        bdx["lux_cancellationdate"] = Convert.ToDateTime(appln.Attributes.Contains("lux_mtaeffectivedate") == true ? appln.FormattedValues["lux_mtaeffectivedate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_cancellationreason"] = new OptionSetValue(appln.Attributes.Contains("lux_reasonforcancellation") ? appln.GetAttributeValue<OptionSetValueCollection>("lux_reasonforcancellation").FirstOrDefault().Value : 972970010);
                        bdx["lux_riskstatus"] = new OptionSetValue(972970003);
                        bdx["lux_premiumtransactiontype"] = new OptionSetValue(972970002);
                        bdx["lux_iptel"] = new Money(isIsleofManPolicy == false ? GrossEL * 12 / 100 : 0);
                        bdx["lux_iptpl"] = new Money(isIsleofManPolicy == false ? GrossPL * 12 / 100 : 0);
                        bdx["lux_grossel"] = new Money(GrossEL);
                        bdx["lux_grosspl"] = new Money(GrossPL);
                        bdx["lux_netel"] = new Money(GrossEL - GrossEL * TotalComm / 100);
                        bdx["lux_netpl"] = new Money(GrossPL - GrossPL * TotalComm / 100);
                        bdx["lux_netei"] = new Money(0);
                        bdx["lux_commissionel"] = new Money(GrossEL * TotalComm / 100);
                        bdx["lux_commissionpl"] = new Money(GrossPL * TotalComm / 100);
                        bdx["lux_otherfees"] = new Money(appln.Attributes.Contains("lux_mtapolicyfee") ? appln.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);
                    }
                    else if (appln.FormattedValues["lux_applicationtype"] == "MTA")
                    {
                        var GrossEL = appln.Attributes.Contains("lux_employersliabilitymtapremium") ? appln.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0;
                        var GrossPL = appln.Attributes.Contains("lux_publicproductsliabilitymtapremium") ? appln.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0;
                        var BrokerComm = appln.Attributes.Contains("lux_mtabrokercommissionpercentage") ? Convert.ToDecimal(appln.Attributes["lux_mtabrokercommissionpercentage"].ToString().Replace("%", "")) : 0;
                        var ACIESComm = appln.Attributes.Contains("lux_policyaciescommission") ? Convert.ToDecimal(appln.Attributes["lux_policyaciescommission"].ToString().Replace("%", "")) : 0;
                        var TotalComm = BrokerComm + ACIESComm;

                        bdx["lux_riskstatus"] = new OptionSetValue(972970004);
                        if (GrossEL + GrossPL >= 0)
                        {
                            bdx["lux_premiumtransactiontype"] = new OptionSetValue(972970003);
                        }
                        else if (GrossEL + GrossPL < 0)
                        {
                            bdx["lux_premiumtransactiontype"] = new OptionSetValue(972970002);
                        }

                        bdx["lux_mtadate"] = Convert.ToDateTime(appln.Attributes.Contains("lux_mtaeffectivedate") == true ? appln.FormattedValues["lux_mtaeffectivedate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_iptel"] = new Money(isIsleofManPolicy == false ? GrossEL * 12 / 100 : 0);
                        bdx["lux_iptpl"] = new Money(isIsleofManPolicy == false ? GrossPL * 12 / 100 : 0);
                        bdx["lux_grossel"] = new Money(GrossEL);
                        bdx["lux_grosspl"] = new Money(GrossPL);
                        bdx["lux_netel"] = new Money(GrossEL - GrossEL * TotalComm / 100);
                        bdx["lux_netpl"] = new Money(GrossPL - GrossPL * TotalComm / 100);
                        bdx["lux_netei"] = new Money(0);
                        bdx["lux_commissionel"] = new Money(GrossEL * TotalComm / 100);
                        bdx["lux_commissionpl"] = new Money(GrossPL * TotalComm / 100);
                        bdx["lux_otherfees"] = new Money(appln.Attributes.Contains("lux_mtapolicyfee") ? appln.GetAttributeValue<Money>("lux_mtapolicyfee").Value : 0);
                    }

                    if (appln.GetAttributeValue<bool>("lux_employersliability") == true)
                    {
                        bdx["lux_ellimitofindemnity"] = new OptionSetValue(972970001);
                    }
                    if (appln.Attributes.Contains("lux_pllimitofindemnity") && appln.GetAttributeValue<bool>("lux_publicliability") == true)
                    {
                        bdx["lux_pllimitofindemnity"] = new OptionSetValue(appln.GetAttributeValue<OptionSetValue>("lux_pllimitofindemnity").Value);
                    }

                    bdx["lux_premiumbasis"] = new OptionSetValue(972970001);
                    bdx["lux_wageroll"] = new Money(appln.Attributes.Contains("lux_estimatedwagerollfornext12months") ? appln.GetAttributeValue<Money>("lux_estimatedwagerollfornext12months").Value : 0);
                    bdx["lux_turnover"] = new Money(appln.Attributes.Contains("lux_totalestimatedturnover") ? appln.GetAttributeValue<Money>("lux_totalestimatedturnover").Value : 0);
                    //bdx["lux_rateincrease"] = new decimal(0.1);
                    service.Create(bdx);
                }
            }
        }
    }
}


//var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
//                  <entity name='lux_bordereau'>
//                    <attribute name='lux_wallconstructiontype2' />
//                    <attribute name='lux_wallconstructiontype1' />
//                    <attribute name='lux_totalgrosswrittenpremium' />
//                    <attribute name='lux_tax1taxtype' />
//                    <attribute name='lux_tax1amountoftaxablepremium' />
//                    <attribute name='lux_tax1amount' />
//                    <attribute name='lux_suminsuredamount' />
//                    <attribute name='lux_roofconstructiontype2' />
//                    <attribute name='lux_roofconstructiontype1' />
//                    <attribute name='lux_reasonforcancellation' />
//                    <attribute name='lux_propertytype' />
//                    <attribute name='lux_policynumber' />
//                    <attribute name='lux_otherfeesordeductionsdescription' />
//                    <attribute name='lux_otherfeesordeductionsamount' />
//                    <attribute name='lux_occupancytype' />
//                    <attribute name='lux_occupancydescription' />
//                    <attribute name='lux_occupancycategory' />
//                    <attribute name='lux_netpremiumtolondoninoriginalcurrency' />
//                    <attribute name='lux_nameofinsured' />
//                    <attribute name='lux_locationofriskpostcodezipcodeorsimilar' />
//                    <attribute name='lux_locationofriskcountry' />
//                    <attribute name='lux_locationofriskaddress' />
//                    <attribute name='lux_localsubproducerscommissionamount' />
//                    <attribute name='lux_lloydsriskcode' />
//                    <attribute name='lux_insuredzipcodepostalcode' />
//                    <attribute name='lux_insuredcountry' />
//                    <attribute name='lux_insuredaddress' />
//                    <attribute name='lux_inceptiondate' />
//                    <attribute name='lux_grosspremiumpaidthistime' />
//                    <attribute name='lux_grosspremium' />
//                    <attribute name='lux_finalnetpremiumoriginalcurrency' />
//                    <attribute name='lux_expirydate' />
//                    <attribute name='lux_covereffectivedate' />
//                    <attribute name='lux_commissionamount' />
//                    <attribute name='lux_brokerageamountoriginalcurrency' />
//                    <attribute name='lux_certificateissuancedate' />
//                    <attribute name='lux_totalinsurablevalues' />
//                    <attribute name='lux_transactiontypeoriginalpremiumetc' />
//                    <attribute name='lux_suminsuredcurrency' />
//                    <attribute name='lux_neworrenewal' />
//                    <attribute name='lux_commission' />
//                    <attribute name='lux_localsubproducerscommission' />
//                    <attribute name='lux_brokeragepercentofgrosspremium' />
//                    <attribute name='lux_locationid' />
//                    <attribute name='lux_plpremium' />
//                    <attribute name='lux_elpremium' />
//                    <attribute name='lux_wageroll' />
//                    <attribute name='lux_turnover' />
//                    <attribute name='lux_trade' />
//                    <attribute name='lux_propertyownersliabilitypremium' />
//                    <attribute name='lux_application' />
//                    <attribute name='lux_floodcover' />
//                    <attribute name='lux_bordereauid' />
//                    <order attribute='lux_covereffectivedate' descending='false' />
//                    <filter type='and'>
//                      <condition attribute='statecode' operator='eq' value='0' />
//                      <condition attribute='lux_covereffectivedate' operator='on-or-after' value='2021-05-01' />
//                      <condition attribute='lux_application' operator='not-null' />
//                    </filter>
//                  </entity>
//                </fetch>";

//if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
//{
//    var bordereau = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
//    foreach (var item1 in bordereau)
//    {
//        var application = service.Retrieve("lux_propertyownersapplications", item1.GetAttributeValue<EntityReference>("lux_application").Id, new ColumnSet("lux_insuranceproductrequired"));
//        if (application.FormattedValues["lux_insuranceproductrequired"] == "Property Owners" || application.FormattedValues["lux_insuranceproductrequired"] == "Unoccupied")
//        {
//            var premfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
//                      <entity name='lux_propertyownerspremise'>
//                        <attribute name='lux_subsidencescore' />
//                        <attribute name='lux_securityrating' />
//                        <attribute name='lux_covers' />
//                        <attribute name='lux_riskpostcode' />
//                        <attribute name='lux_locationnumber' />
//                        <attribute name='lux_propertyownerspremiseid' />
//                        <order attribute='lux_locationnumber' descending='false' />
//                        <filter type='and'>
//                          <condition attribute='statecode' operator='eq' value='0' />
//                          <condition attribute='lux_locationnumber' operator='eq' value='{item1.GetAttributeValue<string>("lux_locationid")}' />
//                          <condition attribute='lux_propertyownersapplication' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{application.Id}' />
//                        </filter>
//                      </entity>
//                    </fetch>";

//            if (service.RetrieveMultiple(new FetchExpression(premfetch)).Entities.Count > 0)
//            {
//                var item = service.RetrieveMultiple(new FetchExpression(premfetch)).Entities[0];
//                Entity bdx = service.Retrieve("lux_bordereau", item1.Id, new ColumnSet("lux_floodcover"));
//                if (item.Attributes.Contains("lux_covers"))
//                {
//                    if (item.GetAttributeValue<OptionSetValueCollection>("lux_covers").Contains(new OptionSetValue(972970011)))
//                    {
//                        bdx["lux_floodcover"] = true;
//                    }
//                    else
//                    {
//                        bdx["lux_floodcover"] = false;
//                    }
//                }
//                else
//                {
//                    bdx["lux_floodcover"] = false;
//                }
//                service.Update(bdx);
//            }
//        }
//        else if (application.FormattedValues["lux_insuranceproductrequired"] == "Retail")
//        {
//            var premfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
//                                  <entity name='lux_propertyownersretail'>
//                                    <attribute name='lux_propertyownersretailid' />
//                                    <attribute name='lux_name' />
//                                    <attribute name='lux_riskpostcode' />       
//                                    <attribute name='lux_materialdamagecoverdetails' />       
//                                    <attribute name='lux_locationnumber' />
//                                    <attribute name='createdon' />
//                                    <order attribute='lux_locationnumber' descending='false' />
//                                    <filter type='and'>
//                                      <condition attribute='statecode' operator='eq' value='0' />
//                                      <condition attribute='lux_locationnumber' operator='eq' value='{item1.GetAttributeValue<string>("lux_locationid")}' />
//                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{application.Id}' />
//                                    </filter>
//                                  </entity>
//                                </fetch>";

//            if (service.RetrieveMultiple(new FetchExpression(premfetch)).Entities.Count > 0)
//            {
//                var item = service.RetrieveMultiple(new FetchExpression(premfetch)).Entities[0];
//                Entity bdx = service.Retrieve("lux_bordereau", item1.Id, new ColumnSet("lux_floodcover"));
//                if (item.Attributes.Contains("lux_materialdamagecoverdetails"))
//                {
//                    if (item.GetAttributeValue<OptionSetValueCollection>("lux_materialdamagecoverdetails").Contains(new OptionSetValue(972970011)))
//                    {
//                        bdx["lux_floodcover"] = true;
//                    }
//                    else
//                    {
//                        bdx["lux_floodcover"] = false;
//                    }
//                }
//                else
//                {
//                    bdx["lux_floodcover"] = false;
//                }
//                service.Update(bdx);
//            }
//        }
//        else if (application.FormattedValues["lux_insuranceproductrequired"] == "Pubs & Restaurants" || application.FormattedValues["lux_insuranceproductrequired"] == "Hotels and Guesthouses")
//        {
//            var premfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
//                                  <entity name='lux_pubsrestaurantspropertyownersapplicatio'>
//                                    <attribute name='lux_pubsrestaurantspropertyownersapplicatioid' />
//                                    <attribute name='lux_name' />
//                                    <attribute name='lux_riskpostcode' />       
//                                    <attribute name='lux_materialdamagecoverdetails' />       
//                                    <attribute name='lux_locationnumber' />
//                                    <attribute name='createdon' />
//                                    <order attribute='lux_locationnumber' descending='false' />
//                                    <filter type='and'>
//                                      <condition attribute='statecode' operator='eq' value='0' />
//                                      <condition attribute='lux_locationnumber' operator='eq' value='{item1.GetAttributeValue<string>("lux_locationid")}' />
//                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{application.Id}' />
//                                    </filter>
//                                  </entity>
//                                </fetch>";

//            if (service.RetrieveMultiple(new FetchExpression(premfetch)).Entities.Count > 0)
//            {
//                var item = service.RetrieveMultiple(new FetchExpression(premfetch)).Entities[0];
//                Entity bdx = service.Retrieve("lux_bordereau", item1.Id, new ColumnSet("lux_floodcover"));
//                if (item.Attributes.Contains("lux_materialdamagecoverdetails"))
//                {
//                    if (item.GetAttributeValue<OptionSetValueCollection>("lux_materialdamagecoverdetails").Contains(new OptionSetValue(972970011)))
//                    {
//                        bdx["lux_floodcover"] = true;
//                    }
//                    else
//                    {
//                        bdx["lux_floodcover"] = false;
//                    }
//                }
//                else
//                {
//                    bdx["lux_floodcover"] = false;
//                }
//                service.Update(bdx);
//            }
//        }
//        else if (application.FormattedValues["lux_insuranceproductrequired"] == "Commercial Combined")
//        {
//            var premfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
//                                  <entity name='lux_commercialcombinedapplication'>
//                                    <attribute name='lux_commercialcombinedapplicationid' />
//                                    <attribute name='lux_name' />
//                                    <attribute name='lux_riskpostcode' />       
//                                    <attribute name='lux_materialdamagecoverdetails' />       
//                                    <attribute name='lux_locationnumber' />
//                                    <attribute name='createdon' />
//                                    <order attribute='lux_locationnumber' descending='false' />
//                                    <filter type='and'>
//                                      <condition attribute='statecode' operator='eq' value='0' />
//                                      <condition attribute='lux_locationnumber' operator='eq' value='{item1.GetAttributeValue<string>("lux_locationid")}' />
//                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{application.Id}' />
//                                    </filter>
//                                  </entity>
//                                </fetch>";

//            if (service.RetrieveMultiple(new FetchExpression(premfetch)).Entities.Count > 0)
//            {
//                var item = service.RetrieveMultiple(new FetchExpression(premfetch)).Entities[0];
//                Entity bdx = service.Retrieve("lux_bordereau", item1.Id, new ColumnSet("lux_floodcover"));
//                if (item.Attributes.Contains("lux_materialdamagecoverdetails"))
//                {
//                    if (item.GetAttributeValue<OptionSetValueCollection>("lux_materialdamagecoverdetails").Contains(new OptionSetValue(972970011)))
//                    {
//                        bdx["lux_floodcover"] = true;
//                    }
//                    else
//                    {
//                        bdx["lux_floodcover"] = false;
//                    }
//                }
//                else
//                {
//                    bdx["lux_floodcover"] = false;
//                }
//                service.Update(bdx);
//            }
//        }
//        else if (application.FormattedValues["lux_insuranceproductrequired"] == "Contractors Combined")
//        {
//            var premfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
//                                  <entity name='lux_contractorscombined'>
//                                    <attribute name='lux_contractorscombinedid' />
//                                    <attribute name='lux_name' />
//                                    <attribute name='lux_riskpostcode' />       
//                                    <attribute name='lux_materialdamagecoverdetails' />       
//                                    <attribute name='lux_locationnumber' />
//                                    <attribute name='createdon' />
//                                    <order attribute='lux_locationnumber' descending='false' />
//                                    <filter type='and'>
//                                      <condition attribute='statecode' operator='eq' value='0' />
//                                      <condition attribute='lux_locationnumber' operator='eq' value='{item1.GetAttributeValue<string>("lux_locationid")}' />
//                                      <condition attribute='lux_propertyownersapplications' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{application.Id}' />
//                                    </filter>
//                                  </entity>
//                                </fetch>";

//            if (service.RetrieveMultiple(new FetchExpression(premfetch)).Entities.Count > 0)
//            {
//                var item = service.RetrieveMultiple(new FetchExpression(premfetch)).Entities[0];
//                Entity bdx = service.Retrieve("lux_bordereau", item1.Id, new ColumnSet("lux_floodcover"));
//                if (item.Attributes.Contains("lux_materialdamagecoverdetails"))
//                {
//                    if (item.GetAttributeValue<OptionSetValueCollection>("lux_materialdamagecoverdetails").Contains(new OptionSetValue(972970011)))
//                    {
//                        bdx["lux_floodcover"] = true;
//                    }
//                    else
//                    {
//                        bdx["lux_floodcover"] = false;
//                    }
//                }
//                else
//                {
//                    bdx["lux_floodcover"] = false;
//                }
//                service.Update(bdx);
//            }
//        }
//        else
//        {
//            Entity bdx = service.Retrieve("lux_bordereau", item1.Id, new ColumnSet("lux_floodcover"));
//            bdx["lux_floodcover"] = false;
//            service.Update(bdx);
//        }
//    }
//}