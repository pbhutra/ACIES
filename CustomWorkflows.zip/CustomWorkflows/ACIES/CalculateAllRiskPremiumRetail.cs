﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculateAllRiskPremiumRetail : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_allriskitem'>
                                <attribute name='lux_typeofequipment' />
                                <attribute name='lux_territoriallimit' />
                                <attribute name='lux_suminsured' />
                                <attribute name='lux_excess' />
                                <attribute name='lux_allriskitemid' />
                                <order attribute='lux_typeofequipment' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_application' link-type='inner' alias='aa'>
                                  <filter type='and'>
                                    <condition attribute='lux_allriskitems' operator='eq' value='1' />
                                  </filter>
                                </link-entity>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                decimal ARIPremium = 0;
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    var SARFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='lux_specifiedallrisksrate'>
                                        <attribute name='lux_name' />
                                        <attribute name='createdon' />
                                        <attribute name='lux_rate' />
                                        <attribute name='lux_specifiedallrisksrateid' />
                                        <order attribute='lux_name' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='statecode' operator='eq' value='0' />
                                          <condition attribute='lux_specifiedallrisks' operator='eq' value='{item.GetAttributeValue<OptionSetValue>("lux_typeofequipment").Value}' />
                                        </filter>
                                      </entity>
                                    </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(SARFetch)).Entities.Count > 0)
                    {
                        var data = service.RetrieveMultiple(new FetchExpression(SARFetch)).Entities[0];
                        var Rate = data.GetAttributeValue<decimal>("lux_rate");
                        var SumInsured = item.Attributes.Contains("lux_suminsured") ? item.GetAttributeValue<Money>("lux_suminsured").Value : 0;
                        ARIPremium += SumInsured * Rate / 100;
                    }
                }
                var item1 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                var dateDiffDays = (item1.GetAttributeValue<DateTime>("lux_renewaldate") - item1.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                if (dateDiffDays == 364 || dateDiffDays == 365 || dateDiffDays == 366)
                {
                    dateDiffDays = 365;
                }
                ARIPremium = ARIPremium * dateDiffDays / 365;

                if (ARIPremium < 25)
                {
                    ARIPremium = 25;
                }
                item1["lux_specifiedallriskpremium"] = new Money(ARIPremium);
                service.Update(item1);
            }
            else
            {
                var item1 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                item1["lux_specifiedallriskpremium"] = new Money(0);
                service.Update(item1);
            }

            var item2 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
            var product = item2.FormattedValues["lux_insuranceproductrequired"];
            if (product == "Contractors Combined")
            {
                if (item2.GetAttributeValue<bool>("lux_allriskitems") == false || item2.GetAttributeValue<bool>("lux_ismaterialdamagecoverrequired") == false)
                {
                    var item1 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                    item1["lux_specifiedallriskpremium"] = new Money(0);
                    service.Update(item1);
                }
            }
        }
    }
}
