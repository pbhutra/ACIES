﻿using Microsoft.SharePoint.Client;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using msdyncrmWorkflowTools;
using System;
using System.Activities;
using System.Linq;
using System.Security;

namespace CustomWorkflows
{
    public class MoveAttachmentstoSharepoint : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Input("Tradesman Application")]
        [ReferenceTarget("lux_tradesman")]
        public InArgument<EntityReference> TradesmanApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            #region "Load CRM Service from context"

            Common objCommon = new Common(executionContext);
            objCommon.tracingService.Trace("Load CRM Service from context --- OK");

            #endregion

            if (TradesmanApplication.Get(executionContext) == null)
            {
                EntityReference applnref = PropertyOwnersApplication.Get<EntityReference>(executionContext);
                Entity appln = new Entity(applnref.LogicalName, applnref.Id);
                appln = service.Retrieve("lux_propertyownersapplications", applnref.Id, new ColumnSet(true));

                var CompanyName = appln.Attributes["lux_name"].ToString();

                var notesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='annotation'>
                                    <attribute name='subject' />
                                    <attribute name='notetext' />
                                    <attribute name='filename' />  
                                    <attribute name='documentbody' />
                                    <attribute name='annotationid' />
                                    <order attribute='subject' descending='false' />
                                    <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='objectid' link-type='inner' alias='ab'>
                                      <filter type='and'>
                                        <condition attribute='lux_propertyownersapplicationsid' operator='eq' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      </filter>
                                    </link-entity>
                                  </entity>
                                </fetch>";

                var file = service.RetrieveMultiple(new FetchExpression(notesFetch)).Entities;
                if (file.Count() > 0)
                {
                    using (ClientContext clientContext = new ClientContext("https://aciesltd.sharepoint.com/sites/ACIES-CRMSharePoint"))
                    {
                        SecureString passWord = new SecureString();
                        foreach (char c in "Nup496791".ToCharArray()) passWord.AppendChar(c);
                        clientContext.Credentials = new SharePointOnlineCredentials("lucidux@aciesmgu.com", passWord);
                        foreach (var item in file)
                        {
                            FileCreationInformation fcInfo = new FileCreationInformation();
                            fcInfo.Overwrite = true;
                            fcInfo.Url = item.Attributes["filename"].ToString();
                            fcInfo.Content = System.Convert.FromBase64String(item.Attributes["documentbody"].ToString());
                            string companyFolderName = CompanyName + "_" + (appln.Id.ToString().Replace("-", "")).ToUpper();
                            var targetFolder = clientContext.Web.GetFolderByServerRelativeUrl("https://aciesltd.sharepoint.com/sites/ACIES-CRMSharePoint/lux_propertyownersapplications/" + CompanyName);
                            var uploadFile = targetFolder.Files.Add(fcInfo);
                            clientContext.Load(uploadFile);
                            try
                            {
                                clientContext.ExecuteQuery();
                            }
                            catch (Exception ex)
                            {
                                var targetFolder1 = clientContext.Web.GetFolderByServerRelativeUrl("https://aciesltd.sharepoint.com/sites/ACIES-CRMSharePoint/lux_propertyownersapplications");
                                var newTargetFolder = targetFolder1.Folders.Add(companyFolderName);
                                var uploadFile1 = newTargetFolder.Files.Add(fcInfo);
                                clientContext.Load(uploadFile1);
                                clientContext.ExecuteQuery();
                            }
                            service.Delete("annotation", item.Id);
                        }
                    }
                }
            }
            else
            {
                EntityReference applnref = TradesmanApplication.Get<EntityReference>(executionContext);
                Entity appln = new Entity(applnref.LogicalName, applnref.Id);
                appln = service.Retrieve("lux_tradesman", applnref.Id, new ColumnSet(true));

                var CompanyName = appln.Attributes["lux_name"].ToString();

                var notesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='annotation'>
                                    <attribute name='subject' />
                                    <attribute name='notetext' />
                                    <attribute name='filename' />  
                                    <attribute name='documentbody' />
                                    <attribute name='annotationid' />
                                    <order attribute='subject' descending='false' />
                                    <link-entity name='lux_tradesman' from='lux_tradesmanid' to='objectid' link-type='inner' alias='ab'>
                                      <filter type='and'>
                                        <condition attribute='lux_tradesmanid' operator='eq' uitype='lux_tradesman' value='{appln.Id}' />
                                      </filter>
                                    </link-entity>
                                  </entity>
                                </fetch>";

                var file = service.RetrieveMultiple(new FetchExpression(notesFetch)).Entities;
                if (file.Count() > 0)
                {
                    using (ClientContext clientContext = new ClientContext("https://aciesltd.sharepoint.com/sites/ACIES-CRMSharePoint"))
                    {
                        SecureString passWord = new SecureString();
                        foreach (char c in "Nup496791".ToCharArray()) passWord.AppendChar(c);
                        clientContext.Credentials = new SharePointOnlineCredentials("lucidux@aciesmgu.com", passWord);
                        foreach (var item in file)
                        {
                            FileCreationInformation fcInfo = new FileCreationInformation();
                            fcInfo.Overwrite = true;
                            fcInfo.Url = item.Attributes["filename"].ToString();
                            fcInfo.Content = System.Convert.FromBase64String(item.Attributes["documentbody"].ToString());
                            string companyFolderName = CompanyName + "_" + (appln.Id.ToString().Replace("-", "")).ToUpper();
                            var targetFolder = clientContext.Web.GetFolderByServerRelativeUrl("https://aciesltd.sharepoint.com/sites/ACIES-CRMSharePoint/lux_tradesman/" + CompanyName);
                            var uploadFile = targetFolder.Files.Add(fcInfo);
                            clientContext.Load(uploadFile);
                            try
                            {
                                clientContext.ExecuteQuery();
                            }
                            catch (Exception ex)
                            {
                                var targetFolder1 = clientContext.Web.GetFolderByServerRelativeUrl("https://aciesltd.sharepoint.com/sites/ACIES-CRMSharePoint/lux_tradesman");
                                var newTargetFolder = targetFolder1.Folders.Add(companyFolderName);
                                var uploadFile1 = newTargetFolder.Files.Add(fcInfo);
                                clientContext.Load(uploadFile1);
                                clientContext.ExecuteQuery();
                            }
                            service.Delete("annotation", item.Id);
                        }
                    }
                }
            }
        }
    }
}