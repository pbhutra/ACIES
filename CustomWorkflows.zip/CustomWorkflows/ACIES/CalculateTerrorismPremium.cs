﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CustomWorkflows
{
    public class CalculateTerrorismPremium : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Input("Product")]
        public InArgument<string> Product { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var request = new RetrieveCurrentOrganizationRequest();
            var organzationResponse = (RetrieveCurrentOrganizationResponse)service.Execute(request);
            var uriString = organzationResponse.Detail.UrlName;

            var product = Product.Get(executionContext).ToString();
            var item2 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
            var dateDiffDays = (item2.GetAttributeValue<DateTime>("lux_renewaldate") - item2.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;

            if (dateDiffDays == 364 || dateDiffDays == 365 || dateDiffDays == 366)
            {
                dateDiffDays = 365;
            }
            var quotationDate = item2.Contains("lux_quotationdate") ? Convert.ToDateTime(item2.FormattedValues["lux_quotationdate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat) : item2.GetAttributeValue<DateTime>("lux_inceptiondate");
            var inceptionDate = Convert.ToDateTime(item2.FormattedValues["lux_inceptiondate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

            if (product == "Property Owners" || product == "Unoccupied")
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownerspremise'>
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_declaredvalueforrebuildingthisproperty' />
                                <attribute name='lux_buildingconstruction' />
                                <attribute name='lux_totalsuminsuredforthislocation' />
                                <attribute name='lux_basisofcover' />
                                <attribute name='lux_suminsuredwithupliftedamount' />
                                <attribute name='lux_landlordscontentsinresidentialareas' />
                                <attribute name='lux_lossofannualrentalincome' />
                                <attribute name='lux_indemnityperiodrequired' />
                                <attribute name='lux_propertyownerspremiseid' />
                                <attribute name='lux_materialdamagepremium' />
                                <attribute name='lux_materialdamageperilsrate' />
                                <attribute name='lux_covers' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplication' visible='false' link-type='outer' alias='poa'>
                                  <attribute name='lux_levelofcommission' />
                                  <attribute name='lux_isterrorismcoverrequired' />
                                  <attribute name='lux_rpocpoproducttype' />
                                </link-entity>
                              </entity>
                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    decimal TerrorismTotal = 0;
                    foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        var premise_data = item;

                        if (premise_data.Contains("poa.lux_isterrorismcoverrequired") && ((bool)((premise_data.GetAttributeValue<AliasedValue>("poa.lux_isterrorismcoverrequired")).Value)) == true)
                        {
                            var postcode = premise_data.Contains("lux_riskpostcode") ? premise_data.Attributes["lux_riskpostcode"] : "";
                            var post2digits = postcode.ToString().Substring(0, 2);
                            var post3digits = postcode.ToString().Substring(0, 3);
                            var post4digits = postcode.ToString().Substring(0, 4);
                            var zone = 972970003;
                            if (postcode.ToString() != "")
                            {
                                var TerrorismFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_terrorismratingzone'>
                                                            <attribute name='lux_name' />
                                                            <attribute name='lux_locationzone' />
                                                            <attribute name='lux_terrorismratingzoneid' />
                                                            <order attribute='lux_locationzone' descending='false' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_name' operator='eq' value='{post4digits}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";
                                if (service.RetrieveMultiple(new FetchExpression(TerrorismFetch)).Entities.Count > 0)
                                {
                                    zone = service.RetrieveMultiple(new FetchExpression(TerrorismFetch)).Entities[0].GetAttributeValue<OptionSetValue>("lux_locationzone").Value;
                                }
                                else
                                {
                                    var TerrorismFetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_terrorismratingzone'>
                                                            <attribute name='lux_name' />
                                                            <attribute name='lux_locationzone' />
                                                            <attribute name='lux_terrorismratingzoneid' />
                                                            <order attribute='lux_locationzone' descending='false' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_name' operator='eq' value='{post3digits}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";
                                    if (service.RetrieveMultiple(new FetchExpression(TerrorismFetch1)).Entities.Count > 0)
                                    {
                                        zone = service.RetrieveMultiple(new FetchExpression(TerrorismFetch1)).Entities[0].GetAttributeValue<OptionSetValue>("lux_locationzone").Value;
                                    }
                                    else
                                    {
                                        var TerrorismFetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_terrorismratingzone'>
                                                            <attribute name='lux_name' />
                                                            <attribute name='lux_locationzone' />
                                                            <attribute name='lux_terrorismratingzoneid' />
                                                            <order attribute='lux_locationzone' descending='false' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_name' operator='eq' value='{post2digits}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";
                                        if (service.RetrieveMultiple(new FetchExpression(TerrorismFetch2)).Entities.Count > 0)
                                        {
                                            zone = service.RetrieveMultiple(new FetchExpression(TerrorismFetch2)).Entities[0].GetAttributeValue<OptionSetValue>("lux_locationzone").Value;
                                        }
                                    }
                                }
                            }

                            var sum_Insured = premise_data.Contains("lux_totalsuminsuredforthislocation") ? premise_data.GetAttributeValue<Money>("lux_totalsuminsuredforthislocation").Value : 0;
                            var BISum_insured = premise_data.GetAttributeValue<Money>("lux_lossofannualrentalincome").Value;
                            var MDSum_insured = sum_Insured - BISum_insured;

                            decimal TerrorismPremium = 0;
                            decimal TerrorismMDPremium = 0;
                            decimal TerrorismBIPremium = 0;
                            decimal MDSI_rate = 0;
                            decimal BISI_rate = 0;

                            if (MDSum_insured > 0)
                            {
                                var MDRatesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_terrorismrate'>
                                                    <attribute name='lux_ratebeforeanydiscount' />
                                                    <attribute name='lux_locationzone' />
                                                    <attribute name='lux_ratetype' />
                                                    <attribute name='lux_terrorismrateid' />
                                                    <order attribute='lux_ratetype' descending='false' />
                                                    <order attribute='lux_locationzone' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_locationzone' operator='eq' value='{zone}' />
                                                      <condition attribute='lux_ratetype' operator='eq' value='972970002' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(MDRatesFetch)).Entities.Count > 0)
                                {
                                    var SI_data = service.RetrieveMultiple(new FetchExpression(MDRatesFetch)).Entities[0];
                                    if (SI_data.Contains("lux_ratebeforeanydiscount"))
                                    {
                                        MDSI_rate = SI_data.GetAttributeValue<decimal>("lux_ratebeforeanydiscount");
                                    }
                                    TerrorismMDPremium = MDSum_insured * MDSI_rate / 100;
                                }
                            }
                            if (BISum_insured > 0)
                            {
                                var BIRatesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_terrorismrate'>
                                                    <attribute name='lux_ratebeforeanydiscount' />
                                                    <attribute name='lux_locationzone' />
                                                    <attribute name='lux_ratetype' />
                                                    <attribute name='lux_terrorismrateid' />
                                                    <order attribute='lux_ratetype' descending='false' />
                                                    <order attribute='lux_locationzone' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_locationzone' operator='eq' value='{zone}' />
                                                      <condition attribute='lux_ratetype' operator='eq' value='972970001' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(BIRatesFetch)).Entities.Count > 0)
                                {
                                    var SI_data = service.RetrieveMultiple(new FetchExpression(BIRatesFetch)).Entities[0];
                                    if (SI_data.Contains("lux_ratebeforeanydiscount"))
                                    {
                                        BISI_rate = SI_data.GetAttributeValue<decimal>("lux_ratebeforeanydiscount");
                                    }
                                    TerrorismBIPremium = BISum_insured * BISI_rate / 100;
                                }
                            }

                            TerrorismMDPremium = TerrorismMDPremium * dateDiffDays / 365;
                            TerrorismBIPremium = TerrorismBIPremium * dateDiffDays / 365;

                            TerrorismPremium = TerrorismMDPremium + TerrorismBIPremium;

                            var item1 = service.Retrieve("lux_propertyownerspremise", item.Id, new ColumnSet(false));
                            item1["lux_terrorismbipremium"] = new Money(TerrorismBIPremium);
                            item1["lux_terrorismmdpremium"] = new Money(TerrorismMDPremium);
                            item1["lux_terrorismbirate"] = BISI_rate;
                            item1["lux_terrorismmdrate"] = MDSI_rate;
                            item1["lux_terrorismpremium"] = new Money(TerrorismPremium);
                            item1["lux_terrorismzone"] = new OptionSetValue(zone);
                            service.Update(item1);

                            TerrorismTotal += TerrorismPremium;
                        }
                        else
                        {
                            var item1 = service.Retrieve("lux_propertyownerspremise", item.Id, new ColumnSet(false));
                            item1["lux_terrorismbipremium"] = new Money(0);
                            item1["lux_terrorismmdpremium"] = new Money(0);
                            item1["lux_terrorismbirate"] = new decimal(0);
                            item1["lux_terrorismmdrate"] = new decimal(0);
                            item1["lux_terrorismpremium"] = new Money(0);
                            service.Update(item1);

                            TerrorismTotal += 0;
                        }
                    }

                    if (item2.Contains("lux_isterrorismcoverrequired") && item2.GetAttributeValue<bool>("lux_isterrorismcoverrequired") == true)
                    {
                        if (item2.GetAttributeValue<OptionSetValue>("lux_rpocpoproducttype").Value == 972970001 || item2.GetAttributeValue<OptionSetValue>("lux_rpocpoproducttype").Value == 972970003)
                        {
                            if (TerrorismTotal < 35)
                            {
                                TerrorismTotal = 35;
                            }
                        }
                        else if (item2.GetAttributeValue<OptionSetValue>("lux_rpocpoproducttype").Value == 972970002 || item2.GetAttributeValue<OptionSetValue>("lux_rpocpoproducttype").Value == 972970004)
                        {
                            if (TerrorismTotal < 50)
                            {
                                TerrorismTotal = 50;
                            }
                        }

                        if (quotationDate >= new DateTime(2025, 05, 01))
                        {
                            item2["lux_terrorismbrokercommission"] = "22.5%";
                            item2["lux_terrorismpolicybrokercommission"] = "22.5%";
                            item2["lux_terrorismaciescommission"] = "15.0%";
                            item2["lux_terrorismpolicyaciescommission"] = "15.0%";
                            item2["lux_terrorismtotalcommission"] = "37.5%";
                            item2["lux_terrorismpolicytotalcommission"] = "37.5%";

                            item2["lux_terrorismpremium"] = new Money(TerrorismTotal);
                            item2["lux_terrorismnetpremium"] = new Money(TerrorismTotal - TerrorismTotal * Convert.ToDecimal(37.5) / 100);

                            item2["lux_terrorismbrokercommissionamount"] = new Money(TerrorismTotal * 22.5M / 100);
                            item2["lux_terrorismaciescommissionamout"] = new Money(TerrorismTotal * 15M / 100);

                            item2["lux_terrorismquotedpremium"] = new Money(TerrorismTotal);
                            item2["lux_terrorismpolicynetpremiumexcludingipt"] = new Money(TerrorismTotal - TerrorismTotal * Convert.ToDecimal(37.5) / 100);

                            item2["lux_terrorismquotedpremiumbrokercommissionamo"] = new Money(TerrorismTotal * 22.5M / 100);
                            item2["lux_terrorismquotedpremiumaciescommissionamou"] = new Money(TerrorismTotal * 15M / 100);

                            if (item2.GetAttributeValue<OptionSetValue>("lux_rpocpoproducttype").Value == 972970001 && quotationDate >= new DateTime(2024, 09, 27))
                            {
                                if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                                {
                                    item2["lux_terrorismsectiondiscount"] = -30M;
                                    TerrorismTotal = TerrorismTotal - TerrorismTotal * 30 / 100;
                                    if (TerrorismTotal < 35)
                                    {
                                        TerrorismTotal = 35;
                                    }

                                    item2["lux_terrorismquotedpremium"] = new Money(TerrorismTotal);
                                    item2["lux_terrorismpolicynetpremiumexcludingipt"] = new Money(TerrorismTotal - TerrorismTotal * Convert.ToDecimal(37.5) / 100);

                                    item2["lux_terrorismquotedpremiumbrokercommissionamo"] = new Money(TerrorismTotal * 22.5M / 100);
                                    item2["lux_terrorismquotedpremiumaciescommissionamou"] = new Money(TerrorismTotal * 15M / 100);
                                }
                                else if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002 || item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970004)
                                {
                                    if (item2.Attributes.Contains("lux_policy"))
                                    {
                                        var Policy = service.Retrieve("lux_policy", item2.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                        if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                        {
                                            item2["lux_terrorismsectiondiscount"] = -30M;
                                            TerrorismTotal = TerrorismTotal - TerrorismTotal * 30 / 100;
                                            if (TerrorismTotal < 35)
                                            {
                                                TerrorismTotal = 35;
                                            }

                                            item2["lux_terrorismquotedpremium"] = new Money(TerrorismTotal);
                                            item2["lux_terrorismpolicynetpremiumexcludingipt"] = new Money(TerrorismTotal - TerrorismTotal * Convert.ToDecimal(37.5) / 100);

                                            item2["lux_terrorismquotedpremiumbrokercommissionamo"] = new Money(TerrorismTotal * 22.5M / 100);
                                            item2["lux_terrorismquotedpremiumaciescommissionamou"] = new Money(TerrorismTotal * 15M / 100);
                                        }
                                    }
                                }
                            }
                        }
                        else
                        {
                            item2["lux_terrorismbrokercommission"] = "20%";
                            item2["lux_terrorismpolicybrokercommission"] = "20%";
                            item2["lux_terrorismaciescommission"] = "12.5%";
                            item2["lux_terrorismpolicyaciescommission"] = "12.5%";
                            item2["lux_terrorismtotalcommission"] = "32.5%";
                            item2["lux_terrorismpolicytotalcommission"] = "32.5%";

                            item2["lux_terrorismpremium"] = new Money(TerrorismTotal);
                            item2["lux_terrorismnetpremium"] = new Money(TerrorismTotal - TerrorismTotal * Convert.ToDecimal(32.5) / 100);

                            item2["lux_terrorismbrokercommissionamount"] = new Money(TerrorismTotal * 20 / 100);
                            item2["lux_terrorismaciescommissionamout"] = new Money(TerrorismTotal * 12.5M / 100);

                            item2["lux_terrorismquotedpremium"] = new Money(TerrorismTotal);
                            item2["lux_terrorismpolicynetpremiumexcludingipt"] = new Money(TerrorismTotal - TerrorismTotal * Convert.ToDecimal(32.5) / 100);

                            item2["lux_terrorismquotedpremiumbrokercommissionamo"] = new Money(TerrorismTotal * 20 / 100);
                            item2["lux_terrorismquotedpremiumaciescommissionamou"] = new Money(TerrorismTotal * 12.5M / 100);

                            if (item2.GetAttributeValue<OptionSetValue>("lux_rpocpoproducttype").Value == 972970001 && quotationDate >= new DateTime(2024, 09, 27))
                            {
                                if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                                {
                                    item2["lux_terrorismsectiondiscount"] = -30M;
                                    TerrorismTotal = TerrorismTotal - TerrorismTotal * 30 / 100;
                                    if (TerrorismTotal < 35)
                                    {
                                        TerrorismTotal = 35;
                                    }

                                    item2["lux_terrorismquotedpremium"] = new Money(TerrorismTotal);
                                    item2["lux_terrorismpolicynetpremiumexcludingipt"] = new Money(TerrorismTotal - TerrorismTotal * Convert.ToDecimal(32.5) / 100);

                                    item2["lux_terrorismquotedpremiumbrokercommissionamo"] = new Money(TerrorismTotal * 20 / 100);
                                    item2["lux_terrorismquotedpremiumaciescommissionamou"] = new Money(TerrorismTotal * 12.5M / 100);
                                }
                                else if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970002 || item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970004)
                                {
                                    if (item2.Attributes.Contains("lux_policy"))
                                    {
                                        var Policy = service.Retrieve("lux_policy", item2.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                        if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                        {
                                            item2["lux_terrorismsectiondiscount"] = -30M;
                                            TerrorismTotal = TerrorismTotal - TerrorismTotal * 30 / 100;
                                            if (TerrorismTotal < 35)
                                            {
                                                TerrorismTotal = 35;
                                            }

                                            item2["lux_terrorismquotedpremium"] = new Money(TerrorismTotal);
                                            item2["lux_terrorismpolicynetpremiumexcludingipt"] = new Money(TerrorismTotal - TerrorismTotal * Convert.ToDecimal(32.5) / 100);

                                            item2["lux_terrorismquotedpremiumbrokercommissionamo"] = new Money(TerrorismTotal * 20 / 100);
                                            item2["lux_terrorismquotedpremiumaciescommissionamou"] = new Money(TerrorismTotal * 12.5M / 100);
                                        }
                                    }
                                }
                            }
                        }

                        service.Update(item2);
                    }
                }
            }
            else if (product == "Terrorism")
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_terrorismpremise'>
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_declaredvalueforrebuildingthisproperty' />
                                <attribute name='lux_totalsuminsuredforthislocation' />
                                <attribute name='lux_basisofcover' />
                                <attribute name='lux_suminsuredwithupliftedamount' />
                                <attribute name='lux_landlordscontentsinresidentialareas' />
                                <attribute name='lux_lossofannualrentalincome' />
                                <attribute name='lux_indemnityperiodrequired' />
                                <attribute name='lux_terrorismpremiseid' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    decimal TerrorismTotal = 0;
                    foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        var premise_data = item;

                        var postcode = premise_data.Contains("lux_riskpostcode") ? premise_data.Attributes["lux_riskpostcode"] : "";
                        var post2digits = postcode.ToString().Substring(0, 2);
                        var post3digits = postcode.ToString().Substring(0, 3);
                        var post4digits = postcode.ToString().Substring(0, 4);
                        var zone = 972970003;
                        if (postcode.ToString() != "")
                        {
                            var TerrorismFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_terrorismratingzone'>
                                                            <attribute name='lux_name' />
                                                            <attribute name='lux_locationzone' />
                                                            <attribute name='lux_terrorismratingzoneid' />
                                                            <order attribute='lux_locationzone' descending='false' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_name' operator='eq' value='{post4digits}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";
                            if (service.RetrieveMultiple(new FetchExpression(TerrorismFetch)).Entities.Count > 0)
                            {
                                zone = service.RetrieveMultiple(new FetchExpression(TerrorismFetch)).Entities[0].GetAttributeValue<OptionSetValue>("lux_locationzone").Value;
                            }
                            else
                            {
                                var TerrorismFetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_terrorismratingzone'>
                                                            <attribute name='lux_name' />
                                                            <attribute name='lux_locationzone' />
                                                            <attribute name='lux_terrorismratingzoneid' />
                                                            <order attribute='lux_locationzone' descending='false' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_name' operator='eq' value='{post3digits}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";
                                if (service.RetrieveMultiple(new FetchExpression(TerrorismFetch1)).Entities.Count > 0)
                                {
                                    zone = service.RetrieveMultiple(new FetchExpression(TerrorismFetch1)).Entities[0].GetAttributeValue<OptionSetValue>("lux_locationzone").Value;
                                }
                                else
                                {
                                    var TerrorismFetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_terrorismratingzone'>
                                                            <attribute name='lux_name' />
                                                            <attribute name='lux_locationzone' />
                                                            <attribute name='lux_terrorismratingzoneid' />
                                                            <order attribute='lux_locationzone' descending='false' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_name' operator='eq' value='{post2digits}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";
                                    if (service.RetrieveMultiple(new FetchExpression(TerrorismFetch2)).Entities.Count > 0)
                                    {
                                        zone = service.RetrieveMultiple(new FetchExpression(TerrorismFetch2)).Entities[0].GetAttributeValue<OptionSetValue>("lux_locationzone").Value;
                                    }
                                }
                            }
                        }

                        var sum_Insured = premise_data.Contains("lux_totalsuminsuredforthislocation") ? premise_data.GetAttributeValue<Money>("lux_totalsuminsuredforthislocation").Value : 0;
                        var BISum_insured = premise_data.GetAttributeValue<Money>("lux_lossofannualrentalincome").Value;
                        var MDSum_insured = sum_Insured - BISum_insured;

                        decimal TerrorismPremium = 0;
                        decimal TerrorismMDPremium = 0;
                        decimal TerrorismBIPremium = 0;
                        decimal MDSI_rate = 0;
                        decimal BISI_rate = 0;

                        if (MDSum_insured > 0)
                        {
                            var MDRatesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_terrorismrate'>
                                                    <attribute name='lux_ratebeforeanydiscount' />
                                                    <attribute name='lux_locationzone' />
                                                    <attribute name='lux_ratetype' />
                                                    <attribute name='lux_terrorismrateid' />
                                                    <order attribute='lux_ratetype' descending='false' />
                                                    <order attribute='lux_locationzone' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_locationzone' operator='eq' value='{zone}' />
                                                      <condition attribute='lux_ratetype' operator='eq' value='972970002' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                            if (service.RetrieveMultiple(new FetchExpression(MDRatesFetch)).Entities.Count > 0)
                            {
                                var SI_data = service.RetrieveMultiple(new FetchExpression(MDRatesFetch)).Entities[0];
                                if (SI_data.Contains("lux_ratebeforeanydiscount"))
                                {
                                    MDSI_rate = SI_data.GetAttributeValue<decimal>("lux_ratebeforeanydiscount");
                                }
                                TerrorismMDPremium = MDSum_insured * MDSI_rate / 100;
                            }
                        }
                        if (BISum_insured > 0)
                        {
                            var BIRatesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_terrorismrate'>
                                                    <attribute name='lux_ratebeforeanydiscount' />
                                                    <attribute name='lux_locationzone' />
                                                    <attribute name='lux_ratetype' />
                                                    <attribute name='lux_terrorismrateid' />
                                                    <order attribute='lux_ratetype' descending='false' />
                                                    <order attribute='lux_locationzone' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_locationzone' operator='eq' value='{zone}' />
                                                      <condition attribute='lux_ratetype' operator='eq' value='972970001' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                            if (service.RetrieveMultiple(new FetchExpression(BIRatesFetch)).Entities.Count > 0)
                            {
                                var SI_data = service.RetrieveMultiple(new FetchExpression(BIRatesFetch)).Entities[0];
                                if (SI_data.Contains("lux_ratebeforeanydiscount"))
                                {
                                    BISI_rate = SI_data.GetAttributeValue<decimal>("lux_ratebeforeanydiscount");
                                }
                                TerrorismBIPremium = BISum_insured * BISI_rate / 100;
                            }
                        }
                        TerrorismMDPremium = TerrorismMDPremium * dateDiffDays / 365;
                        TerrorismBIPremium = TerrorismBIPremium * dateDiffDays / 365;

                        TerrorismPremium = TerrorismMDPremium + TerrorismBIPremium;

                        var item1 = service.Retrieve("lux_terrorismpremise", item.Id, new ColumnSet(true));
                        item1["lux_terrorismbipremium"] = new Money(TerrorismBIPremium);
                        item1["lux_terrorismmdpremium"] = new Money(TerrorismMDPremium);
                        item1["lux_terrorismbirate"] = BISI_rate;
                        item1["lux_terrorismmdrate"] = MDSI_rate;
                        item1["lux_terrorismpremium"] = new Money(TerrorismPremium);
                        item1["lux_terrorismzone"] = new OptionSetValue(zone);
                        service.Update(item1);

                        TerrorismTotal += TerrorismPremium;
                    }

                    if (quotationDate >= new DateTime(2025, 05, 01))
                    {
                        item2["lux_terrorismpremium"] = new Money(TerrorismTotal);
                        item2["lux_terrorismnetpremium"] = new Money(TerrorismTotal - TerrorismTotal * Convert.ToDecimal(37.5) / 100);
                        item2["lux_terrorismquotedpremium"] = new Money(TerrorismTotal);
                        item2["lux_terrorismpolicynetpremiumexcludingipt"] = new Money(TerrorismTotal - TerrorismTotal * Convert.ToDecimal(37.5) / 100);

                        item2["lux_terrorismbrokercommission"] = "22.5%";
                        item2["lux_terrorismpolicybrokercommission"] = "22.5%";
                        item2["lux_terrorismbrokercommissionamount"] = new Money(TerrorismTotal * 22.5M / 100);
                        item2["lux_terrorismquotedpremiumbrokercommissionamo"] = new Money(TerrorismTotal * 22.5M / 100);
                        item2["lux_terrorismaciescommission"] = "15.0%";
                        item2["lux_terrorismpolicyaciescommission"] = "15.0%";
                        item2["lux_terrorismaciescommissionamout"] = new Money(TerrorismTotal * 15M / 100);
                        item2["lux_terrorismquotedpremiumaciescommissionamou"] = new Money(TerrorismTotal * 15M / 100);
                        item2["lux_terrorismtotalcommission"] = "37.5%";
                        item2["lux_terrorismpolicytotalcommission"] = "37.5%";
                    }
                    else
                    {
                        item2["lux_terrorismpremium"] = new Money(TerrorismTotal);
                        item2["lux_terrorismnetpremium"] = new Money(TerrorismTotal - TerrorismTotal * Convert.ToDecimal(32.5) / 100);
                        item2["lux_terrorismquotedpremium"] = new Money(TerrorismTotal);
                        item2["lux_terrorismpolicynetpremiumexcludingipt"] = new Money(TerrorismTotal - TerrorismTotal * Convert.ToDecimal(32.5) / 100);

                        item2["lux_terrorismbrokercommission"] = "20%";
                        item2["lux_terrorismpolicybrokercommission"] = "20%";
                        item2["lux_terrorismbrokercommissionamount"] = new Money(TerrorismTotal * 20 / 100);
                        item2["lux_terrorismquotedpremiumbrokercommissionamo"] = new Money(TerrorismTotal * 20 / 100);
                        item2["lux_terrorismaciescommission"] = "12.5%";
                        item2["lux_terrorismpolicyaciescommission"] = "12.5%";
                        item2["lux_terrorismaciescommissionamout"] = new Money(TerrorismTotal * 12.5M / 100);
                        item2["lux_terrorismquotedpremiumaciescommissionamou"] = new Money(TerrorismTotal * 12.5M / 100);
                        item2["lux_terrorismtotalcommission"] = "32.5%";
                        item2["lux_terrorismpolicytotalcommission"] = "32.5%";
                    }
                    service.Update(item2);
                }
            }
            else
            {
                Entity appln = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));

                var fetch = "";
                var entityName = "";
                if (product == "Retail")
                {
                    entityName = "lux_propertyownersretail";
                    fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersretail'>
                                <attribute name='lux_propertyownersretailid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_rentreceivable' />
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_icow' />
                                <attribute name='lux_typeofcover' />
                                <attribute name='lux_bookdebts' />
                                <attribute name='lux_amount' />
                                <attribute name='lux_generalcontentsdeclaredvalueincludingmach' />
                                <attribute name='lux_buildingsdeclaredvalue' /> 
                                <attribute name='lux_tenantsimprovementsdeclaredvalue' />
                                <attribute name='lux_listhighvaluestock' />
                                <attribute name='lux_stockexcludinghighvaluestock' />
                                <attribute name='lux_computerandelectronicbusinessequipment' />
                                <attribute name='lux_winesfortifiedwinesspiritsfinesuminsured' />
                                <attribute name='lux_powertoolssuminsured' />
                                <attribute name='lux_nonferrousmetalssuminsured' />
                                <attribute name='lux_mobilephonessuminsured' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_computerequipmentsuminsured' />
                                <attribute name='lux_audiovideoequipmentsuminsured' />
                                <attribute name='lux_alcoholsuminsured' />
                                <attribute name='lux_computergamesandorconsolessuminsured' />
                                <attribute name='lux_cigarettescigarsortobaccoproductssuminsur' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_fineartsuminsured' />
                                <attribute name='lux_additionalincreasedcostofworking' /> 
                                <attribute name='lux_materialdamagelossofrentpayable' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplications' visible='false' link-type='outer' alias='poa'>
                                  <attribute name='lux_levelofcommission' />
                                  <attribute name='lux_isterrorismcoverrequired' />
                                </link-entity>
                              </entity>
                            </fetch>";
                }
                else if (product == "Commercial Combined" || product == "Office")
                {
                    entityName = "lux_commercialcombinedapplication";
                    fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_commercialcombinedapplication'>
                                <attribute name='lux_commercialcombinedapplicationid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_rentreceivable' />
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_icow' />
                                <attribute name='lux_typeofcover' />
                                <attribute name='lux_bookdebts' />
                                <attribute name='lux_amount' />
                                <attribute name='lux_generalcontentsdeclaredvalueincludingmach' />
                                <attribute name='lux_buildingsdeclaredvalue' /> 
                                <attribute name='lux_tenantsimprovementsdeclaredvalue' />
                                <attribute name='lux_listhighvaluestock' />
                                <attribute name='lux_stockexcludinghighvaluestock' />
                                <attribute name='lux_computerandelectronicbusinessequipment' />
                                <attribute name='lux_winesfortifiedwinesspiritsfinesuminsured' />
                                <attribute name='lux_powertoolssuminsured' />
                                <attribute name='lux_nonferrousmetalssuminsured' />
                                <attribute name='lux_mobilephonessuminsured' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_computerequipmentsuminsured' />
                                <attribute name='lux_audiovideoequipmentsuminsured' />
                                <attribute name='lux_alcoholsuminsured' />
                                <attribute name='lux_computergamesandorconsolessuminsured' />
                                <attribute name='lux_cigarettescigarsortobaccoproductssuminsur' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_fineartsuminsured' />
                                <attribute name='lux_additionalincreasedcostofworking' /> 
                                <attribute name='lux_materialdamagelossofrentpayable' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplications' visible='false' link-type='outer' alias='poa'>
                                  <attribute name='lux_levelofcommission' />
                                  <attribute name='lux_isterrorismcoverrequired' />
                                </link-entity>
                              </entity>
                            </fetch>";
                }
                else if (product == "Pubs & Restaurants" || product == "Hotels and Guesthouses")
                {
                    entityName = "lux_pubsrestaurantspropertyownersapplicatio";
                    fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_pubsrestaurantspropertyownersapplicatio'>
                                <attribute name='lux_pubsrestaurantspropertyownersapplicatioid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_rentreceivable' />
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_icow' />
                                <attribute name='lux_typeofcover' />
                                <attribute name='lux_bookdebts' />
                                <attribute name='lux_amount' />
                                <attribute name='lux_generalcontentsdeclaredvalueincludingmach' />
                                <attribute name='lux_buildingsdeclaredvalue' /> 
                                <attribute name='lux_tenantsimprovementsdeclaredvalue' />
                                <attribute name='lux_listhighvaluestock' />
                                <attribute name='lux_stockexcludinghighvaluestock' />
                                <attribute name='lux_computerandelectronicbusinessequipment' />
                                <attribute name='lux_winesfortifiedwinesspiritsfinesuminsured' />
                                <attribute name='lux_powertoolssuminsured' />
                                <attribute name='lux_nonferrousmetalssuminsured' />
                                <attribute name='lux_mobilephonessuminsured' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_computerequipmentsuminsured' />
                                <attribute name='lux_audiovideoequipmentsuminsured' />
                                <attribute name='lux_alcoholsuminsured' />
                                <attribute name='lux_computergamesandorconsolessuminsured' />
                                <attribute name='lux_cigarettescigarsortobaccoproductssuminsur' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_fineartsuminsured' />
                                <attribute name='lux_additionalincreasedcostofworking' /> 
                                <attribute name='lux_materialdamagelossofrentpayable' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplications' visible='false' link-type='outer' alias='poa'>
                                  <attribute name='lux_levelofcommission' />
                                  <attribute name='lux_isterrorismcoverrequired' />
                                </link-entity>
                              </entity>
                            </fetch>";
                }
                else if (product == "Contractors Combined")
                {
                    entityName = "lux_contractorscombined";
                    fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_contractorscombined'>
                                <attribute name='lux_contractorscombinedid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_rentreceivable' />
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_icow' />
                                <attribute name='lux_typeofcover' />
                                <attribute name='lux_bookdebts' />
                                <attribute name='lux_amount' />
                                <attribute name='lux_generalcontentsdeclaredvalueincludingmach' />
                                <attribute name='lux_buildingsdeclaredvalue' /> 
                                <attribute name='lux_tenantsimprovementsdeclaredvalue' />
                                <attribute name='lux_listhighvaluestock' />
                                <attribute name='lux_stockexcludinghighvaluestock' />
                                <attribute name='lux_computerandelectronicbusinessequipment' />
                                <attribute name='lux_winesfortifiedwinesspiritsfinesuminsured' />
                                <attribute name='lux_powertoolssuminsured' />
                                <attribute name='lux_nonferrousmetalssuminsured' />
                                <attribute name='lux_mobilephonessuminsured' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_computerequipmentsuminsured' />
                                <attribute name='lux_audiovideoequipmentsuminsured' />
                                <attribute name='lux_alcoholsuminsured' />
                                <attribute name='lux_computergamesandorconsolessuminsured' />
                                <attribute name='lux_cigarettescigarsortobaccoproductssuminsur' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_fineartsuminsured' />
                                <attribute name='lux_additionalincreasedcostofworking' /> 
                                <attribute name='lux_materialdamagelossofrentpayable' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplications' visible='false' link-type='outer' alias='poa'>
                                  <attribute name='lux_levelofcommission' />
                                  <attribute name='lux_isterrorismcoverrequired' />
                                </link-entity>
                              </entity>
                            </fetch>";
                }

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    decimal TerrorismTotal = 0;
                    foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                    {
                        var premise_data = item;

                        if (premise_data.Contains("poa.lux_isterrorismcoverrequired") && ((bool)((premise_data.GetAttributeValue<AliasedValue>("poa.lux_isterrorismcoverrequired")).Value)) == true)
                        {
                            var postcode = premise_data.Contains("lux_riskpostcode") ? premise_data.Attributes["lux_riskpostcode"] : "";
                            var post2digits = postcode.ToString().Substring(0, 2);
                            var post3digits = postcode.ToString().Substring(0, 3);
                            var post4digits = postcode.ToString().Substring(0, 4);
                            var zone = 972970003;
                            if (postcode.ToString() != "")
                            {
                                var TerrorismFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_terrorismratingzone'>
                                                            <attribute name='lux_name' />
                                                            <attribute name='lux_locationzone' />
                                                            <attribute name='lux_terrorismratingzoneid' />
                                                            <order attribute='lux_locationzone' descending='false' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_name' operator='eq' value='{post4digits}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";
                                if (service.RetrieveMultiple(new FetchExpression(TerrorismFetch)).Entities.Count > 0)
                                {
                                    zone = service.RetrieveMultiple(new FetchExpression(TerrorismFetch)).Entities[0].GetAttributeValue<OptionSetValue>("lux_locationzone").Value;
                                }
                                else
                                {
                                    var TerrorismFetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_terrorismratingzone'>
                                                            <attribute name='lux_name' />
                                                            <attribute name='lux_locationzone' />
                                                            <attribute name='lux_terrorismratingzoneid' />
                                                            <order attribute='lux_locationzone' descending='false' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_name' operator='eq' value='{post3digits}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";
                                    if (service.RetrieveMultiple(new FetchExpression(TerrorismFetch1)).Entities.Count > 0)
                                    {
                                        zone = service.RetrieveMultiple(new FetchExpression(TerrorismFetch1)).Entities[0].GetAttributeValue<OptionSetValue>("lux_locationzone").Value;
                                    }
                                    else
                                    {
                                        var TerrorismFetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_terrorismratingzone'>
                                                            <attribute name='lux_name' />
                                                            <attribute name='lux_locationzone' />
                                                            <attribute name='lux_terrorismratingzoneid' />
                                                            <order attribute='lux_locationzone' descending='false' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_name' operator='eq' value='{post2digits}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";
                                        if (service.RetrieveMultiple(new FetchExpression(TerrorismFetch2)).Entities.Count > 0)
                                        {
                                            zone = service.RetrieveMultiple(new FetchExpression(TerrorismFetch2)).Entities[0].GetAttributeValue<OptionSetValue>("lux_locationzone").Value;
                                        }
                                    }
                                }
                            }

                            var IsBITaken = appln.GetAttributeValue<OptionSetValue>("lux_typeofcover");
                            decimal BIsum_Insured = 0;
                            if (IsBITaken != null)
                            {
                                decimal GrossProfitRevenue = appln.Attributes.Contains("lux_amount") ? appln.GetAttributeValue<Money>("lux_amount").Value : 0;
                                decimal IncreasedCOW = appln.Attributes.Contains("lux_icow") ? appln.GetAttributeValue<Money>("lux_icow").Value : 0;
                                decimal AdditionalIncreasedCOW = appln.Attributes.Contains("lux_additionalincreasedcostofworking") ? appln.GetAttributeValue<Money>("lux_additionalincreasedcostofworking").Value : 0;
                                decimal BookDebts = appln.Attributes.Contains("lux_bookdebts") ? appln.GetAttributeValue<Money>("lux_bookdebts").Value : 0;
                                decimal LOR = appln.Attributes.Contains("lux_rentreceivable") ? appln.GetAttributeValue<Money>("lux_rentreceivable").Value : 0;
                                BIsum_Insured = GrossProfitRevenue + IncreasedCOW + AdditionalIncreasedCOW + LOR;
                            }

                            var Buildings = premise_data.Attributes.Contains("lux_buildingsdeclaredvalue") ? premise_data.GetAttributeValue<Money>("lux_buildingsdeclaredvalue").Value : 0;
                            var Tenents = premise_data.Attributes.Contains("lux_tenantsimprovementsdeclaredvalue") ? premise_data.GetAttributeValue<Money>("lux_tenantsimprovementsdeclaredvalue").Value : 0;
                            var Contents = premise_data.Attributes.Contains("lux_generalcontentsdeclaredvalueincludingmach") ? premise_data.GetAttributeValue<Money>("lux_generalcontentsdeclaredvalueincludingmach").Value : 0;
                            var ComputerEquip = premise_data.Attributes.Contains("lux_computerandelectronicbusinessequipment") ? premise_data.GetAttributeValue<Money>("lux_computerandelectronicbusinessequipment").Value : 0;
                            var Stock = premise_data.Attributes.Contains("lux_stockexcludinghighvaluestock") ? premise_data.GetAttributeValue<Money>("lux_stockexcludinghighvaluestock").Value : 0;
                            decimal TargetStockSI = 0;
                            var TargetStock = premise_data.GetAttributeValue<OptionSetValueCollection>("lux_listhighvaluestock");
                            if (TargetStock != null)
                            {
                                decimal WineSumInsured = premise_data.Attributes.Contains("lux_winesfortifiedwinesspiritsfinesuminsured") ? premise_data.GetAttributeValue<Money>("lux_winesfortifiedwinesspiritsfinesuminsured").Value : 0;
                                decimal NonFerrusInsured = premise_data.Attributes.Contains("lux_nonferrousmetalssuminsured") ? premise_data.GetAttributeValue<Money>("lux_nonferrousmetalssuminsured").Value : 0;
                                decimal MobileInsured = premise_data.Attributes.Contains("lux_mobilephonessuminsured") ? premise_data.GetAttributeValue<Money>("lux_mobilephonessuminsured").Value : 0;
                                decimal ComputerSumInsured = premise_data.Attributes.Contains("lux_computerequipmentsuminsured") ? premise_data.GetAttributeValue<Money>("lux_computerequipmentsuminsured").Value : 0;
                                decimal AlcoholSumInsured = premise_data.Attributes.Contains("lux_alcoholsuminsured") ? premise_data.GetAttributeValue<Money>("lux_alcoholsuminsured").Value : 0;
                                decimal AudioSumInsured = premise_data.Attributes.Contains("lux_audiovideoequipmentsuminsured") ? premise_data.GetAttributeValue<Money>("lux_audiovideoequipmentsuminsured").Value : 0;
                                decimal CigarettesSumInsured = premise_data.Attributes.Contains("lux_cigarettescigarsortobaccoproductssuminsur") ? premise_data.GetAttributeValue<Money>("lux_cigarettescigarsortobaccoproductssuminsur").Value : 0;
                                decimal ComputerGamesInsured = premise_data.Attributes.Contains("lux_computergamesandorconsolessuminsured") ? premise_data.GetAttributeValue<Money>("lux_computergamesandorconsolessuminsured").Value : 0;
                                decimal JewelleryInsured = premise_data.Attributes.Contains("lux_jewellerywatchessuminsured") ? premise_data.GetAttributeValue<Money>("lux_jewellerywatchessuminsured").Value : 0;
                                decimal PowerToolsSumInsured = premise_data.Attributes.Contains("lux_powertoolssuminsured") ? premise_data.GetAttributeValue<Money>("lux_powertoolssuminsured").Value : 0;
                                decimal FineArtSumInsured = premise_data.Attributes.Contains("lux_fineartsuminsured") ? premise_data.GetAttributeValue<Money>("lux_fineartsuminsured").Value : 0;
                                TargetStockSI = WineSumInsured + NonFerrusInsured + MobileInsured + ComputerSumInsured + AlcoholSumInsured + AudioSumInsured + CigarettesSumInsured + ComputerGamesInsured + JewelleryInsured + PowerToolsSumInsured + FineArtSumInsured;
                            }
                            var LossofRent = premise_data.Attributes.Contains("lux_materialdamagelossofrentpayable") ? premise_data.GetAttributeValue<Money>("lux_materialdamagelossofrentpayable").Value : 0;
                            decimal SARSI = 0;
                            var fetch11 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_allriskitem'>
                                <attribute name='lux_typeofequipment' />
                                <attribute name='lux_territoriallimit' />
                                <attribute name='lux_suminsured' />
                                <attribute name='lux_excess' />
                                <attribute name='lux_allriskitemid' />
                                <order attribute='lux_typeofequipment' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_application' link-type='inner' alias='aa'>
                                  <filter type='and'>
                                    <condition attribute='lux_allriskitems' operator='eq' value='1' />
                                  </filter>
                                </link-entity>
                              </entity>
                            </fetch>";

                            if (service.RetrieveMultiple(new FetchExpression(fetch11)).Entities.Count > 0)
                            {
                                foreach (var item11 in service.RetrieveMultiple(new FetchExpression(fetch11)).Entities)
                                {
                                    SARSI += item11.Attributes.Contains("lux_suminsured") ? item11.GetAttributeValue<Money>("lux_suminsured").Value : 0;
                                }
                            }

                            var MDSum_insured = Buildings + Tenents + Contents + ComputerEquip + Stock + TargetStockSI + LossofRent + SARSI;

                            decimal TerrorismPremium = 0;
                            decimal TerrorismMDPremium = 0;
                            decimal TerrorismBIPremium = 0;
                            decimal MDSI_rate = 0;
                            decimal BISI_rate = 0;

                            if (MDSum_insured > 0)
                            {
                                var MDRatesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_terrorismrate'>
                                                <attribute name='lux_ratebeforeanydiscount' />
                                                <attribute name='lux_locationzone' />
                                                <attribute name='lux_ratetype' />
                                                <attribute name='lux_terrorismrateid' />
                                                <order attribute='lux_ratetype' descending='false' />
                                                <order attribute='lux_locationzone' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_locationzone' operator='eq' value='{zone}' />
                                                  <condition attribute='lux_ratetype' operator='eq' value='972970002' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(MDRatesFetch)).Entities.Count > 0)
                                {
                                    var SI_data = service.RetrieveMultiple(new FetchExpression(MDRatesFetch)).Entities[0];
                                    if (SI_data.Contains("lux_ratebeforeanydiscount"))
                                    {
                                        MDSI_rate = SI_data.GetAttributeValue<decimal>("lux_ratebeforeanydiscount");
                                    }
                                    TerrorismMDPremium = MDSum_insured * MDSI_rate / 100;
                                }
                            }
                            if (BIsum_Insured > 0)
                            {
                                var BIRatesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_terrorismrate'>
                                                <attribute name='lux_ratebeforeanydiscount' />
                                                <attribute name='lux_locationzone' />
                                                <attribute name='lux_ratetype' />
                                                <attribute name='lux_terrorismrateid' />
                                                <order attribute='lux_ratetype' descending='false' />
                                                <order attribute='lux_locationzone' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_locationzone' operator='eq' value='{zone}' />
                                                  <condition attribute='lux_ratetype' operator='eq' value='972970001' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(BIRatesFetch)).Entities.Count > 0)
                                {
                                    var SI_data = service.RetrieveMultiple(new FetchExpression(BIRatesFetch)).Entities[0];
                                    if (SI_data.Contains("lux_ratebeforeanydiscount"))
                                    {
                                        BISI_rate = SI_data.GetAttributeValue<decimal>("lux_ratebeforeanydiscount");
                                    }
                                    TerrorismBIPremium += BIsum_Insured * BISI_rate / 100;
                                }
                            }
                            TerrorismMDPremium = TerrorismMDPremium * dateDiffDays / 365;
                            TerrorismBIPremium = TerrorismBIPremium * dateDiffDays / 365;

                            TerrorismPremium = TerrorismMDPremium + TerrorismBIPremium;

                            //var MDSIDisk = Buildings + Contents + Stock + TargetStockSI;
                            //if (MDSIDisk < 2000000)
                            //{
                            //    TerrorismPremium = TerrorismPremium - TerrorismPremium * 40 / 100;
                            //}

                            var item1 = service.Retrieve(entityName, item.Id, new ColumnSet(true));
                            item1["lux_terrorismbipremium"] = new Money(TerrorismBIPremium);
                            item1["lux_terrorismmdpremium"] = new Money(TerrorismMDPremium);
                            item1["lux_terrorismbirate"] = BISI_rate;
                            item1["lux_terrorismmdrate"] = MDSI_rate;
                            item1["lux_terrorismpremium"] = new Money(TerrorismPremium);
                            item1["lux_terrorismzone"] = new OptionSetValue(zone);
                            service.Update(item1);

                            TerrorismTotal += TerrorismPremium;
                        }
                        else
                        {
                            var item1 = service.Retrieve(entityName, item.Id, new ColumnSet(true));
                            item1["lux_terrorismbipremium"] = new Money(0);
                            item1["lux_terrorismmdpremium"] = new Money(0);
                            item1["lux_terrorismbirate"] = new decimal(0);
                            item1["lux_terrorismmdrate"] = new decimal(0);
                            item1["lux_terrorismpremium"] = new Money(0);
                            service.Update(item1);

                            TerrorismTotal += 0;
                        }
                    }
                    if (quotationDate >= new DateTime(2025, 05, 01))
                    {
                        item2["lux_terrorismpremium"] = new Money(TerrorismTotal);
                        item2["lux_terrorismnetpremium"] = new Money(TerrorismTotal - TerrorismTotal * Convert.ToDecimal(37.5) / 100);
                        item2["lux_terrorismquotedpremium"] = new Money(TerrorismTotal);
                        item2["lux_terrorismpolicynetpremiumexcludingipt"] = new Money(TerrorismTotal - TerrorismTotal * Convert.ToDecimal(37.5) / 100);

                        item2["lux_terrorismbrokercommission"] = "22.5%";
                        item2["lux_terrorismpolicybrokercommission"] = "22.5%";
                        item2["lux_terrorismbrokercommissionamount"] = new Money(TerrorismTotal * 22.5M / 100);
                        item2["lux_terrorismquotedpremiumbrokercommissionamo"] = new Money(TerrorismTotal * 22.5M / 100);
                        item2["lux_terrorismaciescommission"] = "15.0%";
                        item2["lux_terrorismpolicyaciescommission"] = "15.0%";
                        item2["lux_terrorismaciescommissionamout"] = new Money(TerrorismTotal * 15M / 100);
                        item2["lux_terrorismquotedpremiumaciescommissionamou"] = new Money(TerrorismTotal * 15M / 100);
                        item2["lux_terrorismtotalcommission"] = "37.5%";
                        item2["lux_terrorismpolicytotalcommission"] = "37.5%";
                    }
                    else
                    {
                        item2["lux_terrorismpremium"] = new Money(TerrorismTotal);
                        item2["lux_terrorismnetpremium"] = new Money(TerrorismTotal - TerrorismTotal * Convert.ToDecimal(32.5) / 100);
                        item2["lux_terrorismquotedpremium"] = new Money(TerrorismTotal);
                        item2["lux_terrorismpolicynetpremiumexcludingipt"] = new Money(TerrorismTotal - TerrorismTotal * Convert.ToDecimal(32.5) / 100);

                        item2["lux_terrorismbrokercommission"] = "20%";
                        item2["lux_terrorismpolicybrokercommission"] = "20%";
                        item2["lux_terrorismbrokercommissionamount"] = new Money(TerrorismTotal * 20 / 100);
                        item2["lux_terrorismquotedpremiumbrokercommissionamo"] = new Money(TerrorismTotal * 20 / 100);
                        item2["lux_terrorismaciescommission"] = "12.5%";
                        item2["lux_terrorismpolicyaciescommission"] = "12.5%";
                        item2["lux_terrorismaciescommissionamout"] = new Money(TerrorismTotal * 12.5M / 100);
                        item2["lux_terrorismquotedpremiumaciescommissionamou"] = new Money(TerrorismTotal * 12.5M / 100);
                        item2["lux_terrorismtotalcommission"] = "32.5%";
                        item2["lux_terrorismpolicytotalcommission"] = "32.5%";
                    }
                    service.Update(item2);
                }
            }
        }
    }
}