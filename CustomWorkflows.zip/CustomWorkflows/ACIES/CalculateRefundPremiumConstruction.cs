﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculateRefundPremiumConstruction : CodeActivity
    {
        [Input("Application")]
        [ReferenceTarget("lux_constructionquotes")]
        public InArgument<EntityReference> Application { get; set; }

        [Input("Policy")]
        [ReferenceTarget("lux_constructionpolicy")]
        public InArgument<EntityReference> Policy { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            Entity applnref = service.Retrieve("lux_constructionquotes", Application.Get(executionContext).Id, new ColumnSet(true));
            Entity appln = service.Retrieve(applnref.LogicalName, applnref.Id, new ColumnSet(true));

            var mainfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_constructionquotes'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_constructionquotesid' />
                                <attribute name='lux_constructioncombinedprojectsection' />                                
                                <attribute name='lux_publicliabilitybuildingandalliedtradessec' />
                                <attribute name='lux_nonnegligentdamagesection' />
                                <attribute name='lux_delayinstartupsection' />
                                <attribute name='lux_contractorsplantandequipmentsection' />
                                <attribute name='lux_constructioncombinedannualsection' />
                                <attribute name='lux_existingstructurespremium' />
                                <attribute name='lux_terrorismsection' />                               
                                <attribute name='lux_premium' />
                                <attribute name='lux_policyadministrationfeepaf' />
                                <attribute name='lux_inceptiondate' />
                                <attribute name='lux_expirydate' />
                                <attribute name='lux_mtapolicyadministrationfeepaf' />
                                <attribute name='lux_mtadate' />
                                <order attribute='lux_inceptiondate' descending='true' />
                                <order attribute='lux_name' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_name' operator='eq' value='{appln.Attributes["lux_quotenumber"].ToString()}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities.Count > 0)
            {
                var mtafetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_constructionquotes'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />                      
                                <attribute name='lux_constructionquotesid' />
                                <attribute name='lux_constructioncombinedprojectsection' />                                
                                <attribute name='lux_publicliabilitybuildingandalliedtradessec' />
                                <attribute name='lux_nonnegligentdamagesection' />
                                <attribute name='lux_delayinstartupsection' />
                                <attribute name='lux_contractorsplantandequipmentsection' />
                                <attribute name='lux_constructioncombinedannualsection' />
                                <attribute name='lux_existingstructurespremium' />
                                <attribute name='lux_terrorismsection' />                               
                                <attribute name='lux_premium' />
                                <attribute name='lux_policyadministrationfeepaf' />
                                <attribute name='lux_inceptiondate' />
                                <attribute name='lux_expirydate' />
                                <attribute name='lux_mtapolicyadministrationfeepaf' />
                                <attribute name='lux_mtadate' />
                                <order attribute='lux_inceptiondate' descending='true' />
                                <order attribute='lux_name' descending='true' />
                                <filter type='and'>
                                      <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_constructionpolicy' value='{Policy.Get(executionContext).Id}' />
                                      <condition attribute='lux_applicationtype' operator='eq' value='972970002' />     
                                      <condition attribute='statuscode' operator='eq' value='972970006' />
                                </filter>
                              </entity>
                            </fetch>";

                var mainRecord = service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities[0];

                var mainGrossPremium = mainRecord.Attributes.Contains("lux_premium") ? mainRecord.GetAttributeValue<Money>("lux_premium").Value : 0;
                var mainCCSingleProjectPremium = mainRecord.Attributes.Contains("lux_constructioncombinedprojectsection") ? mainRecord.GetAttributeValue<Money>("lux_constructioncombinedprojectsection").Value : 0;
                var mainPLPremium = mainRecord.Attributes.Contains("lux_publicliabilitybuildingandalliedtradessec") ? mainRecord.GetAttributeValue<Money>("lux_publicliabilitybuildingandalliedtradessec").Value : 0;
                var mainNonNegPremium = mainRecord.Attributes.Contains("lux_nonnegligentdamagesection") ? mainRecord.GetAttributeValue<Money>("lux_nonnegligentdamagesection").Value : 0;
                var mainDelayPremium = mainRecord.Attributes.Contains("lux_delayinstartupsection") ? mainRecord.GetAttributeValue<Money>("lux_delayinstartupsection").Value : 0;
                var mainCPEPremium = mainRecord.Attributes.Contains("lux_contractorsplantandequipmentsection") ? mainRecord.GetAttributeValue<Money>("lux_contractorsplantandequipmentsection").Value : 0;
                var mainCCAnnualPremium = mainRecord.Attributes.Contains("lux_constructioncombinedannualsection") ? mainRecord.GetAttributeValue<Money>("lux_constructioncombinedannualsection").Value : 0;
                var mainExistingStrucPremium = mainRecord.Attributes.Contains("lux_existingstructurespremium") ? mainRecord.GetAttributeValue<Money>("lux_existingstructurespremium").Value : 0;
                var mainTerrorismPremium = mainRecord.Attributes.Contains("lux_terrorismsection") ? mainRecord.GetAttributeValue<Money>("lux_terrorismsection").Value : 0;
                var mainPolicyFee = mainRecord.Attributes.Contains("lux_policyadministrationfeepaf") ? mainRecord.GetAttributeValue<Money>("lux_policyadministrationfeepaf").Value : 0;

                var mtaGrossPremium = 0M;
                var mtaCCSingleProjectPremium = 0M;
                var mtaPLPremium = 0M;
                var mtaNonNegPremium = 0M;
                var mtaDelayPremium = 0M;
                var mtaCPEPremium = 0M;
                var mtaCCAnnualPremium = 0M;
                var mtaExistingStrucPremium = 0M;
                var mtaTerrorismPremium = 0M;
                var mtaPolicyFee = 0M;

                if (service.RetrieveMultiple(new FetchExpression(mtafetch)).Entities.Count > 0)
                {
                    var mtaRocords = service.RetrieveMultiple(new FetchExpression(mtafetch)).Entities;

                    mtaGrossPremium = mtaRocords.Sum(x => x.Contains("lux_mtapremium") ? x.GetAttributeValue<Money>("lux_mtapremium").Value : 0);
                    mtaCCSingleProjectPremium = mtaRocords.Sum(x => x.Contains("lux_constructioncombinedprojectsectionmta") ? x.GetAttributeValue<Money>("lux_constructioncombinedprojectsectionmta").Value : 0);
                    mtaPLPremium = mtaRocords.Sum(x => x.Contains("lux_publicliabilitybuildingandalliedtradesmta") ? x.GetAttributeValue<Money>("lux_publicliabilitybuildingandalliedtradesmta").Value : 0);
                    mtaNonNegPremium = mtaRocords.Sum(x => x.Contains("lux_nonnegligentdamagesectionmta") ? x.GetAttributeValue<Money>("lux_nonnegligentdamagesectionmta").Value : 0);
                    mtaDelayPremium = mtaRocords.Sum(x => x.Contains("lux_delayinstartupsectionmta") ? x.GetAttributeValue<Money>("lux_delayinstartupsectionmta").Value : 0);
                    mtaCPEPremium = mtaRocords.Sum(x => x.Contains("lux_contractorsplantandequipmentsectionmta") ? x.GetAttributeValue<Money>("lux_contractorsplantandequipmentsectionmta").Value : 0);
                    mtaCCAnnualPremium = mtaRocords.Sum(x => x.Contains("lux_constructioncombinedannualsectionmta") ? x.GetAttributeValue<Money>("lux_constructioncombinedannualsectionmta").Value : 0);
                    mtaExistingStrucPremium = mtaRocords.Sum(x => x.Contains("lux_existingstructurespremiummta") ? x.GetAttributeValue<Money>("lux_existingstructurespremiummta").Value : 0);
                    mtaTerrorismPremium = mtaRocords.Sum(x => x.Contains("lux_terrorismsectionmta") ? x.GetAttributeValue<Money>("lux_terrorismsectionmta").Value : 0);
                    mtaPolicyFee = mtaRocords.Sum(x => x.Contains("lux_mtapolicyadministrationfeepaf") ? x.GetAttributeValue<Money>("lux_mtapolicyadministrationfeepaf").Value : 0);
                }

                var PolicyDuration = (appln.GetAttributeValue<DateTime>("lux_expirydate") - appln.GetAttributeValue<DateTime>("lux_inceptiondate")).Days + 1;
                var LengthtillNow = (appln.GetAttributeValue<DateTime>("lux_mtadate") - appln.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                var remainingDays = PolicyDuration - LengthtillNow;

                var MTAGrossPremium = (mainGrossPremium + mtaGrossPremium) * remainingDays / PolicyDuration;
                var MTACCSingleProjectPremium = (mainCCSingleProjectPremium + mtaCCSingleProjectPremium) * remainingDays / PolicyDuration;
                var MTAPLPremium = (mainPLPremium + mtaPLPremium) * remainingDays / PolicyDuration;
                var MTANonNegPremium = (mainNonNegPremium + mtaNonNegPremium) * remainingDays / PolicyDuration;
                var MTADelayPremium = (mainDelayPremium + mtaDelayPremium) * remainingDays / PolicyDuration;
                var MTACPEPremium = (mainCPEPremium + mtaCPEPremium) * remainingDays / PolicyDuration;
                var MTACCAnnualPremium = (mainCCAnnualPremium + mtaCCAnnualPremium) * remainingDays / PolicyDuration;
                var MTAExistingStrucPremium = (mainExistingStrucPremium + mtaExistingStrucPremium) * remainingDays / PolicyDuration;
                var MTATerrorismPremium = (mainTerrorismPremium + mtaTerrorismPremium) * remainingDays / PolicyDuration;
                var MTAPolicyFee = (mainPolicyFee + mtaPolicyFee) * remainingDays / PolicyDuration;

                appln["lux_mtapremium"] = new Money(-1 * MTAGrossPremium);
                appln["lux_constructioncombinedprojectsectionmta"] = new Money(-1 * MTACCSingleProjectPremium);
                appln["lux_publicliabilitybuildingandalliedtradesmta"] = new Money(-1 * MTAPLPremium);
                appln["lux_nonnegligentdamagesectionmta"] = new Money(-1 * MTANonNegPremium);
                appln["lux_delayinstartupsectionmta"] = new Money(-1 * MTADelayPremium);
                appln["lux_contractorsplantandequipmentsectionmta"] = new Money(-1 * MTACPEPremium);
                appln["lux_constructioncombinedannualsectionmta"] = new Money(-1 * MTACCAnnualPremium);
                appln["lux_existingstructurespremiummta"] = new Money(-1 * MTAExistingStrucPremium);
                appln["lux_terrorismsectionmta"] = new Money(-1 * MTATerrorismPremium);

                if (LengthtillNow == 0)
                {
                    appln["lux_mtapolicyadministrationfeepaf"] = new Money(-1 * mainPolicyFee);
                }
                else
                {
                    appln["lux_mtapolicyadministrationfeepaf"] = new Money(0);
                }

                service.Update(appln);
            }
        }
    }
}