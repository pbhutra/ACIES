﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CustomWorkflows
{
    public class AssociateEndorsementsDataFromView : CodeActivity
    {
        [Input("Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> Application { get; set; }

        [Input("View")]
        [ReferenceTarget("savedquery")]
        [RequiredArgument]
        public InArgument<EntityReference> View { get; set; }

        [Input("Product")]
        public InArgument<string> Product { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference viewref = View.Get<EntityReference>(executionContext);
            Entity view = service.Retrieve("savedquery", viewref.Id, new ColumnSet(true));

            EntityReference applref = Application.Get<EntityReference>(executionContext);
            Entity appln = service.Retrieve("lux_propertyownersapplications", applref.Id, new ColumnSet(true));

            var fetch = view.Attributes["fetchxml"].ToString();

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_applicationendorsements'>
                                            <attribute name='lux_applicationendorsementsid' />
                                            <attribute name='lux_name' />
                                            <attribute name='createdon' />
                                            <order attribute='lux_name' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_endorsementlibrary' operator='eq' uiname='Wood Burner Condition' uitype='lux_endorsementlibrary' value='{item.Attributes["lux_endorsementlibraryid"]}' />
                                              <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{Application.Get(executionContext).Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";
                    if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count == 0)
                    {
                        Entity ent = new Entity("lux_applicationendorsements");
                        ent["lux_application"] = new EntityReference("lux_propertyownersapplications", Application.Get(executionContext).Id);
                        ent["lux_endorsementdescription"] = item.Attributes["lux_endorsementdescription"];
                        ent["lux_name"] = item.Attributes["lux_name"];
                        ent["lux_endorsementlibrary"] = new EntityReference("lux_endorsementlibrary", new Guid(item.Attributes["lux_endorsementlibraryid"].ToString()));
                        service.Create(ent);
                    }
                }
            }
        }
    }
}