﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CustomWorkflows
{
    public class CalculateMDPremium : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownerspremise'>
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_tenanttype' />                                
                                <attribute name='lux_isthepremisesahouseofmultipleoccupation' />
                                <attribute name='lux_declaredvalueforrebuildingthisproperty' />
                                <attribute name='lux_buildingconstruction' />
                                <attribute name='lux_totalsuminsuredforthislocation' />
                                <attribute name='lux_basisofcover' />
                                <attribute name='lux_occupancytype' />
                                <attribute name='lux_suminsuredwithupliftedamount' />
                                <attribute name='lux_landlordscontentsinresidentialareas' />                                
                                <attribute name='lux_totalcontentsofcommunalareas' />
                                <attribute name='lux_totalnumberofcommercialunitsatthisaddress' />
                                <attribute name='lux_howmanyfloorsareofconcreteconstruction' />
                                <attribute name='lux_howmanyfloorsareofwoodenconstruction' />
                                <attribute name='lux_commercialunit1' />
                                <attribute name='lux_commercialunit2' />
                                <attribute name='lux_commercialunit3' />
                                <attribute name='lux_commercialunit4' />
                                <attribute name='lux_commercialunit5' />
                                <attribute name='lux_commercialunit6' />
                                <attribute name='lux_commercialunit7' />
                                <attribute name='lux_commercialunit8' />
                                <attribute name='lux_commercialunit9' />
                                <attribute name='lux_commercialunit10' />
                                <attribute name='lux_commercialunit11' />
                                <attribute name='lux_commercialunit12' />
                                <attribute name='lux_commercialunit13' />
                                <attribute name='lux_commercialunit14' />
                                <attribute name='lux_commercialunit15' />
                                <attribute name='lux_commercialunit16' />
                                <attribute name='lux_commercialunit17' />
                                <attribute name='lux_commercialunit18' />
                                <attribute name='lux_commercialunit19' />
                                <attribute name='lux_commercialunit20' />
                                <attribute name='lux_lossofannualrentalincome' />
                                <attribute name='lux_indemnityperiodrequired' />
                                <attribute name='lux_propertyownerspremiseid' />
                                <attribute name='lux_materialdamagepremium' />
                                <attribute name='lux_materialdamageperilsrate' />
                                <attribute name='lux_buildingpolicypremium' />
                                <attribute name='lux_covers' />
                                <attribute name='lux_levelofcover' />                                
                                <attribute name='lux_lengthofexpectedunoccupancy' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplication' visible='false' link-type='outer' alias='poa'>
                                  <attribute name='lux_levelofcommission' />
                                  <attribute name='lux_whatisyourtrade' />
                                  <attribute name='lux_rpocpoproducttype' />
                                </link-entity>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var NoOfLocations = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count;
                decimal TotalMDPremium = 0;
                var item2 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                var dateDiffDays = (item2.GetAttributeValue<DateTime>("lux_renewaldate") - item2.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                if (dateDiffDays == 364 || dateDiffDays == 365 || dateDiffDays == 366)
                {
                    dateDiffDays = 365;
                }
                var quotationDate = item2.Contains("lux_quotationdate") ? item2.GetAttributeValue<DateTime>("lux_quotationdate") : item2.GetAttributeValue<DateTime>("lux_inceptiondate");
                var inceptionDate = item2.GetAttributeValue<DateTime>("lux_inceptiondate");
                var ApplicationType = item2.Attributes.Contains("lux_applicationtype") ? item2.FormattedValues["lux_applicationtype"].ToString() : "";

                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    var premise_data = item;
                    var covers = premise_data.GetAttributeValue<OptionSetValueCollection>("lux_covers");
                    var sum_Insured = premise_data.Contains("lux_totalsuminsuredforthislocation") ? premise_data.GetAttributeValue<Money>("lux_totalsuminsuredforthislocation").Value : 0;
                    var BuildingDeclaredValue = premise_data.Contains("lux_declaredvalueforrebuildingthisproperty") ? premise_data.GetAttributeValue<Money>("lux_declaredvalueforrebuildingthisproperty").Value : 0;
                    var ContentsDeclaredValue = premise_data.Contains("lux_landlordscontentsinresidentialareas") ? premise_data.GetAttributeValue<Money>("lux_landlordscontentsinresidentialareas").Value : 0;
                    var ContentsCommunalArea = premise_data.Contains("lux_totalcontentsofcommunalareas") ? premise_data.GetAttributeValue<Money>("lux_totalcontentsofcommunalareas").Value : 0;

                    decimal MDFireRate = 0;
                    decimal MDTheftRate = 0;
                    decimal SI_rate = 0;
                    decimal TotalRate = 0;
                    decimal GrossRate = 0;
                    var Trade = "";
                    if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970001 || ((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                    {
                        if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970002 || item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970003) //residential and unoccupied
                        {
                            Trade = "Property Owner - Residential";
                            if (item.Contains("poa.lux_whatisyourtrade"))
                            {
                                if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970001)
                                {
                                    Trade = "Housing Association";
                                }
                                else if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970002)
                                {
                                    Trade = "Property Developer";
                                }
                                else if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970003)
                                {
                                    Trade = "Property Owner - Residential";
                                }
                                else if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970004)
                                {
                                    Trade = "Property Owner - Residential";
                                }
                                else if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970005)
                                {
                                    Trade = "Property Management";
                                }
                            }

                            var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                  <filter type='or'>
                                                    <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                    <condition attribute='lux_enddate' operator='null' />
                                                  </filter>
                                                  <condition attribute='lux_name' operator='eq' uiname='' value='{Trade}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                            if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                            {
                                var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];
                                MDFireRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                MDTheftRate = FireData.GetAttributeValue<decimal>("lux_theftcontentsrate");

                                if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value != 972970001)
                                {
                                    if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                                    {
                                        if (MDFireRate < 0.10M)
                                        {
                                            MDFireRate = 0.10M;
                                        }
                                    }
                                    else if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                                    {
                                        if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                        {
                                            if (MDFireRate < 0.10M)
                                            {
                                                MDFireRate = 0.10M;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (item2.Attributes.Contains("lux_policy"))
                                        {
                                            var Policy = service.Retrieve("lux_policy", item2.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                            if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                            {
                                                if (quotationDate < new DateTime(2023, 02, 15))
                                                {
                                                    if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                                    {
                                                        if (MDFireRate < 0.10M)
                                                        {
                                                            MDFireRate = 0.10M;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    if (MDFireRate < 0.10M)
                                                    {
                                                        MDFireRate = 0.10M;
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                                {
                                                    if (MDFireRate < 0.10M)
                                                    {
                                                        MDFireRate = 0.10M;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                var timberCount = 0;
                                decimal ConstructionLoad = 0;
                                decimal TenantLoad = 0;
                                decimal ConsructionFireRate = MDFireRate;

                                var timber = premise_data.Contains("lux_howmanyfloorsareofwoodenconstruction") ? premise_data.Attributes["lux_howmanyfloorsareofwoodenconstruction"].ToString() : "";

                                if (timber != "" && !timber.Contains("0"))
                                {
                                    timberCount = 1;
                                }

                                if (timberCount == 1)
                                {
                                    var ConstructionFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_floorconstructionloaddiscount'>
                                                                    <attribute name='lux_name' />
                                                                    <attribute name='createdon' />
                                                                    <attribute name='lux_loaddiscount' />
                                                                    <attribute name='lux_floorconstructionloaddiscountid' />
                                                                    <order attribute='lux_name' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                      <filter type='or'>
                                                                        <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                        <condition attribute='lux_enddate' operator='null' />
                                                                      </filter>
                                                                      <condition attribute='lux_floorconstruction' operator='eq' value='972970001' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";
                                    if (service.RetrieveMultiple(new FetchExpression(ConstructionFetch)).Entities.Count > 0)
                                    {
                                        var LoadData = service.RetrieveMultiple(new FetchExpression(ConstructionFetch)).Entities[0];
                                        ConstructionLoad = LoadData.GetAttributeValue<decimal>("lux_loaddiscount");
                                    }
                                    ConsructionFireRate = MDFireRate + MDFireRate * ConstructionLoad / 100;
                                }

                                var tenantType = premise_data.Contains("lux_tenanttype") ? premise_data.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value : 0;
                                if (tenantType != 0)
                                {
                                    var TenantFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                              <entity name='lux_tenanttypeloaddiscount'>
                                                                <attribute name='lux_name' />
                                                                <attribute name='createdon' />
                                                                <attribute name='lux_loaddiscount' />
                                                                <attribute name='lux_tenanttypeloaddiscountid' />
                                                                <order attribute='lux_name' descending='false' />
                                                                <filter type='and'>
                                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                  <filter type='or'>
                                                                    <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                    <condition attribute='lux_enddate' operator='null' />
                                                                  </filter>
                                                                  <condition attribute='lux_tenanttype' operator='eq' value='{tenantType}' />
                                                                </filter>
                                                              </entity>
                                                            </fetch>";
                                    if (service.RetrieveMultiple(new FetchExpression(TenantFetch)).Entities.Count > 0)
                                    {
                                        var LoadData = service.RetrieveMultiple(new FetchExpression(TenantFetch)).Entities[0];
                                        TenantLoad = LoadData.GetAttributeValue<decimal>("lux_loaddiscount");
                                    }
                                }

                                var HMO = premise_data.Contains("lux_isthepremisesahouseofmultipleoccupation") ? premise_data.GetAttributeValue<bool>("lux_isthepremisesahouseofmultipleoccupation") : false;
                                if (HMO == true)
                                {
                                    var TenantFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                              <entity name='lux_tenanttypeloaddiscount'>
                                                                <attribute name='lux_name' />
                                                                <attribute name='createdon' />
                                                                <attribute name='lux_loaddiscount' />
                                                                <attribute name='lux_tenanttypeloaddiscountid' />
                                                                <order attribute='lux_name' descending='false' />
                                                                <filter type='and'>
                                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                  <filter type='or'>
                                                                    <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                    <condition attribute='lux_enddate' operator='null' />
                                                                  </filter>
                                                                  <condition attribute='lux_tenanttype' operator='eq' value='{972970008}' />
                                                                </filter>
                                                              </entity>
                                                            </fetch>";
                                    if (service.RetrieveMultiple(new FetchExpression(TenantFetch)).Entities.Count > 0)
                                    {
                                        var LoadData = service.RetrieveMultiple(new FetchExpression(TenantFetch)).Entities[0];
                                        TenantLoad += LoadData.GetAttributeValue<decimal>("lux_loaddiscount");
                                    }
                                }
                                GrossRate = ConsructionFireRate + ConsructionFireRate * TenantLoad / 100;
                            }
                        }
                        else if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970004) //commercial with residential
                        {
                            var numberofTrades = item.Attributes.Contains("lux_totalnumberofcommercialunitsatthisaddress") ? item.GetAttributeValue<int>("lux_totalnumberofcommercialunitsatthisaddress") : 0;
                            decimal FireRate = 0;
                            decimal TheftRate = 0;
                            if (numberofTrades > 0)
                            {
                                for (int i = 1; i <= numberofTrades; i++)
                                {
                                    var fieldName = "lux_commercialunit" + i;
                                    Trade = item.FormattedValues[fieldName].ToString();

                                    var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                  <filter type='or'>
                                                    <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                    <condition attribute='lux_enddate' operator='null' />
                                                  </filter>
                                                  <condition attribute='lux_name' operator='eq' uiname='' value='{Trade}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                                    if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                                    {
                                        var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];

                                        var item5 = service.Retrieve("lux_propertyownerspremise", item.Id, new ColumnSet(false));
                                        item5[fieldName] = new EntityReference("lux_propertyownersrate", FireData.Id);
                                        service.Update(item5);

                                        FireRate += FireData.GetAttributeValue<decimal>("lux_mdfirerate") < 0.10M ? 0.10M : FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                        TheftRate += FireData.GetAttributeValue<decimal>("lux_theftcontentsrate");
                                    }
                                }

                                MDFireRate = FireRate / numberofTrades;
                                MDTheftRate = TheftRate / numberofTrades;

                                if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value != 972970001)
                                {
                                    if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                                    {
                                        if (MDFireRate < 0.10M)
                                        {
                                            MDFireRate = 0.10M;
                                        }
                                    }
                                    else if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                                    {
                                        if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                        {
                                            if (MDFireRate < 0.10M)
                                            {
                                                MDFireRate = 0.10M;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (item2.Attributes.Contains("lux_policy"))
                                        {
                                            var Policy = service.Retrieve("lux_policy", item2.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                            if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                            {
                                                if (quotationDate < new DateTime(2023, 02, 15))
                                                {
                                                    if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                                    {
                                                        if (MDFireRate < 0.10M)
                                                        {
                                                            MDFireRate = 0.10M;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    if (MDFireRate < 0.10M)
                                                    {
                                                        MDFireRate = 0.10M;
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                                {
                                                    if (MDFireRate < 0.10M)
                                                    {
                                                        MDFireRate = 0.10M;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                var timberCount = 0;
                                decimal ConstructionLoad = 0;
                                decimal TenantLoad = 0;
                                decimal ConsructionFireRate = MDFireRate;

                                var timber = premise_data.Contains("lux_howmanyfloorsareofwoodenconstruction") ? premise_data.Attributes["lux_howmanyfloorsareofwoodenconstruction"].ToString() : "";

                                if (timber != "" && !timber.Contains("0"))
                                {
                                    timberCount = 1;
                                }

                                if (timberCount == 1)
                                {
                                    var ConstructionFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_floorconstructionloaddiscount'>
                                                                    <attribute name='lux_name' />
                                                                    <attribute name='createdon' />
                                                                    <attribute name='lux_loaddiscount' />
                                                                    <attribute name='lux_floorconstructionloaddiscountid' />
                                                                    <order attribute='lux_name' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                      <filter type='or'>
                                                                        <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                        <condition attribute='lux_enddate' operator='null' />
                                                                      </filter>
                                                                      <condition attribute='lux_floorconstruction' operator='eq' value='972970001' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";
                                    if (service.RetrieveMultiple(new FetchExpression(ConstructionFetch)).Entities.Count > 0)
                                    {
                                        var LoadData = service.RetrieveMultiple(new FetchExpression(ConstructionFetch)).Entities[0];
                                        ConstructionLoad = LoadData.GetAttributeValue<decimal>("lux_loaddiscount");
                                    }
                                    ConsructionFireRate = MDFireRate + MDFireRate * ConstructionLoad / 100;
                                }

                                var tenantType = premise_data.Contains("lux_tenanttype") ? premise_data.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value : 0;
                                if (tenantType != 0)
                                {
                                    var TenantFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                              <entity name='lux_tenanttypeloaddiscount'>
                                                                <attribute name='lux_name' />
                                                                <attribute name='createdon' />
                                                                <attribute name='lux_loaddiscount' />
                                                                <attribute name='lux_tenanttypeloaddiscountid' />
                                                                <order attribute='lux_name' descending='false' />
                                                                <filter type='and'>
                                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                  <filter type='or'>
                                                                    <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                    <condition attribute='lux_enddate' operator='null' />
                                                                  </filter>
                                                                  <condition attribute='lux_tenanttype' operator='eq' value='{tenantType}' />
                                                                </filter>
                                                              </entity>
                                                            </fetch>";
                                    if (service.RetrieveMultiple(new FetchExpression(TenantFetch)).Entities.Count > 0)
                                    {
                                        var LoadData = service.RetrieveMultiple(new FetchExpression(TenantFetch)).Entities[0];
                                        TenantLoad = LoadData.GetAttributeValue<decimal>("lux_loaddiscount");
                                    }
                                }

                                var HMO = premise_data.Contains("lux_isthepremisesahouseofmultipleoccupation") ? premise_data.GetAttributeValue<bool>("lux_isthepremisesahouseofmultipleoccupation") : false;
                                if (HMO == true)
                                {
                                    var TenantFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                              <entity name='lux_tenanttypeloaddiscount'>
                                                                <attribute name='lux_name' />
                                                                <attribute name='createdon' />
                                                                <attribute name='lux_loaddiscount' />
                                                                <attribute name='lux_tenanttypeloaddiscountid' />
                                                                <order attribute='lux_name' descending='false' />
                                                                <filter type='and'>
                                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                  <filter type='or'>
                                                                    <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                    <condition attribute='lux_enddate' operator='null' />
                                                                  </filter>
                                                                  <condition attribute='lux_tenanttype' operator='eq' value='{972970008}' />
                                                                </filter>
                                                              </entity>
                                                            </fetch>";
                                    if (service.RetrieveMultiple(new FetchExpression(TenantFetch)).Entities.Count > 0)
                                    {
                                        var LoadData = service.RetrieveMultiple(new FetchExpression(TenantFetch)).Entities[0];
                                        TenantLoad += LoadData.GetAttributeValue<decimal>("lux_loaddiscount");
                                    }
                                }
                                GrossRate = ConsructionFireRate + ConsructionFireRate * TenantLoad / 100;
                            }
                        }
                        else if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970001) //commercial
                        {
                            var numberofTrades = item.Attributes.Contains("lux_totalnumberofcommercialunitsatthisaddress") ? item.GetAttributeValue<int>("lux_totalnumberofcommercialunitsatthisaddress") : 0;
                            decimal FireRate = 0;
                            decimal TheftRate = 0;

                            if (numberofTrades > 0)
                            {
                                for (int i = 1; i <= numberofTrades; i++)
                                {
                                    var fieldName = "lux_commercialunit" + i;
                                    Trade = item.FormattedValues[fieldName].ToString();

                                    var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                  <filter type='or'>
                                                    <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                    <condition attribute='lux_enddate' operator='null' />
                                                  </filter>
                                                  <condition attribute='lux_name' operator='eq' uiname='' value='{Trade}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                                    if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                                    {
                                        var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];

                                        var item5 = service.Retrieve("lux_propertyownerspremise", item.Id, new ColumnSet(false));
                                        item5[fieldName] = new EntityReference("lux_propertyownersrate", FireData.Id);
                                        service.Update(item5);

                                        FireRate += FireData.GetAttributeValue<decimal>("lux_mdfirerate") < 0.10M ? 0.10M : FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                        TheftRate += FireData.GetAttributeValue<decimal>("lux_theftcontentsrate");
                                    }
                                }

                                MDFireRate = FireRate / numberofTrades;
                                MDTheftRate = TheftRate / numberofTrades;

                                if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value != 972970001)
                                {
                                    if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                                    {
                                        if (MDFireRate < 0.10M)
                                        {
                                            MDFireRate = 0.10M;
                                        }
                                    }
                                    else if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                                    {
                                        if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                        {
                                            if (MDFireRate < 0.10M)
                                            {
                                                MDFireRate = 0.10M;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (item2.Attributes.Contains("lux_policy"))
                                        {
                                            var Policy = service.Retrieve("lux_policy", item2.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                            if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                            {
                                                if (quotationDate < new DateTime(2023, 02, 15))
                                                {
                                                    if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                                    {
                                                        if (MDFireRate < 0.10M)
                                                        {
                                                            MDFireRate = 0.10M;
                                                        }
                                                    }
                                                }
                                                else
                                                {
                                                    if (MDFireRate < 0.10M)
                                                    {
                                                        MDFireRate = 0.10M;
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                                {
                                                    if (MDFireRate < 0.10M)
                                                    {
                                                        MDFireRate = 0.10M;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                var timberCount = 0;
                                decimal ConstructionLoad = 0;
                                decimal ConsructionFireRate = MDFireRate;

                                var timber = premise_data.Contains("lux_howmanyfloorsareofwoodenconstruction") ? premise_data.Attributes["lux_howmanyfloorsareofwoodenconstruction"].ToString() : "";

                                if (timber != "" && !timber.Contains("0"))
                                {
                                    timberCount = 1;
                                }

                                if (timberCount == 1)
                                {
                                    var ConstructionFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_floorconstructionloaddiscount'>
                                                                    <attribute name='lux_name' />
                                                                    <attribute name='createdon' />
                                                                    <attribute name='lux_loaddiscount' />
                                                                    <attribute name='lux_floorconstructionloaddiscountid' />
                                                                    <order attribute='lux_name' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                      <filter type='or'>
                                                                        <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                        <condition attribute='lux_enddate' operator='null' />
                                                                      </filter>
                                                                      <condition attribute='lux_floorconstruction' operator='eq' value='972970001' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";
                                    if (service.RetrieveMultiple(new FetchExpression(ConstructionFetch)).Entities.Count > 0)
                                    {
                                        var LoadData = service.RetrieveMultiple(new FetchExpression(ConstructionFetch)).Entities[0];
                                        ConstructionLoad = LoadData.GetAttributeValue<decimal>("lux_loaddiscount");
                                    }
                                    ConsructionFireRate = MDFireRate + MDFireRate * ConstructionLoad / 100;
                                }
                                GrossRate = ConsructionFireRate;
                            }
                        }
                    }
                    else
                    {
                        if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970002 || item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970003) //residential
                        {
                            MDFireRate = 0.20M;

                            var timberCount = 0;
                            decimal ConstructionLoad = 0;
                            decimal TenantLoad = 0;
                            decimal ConsructionFireRate = MDFireRate;

                            var timber = premise_data.Contains("lux_howmanyfloorsareofwoodenconstruction") ? premise_data.Attributes["lux_howmanyfloorsareofwoodenconstruction"].ToString() : "";

                            if (timber != "" && !timber.Contains("0"))
                            {
                                timberCount = 1;
                            }

                            if (timberCount == 1)
                            {
                                var ConstructionFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_floorconstructionloaddiscount'>
                                                                    <attribute name='lux_name' />
                                                                    <attribute name='createdon' />
                                                                    <attribute name='lux_loaddiscount' />
                                                                    <attribute name='lux_floorconstructionloaddiscountid' />
                                                                    <order attribute='lux_name' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                      <filter type='or'>
                                                                        <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                        <condition attribute='lux_enddate' operator='null' />
                                                                      </filter>
                                                                      <condition attribute='lux_floorconstruction' operator='eq' value='972970001' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";
                                if (service.RetrieveMultiple(new FetchExpression(ConstructionFetch)).Entities.Count > 0)
                                {
                                    var LoadData = service.RetrieveMultiple(new FetchExpression(ConstructionFetch)).Entities[0];
                                    ConstructionLoad = LoadData.GetAttributeValue<decimal>("lux_loaddiscount");
                                }
                                ConsructionFireRate = MDFireRate + MDFireRate * ConstructionLoad / 100;
                            }

                            var coverType = premise_data.Contains("lux_levelofcover") ? premise_data.GetAttributeValue<OptionSetValue>("lux_levelofcover").Value : 0;

                            if (coverType == 972970001)
                            {
                                TenantLoad = 0;
                            }
                            else if (coverType == 972970002)
                            {
                                TenantLoad = 25;
                            }
                            else if (coverType == 972970003)
                            {
                                TenantLoad = 35;
                            }

                            var unoccupancyLength = premise_data.Contains("lux_lengthofexpectedunoccupancy") ? premise_data.GetAttributeValue<OptionSetValue>("lux_lengthofexpectedunoccupancy").Value : 0;

                            if (unoccupancyLength == 972970002 || unoccupancyLength == 972970003)
                            {
                                TenantLoad += 10;
                            }
                            else if (unoccupancyLength == 972970004 || unoccupancyLength == 972970005 || unoccupancyLength == 972970006)
                            {
                                TenantLoad += 20;
                            }

                            GrossRate = ConsructionFireRate + ConsructionFireRate * TenantLoad / 100;
                        }
                        else if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970001 || item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970004) //commercial
                        {
                            MDFireRate = 0.25M;

                            var timberCount = 0;
                            decimal ConstructionLoad = 0;
                            decimal TenantLoad = 0;
                            decimal ConsructionFireRate = MDFireRate;

                            var timber = premise_data.Contains("lux_howmanyfloorsareofwoodenconstruction") ? premise_data.Attributes["lux_howmanyfloorsareofwoodenconstruction"].ToString() : "";

                            if (timber != "" && !timber.Contains("0"))
                            {
                                timberCount = 1;
                            }

                            if (timberCount == 1)
                            {
                                var ConstructionFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                                  <entity name='lux_floorconstructionloaddiscount'>
                                                                    <attribute name='lux_name' />
                                                                    <attribute name='createdon' />
                                                                    <attribute name='lux_loaddiscount' />
                                                                    <attribute name='lux_floorconstructionloaddiscountid' />
                                                                    <order attribute='lux_name' descending='false' />
                                                                    <filter type='and'>
                                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                                      <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                      <filter type='or'>
                                                                        <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                                        <condition attribute='lux_enddate' operator='null' />
                                                                      </filter>
                                                                      <condition attribute='lux_floorconstruction' operator='eq' value='972970001' />
                                                                    </filter>
                                                                  </entity>
                                                                </fetch>";
                                if (service.RetrieveMultiple(new FetchExpression(ConstructionFetch)).Entities.Count > 0)
                                {
                                    var LoadData = service.RetrieveMultiple(new FetchExpression(ConstructionFetch)).Entities[0];
                                    ConstructionLoad = LoadData.GetAttributeValue<decimal>("lux_loaddiscount");
                                }
                                ConsructionFireRate = MDFireRate + MDFireRate * ConstructionLoad / 100;
                            }

                            var coverType = premise_data.Contains("lux_levelofcover") ? premise_data.GetAttributeValue<OptionSetValue>("lux_levelofcover").Value : 0;

                            if (coverType == 972970001)
                            {
                                TenantLoad = 0;
                            }
                            else if (coverType == 972970002)
                            {
                                TenantLoad = 25;
                            }
                            else if (coverType == 972970003)
                            {
                                TenantLoad = 35;
                            }

                            var unoccupancyLength = premise_data.Contains("lux_lengthofexpectedunoccupancy") ? premise_data.GetAttributeValue<OptionSetValue>("lux_lengthofexpectedunoccupancy").Value : 0;

                            if (unoccupancyLength == 972970002 || unoccupancyLength == 972970003)
                            {
                                TenantLoad += 10;
                            }
                            else if (unoccupancyLength == 972970004 || unoccupancyLength == 972970005 || unoccupancyLength == 972970006)
                            {
                                TenantLoad += 20;
                            }
                            GrossRate = ConsructionFireRate + ConsructionFireRate * TenantLoad / 100;
                        }
                    }
                    if (covers != null && sum_Insured > 0)
                    {
                        var TotalSumInsuredFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_totalsuminsuredrate'>
                                                    <attribute name='lux_5m25m' />
                                                    <attribute name='lux_50m100m' />
                                                    <attribute name='lux_25m50m' />
                                                    <attribute name='lux_100m200m' />
                                                    <attribute name='lux_05m' />
                                                    <attribute name='lux_totalsuminsuredrateid' />
                                                    <attribute name='lux_peril' />
                                                    <order attribute='lux_05m' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                      <filter type='or'>
                                                        <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                        <condition attribute='lux_enddate' operator='null' />
                                                      </filter>";
                        if (covers != null)
                        {
                            TotalSumInsuredFetch += $@"<condition attribute='lux_peril' operator='contain-values'>";
                            foreach (var cover in covers)
                            {
                                TotalSumInsuredFetch += $@"<value>" + cover.Value + "</value>";
                            }
                            TotalSumInsuredFetch += $@"</condition>";
                        }
                        TotalSumInsuredFetch += $@"</filter>
                                                  </entity>
                                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(TotalSumInsuredFetch)).Entities.Count > 0)
                        {
                            var SI_data = service.RetrieveMultiple(new FetchExpression(TotalSumInsuredFetch)).Entities;
                            var SI_field = "";
                            if (sum_Insured < 5000000)
                            {
                                SI_field = "lux_05m";
                            }
                            else if (sum_Insured >= 5000000 && sum_Insured < 25000000)
                            {
                                SI_field = "lux_5m25m";
                            }
                            else if (sum_Insured >= 25000000 && sum_Insured < 50000000)
                            {
                                SI_field = "lux_25m50m";
                            }
                            else if (sum_Insured >= 50000000 && sum_Insured < 100000000)
                            {
                                SI_field = "lux_50m100m";
                            }
                            else if (sum_Insured >= 100000000 && sum_Insured < 200000000)
                            {
                                SI_field = "lux_100m200m";
                            }
                            SI_rate = SI_data.Sum(x => x.GetAttributeValue<decimal>(SI_field)) * 100;
                        }


                        if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                        {
                            if (SI_rate < 0.049M)
                            {
                                SI_rate = 0.049M;
                            }
                        }
                        else if (item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                        {

                        }
                        else
                        {
                            if (item2.Attributes.Contains("lux_policy"))
                            {
                                var Policy = service.Retrieve("lux_policy", item2.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                {
                                    if (quotationDate > new DateTime(2023, 02, 15))
                                    {
                                        if (SI_rate < 0.049M)
                                        {
                                            SI_rate = 0.049M;
                                        }
                                    }
                                }
                            }
                        }

                        TotalRate = GrossRate + SI_rate;

                        var ContentsPremium = 0M;
                        var ContentsRate = 0.15M;
                        ContentsDeclaredValue = ContentsDeclaredValue + ContentsCommunalArea;

                        if (ContentsDeclaredValue != 0 && item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                        {
                            ContentsPremium = ContentsDeclaredValue * ContentsRate / 100;
                            decimal TheftContentPremium = 0;

                            if (MDTheftRate != 0)
                            {
                                if (ContentsDeclaredValue <= 10000)
                                {
                                    TheftContentPremium = ContentsDeclaredValue * MDTheftRate / 100;
                                }
                                else
                                {
                                    if (ContentsDeclaredValue <= 30000)
                                    {
                                        TheftContentPremium = 10000 * MDTheftRate / 100;
                                        var remainingContent = ContentsDeclaredValue - 10000;
                                        TheftContentPremium += remainingContent * (MDTheftRate * 75 / 100) / 100;
                                    }
                                    else if (ContentsDeclaredValue <= 50000)
                                    {
                                        TheftContentPremium = 10000 * MDTheftRate / 100;
                                        TheftContentPremium += 20000 * (MDTheftRate * 75 / 100) / 100;

                                        var remainingContent1 = ContentsDeclaredValue - 30000;
                                        TheftContentPremium += remainingContent1 * (MDTheftRate * 50 / 100) / 100;
                                    }
                                    else if (ContentsDeclaredValue > 50000)
                                    {
                                        TheftContentPremium = 10000 * MDTheftRate / 100;
                                        TheftContentPremium += 20000 * (MDTheftRate * 75 / 100) / 100;
                                        TheftContentPremium += 20000 * (MDTheftRate * 50 / 100) / 100;

                                        var remainingContent1 = ContentsDeclaredValue - 50000;
                                        TheftContentPremium += remainingContent1 * (MDTheftRate * 25 / 100) / 100;
                                    }
                                }
                            }
                            ContentsPremium = ContentsPremium + TheftContentPremium;
                        }
                        else if (ContentsDeclaredValue != 0 && item2.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                        {
                            if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                            {
                                if (ContentsDeclaredValue <= 20000)
                                {
                                    ContentsPremium = ContentsDeclaredValue * ContentsRate / 100;
                                }
                                else
                                {
                                    if (ContentsDeclaredValue <= 60000)
                                    {
                                        ContentsPremium = 20000 * ContentsRate / 100;
                                        var remainingContent = ContentsDeclaredValue - 20000;
                                        ContentsPremium += remainingContent * (ContentsRate * 75 / 100) / 100;
                                    }
                                    else if (ContentsDeclaredValue <= 100000)
                                    {
                                        ContentsPremium = 20000 * ContentsRate / 100;
                                        ContentsPremium += 40000 * (ContentsRate * 75 / 100) / 100;

                                        var remainingContent1 = ContentsDeclaredValue - 60000;
                                        ContentsPremium += remainingContent1 * (ContentsRate * 50 / 100) / 100;
                                    }
                                    else if (ContentsDeclaredValue > 100000)
                                    {
                                        ContentsPremium = 20000 * ContentsRate / 100;
                                        ContentsPremium += 40000 * (ContentsRate * 75 / 100) / 100;
                                        ContentsPremium += 40000 * (ContentsRate * 50 / 100) / 100;

                                        var remainingContent1 = ContentsDeclaredValue - 100000;
                                        ContentsPremium += remainingContent1 * (ContentsRate * 25 / 100) / 100;
                                    }
                                }
                            }
                            else
                            {
                                if (ContentsDeclaredValue <= 10000)
                                {
                                    ContentsPremium = ContentsDeclaredValue * ContentsRate / 100;
                                }
                                else
                                {
                                    if (ContentsDeclaredValue <= 30000)
                                    {
                                        ContentsPremium = 10000 * ContentsRate / 100;
                                        var remainingContent = ContentsDeclaredValue - 10000;
                                        ContentsPremium += remainingContent * (ContentsRate * 75 / 100) / 100;
                                    }
                                    else if (ContentsDeclaredValue <= 50000)
                                    {
                                        ContentsPremium = 10000 * ContentsRate / 100;
                                        ContentsPremium += 20000 * (ContentsRate * 75 / 100) / 100;

                                        var remainingContent1 = ContentsDeclaredValue - 30000;
                                        ContentsPremium += remainingContent1 * (ContentsRate * 50 / 100) / 100;
                                    }
                                    else if (ContentsDeclaredValue > 50000)
                                    {
                                        ContentsPremium = 10000 * ContentsRate / 100;
                                        ContentsPremium += 20000 * (ContentsRate * 75 / 100) / 100;
                                        ContentsPremium += 20000 * (ContentsRate * 50 / 100) / 100;

                                        var remainingContent1 = ContentsDeclaredValue - 50000;
                                        ContentsPremium += remainingContent1 * (ContentsRate * 25 / 100) / 100;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (ContentsDeclaredValue != 0 && item2.Attributes.Contains("lux_policy"))
                            {
                                var Policy = service.Retrieve("lux_policy", item2.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                {
                                    if (quotationDate < new DateTime(2023, 02, 15))
                                    {
                                        if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                        {
                                            if (ContentsDeclaredValue <= 20000)
                                            {
                                                ContentsPremium = ContentsDeclaredValue * ContentsRate / 100;
                                            }
                                            else
                                            {
                                                if (ContentsDeclaredValue <= 60000)
                                                {
                                                    ContentsPremium = 20000 * ContentsRate / 100;
                                                    var remainingContent = ContentsDeclaredValue - 20000;
                                                    ContentsPremium += remainingContent * (ContentsRate * 75 / 100) / 100;
                                                }
                                                else if (ContentsDeclaredValue <= 100000)
                                                {
                                                    ContentsPremium = 20000 * ContentsRate / 100;
                                                    ContentsPremium += 40000 * (ContentsRate * 75 / 100) / 100;

                                                    var remainingContent1 = ContentsDeclaredValue - 60000;
                                                    ContentsPremium += remainingContent1 * (ContentsRate * 50 / 100) / 100;
                                                }
                                                else if (ContentsDeclaredValue > 100000)
                                                {
                                                    ContentsPremium = 20000 * ContentsRate / 100;
                                                    ContentsPremium += 40000 * (ContentsRate * 75 / 100) / 100;
                                                    ContentsPremium += 40000 * (ContentsRate * 50 / 100) / 100;

                                                    var remainingContent1 = ContentsDeclaredValue - 100000;
                                                    ContentsPremium += remainingContent1 * (ContentsRate * 25 / 100) / 100;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if (ContentsDeclaredValue <= 10000)
                                            {
                                                ContentsPremium = ContentsDeclaredValue * ContentsRate / 100;
                                            }
                                            else
                                            {
                                                if (ContentsDeclaredValue <= 30000)
                                                {
                                                    ContentsPremium = 10000 * ContentsRate / 100;
                                                    var remainingContent = ContentsDeclaredValue - 10000;
                                                    ContentsPremium += remainingContent * (ContentsRate * 75 / 100) / 100;
                                                }
                                                else if (ContentsDeclaredValue <= 50000)
                                                {
                                                    ContentsPremium = 10000 * ContentsRate / 100;
                                                    ContentsPremium += 20000 * (ContentsRate * 75 / 100) / 100;

                                                    var remainingContent1 = ContentsDeclaredValue - 30000;
                                                    ContentsPremium += remainingContent1 * (ContentsRate * 50 / 100) / 100;
                                                }
                                                else if (ContentsDeclaredValue > 50000)
                                                {
                                                    ContentsPremium = 10000 * ContentsRate / 100;
                                                    ContentsPremium += 20000 * (ContentsRate * 75 / 100) / 100;
                                                    ContentsPremium += 20000 * (ContentsRate * 50 / 100) / 100;

                                                    var remainingContent1 = ContentsDeclaredValue - 50000;
                                                    ContentsPremium += remainingContent1 * (ContentsRate * 25 / 100) / 100;
                                                }
                                            }
                                        }
                                    }
                                    else
                                    {
                                        ContentsPremium = ContentsDeclaredValue * ContentsRate / 100;
                                        decimal TheftContentPremium = 0;

                                        if (MDTheftRate != 0)
                                        {
                                            if (ContentsDeclaredValue <= 10000)
                                            {
                                                TheftContentPremium = ContentsDeclaredValue * MDTheftRate / 100;
                                            }
                                            else
                                            {
                                                if (ContentsDeclaredValue <= 30000)
                                                {
                                                    TheftContentPremium = 10000 * MDTheftRate / 100;
                                                    var remainingContent = ContentsDeclaredValue - 10000;
                                                    TheftContentPremium += remainingContent * (MDTheftRate * 75 / 100) / 100;
                                                }
                                                else if (ContentsDeclaredValue <= 50000)
                                                {
                                                    TheftContentPremium = 10000 * MDTheftRate / 100;
                                                    TheftContentPremium += 20000 * (MDTheftRate * 75 / 100) / 100;

                                                    var remainingContent1 = ContentsDeclaredValue - 30000;
                                                    TheftContentPremium += remainingContent1 * (MDTheftRate * 50 / 100) / 100;
                                                }
                                                else if (ContentsDeclaredValue > 50000)
                                                {
                                                    TheftContentPremium = 10000 * MDTheftRate / 100;
                                                    TheftContentPremium += 20000 * (MDTheftRate * 75 / 100) / 100;
                                                    TheftContentPremium += 20000 * (MDTheftRate * 50 / 100) / 100;

                                                    var remainingContent1 = ContentsDeclaredValue - 50000;
                                                    TheftContentPremium += remainingContent1 * (MDTheftRate * 25 / 100) / 100;
                                                }
                                            }
                                        }
                                        ContentsPremium = ContentsPremium + TheftContentPremium;
                                    }
                                }
                                else
                                {
                                    if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value == 972970002)
                                    {
                                        if (ContentsDeclaredValue <= 20000)
                                        {
                                            ContentsPremium = ContentsDeclaredValue * ContentsRate / 100;
                                        }
                                        else
                                        {
                                            if (ContentsDeclaredValue <= 60000)
                                            {
                                                ContentsPremium = 20000 * ContentsRate / 100;
                                                var remainingContent = ContentsDeclaredValue - 20000;
                                                ContentsPremium += remainingContent * (ContentsRate * 75 / 100) / 100;
                                            }
                                            else if (ContentsDeclaredValue <= 100000)
                                            {
                                                ContentsPremium = 20000 * ContentsRate / 100;
                                                ContentsPremium += 40000 * (ContentsRate * 75 / 100) / 100;

                                                var remainingContent1 = ContentsDeclaredValue - 60000;
                                                ContentsPremium += remainingContent1 * (ContentsRate * 50 / 100) / 100;
                                            }
                                            else if (ContentsDeclaredValue > 100000)
                                            {
                                                ContentsPremium = 20000 * ContentsRate / 100;
                                                ContentsPremium += 40000 * (ContentsRate * 75 / 100) / 100;
                                                ContentsPremium += 40000 * (ContentsRate * 50 / 100) / 100;

                                                var remainingContent1 = ContentsDeclaredValue - 100000;
                                                ContentsPremium += remainingContent1 * (ContentsRate * 25 / 100) / 100;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        if (ContentsDeclaredValue <= 10000)
                                        {
                                            ContentsPremium = ContentsDeclaredValue * ContentsRate / 100;
                                        }
                                        else
                                        {
                                            if (ContentsDeclaredValue <= 30000)
                                            {
                                                ContentsPremium = 10000 * ContentsRate / 100;
                                                var remainingContent = ContentsDeclaredValue - 10000;
                                                ContentsPremium += remainingContent * (ContentsRate * 75 / 100) / 100;
                                            }
                                            else if (ContentsDeclaredValue <= 50000)
                                            {
                                                ContentsPremium = 10000 * ContentsRate / 100;
                                                ContentsPremium += 20000 * (ContentsRate * 75 / 100) / 100;

                                                var remainingContent1 = ContentsDeclaredValue - 30000;
                                                ContentsPremium += remainingContent1 * (ContentsRate * 50 / 100) / 100;
                                            }
                                            else if (ContentsDeclaredValue > 50000)
                                            {
                                                ContentsPremium = 10000 * ContentsRate / 100;
                                                ContentsPremium += 20000 * (ContentsRate * 75 / 100) / 100;
                                                ContentsPremium += 20000 * (ContentsRate * 50 / 100) / 100;

                                                var remainingContent1 = ContentsDeclaredValue - 50000;
                                                ContentsPremium += remainingContent1 * (ContentsRate * 25 / 100) / 100;
                                            }
                                        }
                                    }
                                }
                            }
                        }

                        var MD_Total_Premium = (BuildingDeclaredValue * TotalRate / 100 + ContentsPremium) * dateDiffDays / 365;

                        var item1 = service.Retrieve("lux_propertyownerspremise", item.Id, new ColumnSet(false));
                        if (MD_Total_Premium < Convert.ToDecimal(37.5))
                        {
                            MD_Total_Premium = Convert.ToDecimal(37.5);
                            item1["lux_materialdamagepremium"] = new Money(Convert.ToDecimal(37.5));
                        }
                        else
                        {
                            item1["lux_materialdamagepremium"] = new Money(MD_Total_Premium);
                        }
                        item1["lux_materialdamageperilsrate"] = Convert.ToDecimal(SI_rate);
                        item1["lux_materialdamagefirerate"] = Convert.ToDecimal(MDFireRate);

                        item1["lux_buildingpremium"] = new Money((BuildingDeclaredValue * TotalRate / 100) * dateDiffDays / 365);
                        item1["lux_contentspremium"] = new Money(ContentsPremium * dateDiffDays / 365);
                        //item1["lux_contentspremium"] = new Money((ContentsDeclaredValue * Convert.ToDecimal(0.15) / 100) * dateDiffDays / 365);
                        //item1["lux_contentsrate"] = Convert.ToDecimal(0.125); Old Rates
                        item1["lux_contentsrate"] = Convert.ToDecimal(0.15);

                        item1["lux_materialdamageloadedfirerate"] = Convert.ToDecimal(GrossRate);

                        //if (ApplicationType == "MTA" || ApplicationType == "Cancellation")
                        //{
                        //    if (item1.Attributes.Contains("lux_buildingpolicypremium"))
                        //    {
                        //        item1["lux_parentbuildingpolicypremium"] = item1.GetAttributeValue<Money>("lux_buildingpolicypremium");
                        //    }
                        //}

                        service.Update(item1);

                        TotalMDPremium += MD_Total_Premium;
                    }
                    else
                    {
                        TotalMDPremium += Convert.ToDecimal(37.5);
                        var item1 = service.Retrieve("lux_propertyownerspremise", item.Id, new ColumnSet(false));
                        item1["lux_materialdamagepremium"] = new Money(Convert.ToDecimal(0));
                        item1["lux_materialdamageperilsrate"] = Convert.ToDecimal(0);
                        item1["lux_materialdamagefirerate"] = Convert.ToDecimal(0);
                        item1["lux_materialdamageloadedfirerate"] = Convert.ToDecimal(0);
                        service.Update(item1);
                    }
                }

                if (TotalMDPremium < 75)
                {
                    TotalMDPremium = 75;
                }
                item2["lux_materialdamagepremium"] = new Money(TotalMDPremium);
                service.Update(item2);
            }
        }
    }
}
