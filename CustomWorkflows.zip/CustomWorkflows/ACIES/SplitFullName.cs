﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System.Activities;

namespace CustomWorkflows
{
    public class SplitFullName : CodeActivity
    {
        #region "Parameter Definition"

        [RequiredArgument]
        [Input("CustomerName")]
        public InArgument<string> CustomerName { get; set; }

        [Output("FirstName")]
        public OutArgument<string> FirstName { get; set; }

        [Output("LastName")]
        public OutArgument<string> LastName { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var customerName = CustomerName.Get<string>(executionContext).ToString().Trim();
            string[] names = customerName.Split(' ');
            var length = names.Length;

            FirstName.Set(executionContext, names[0].Trim());
            if (length > 1)
                LastName.Set(executionContext, names[length - 1].Trim());
        }
    }
}