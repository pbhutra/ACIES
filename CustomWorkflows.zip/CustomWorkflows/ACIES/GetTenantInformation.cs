﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System.Activities;

namespace CustomWorkflows
{
    public class GetTenantInformation : CodeActivity
    {
        #region "Parameter Definition"

        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Output("Record Count")]
        public OutArgument<int> RecordCount { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference appref = PropertyOwnersApplication.Get<EntityReference>(executionContext);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownerspremise'>
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_tenanttype' />
                                <attribute name='lux_occupancytype' />
                                <attribute name='lux_covers' />
                                <attribute name='lux_name' />
                                <attribute name='lux_aretenantcertificatesrequired' />
                                <attribute name='lux_suminsuredwithupliftedamount' />
                                <attribute name='lux_propertyownerspremiseid' />
                                <order attribute='lux_locationnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_aretenantcertificatesrequired' operator='eq' value='1' />
                                  <condition attribute='lux_propertyownersapplication' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            var count = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count;
            RecordCount.Set(executionContext, count);
        }
    }
}

