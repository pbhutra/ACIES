﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class WaitForDocument : CodeActivity
    {
        [Input("Automerge Item")]
        [ReferenceTarget("ptm_automergeworkingitems")]
        public InArgument<EntityReference> AutomergeItem { get; set; }

        [Output("IsGenerated")]
        public OutArgument<bool> IsGenerated { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference docref = AutomergeItem.Get<EntityReference>(executionContext);
            Entity doc = new Entity(docref.LogicalName, docref.Id);
            doc = service.Retrieve("ptm_automergeworkingitems", docref.Id, new ColumnSet(true));

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='ptm_automergeworkingitems'>
                                <attribute name='ptm_automergeworkingitemsid' />
                                <attribute name='ptm_name' />
                                <attribute name='createdon' />
                                <attribute name='ptm_createddocumentid' />
                                <order attribute='ptm_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='ptm_automergeworkingitemsid' operator='eq' uiname='Attach' uitype='ptm_automergeworkingitems' value='{doc.Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var Document = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
            }
        }
    }
}
