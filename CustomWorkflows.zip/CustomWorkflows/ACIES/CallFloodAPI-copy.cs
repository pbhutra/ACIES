﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace CustomWorkflows
{
    public class CallFloodAPISandbox : CodeActivity
    {
        [RequiredArgument]
        [Input("Postcode")]
        public InArgument<string> Postcode { get; set; }

        [RequiredArgument]
        [Input("Product")]
        public InArgument<string> Product { get; set; }

        [RequiredArgument]
        [Input("RecordID")]
        public InArgument<string> RecordID { get; set; }

        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var ProductName = Product.Get(executionContext).Trim();
            var schemaName = "";
            if (ProductName == "Property Owners" || ProductName == "Unoccupied")
            {
                schemaName = "lux_propertyownerspremise";
            }
            else if (ProductName == "Retail")
            {
                schemaName = "lux_propertyownersretail";
            }
            else if (ProductName == "Commercial Combined" || ProductName == "Office")
            {
                schemaName = "lux_commercialcombinedapplication";
            }
            else if (ProductName == "Pubs & Restaurants" || ProductName == "Hotels and Guesthouses")
            {
                schemaName = "lux_pubsrestaurantspropertyownersapplicatio";
            }

            var dictForApiParams = new Dictionary<string, string>();
            dictForApiParams.Add("postcode", Postcode.Get(executionContext).Trim());
            dictForApiParams.Add("product", schemaName);
            dictForApiParams.Add("PremiseId", RecordID.Get(executionContext).Trim());
            dictForApiParams.Add("ApplicationID", PropertyOwnersApplication.Get(executionContext).Id.ToString());

            var client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.BaseAddress = new Uri("https://msdynamicswebapi.azurewebsites.net/api/ACIES/GetFloodData");
            var apiRequest = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress) { Content = new FormUrlEncodedContent(dictForApiParams) };
            var apiResponseString = ProcessWebResponse(client, apiRequest, tracingService);
            var apiResponse = apiResponseString.Result;

            tracingService.Trace(apiResponse);
        }

        public static async Task<string> ProcessWebResponse(HttpClient client, HttpRequestMessage apiRequest, ITracingService tracingService)
        {
            var reponseContentString = "";
            try
            {
                HttpResponseMessage apiResponse = await client.SendAsync(apiRequest);
                reponseContentString = await apiResponse.Content.ReadAsStringAsync();
            }
            catch (HttpRequestException ex)
            {
                tracingService.Trace(ex.Message + Environment.NewLine + ex.StackTrace);
            }
            tracingService.Trace(reponseContentString);
            return reponseContentString;
        }
    }
}