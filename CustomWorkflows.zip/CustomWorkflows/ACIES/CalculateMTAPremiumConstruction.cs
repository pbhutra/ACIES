﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculateMTAPremiumConstruction : CodeActivity
    {
        [Input("Application")]
        [ReferenceTarget("lux_constructionquotes")]
        public InArgument<EntityReference> Application { get; set; }

        [Input("Parent Application")]
        [ReferenceTarget("lux_constructionquotes")]
        public InArgument<EntityReference> ParentApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var mainfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_constructionquotes'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_constructionquotesid' />
                                <attribute name='lux_constructioncombinedprojectsection' />                                
                                <attribute name='lux_publicliabilitybuildingandalliedtradessec' />
                                <attribute name='lux_nonnegligentdamagesection' />
                                <attribute name='lux_delayinstartupsection' />
                                <attribute name='lux_contractorsplantandequipmentsection' />
                                <attribute name='lux_constructioncombinedannualsection' />
                                <attribute name='lux_existingstructurespremium' />
                                <attribute name='lux_terrorismsection' />                               
                                <attribute name='lux_premium' />
                                <attribute name='lux_policyadministrationfeepaf' />
                                <attribute name='lux_inceptiondate' />
                                <attribute name='lux_expirydate' />
                                <attribute name='lux_mtadate' />
                                <order attribute='lux_inceptiondate' descending='true' />
                                <order attribute='lux_name' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_constructionquotesid' operator='eq' uiname='' uitype='lux_constructionquotes' value='{Application.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities.Count > 0)
            {
                var parentfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_constructionquotes'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />                      
                                <attribute name='lux_constructionquotesid' />
                                <attribute name='lux_constructioncombinedprojectsection' />                                
                                <attribute name='lux_publicliabilitybuildingandalliedtradessec' />
                                <attribute name='lux_nonnegligentdamagesection' />
                                <attribute name='lux_delayinstartupsection' />
                                <attribute name='lux_contractorsplantandequipmentsection' />
                                <attribute name='lux_constructioncombinedannualsection' />
                                <attribute name='lux_existingstructurespremium' />
                                <attribute name='lux_terrorismsection' />                               
                                <attribute name='lux_premium' />
                                <attribute name='lux_policyadministrationfeepaf' />
                                <attribute name='lux_inceptiondate' />
                                <attribute name='lux_expirydate' />
                                <attribute name='lux_mtadate' />
                                <order attribute='lux_inceptiondate' descending='true' />
                                <order attribute='lux_name' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_constructionquotesid' operator='eq' uiname='Landcage LLP' uitype='lux_constructionquotes' value='{ParentApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(parentfetch)).Entities.Count > 0)
                {
                    var parentRecord = service.RetrieveMultiple(new FetchExpression(parentfetch)).Entities[0];
                    var mainRecord = service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities[0];

                    var mainGrossPremium = mainRecord.Attributes.Contains("lux_premium") ? mainRecord.GetAttributeValue<Money>("lux_premium").Value : 0;
                    var parentGrossPremium = parentRecord.Attributes.Contains("lux_premium") ? parentRecord.GetAttributeValue<Money>("lux_premium").Value : 0;

                    var mainCCSingleProjectPremium = mainRecord.Attributes.Contains("lux_constructioncombinedprojectsection") ? mainRecord.GetAttributeValue<Money>("lux_constructioncombinedprojectsection").Value : 0;
                    var mainPLPremium = mainRecord.Attributes.Contains("lux_publicliabilitybuildingandalliedtradessec") ? mainRecord.GetAttributeValue<Money>("lux_publicliabilitybuildingandalliedtradessec").Value : 0;
                    var mainNonNegPremium = mainRecord.Attributes.Contains("lux_nonnegligentdamagesection") ? mainRecord.GetAttributeValue<Money>("lux_nonnegligentdamagesection").Value : 0;
                    var mainDelayPremium = mainRecord.Attributes.Contains("lux_delayinstartupsection") ? mainRecord.GetAttributeValue<Money>("lux_delayinstartupsection").Value : 0;
                    var mainCPEPremium = mainRecord.Attributes.Contains("lux_contractorsplantandequipmentsection") ? mainRecord.GetAttributeValue<Money>("lux_contractorsplantandequipmentsection").Value : 0;
                    var mainCCAnnualPremium = mainRecord.Attributes.Contains("lux_constructioncombinedannualsection") ? mainRecord.GetAttributeValue<Money>("lux_constructioncombinedannualsection").Value : 0;
                    var mainExistingStrucPremium = mainRecord.Attributes.Contains("lux_existingstructurespremium") ? mainRecord.GetAttributeValue<Money>("lux_existingstructurespremium").Value : 0;
                    var mainTerrorismPremium = mainRecord.Attributes.Contains("lux_terrorismsection") ? mainRecord.GetAttributeValue<Money>("lux_terrorismsection").Value : 0;

                    var parentCCSingleProjectPremium = parentRecord.Attributes.Contains("lux_constructioncombinedprojectsection") ? parentRecord.GetAttributeValue<Money>("lux_constructioncombinedprojectsection").Value : 0;
                    var parentPLPremium = parentRecord.Attributes.Contains("lux_publicliabilitybuildingandalliedtradessec") ? parentRecord.GetAttributeValue<Money>("lux_publicliabilitybuildingandalliedtradessec").Value : 0;
                    var parentNonNegPremium = parentRecord.Attributes.Contains("lux_nonnegligentdamagesection") ? parentRecord.GetAttributeValue<Money>("lux_nonnegligentdamagesection").Value : 0;
                    var parentDelayPremium = parentRecord.Attributes.Contains("lux_delayinstartupsection") ? parentRecord.GetAttributeValue<Money>("lux_delayinstartupsection").Value : 0;
                    var parentCPEPremium = parentRecord.Attributes.Contains("lux_contractorsplantandequipmentsection") ? parentRecord.GetAttributeValue<Money>("lux_contractorsplantandequipmentsection").Value : 0;
                    var parentCCAnnualPremium = parentRecord.Attributes.Contains("lux_constructioncombinedannualsection") ? parentRecord.GetAttributeValue<Money>("lux_constructioncombinedannualsection").Value : 0;
                    var parentExistingStrucPremium = parentRecord.Attributes.Contains("lux_existingstructurespremium") ? parentRecord.GetAttributeValue<Money>("lux_existingstructurespremium").Value : 0;
                    var parentTerrorismPremium = parentRecord.Attributes.Contains("lux_terrorismsection") ? parentRecord.GetAttributeValue<Money>("lux_terrorismsection").Value : 0;

                    var PolicyDuration = (mainRecord.GetAttributeValue<DateTime>("lux_expirydate") - mainRecord.GetAttributeValue<DateTime>("lux_inceptiondate")).Days + 1;
                    var LengthtillNow = (mainRecord.GetAttributeValue<DateTime>("lux_mtadate") - mainRecord.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                    var remainingDays = PolicyDuration - LengthtillNow;

                    var MTAGrossPremium = (mainGrossPremium - parentGrossPremium) * remainingDays / PolicyDuration;

                    var MTACCSingleProjectPremium = ((mainCCSingleProjectPremium - parentCCSingleProjectPremium) > 1 || (mainCCSingleProjectPremium - parentCCSingleProjectPremium) < 1 ? (mainCCSingleProjectPremium - parentCCSingleProjectPremium) : 0) * remainingDays / PolicyDuration;
                    var MTAPLPremium = ((mainPLPremium - parentPLPremium) > 1 || (mainPLPremium - parentPLPremium) < 1 ? (mainPLPremium - parentPLPremium) : 0) * remainingDays / PolicyDuration;
                    var MTANonNegPremium = ((mainNonNegPremium - parentNonNegPremium) > 1 || (mainNonNegPremium - parentNonNegPremium) < 1 ? (mainNonNegPremium - parentNonNegPremium) : 0) * remainingDays / PolicyDuration;
                    var MTADelayPremium = ((mainDelayPremium - parentDelayPremium) > 1 || (mainDelayPremium - parentDelayPremium) < 1 ? (mainDelayPremium - parentDelayPremium) : 0) * remainingDays / PolicyDuration;
                    var MTACPEPremium = ((mainCPEPremium - parentCPEPremium) > 1 || (mainCPEPremium - parentCPEPremium) < 1 ? (mainCPEPremium - parentCPEPremium) : 0) * remainingDays / PolicyDuration;
                    var MTACCAnnualPremium = ((mainCCAnnualPremium - parentCCAnnualPremium) > 1 || (mainCCAnnualPremium - parentCCAnnualPremium) < 1 ? (mainCCAnnualPremium - parentCCAnnualPremium) : 0) * remainingDays / PolicyDuration;
                    var MTAExistingStrucPremium = ((mainExistingStrucPremium - parentExistingStrucPremium) > 1 || (mainExistingStrucPremium - parentExistingStrucPremium) < 1 ? (mainExistingStrucPremium - parentExistingStrucPremium) : 0) * remainingDays / PolicyDuration;
                    var MTATerrorismPremium = ((mainTerrorismPremium - parentTerrorismPremium) > 1 || (mainTerrorismPremium - parentTerrorismPremium) < 1 ? (mainTerrorismPremium - parentTerrorismPremium) : 0) * remainingDays / PolicyDuration;


                    Entity appln = service.Retrieve("lux_constructionquotes", mainRecord.Id, new ColumnSet());

                    appln["lux_mtapremium"] = new Money(MTAGrossPremium);
                    appln["lux_constructioncombinedprojectsectionmta"] = new Money(MTACCSingleProjectPremium);
                    appln["lux_publicliabilitybuildingandalliedtradesmta"] = new Money(MTAPLPremium);
                    appln["lux_nonnegligentdamagesectionmta"] = new Money(MTANonNegPremium);
                    appln["lux_delayinstartupsectionmta"] = new Money(MTADelayPremium);
                    appln["lux_contractorsplantandequipmentsectionmta"] = new Money(MTACPEPremium);
                    appln["lux_constructioncombinedannualsectionmta"] = new Money(MTACCAnnualPremium);
                    appln["lux_existingstructurespremiummta"] = new Money(MTAExistingStrucPremium);
                    appln["lux_terrorismsectionmta"] = new Money(MTATerrorismPremium);
                    appln["lux_mtapolicyadministrationfeepaf"] = new Money(0);

                    service.Update(appln);
                }
            }
        }
    }
}