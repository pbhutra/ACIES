﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculateARAGPremium : CodeActivity
    {
        [Input("Product")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> Product { get; set; }

        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var request = new RetrieveCurrentOrganizationRequest();
            var organzationResponse = (RetrieveCurrentOrganizationResponse)service.Execute(request);
            var uriString = organzationResponse.Detail.UrlName;

            var productData = service.Retrieve("product", this.Product.Get(executionContext).Id, new ColumnSet(true));

            EntityReference applnref = PropertyOwnersApplication.Get<EntityReference>(executionContext);
            Entity appln = new Entity(applnref.LogicalName, applnref.Id);
            appln = service.Retrieve("lux_propertyownersapplications", applnref.Id, new ColumnSet(true));

            var inceptionDate = Convert.ToDateTime(appln.FormattedValues["lux_inceptiondate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
            var quotationDate = appln.Contains("lux_quotationdate") ? appln.GetAttributeValue<DateTime>("lux_quotationdate") : DateTime.UtcNow;

            //var quotationDate = Convert.ToDateTime(appln.FormattedValues["lux_quotationdate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

            if (inceptionDate >= new DateTime(2023, 11, 01) && quotationDate < new DateTime(2023, 11, 01))
            {
                quotationDate = Convert.ToDateTime(appln.FormattedValues["lux_inceptiondate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
            }

            if (inceptionDate >= new DateTime(2025, 05, 01))
            {
                quotationDate = Convert.ToDateTime(appln.FormattedValues["lux_inceptiondate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
            }

            var dateDiffDays = (appln.GetAttributeValue<DateTime>("lux_renewaldate") - appln.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
            if (dateDiffDays == 363 || dateDiffDays == 364 || dateDiffDays == 365 || dateDiffDays == 366 || dateDiffDays == 367)
            {
                dateDiffDays = 365;
            }
            if (productData.Attributes["name"].ToString() != "Commercial Combined" && productData.Attributes["name"].ToString() != "Contractors Combined" && productData.Attributes["name"].ToString() != "Office")
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_aragrate'>
                                <attribute name='createdon' />
                                <attribute name='lux_product' />
                                <attribute name='lux_netrate' />
                                <attribute name='lux_grossrate' />                                
                                <attribute name='lux_turnoverfrom' />
                                <attribute name='lux_turnoverto' />
                                <attribute name='lux_aragrateid' />
                                <order attribute='createdon' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_product' operator='eq' uiname='' uitype='product' value='{this.Product.Get(executionContext).Id}' />
                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                  <filter type='or'>
                                      <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                      <condition attribute='lux_enddate' operator='null' />
                                  </filter>
                                </filter>
                              </entity>
                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    var Rates = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                    var item2 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                    var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownerspremise'>
                                                <attribute name='lux_riskpostcode' />
                                                <attribute name='lux_riskaddress' />
                                                <attribute name='lux_locationnumber' />
                                                <attribute name='lux_propertyownerspremiseid' />
                                                <order attribute='lux_riskpostcode' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                    var NoOfLocations = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count;

                    if (productData.Attributes["name"].ToString() == "Property Owners" || productData.Attributes["name"].ToString() == "Unoccupied")
                    {
                        var POProuctType = appln.Attributes.Contains("lux_rpocpoproducttype") ? appln.GetAttributeValue<OptionSetValue>("lux_rpocpoproducttype").Value : 0;
                        if (inceptionDate >= new DateTime(2025, 05, 01))
                        {
                            if (NoOfLocations == 1)
                            {
                                item2["lux_legrosspremium"] = new Money(35M * dateDiffDays / 365);
                                item2["lux_lenetpremium"] = new Money(17.88M * dateDiffDays / 365);
                            }
                            else
                            {
                                item2["lux_legrosspremium"] = new Money(Rates.GetAttributeValue<Money>("lux_grossrate").Value * dateDiffDays / 365);
                                item2["lux_lenetpremium"] = new Money(Rates.GetAttributeValue<Money>("lux_netrate").Value * dateDiffDays / 365);
                            }
                        }
                        else
                        {
                            if (POProuctType == 972970001)
                            {
                                if (NoOfLocations == 1)
                                {
                                    item2["lux_legrosspremium"] = new Money(30M * dateDiffDays / 365);
                                    item2["lux_lenetpremium"] = new Money(14.30M * dateDiffDays / 365);

                                    if (quotationDate >= new DateTime(2024, 09, 01))
                                    {
                                        item2["lux_legrosspremium"] = new Money(35M * dateDiffDays / 365);
                                        item2["lux_lenetpremium"] = new Money(14.30M * dateDiffDays / 365);
                                    }
                                }
                                else
                                {
                                    item2["lux_legrosspremium"] = new Money(Rates.GetAttributeValue<Money>("lux_grossrate").Value * dateDiffDays / 365);
                                    item2["lux_lenetpremium"] = new Money(Rates.GetAttributeValue<Money>("lux_netrate").Value * dateDiffDays / 365);
                                }
                            }
                            else
                            {
                                item2["lux_legrosspremium"] = new Money(Rates.GetAttributeValue<Money>("lux_grossrate").Value * dateDiffDays / 365);
                                item2["lux_lenetpremium"] = new Money(Rates.GetAttributeValue<Money>("lux_netrate").Value * dateDiffDays / 365);
                            }
                        }
                    }
                    else
                    {
                        item2["lux_legrosspremium"] = new Money(Rates.GetAttributeValue<Money>("lux_grossrate").Value * dateDiffDays / 365);
                        item2["lux_lenetpremium"] = new Money(Rates.GetAttributeValue<Money>("lux_netrate").Value * dateDiffDays / 365);
                    }
                    service.Update(item2);
                }
            }
            else
            {
                decimal Turnover = 0;
                if (productData.Attributes["name"].ToString() == "Commercial Combined" || productData.Attributes["name"].ToString() == "Office")
                {
                    Turnover = appln.Attributes.Contains("lux_turnover") ? appln.GetAttributeValue<Money>("lux_turnover").Value : 0;
                }
                else if (productData.Attributes["name"].ToString() == "Contractors Combined")
                {
                    decimal primaryTurnover = appln.Contains("lux_primarytradeturnover") ? appln.GetAttributeValue<Money>("lux_primarytradeturnover").Value : 0;
                    decimal secondaryTurnover = appln.Contains("lux_secondarytradeturnover") ? appln.GetAttributeValue<Money>("lux_secondarytradeturnover").Value : 0;
                    Turnover = primaryTurnover + secondaryTurnover;
                }

                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_aragrate'>
                                    <attribute name='createdon' />
                                    <attribute name='lux_product' />
                                    <attribute name='lux_netrate' />
                                    <attribute name='lux_grossrate' />
                                    <attribute name='lux_aragrateid' />
                                    <order attribute='createdon' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_product' operator='eq' uiname='' uitype='product' value='{Product.Get(executionContext).Id}' />
                                      <filter type='or'>
                                        <filter type='and'>
                                          <condition attribute='lux_turnoverfrom' operator='le' value='{Turnover}' />
                                          <condition attribute='lux_turnoverto' operator='ge' value='{Turnover}' />
                                        </filter>
                                        <filter type='and'>
                                          <condition attribute='lux_turnoverfrom' operator='le' value='{Turnover}' />
                                          <condition attribute='lux_turnoverto' operator='null' />
                                        </filter>
                                      </filter>
                                      <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                      <filter type='or'>
                                          <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                          <condition attribute='lux_enddate' operator='null' />
                                      </filter>
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                {
                    var Rates = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                    var item2 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                    item2["lux_legrosspremium"] = new Money(Rates.GetAttributeValue<Money>("lux_grossrate").Value * dateDiffDays / 365);
                    item2["lux_lenetpremium"] = new Money(Rates.GetAttributeValue<Money>("lux_netrate").Value * dateDiffDays / 365);
                    service.Update(item2);
                }
            }
        }
    }
}
