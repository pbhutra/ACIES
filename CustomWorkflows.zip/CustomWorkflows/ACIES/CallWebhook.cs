﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.ServiceModel.Description;
using System.Text;
using System.Threading.Tasks;

namespace CustomWorkflows
{
    public class CallWebhook : CodeActivity
    {
        [RequiredArgument]
        [Input("Request Url")]
        public InArgument<string> RequestUrl { get; set; }

        [RequiredArgument]
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var url = RequestUrl.Get(executionContext);
            var body = "{\r\n  \"Application\": \"" + PropertyOwnersApplication.Get(executionContext).Id.ToString() + "\"}";

            var client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.BaseAddress = new Uri(url.Trim());
            var request = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress) { Content = new StringContent(body, Encoding.UTF8, "application/json") };
            var task = Task.Run(() => client.SendAsync(request));
            task.Wait();
            var response = task.Result;
            tracingService.Trace(response.Content.ToString());
        }
    }
}
