﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculateMTAPremiumCEDAR : CodeActivity
    {
        [Input("Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> Application { get; set; }

        [Input("Parent Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> ParentApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var mainfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_mtadate' />
                                <attribute name='lux_propertyownersapplicationsid' />
                                <attribute name='lux_renewaldate' />
                                <attribute name='lux_inceptiondate' /> 
                                <attribute name='lux_policytotalpremium' />                                
                                <attribute name='lux_insuranceproductrequired' />
                                <attribute name='lux_policybrokercommissionamount' />
                                <attribute name='lux_policycedarcommissionamount' />
                                <attribute name='lux_mtabrokercommission' />
                                <attribute name='lux_mtacedarcommission' />
                                <attribute name='lux_policybrokercommission' />
                                <attribute name='lux_policycedarcommission' /> 
                                <attribute name='lux_buildingspolicypremium' />
                                <attribute name='lux_contentspolicypremium' />
                                <attribute name='lux_propertyownersliabilitypolicypremium' />
                                <order attribute='lux_inceptiondate' descending='true' />
                                <order attribute='lux_quotenumber' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplicationsid' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{Application.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities.Count > 0)
            {
                var parentfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />                      
                                <attribute name='lux_propertyownersapplicationsid' />
                                <attribute name='lux_policytotalpremium' />                                
                                <attribute name='lux_insuranceproductrequired' />
                                <attribute name='lux_policybrokercommissionamount' />
                                <attribute name='lux_policycedarcommissionamount' />
                                <attribute name='lux_mtabrokercommission' />
                                <attribute name='lux_mtacedarcommission' />
                                <attribute name='lux_policybrokercommission' />
                                <attribute name='lux_policycedarcommission' />                               
                                <attribute name='lux_buildingspolicypremium' />
                                <attribute name='lux_contentspolicypremium' />
                                <attribute name='lux_propertyownersliabilitypolicypremium' />
                                <order attribute='lux_inceptiondate' descending='true' />
                                <order attribute='lux_quotenumber' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplicationsid' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{ParentApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(parentfetch)).Entities.Count > 0)
                {
                    var parentRecord = service.RetrieveMultiple(new FetchExpression(parentfetch)).Entities[0];
                    var mainRecord = service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities[0];

                    var mainGrossPremium = mainRecord.GetAttributeValue<Money>("lux_policytotalpremium").Value;
                    var parentGrossPremium = parentRecord.GetAttributeValue<Money>("lux_policytotalpremium").Value;

                    var mainBrokerComm = mainRecord.GetAttributeValue<Money>("lux_policybrokercommissionamount").Value;
                    var parentBrokerComm = parentRecord.GetAttributeValue<Money>("lux_policybrokercommissionamount").Value;

                    var mainGrossComm = mainRecord.GetAttributeValue<Money>("lux_policycedarcommissionamount").Value;
                    var parentGrossComm = parentRecord.GetAttributeValue<Money>("lux_policycedarcommissionamount").Value;

                    var mainBuildingsPremium = mainRecord.Attributes.Contains("lux_buildingspolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_buildingspolicypremium").Value : 0;
                    var mainContentsPremium = mainRecord.Attributes.Contains("lux_contentspolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_contentspolicypremium").Value : 0;
                    var mainPOLPremium = mainRecord.Attributes.Contains("lux_propertyownersliabilitypolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_propertyownersliabilitypolicypremium").Value : 0;

                    var parentBuildingsPremium = parentRecord.Attributes.Contains("lux_buildingspolicypremium") ? parentRecord.GetAttributeValue<Money>("lux_buildingspolicypremium").Value : 0;
                    var parentContentsPremium = parentRecord.Attributes.Contains("lux_contentspolicypremium") ? parentRecord.GetAttributeValue<Money>("lux_contentspolicypremium").Value : 0;
                    var parentPOLPremium = parentRecord.Attributes.Contains("lux_propertyownersliabilitypolicypremium") ? parentRecord.GetAttributeValue<Money>("lux_propertyownersliabilitypolicypremium").Value : 0;

                    var PolicyDuration = (mainRecord.GetAttributeValue<DateTime>("lux_renewaldate") - mainRecord.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                    var LengthtillNow = (mainRecord.GetAttributeValue<DateTime>("lux_mtadate") - mainRecord.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                    var remainingDays = PolicyDuration - LengthtillNow;

                    var GrossDiff = mainGrossPremium - parentGrossPremium;
                    var BrokCommDiff = mainBrokerComm - parentBrokerComm;
                    var GrossCommDiff = mainGrossComm - parentGrossComm;

                    if (GrossDiff > 0 && GrossDiff < 1)
                    {
                        GrossDiff = 0;
                    }
                    if (BrokCommDiff > 0 && BrokCommDiff < 1)
                    {
                        BrokCommDiff = 0;
                    }
                    if (GrossCommDiff > 0 && GrossCommDiff < 1)
                    {
                        GrossCommDiff = 0;
                    }

                    var MTAGrossPremium = (GrossDiff) * remainingDays / PolicyDuration;
                    var PolicyBrokercommission = mainRecord.Attributes.Contains("lux_policybrokercommission") ? mainRecord.Attributes["lux_policybrokercommission"].ToString() : parentRecord.Attributes["lux_policybrokercommission"].ToString();
                    var PolicyAciescommission = mainRecord.Attributes.Contains("lux_policycedarcommission") ? mainRecord.Attributes["lux_policycedarcommission"].ToString() : parentRecord.Attributes["lux_policycedarcommission"].ToString();

                    var MTABrokerCommission = MTAGrossPremium * Convert.ToDecimal(PolicyBrokercommission.Replace("%", "")) / 100;
                    var MTAGrossCommission = MTAGrossPremium * Convert.ToDecimal(PolicyAciescommission.Replace("%", "")) / 100;
                    var MTANetPremium = MTAGrossPremium - MTABrokerCommission - MTAGrossCommission;

                    var MTABuildingsPremium = ((mainBuildingsPremium - parentBuildingsPremium) > 1 || (mainBuildingsPremium - parentBuildingsPremium) < 1 ? (mainBuildingsPremium - parentBuildingsPremium) : 0) * remainingDays / PolicyDuration;
                    var MTAContentsPremium = ((mainContentsPremium - parentContentsPremium) > 1 || (mainContentsPremium - parentContentsPremium) < 1 ? (mainContentsPremium - parentContentsPremium) : 0) * remainingDays / PolicyDuration;
                    var MTAPOLPremium = ((mainPOLPremium - parentPOLPremium) > 1 || (mainPOLPremium - parentPOLPremium) < 1 ? (mainPOLPremium - parentPOLPremium) : 0) * remainingDays / PolicyDuration;

                    Entity appln = service.Retrieve("lux_propertyownersapplications", mainRecord.Id, new ColumnSet());
                    //appln["lux_annualmtatechnicalpremium"] = new Money(GrossDiff);
                    appln["lux_mtabrokercommissionamount"] = new Money(MTABrokerCommission);
                    appln["lux_mtacedarcommissionamount"] = new Money(MTAGrossCommission);
                    appln["lux_mtanetpremium"] = new Money(MTANetPremium);
                    appln["lux_mtapremium"] = new Money(MTAGrossPremium);
                    appln["lux_mtaipt"] = new Money(MTAGrossPremium * 12 / 100);
                    appln["lux_buildingsmtapremium"] = new Money(MTABuildingsPremium);
                    appln["lux_contentsmtapremium"] = new Money(MTAContentsPremium);
                    appln["lux_propertyownersliabilitymtapremium"] = new Money(MTAPOLPremium);
                    appln["lux_mtapolicyfee"] = new Money(10);
                    service.Update(appln);
                }
            }
        }
    }
}