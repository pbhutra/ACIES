﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CustomWorkflows
{
    public class CalculateELPremium : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                <attribute name='lux_propertyownersapplicationsid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_policy' />
                                <attribute name='lux_applicationtype' />
                                <attribute name='lux_limitofindemnity' />
                                <attribute name='lux_levelofcommission' />
                                <attribute name='lux_iselcoverrequired' />
                                <attribute name='lux_inceptiondate' />
                                <attribute name='lux_applicationtype' />
                                <attribute name='lux_renewaldate' />
                                <attribute name='lux_clericalcommercialandmanagerialwageroll' />
                                <attribute name='lux_caretakerscleanersporterswageroll' />
                                <attribute name='lux_alterationmaintenancerepairwageroll' />
                                <attribute name='lux_allotherswageroll' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplicationsid' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var item = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                var dateDiffDays = (item.GetAttributeValue<DateTime>("lux_renewaldate") - item.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                var inceptionDate = item.GetAttributeValue<DateTime>("lux_inceptiondate");
                var quotationDate = item.Attributes.Contains("lux_quotationdate") ? item.GetAttributeValue<DateTime>("lux_quotationdate") : DateTime.UtcNow;
                var ApplicationType = item.Attributes.Contains("lux_applicationtype") ? item.FormattedValues["lux_applicationtype"].ToString() : "";

                if (dateDiffDays == 364 || dateDiffDays == 365 || dateDiffDays == 366)
                {
                    dateDiffDays = 365;
                }
                if (item.GetAttributeValue<bool>("lux_iselcoverrequired") == true)
                {
                    var clerical = item.Contains("lux_clericalcommercialandmanagerialwageroll") ? item.GetAttributeValue<Money>("lux_clericalcommercialandmanagerialwageroll").Value : 0;
                    var caretakers = item.Contains("lux_caretakerscleanersporterswageroll") ? item.GetAttributeValue<Money>("lux_caretakerscleanersporterswageroll").Value : 0;
                    var alterations = item.Contains("lux_alterationmaintenancerepairwageroll") ? item.GetAttributeValue<Money>("lux_alterationmaintenancerepairwageroll").Value : 0;

                    //var clericalGrossRate = Convert.ToDecimal(0.3); Old Rate
                    var clericalGrossRate = Convert.ToDecimal(0.1);
                    var caretakersGrossRate = Convert.ToDecimal(0.5);
                    var alterationsGrossRate = Convert.ToDecimal(1);

                    var clericalPremium = clerical * clericalGrossRate / 100;
                    var caretakersPremium = caretakers * caretakersGrossRate / 100;
                    var alterationsPremium = alterations * alterationsGrossRate / 100;

                    var totalPremium = (clericalPremium + caretakersPremium + alterationsPremium) * dateDiffDays / 365;

                    var item1 = service.Retrieve("lux_propertyownersapplications", item.Id, new ColumnSet(true));

                    if (inceptionDate >= new DateTime(2023, 11, 01))
                    {
                        totalPremium = 1.1M * totalPremium;
                    }

                    if (quotationDate >= new DateTime(2025, 01, 01))
                    {
                        if (ApplicationType == "New Business")
                        {
                            totalPremium = 1.06M * totalPremium;
                        }
                        else if (ApplicationType == "MTA" || ApplicationType == "Cancellation")
                        {
                            if (item.Attributes.Contains("lux_policy"))
                            {
                                var Policy = service.Retrieve("lux_policy", item.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                {
                                    totalPremium = 1.06M * totalPremium;
                                }
                            }
                        }
                    }

                    if (quotationDate >= new DateTime(2024, 06, 20) && totalPremium < 25)
                    {
                        totalPremium = 25;
                    }

                    //if (totalPremium < 25)
                    //{
                    //    totalPremium = 25;
                    //}

                    item1["lux_employersliabilitypremium"] = new Money(totalPremium);
                    service.Update(item1);
                }
                else
                {
                    var item1 = service.Retrieve("lux_propertyownersapplications", item.Id, new ColumnSet(true));
                    item1["lux_employersliabilitypremium"] = new Money(0);
                    service.Update(item1);
                }
            }
        }
    }
}
