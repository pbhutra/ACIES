﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculateMTAPremium : CodeActivity
    {
        [Input("Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> Application { get; set; }

        [Input("Parent Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> ParentApplication { get; set; }

        [Input("IsTradesman")]
        public InArgument<bool> IsTradesman { get; set; }

        [Input("TradesmanApplication")]
        [ReferenceTarget("lux_tradesman")]
        public InArgument<EntityReference> TradesmanApplication { get; set; }

        [Input("ParentTradesmanApplication")]
        [ReferenceTarget("lux_tradesman")]
        public InArgument<EntityReference> ParentTradesmanApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            if (IsTradesman.Get(executionContext) == false)
            {
                var mainfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_quotedpremium' />                               
                                <attribute name='lux_quotedpremiumbrokercommissionamount' />                                
                                <attribute name='lux_quotedpremiumaciescommissionamount' />
                                <attribute name='lux_lepolicygrosscommission' />
                                <attribute name='lux_lepolicynetpremium' />
                                <attribute name='lux_totalpolicypremiumincterrorism' />
                                <attribute name='lux_terrorismpremium' />
                                <attribute name='lux_terrorismbrokercommissionamount' />
                                <attribute name='lux_terrorismaciescommissionamout' />
                                <attribute name='lux_terrorismnetpremium' />
                                <attribute name='lux_totalpolicypremiuminciptfee' />
                                <attribute name='lux_policyfee' />
                                <attribute name='lux_mtadate' />
                                <attribute name='lux_lepolicygrosspremium' />
                                <attribute name='lux_propertyownersapplicationsid' />
                                <attribute name='lux_renewaldate' />
                                <attribute name='lux_isterrorismcoverrequired' />
                                <attribute name='lux_inceptiondate' /> 
                                <attribute name='lux_materialdamagepolicypremium' />
                                <attribute name='lux_businessinterruptionpolicypremium' />
                                <attribute name='lux_employersliabilitypolicypremium' />
                                <attribute name='lux_propertyownersliabilitypolicypremium' />
                                <attribute name='lux_moneypolicypremium' />
                                <attribute name='lux_publicproductsliabilitypolicypremium' />
                                <attribute name='lux_allriskpolicypremium' />
                                <attribute name='lux_goodsintransitpolicypremium' />
                                <attribute name='lux_totalpremium' />                                
                                <attribute name='lux_insuranceproductrequired' />
                                <attribute name='lux_brokercommissionamount' />
                                <attribute name='lux_aciestechnicalcommissionamount' />
                                <attribute name='lux_legrosscommission' />
                                <attribute name='lux_legrosspremium' />
                                <attribute name='lux_lenetpremium' />
                                <attribute name='lux_materialdamagepremium' />
                                <attribute name='lux_businessinterruptionpremium' />
                                <attribute name='lux_retailmdpremium' />
                                <attribute name='lux_retailbipremium' />
                                <attribute name='lux_employersliabilitypremium' />
                                <attribute name='lux_propertyownersliabilitypremium' />
                                <attribute name='lux_retailmoneypremium' />
                                <attribute name='lux_publicproductsliabilitypremium' />
                                <attribute name='lux_specifiedallriskpremium' />
                                <attribute name='lux_goodsintransitpremium' />                                
                                <attribute name='lux_contractorspremium' />
                                <attribute name='lux_terrorismmtapremium' />
                                <attribute name='lux_terrorismmtaipt' />
                                <attribute name='lux_terrorismmtanetpremium' />
                                <attribute name='lux_terrorismmtabrokercommissionamount' />
                                <attribute name='lux_terrorismmtaaciescommissionamount' />
                                <attribute name='lux_mtabrokercommissionpercentage' />
                                <attribute name='lux_mtaaciescommissionpercentage' />
                                <order attribute='lux_inceptiondate' descending='true' />
                                <order attribute='lux_quotenumber' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplicationsid' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{Application.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities.Count > 0)
                {
                    var parentfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_quotedpremium' />
                                <attribute name='lux_totalpolicypremiumincterrorism' />
                                <attribute name='lux_terrorismpremium' />
                                <attribute name='lux_terrorismbrokercommissionamount' />
                                <attribute name='lux_terrorismaciescommissionamout' />
                                <attribute name='lux_terrorismnetpremium' />
                                <attribute name='lux_totalpolicypremiuminciptfee' />
                                <attribute name='lux_policyfee' />
                                <attribute name='lux_lepolicygrosspremium' />
                                <attribute name='lux_lepolicynetpremium' />
                                <attribute name='lux_quotedpremium' />                                
                                <attribute name='lux_quotedpremiumbrokercommissionamount' />                                
                                <attribute name='lux_quotedpremiumaciescommissionamount' />
                                <attribute name='lux_lepolicygrosscommission' />                                
                                <attribute name='lux_isterrorismcoverrequired' />
                                <attribute name='lux_propertyownersapplicationsid' />
                                <attribute name='lux_materialdamagepolicypremium' />
                                <attribute name='lux_businessinterruptionpolicypremium' />
                                <attribute name='lux_employersliabilitypolicypremium' />
                                <attribute name='lux_propertyownersliabilitypolicypremium' />
                                <attribute name='lux_moneypolicypremium' />
                                <attribute name='lux_publicproductsliabilitypolicypremium' />
                                <attribute name='lux_allriskpolicypremium' />
                                <attribute name='lux_goodsintransitpolicypremium' />
                                <attribute name='lux_totalpremium' />                                
                                <attribute name='lux_insuranceproductrequired' />
                                <attribute name='lux_brokercommissionamount' />
                                <attribute name='lux_aciestechnicalcommissionamount' />
                                <attribute name='lux_legrosscommission' />
                                <attribute name='lux_legrosspremium' />
                                <attribute name='lux_lenetpremium' />
                                <attribute name='lux_materialdamagepremium' />
                                <attribute name='lux_businessinterruptionpremium' />
                                <attribute name='lux_retailmdpremium' />
                                <attribute name='lux_retailbipremium' />
                                <attribute name='lux_employersliabilitypremium' />
                                <attribute name='lux_propertyownersliabilitypremium' />
                                <attribute name='lux_retailmoneypremium' />
                                <attribute name='lux_publicproductsliabilitypremium' />
                                <attribute name='lux_specifiedallriskpremium' />
                                <attribute name='lux_goodsintransitpremium' />
                                <attribute name='lux_contractorspremium' />
                                <attribute name='lux_terrorismmtapremium' />
                                <attribute name='lux_terrorismmtaipt' />
                                <attribute name='lux_terrorismmtanetpremium' />
                                <attribute name='lux_terrorismmtabrokercommissionamount' />
                                <attribute name='lux_terrorismmtaaciescommissionamount' />
                                <attribute name='lux_policybrokercommission' />
                                <attribute name='lux_policyaciescommission' />
                                <order attribute='lux_inceptiondate' descending='true' />
                                <order attribute='lux_quotenumber' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplicationsid' operator='eq' uiname='Landcage LLP' uitype='lux_propertyownersapplications' value='{ParentApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(parentfetch)).Entities.Count > 0)
                    {
                        var parentRecord = service.RetrieveMultiple(new FetchExpression(parentfetch)).Entities[0];
                        var mainRecord = service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities[0];

                        var mainGrossPremium = mainRecord.GetAttributeValue<Money>("lux_totalpremium").Value;
                        var parentGrossPremium = parentRecord.GetAttributeValue<Money>("lux_totalpremium").Value;

                        var mainBrokerComm = mainRecord.GetAttributeValue<Money>("lux_brokercommissionamount").Value;
                        var parentBrokerComm = parentRecord.GetAttributeValue<Money>("lux_brokercommissionamount").Value;

                        var mainGrossComm = mainRecord.GetAttributeValue<Money>("lux_aciestechnicalcommissionamount").Value;
                        var parentGrossComm = parentRecord.GetAttributeValue<Money>("lux_aciestechnicalcommissionamount").Value;

                        var mainLEGrossComm = mainRecord.GetAttributeValue<Money>("lux_legrosscommission").Value;
                        var parentLEGrossComm = parentRecord.GetAttributeValue<Money>("lux_legrosscommission").Value;

                        var mainLEGrossPremium = mainRecord.GetAttributeValue<Money>("lux_legrosspremium").Value;
                        var parentLEGrossPremium = parentRecord.GetAttributeValue<Money>("lux_legrosspremium").Value;

                        var mainLENetPremium = mainRecord.GetAttributeValue<Money>("lux_lenetpremium").Value;
                        var parentLENetPremium = parentRecord.GetAttributeValue<Money>("lux_lenetpremium").Value;

                        var mainMDPremium = mainRecord.Attributes.Contains("lux_materialdamagepremium") ? mainRecord.GetAttributeValue<Money>("lux_materialdamagepremium").Value : 0;
                        var mainBIPremium = mainRecord.Attributes.Contains("lux_businessinterruptionpremium") ? mainRecord.GetAttributeValue<Money>("lux_businessinterruptionpremium").Value : 0;

                        var parentMDPremium = parentRecord.Attributes.Contains("lux_materialdamagepremium") ? parentRecord.GetAttributeValue<Money>("lux_materialdamagepremium").Value : 0;
                        var parentBIPremium = parentRecord.Attributes.Contains("lux_businessinterruptionpremium") ? parentRecord.GetAttributeValue<Money>("lux_businessinterruptionpremium").Value : 0;

                        var product = mainRecord.FormattedValues["lux_insuranceproductrequired"];
                        if (product != "Property Owners" && product != "Unoccupied")
                        {
                            mainMDPremium = mainRecord.Attributes.Contains("lux_retailmdpremium") ? mainRecord.GetAttributeValue<Money>("lux_retailmdpremium").Value : 0;
                            mainBIPremium = mainRecord.Attributes.Contains("lux_retailbipremium") ? mainRecord.GetAttributeValue<Money>("lux_retailbipremium").Value : 0;

                            parentMDPremium = parentRecord.Attributes.Contains("lux_retailmdpremium") ? parentRecord.GetAttributeValue<Money>("lux_retailmdpremium").Value : 0;
                            parentBIPremium = parentRecord.Attributes.Contains("lux_retailbipremium") ? parentRecord.GetAttributeValue<Money>("lux_retailbipremium").Value : 0;
                        }

                        var mainELPremium = mainRecord.Attributes.Contains("lux_employersliabilitypremium") ? mainRecord.GetAttributeValue<Money>("lux_employersliabilitypremium").Value : 0;
                        var parentELPremium = parentRecord.Attributes.Contains("lux_employersliabilitypremium") ? parentRecord.GetAttributeValue<Money>("lux_employersliabilitypremium").Value : 0;

                        var mainPOLPremium = mainRecord.Attributes.Contains("lux_propertyownersliabilitypremium") ? mainRecord.GetAttributeValue<Money>("lux_propertyownersliabilitypremium").Value : 0;
                        var parentPOLPremium = parentRecord.Attributes.Contains("lux_propertyownersliabilitypremium") ? parentRecord.GetAttributeValue<Money>("lux_propertyownersliabilitypremium").Value : 0;

                        var mainMoneyPremium = mainRecord.Attributes.Contains("lux_retailmoneypremium") ? mainRecord.GetAttributeValue<Money>("lux_retailmoneypremium").Value : 0;
                        var parentMoneyPremium = parentRecord.Attributes.Contains("lux_retailmoneypremium") ? parentRecord.GetAttributeValue<Money>("lux_retailmoneypremium").Value : 0;

                        var mainPLPremium = mainRecord.Attributes.Contains("lux_publicproductsliabilitypremium") ? mainRecord.GetAttributeValue<Money>("lux_publicproductsliabilitypremium").Value : 0;
                        var parentPLPremium = parentRecord.Attributes.Contains("lux_publicproductsliabilitypremium") ? parentRecord.GetAttributeValue<Money>("lux_publicproductsliabilitypremium").Value : 0;

                        var mainARPremium = mainRecord.Attributes.Contains("lux_specifiedallriskpremium") ? mainRecord.GetAttributeValue<Money>("lux_specifiedallriskpremium").Value : 0;
                        var parentARPremium = parentRecord.Attributes.Contains("lux_specifiedallriskpremium") ? parentRecord.GetAttributeValue<Money>("lux_specifiedallriskpremium").Value : 0;

                        var mainGITPremium = mainRecord.Attributes.Contains("lux_goodsintransitpremium") ? mainRecord.GetAttributeValue<Money>("lux_goodsintransitpremium").Value : 0;
                        var parentGITPremium = parentRecord.Attributes.Contains("lux_goodsintransitpremium") ? parentRecord.GetAttributeValue<Money>("lux_goodsintransitpremium").Value : 0;

                        var mainCWPremium = mainRecord.Attributes.Contains("lux_contractorspremium") ? mainRecord.GetAttributeValue<Money>("lux_contractorspremium").Value : 0;
                        var parentCWPremium = parentRecord.Attributes.Contains("lux_contractorspremium") ? parentRecord.GetAttributeValue<Money>("lux_contractorspremium").Value : 0;

                        decimal mainTerrorismPremium = 0;
                        decimal mainTerrorismBrokerComm = 0;
                        decimal mainTerrorismGrossComm = 0;
                        decimal parentTerrorismPremium = 0;
                        decimal parentTerrorismBrokerComm = 0;
                        decimal parentTerrorismGrossComm = 0;

                        if (mainRecord.Contains("lux_isterrorismcoverrequired") && mainRecord.GetAttributeValue<bool>("lux_isterrorismcoverrequired") == true)
                        {
                            mainTerrorismPremium = mainRecord.GetAttributeValue<Money>("lux_terrorismpremium").Value;
                            mainTerrorismBrokerComm = mainRecord.GetAttributeValue<Money>("lux_terrorismbrokercommissionamount").Value;
                            mainTerrorismGrossComm = mainRecord.GetAttributeValue<Money>("lux_terrorismaciescommissionamout").Value;
                        }

                        if (parentRecord.Contains("lux_isterrorismcoverrequired") && parentRecord.GetAttributeValue<bool>("lux_isterrorismcoverrequired") == true)
                        {
                            parentTerrorismPremium = parentRecord.GetAttributeValue<Money>("lux_terrorismpremium").Value;
                            parentTerrorismBrokerComm = parentRecord.GetAttributeValue<Money>("lux_terrorismbrokercommissionamount").Value;
                            parentTerrorismGrossComm = parentRecord.GetAttributeValue<Money>("lux_terrorismaciescommissionamout").Value;
                        }

                        var PolicyDuration = (Convert.ToDateTime(mainRecord.FormattedValues["lux_renewaldate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat) - Convert.ToDateTime(mainRecord.FormattedValues["lux_inceptiondate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat)).Days;
                        var LengthtillNow = (Convert.ToDateTime(mainRecord.FormattedValues["lux_mtadate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat) - Convert.ToDateTime(mainRecord.FormattedValues["lux_inceptiondate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat)).Days;
                        //if (LengthtillNow == 1)
                        //{
                        //    LengthtillNow = 0;
                        //}
                        var remainingDays = PolicyDuration - LengthtillNow;
                        //if (mainRecord.GetAttributeValue<DateTime>("lux_mtadate").Date == mainRecord.GetAttributeValue<DateTime>("lux_renewaldate").Date)
                        //{
                        //    remainingDays = 0;
                        //}

                        if (Convert.ToDateTime(mainRecord.FormattedValues["lux_mtadate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat).Date == Convert.ToDateTime(mainRecord.FormattedValues["lux_renewaldate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat).Date)
                        {
                            remainingDays = 0;
                        }

                        var GrossDiff = mainGrossPremium - parentGrossPremium;
                        var BrokCommDiff = mainBrokerComm - parentBrokerComm;
                        var GrossCommDiff = mainGrossComm - parentGrossComm;
                        var LEGrossCommDiff = mainLEGrossComm - parentLEGrossComm;

                        if (GrossDiff > 0 && GrossDiff < 1)
                        {
                            GrossDiff = 0;
                        }
                        if (BrokCommDiff > 0 && BrokCommDiff < 1)
                        {
                            BrokCommDiff = 0;
                        }
                        if (GrossCommDiff > 0 && GrossCommDiff < 1)
                        {
                            GrossCommDiff = 0;
                        }
                        if (LEGrossCommDiff > 0 && LEGrossCommDiff < 1)
                        {
                            LEGrossCommDiff = 0;
                        }

                        var MTAGrossPremium = (GrossDiff) * remainingDays / PolicyDuration;
                        //var MTABrokerCommission = (BrokCommDiff) * remainingDays / PolicyDuration;
                        //var MTAGrossCommission = (GrossCommDiff) * remainingDays / PolicyDuration;
                        //var MTALEGrossCommission = (LEGrossCommDiff) * remainingDays / PolicyDuration;

                        var PolicyBrokercommission = mainRecord.Attributes.Contains("lux_mtabrokercommissionpercentage") ? mainRecord.Attributes["lux_mtabrokercommissionpercentage"].ToString() : parentRecord.Attributes["lux_policybrokercommission"].ToString();
                        var PolicyAciescommission = mainRecord.Attributes.Contains("lux_mtaaciescommissionpercentage") ? mainRecord.Attributes["lux_mtaaciescommissionpercentage"].ToString() : parentRecord.Attributes["lux_policyaciescommission"].ToString();

                        var MTABrokerCommission = MTAGrossPremium * Convert.ToDecimal(PolicyBrokercommission.Replace("%", "")) / 100;
                        var MTAGrossCommission = MTAGrossPremium * Convert.ToDecimal(PolicyAciescommission.Replace("%", "")) / 100;
                        var MTALEGrossCommission = (LEGrossCommDiff) * remainingDays / PolicyDuration;

                        var TerrorismPremium = (mainTerrorismPremium - parentTerrorismPremium) * remainingDays / PolicyDuration;
                        var TerrorismBrokerComm = (mainTerrorismBrokerComm - parentTerrorismBrokerComm) * remainingDays / PolicyDuration;
                        var TerrorismGrossComm = (mainTerrorismGrossComm - parentTerrorismGrossComm) * remainingDays / PolicyDuration;
                        var TerrorismNetPremium = TerrorismPremium - TerrorismBrokerComm - TerrorismGrossComm;

                        var MTANetPremium = MTAGrossPremium - MTABrokerCommission - MTAGrossCommission - MTALEGrossCommission;

                        var MTAMDPremium = ((mainMDPremium - parentMDPremium) > 1 || (mainMDPremium - parentMDPremium) < 1 ? (mainMDPremium - parentMDPremium) : 0) * remainingDays / PolicyDuration;
                        var MTABIPremium = ((mainBIPremium - parentBIPremium) > 1 || (mainBIPremium - parentBIPremium) < 1 ? (mainBIPremium - parentBIPremium) : 0) * remainingDays / PolicyDuration;
                        var MTAELPremium = ((mainELPremium - parentELPremium) > 1 || (mainELPremium - parentELPremium) < 1 ? (mainELPremium - parentELPremium) : 0) * remainingDays / PolicyDuration;
                        var MTAPLPremium = ((mainPLPremium - parentPLPremium) > 1 || (mainPLPremium - parentPLPremium) < 1 ? (mainPLPremium - parentPLPremium) : 0) * remainingDays / PolicyDuration;
                        var MTAPOLPremium = ((mainPOLPremium - parentPOLPremium) > 1 || (mainPOLPremium - parentPOLPremium) < 1 ? (mainPOLPremium - parentPOLPremium) : 0) * remainingDays / PolicyDuration;
                        var MTAMoneyPremium = ((mainMoneyPremium - parentMoneyPremium) > 1 || (mainMoneyPremium - parentMoneyPremium) < 1 ? (mainMoneyPremium - parentMoneyPremium) : 0) * remainingDays / PolicyDuration;
                        var MTAARPremium = ((mainARPremium - parentARPremium) > 1 || (mainARPremium - parentARPremium) < 1 ? (mainARPremium - parentARPremium) : 0) * remainingDays / PolicyDuration;
                        var MTAGITPremium = ((mainGITPremium - parentGITPremium) > 1 || (mainGITPremium - parentGITPremium) < 1 ? (mainGITPremium - parentGITPremium) : 0) * remainingDays / PolicyDuration;
                        var MTACWPremium = ((mainCWPremium - parentCWPremium) > 1 || (mainCWPremium - parentCWPremium) < 1 ? (mainCWPremium - parentCWPremium) : 0) * remainingDays / PolicyDuration;
                        var MTALEPremium = ((mainLEGrossPremium - parentLEGrossPremium) > 1 || (mainLEGrossPremium - parentLEGrossPremium) < 1 ? (mainLEGrossPremium - parentLEGrossPremium) : 0) * remainingDays / PolicyDuration;
                        var MTALENetPremium = ((mainLENetPremium - parentLENetPremium) > 1 || (mainLENetPremium - parentLENetPremium) < 1 ? (mainLENetPremium - parentLENetPremium) : 0) * remainingDays / PolicyDuration;

                        Entity appln = service.Retrieve("lux_propertyownersapplications", mainRecord.Id, new ColumnSet());
                        appln["lux_annualadditionalreturnpremium"] = new Money(GrossDiff + mainTerrorismPremium - parentTerrorismPremium);
                        appln["lux_annualmtatechnicalpremium"] = new Money(GrossDiff);
                        appln["lux_terrorismannualmtatechnicalpremium"] = new Money(mainTerrorismPremium - parentTerrorismPremium);
                        appln["lux_annualmtaipt"] = new Money(GrossDiff * 12 / 100 + (mainTerrorismPremium - parentTerrorismPremium) * 12 / 100);

                        appln["lux_mtagrosspremium"] = new Money(MTAGrossPremium);
                        appln["lux_mtabrokercommission"] = new Money(MTABrokerCommission);
                        appln["lux_mtaaciescommission"] = new Money(MTAGrossCommission);
                        appln["lux_mtanetpremium"] = new Money(MTANetPremium);
                        appln["lux_mtaipt"] = new Money(MTAGrossPremium * 12 / 100);
                        appln["lux_acieslegalexpensesmtacommissionamount"] = new Money(MTALEGrossCommission);

                        appln["lux_materialdamagemtatechnicalpremium"] = new Money(MTAMDPremium);
                        appln["lux_businessinterruptionmtatechnicalpremium"] = new Money(MTABIPremium);
                        appln["lux_employersliabilitymtatechnicalpremium"] = new Money(MTAELPremium);
                        appln["lux_propertyownersliabilitymtatechnicalpremiu"] = new Money(MTAPOLPremium);
                        appln["lux_legalexpensesmtatechnicalpremium"] = new Money(MTALEPremium);
                        appln["lux_legalexpensesmtatechnicalnetpremium"] = new Money(MTALENetPremium);
                        appln["lux_moneymtatechnicalpremium"] = new Money(MTAMoneyPremium);
                        appln["lux_publicproductsliabilitymtatechnicalpremiu"] = new Money(MTAPLPremium);
                        appln["lux_allriskmtatechnicalpremium"] = new Money(MTAARPremium);
                        appln["lux_goodsintransitmtatechnicalpremium"] = new Money(MTAGITPremium);
                        appln["lux_contractorsmtatechnicalpremium"] = new Money(MTACWPremium);
                        appln["lux_mtapolicyfee"] = new Money(0);

                        if ((mainRecord.Contains("lux_isterrorismcoverrequired") && mainRecord.GetAttributeValue<bool>("lux_isterrorismcoverrequired") == true) || (parentRecord.Contains("lux_isterrorismcoverrequired") && parentRecord.GetAttributeValue<bool>("lux_isterrorismcoverrequired") == true))
                        {
                            if (!mainRecord.Attributes.Contains("lux_terrorismmtabrokercommissionpercentage") || mainRecord.Attributes["lux_terrorismmtabrokercommissionpercentage"].ToString() == "")
                            {
                                appln["lux_terrorismmtabrokercommissionpercentage"] = "22.5%";
                            }
                            if (!mainRecord.Attributes.Contains("lux_terrorismmtaaciescommissionpercentage") || mainRecord.Attributes["lux_terrorismmtaaciescommissionpercentage"].ToString() == "")
                            {
                                appln["lux_terrorismmtaaciescommissionpercentage"] = "15%";
                            }
                            appln["lux_terrorismmtapremium"] = new Money(TerrorismPremium);
                            appln["lux_terrorismmtaipt"] = new Money(TerrorismPremium * 12 / 100);
                            appln["lux_terrorismmtanetpremium"] = new Money(TerrorismNetPremium);
                            appln["lux_terrorismmtabrokercommissionamount"] = new Money(TerrorismBrokerComm);
                            appln["lux_terrorismmtaaciescommissionamount"] = new Money(TerrorismGrossComm);
                            appln["lux_terrorismmtatechnicalpremium"] = new Money(TerrorismPremium);
                        }
                        else
                        {
                            if (!mainRecord.Attributes.Contains("lux_terrorismmtabrokercommissionpercentage") || mainRecord.Attributes["lux_terrorismmtabrokercommissionpercentage"].ToString() == "")
                            {
                                appln["lux_terrorismmtabrokercommissionpercentage"] = "22.5%";
                            }
                            if (!mainRecord.Attributes.Contains("lux_terrorismmtaaciescommissionpercentage") || mainRecord.Attributes["lux_terrorismmtaaciescommissionpercentage"].ToString() == "")
                            {
                                appln["lux_terrorismmtaaciescommissionpercentage"] = "15%";
                            }
                            appln["lux_terrorismmtapremium"] = new Money(0);
                            appln["lux_terrorismmtaipt"] = new Money(0);
                            appln["lux_terrorismmtanetpremium"] = new Money(0);
                            appln["lux_terrorismmtabrokercommissionamount"] = new Money(0);
                            appln["lux_terrorismmtaaciescommissionamount"] = new Money(0);
                            appln["lux_terrorismmtatechnicalpremium"] = new Money(0);
                        }
                        service.Update(appln);
                    }

                    //if (service.RetrieveMultiple(new FetchExpression(parentfetch)).Entities.Count > 0)
                    //{
                    //    var parentRecord = service.RetrieveMultiple(new FetchExpression(parentfetch)).Entities[0];
                    //    var mainRecord = service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities[0];

                    //    var mainGrossPremium = mainRecord.GetAttributeValue<Money>("lux_totalpolicypremiumincterrorism").Value;
                    //    var parentGrossPremium = parentRecord.GetAttributeValue<Money>("lux_totalpolicypremiumincterrorism").Value;

                    //    var mainBrokerComm = mainRecord.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value;
                    //    var parentBrokerComm = parentRecord.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value;

                    //    var mainGrossComm = mainRecord.GetAttributeValue<Money>("lux_quotedpremiumaciescommissionamount").Value;
                    //    var parentGrossComm = parentRecord.GetAttributeValue<Money>("lux_quotedpremiumaciescommissionamount").Value;

                    //    var mainLEGrossComm = mainRecord.GetAttributeValue<Money>("lux_lepolicygrosscommission").Value;
                    //    var parentLEGrossComm = parentRecord.GetAttributeValue<Money>("lux_lepolicygrosscommission").Value;

                    //    var mainLEGrossPremium = mainRecord.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value;
                    //    var parentLEGrossPremium = parentRecord.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value;

                    //    var mainLENetPremium = mainRecord.GetAttributeValue<Money>("lux_lepolicynetpremium").Value;
                    //    var parentLENetPremium = parentRecord.GetAttributeValue<Money>("lux_lepolicynetpremium").Value;

                    //    var mainMDPremium = mainRecord.Attributes.Contains("lux_materialdamagepolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_materialdamagepolicypremium").Value : 0;
                    //    var parentMDPremium = parentRecord.Attributes.Contains("lux_materialdamagepolicypremium") ? parentRecord.GetAttributeValue<Money>("lux_materialdamagepolicypremium").Value : 0;

                    //    var mainBIPremium = mainRecord.Attributes.Contains("lux_businessinterruptionpolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_businessinterruptionpolicypremium").Value : 0;
                    //    var parentBIPremium = parentRecord.Attributes.Contains("lux_businessinterruptionpolicypremium") ? parentRecord.GetAttributeValue<Money>("lux_businessinterruptionpolicypremium").Value : 0;

                    //    var mainELPremium = mainRecord.Attributes.Contains("lux_employersliabilitypolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0;
                    //    var parentELPremium = parentRecord.Attributes.Contains("lux_employersliabilitypolicypremium") ? parentRecord.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0;

                    //    var mainPOLPremium = mainRecord.Attributes.Contains("lux_propertyownersliabilitypolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_propertyownersliabilitypolicypremium").Value : 0;
                    //    var parentPOLPremium = parentRecord.Attributes.Contains("lux_propertyownersliabilitypolicypremium") ? parentRecord.GetAttributeValue<Money>("lux_propertyownersliabilitypolicypremium").Value : 0;

                    //    var mainMoneyPremium = mainRecord.Attributes.Contains("lux_moneypolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_moneypolicypremium").Value : 0;
                    //    var parentMoneyPremium = parentRecord.Attributes.Contains("lux_moneypolicypremium") ? parentRecord.GetAttributeValue<Money>("lux_moneypolicypremium").Value : 0;

                    //    var mainPLPremium = mainRecord.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0;
                    //    var parentPLPremium = parentRecord.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? parentRecord.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0;

                    //    var mainARPremium = mainRecord.Attributes.Contains("lux_allriskpolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_allriskpolicypremium").Value : 0;
                    //    var parentARPremium = parentRecord.Attributes.Contains("lux_allriskpolicypremium") ? parentRecord.GetAttributeValue<Money>("lux_allriskpolicypremium").Value : 0;

                    //    var mainGITPremium = mainRecord.Attributes.Contains("lux_goodsintransitpolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_goodsintransitpolicypremium").Value : 0;
                    //    var parentGITPremium = parentRecord.Attributes.Contains("lux_goodsintransitpolicypremium") ? parentRecord.GetAttributeValue<Money>("lux_goodsintransitpolicypremium").Value : 0;

                    //    decimal mainTerrorismBrokerComm = 0;
                    //    decimal mainTerrorismGrossComm = 0;
                    //    decimal mainTerrorismNetPremium = 0;
                    //    decimal parentTerrorismBrokerComm = 0;
                    //    decimal parentTerrorismGrossComm = 0;
                    //    decimal parentTerrorismNetPremium = 0;

                    //    if (mainRecord.Contains("lux_isterrorismcoverrequired") && mainRecord.GetAttributeValue<bool>("lux_isterrorismcoverrequired") == true)
                    //    {
                    //        mainTerrorismBrokerComm = mainRecord.GetAttributeValue<Money>("lux_terrorismbrokercommissionamount").Value;
                    //        mainTerrorismGrossComm = mainRecord.GetAttributeValue<Money>("lux_terrorismaciescommissionamout").Value;
                    //        mainTerrorismNetPremium = mainRecord.GetAttributeValue<Money>("lux_terrorismnetpremium").Value;
                    //    }

                    //    if (parentRecord.Contains("lux_isterrorismcoverrequired") && parentRecord.GetAttributeValue<bool>("lux_isterrorismcoverrequired") == true)
                    //    {
                    //        parentTerrorismBrokerComm = parentRecord.GetAttributeValue<Money>("lux_terrorismbrokercommissionamount").Value;
                    //        parentTerrorismGrossComm = parentRecord.GetAttributeValue<Money>("lux_terrorismaciescommissionamout").Value;
                    //        parentTerrorismNetPremium = parentRecord.GetAttributeValue<Money>("lux_terrorismnetpremium").Value;
                    //    }

                    //    var PolicyDuration = (mainRecord.GetAttributeValue<DateTime>("lux_renewaldate") - mainRecord.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                    //    var LengthtillNow = (mainRecord.GetAttributeValue<DateTime>("lux_mtadate") - mainRecord.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                    //    var remainingDays = PolicyDuration - LengthtillNow;

                    //    var MTAGrossPremium = (mainGrossPremium - parentGrossPremium) * remainingDays / PolicyDuration;
                    //    var MTABrokerCommission = (mainBrokerComm - parentBrokerComm) * remainingDays / PolicyDuration;
                    //    var MTAGrossCommission = (mainGrossComm - parentGrossComm) * remainingDays / PolicyDuration;
                    //    var MTALEGrossCommission = (mainLEGrossComm - parentLEGrossComm) * remainingDays / PolicyDuration;

                    //    var TerrorismBrokerComm = (mainTerrorismBrokerComm - parentTerrorismBrokerComm) * remainingDays / PolicyDuration;
                    //    var TerrorismGrossComm = (mainTerrorismGrossComm - parentTerrorismGrossComm) * remainingDays / PolicyDuration;
                    //    var TerrorismNetPremium = (mainTerrorismNetPremium - parentTerrorismNetPremium) * remainingDays / PolicyDuration;

                    //    var MTANetPremium = MTAGrossPremium + TerrorismNetPremium - MTABrokerCommission - MTAGrossCommission - MTALEGrossCommission;

                    //    var MTAMDPremium = (mainMDPremium - parentMDPremium) * remainingDays / PolicyDuration;
                    //    var MTABIPremium = (mainBIPremium - parentBIPremium) * remainingDays / PolicyDuration;
                    //    var MTAELPremium = (mainELPremium - parentELPremium) * remainingDays / PolicyDuration;
                    //    var MTAPLPremium = (mainPLPremium - parentPLPremium) * remainingDays / PolicyDuration;
                    //    var MTAPOLPremium = (mainPOLPremium - parentPOLPremium) * remainingDays / PolicyDuration;
                    //    var MTAMoneyPremium = (mainMoneyPremium - parentMoneyPremium) * remainingDays / PolicyDuration;
                    //    var MTAARPremium = (mainARPremium - parentARPremium) * remainingDays / PolicyDuration;
                    //    var MTAGITPremium = (mainGITPremium - parentGITPremium) * remainingDays / PolicyDuration;
                    //    var MTALEPremium = (mainLEGrossPremium - parentLEGrossPremium) * remainingDays / PolicyDuration;
                    //    var MTALENetPremium = (mainLENetPremium - parentLENetPremium) * remainingDays / PolicyDuration;

                    //    Entity appln = service.Retrieve("lux_propertyownersapplications", mainRecord.Id, new ColumnSet());
                    //    appln["lux_mtagrosspremium"] = new Money(MTAGrossPremium);
                    //    appln["lux_annualadditionalreturnpremium"] = new Money(mainGrossPremium - parentGrossPremium);
                    //    appln["lux_annualmtatechnicalpremium"] = new Money(mainGrossPremium - parentGrossPremium);
                    //    appln["lux_annualmtaipt"] = new Money((mainGrossPremium - parentGrossPremium) * 12 / 100);
                    //    appln["lux_mtabrokercommission"] = new Money(MTABrokerCommission + TerrorismBrokerComm);
                    //    appln["lux_mtaaciescommission"] = new Money(MTAGrossCommission + TerrorismGrossComm);
                    //    appln["lux_mtanetpremium"] = new Money(MTANetPremium);
                    //    appln["lux_mtaipt"] = new Money(MTAGrossPremium * 12 / 100);
                    //    appln["lux_acieslegalexpensesmtacommissionamount"] = new Money(MTALEGrossCommission);

                    //    appln["lux_materialdamagemtatechnicalpremium"] = new Money(MTAMDPremium);
                    //    appln["lux_businessinterruptionmtatechnicalpremium"] = new Money(MTABIPremium);
                    //    appln["lux_employersliabilitymtatechnicalpremium"] = new Money(MTAELPremium);
                    //    appln["lux_propertyownersliabilitymtatechnicalpremiu"] = new Money(MTAPOLPremium);
                    //    appln["lux_legalexpensesmtatechnicalpremium"] = new Money(MTALEPremium);
                    //    appln["lux_legalexpensesmtatechnicalnetpremium"] = new Money(MTALENetPremium);
                    //    appln["lux_terrorismmtapremium"] = new Money(TerrorismNetPremium + TerrorismGrossComm + TerrorismBrokerComm);
                    //    appln["lux_moneymtatechnicalpremium"] = new Money(MTAMoneyPremium);
                    //    appln["lux_publicproductsliabilitymtatechnicalpremiu"] = new Money(MTAPLPremium);
                    //    appln["lux_allriskmtatechnicalpremium"] = new Money(MTAARPremium);
                    //    appln["lux_goodsintransitmtatechnicalpremium"] = new Money(MTAGITPremium);
                    //    appln["lux_mtapolicyfee"] = new Money(0);

                    //    service.Update(appln);
                    //}
                }
            }
            else if (IsTradesman.Get(executionContext) == true)
            {
                var mainfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_tradesman'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_policypremiumbeforeipt' />                               
                                <attribute name='lux_policybrokercommissionamount' />                                
                                <attribute name='lux_policyaciescommissionamount' />
                                <attribute name='lux_policyacieslegalexpensescommissionamount' />
                                <attribute name='lux_legalexpensespolicynetpremium' />
                                <attribute name='lux_policytotalpremiuminciptandfee' />
                                <attribute name='lux_policyfee' />
                                <attribute name='lux_mtaeffectivedate' />
                                <attribute name='lux_legalexpensespolicygrosspremium' />
                                <attribute name='lux_tradesmanid' />
                                <attribute name='lux_renewaldate' />
                                <attribute name='lux_inceptiondate' /> 
                                <attribute name='lux_elpolicypremium' />
                                <attribute name='lux_plpolicypremium' />
                                <attribute name='lux_technicalpremiumbeforeipt' />                                
                                <attribute name='lux_technicalbrokercommissionamount' />
                                <attribute name='lux_technicalaciescommissionamount' />
                                <attribute name='lux_technicalacieslegalexpensecommissionamoun' />
                                <attribute name='lux_legalexpensestechnicalgrosspremium' />
                                <attribute name='lux_legalexpensestechnicalnetpremium' />
                                <attribute name='lux_elpremium' />
                                <attribute name='lux_plpremium' />                             
                                <attribute name='lux_carpremium' />
                                <order attribute='lux_inceptiondate' descending='true' />
                                <order attribute='lux_quotenumber' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_tradesmanid' operator='eq' uiname='Landcage LLP' uitype='lux_tradesman' value='{TradesmanApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities.Count > 0)
                {
                    var parentfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_tradesman'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_policypremiumbeforeipt' />
                                <attribute name='lux_policytotalpremiuminciptandfee' />
                                <attribute name='lux_policyfee' />
                                <attribute name='lux_legalexpensespolicygrosspremium' />
                                <attribute name='lux_legalexpensespolicynetpremium' />                             
                                <attribute name='lux_policybrokercommissionamount' />                                
                                <attribute name='lux_policyaciescommissionamount' />
                                <attribute name='lux_policyacieslegalexpensescommissionamount' />                                
                                <attribute name='lux_tradesmanid' />
                                <attribute name='lux_elpolicypremium' />
                                <attribute name='lux_plpolicypremium' />
                                <attribute name='lux_technicalpremiumbeforeipt' />                                
                                <attribute name='lux_technicalbrokercommissionamount' />
                                <attribute name='lux_technicalaciescommissionamount' />
                                <attribute name='lux_technicalacieslegalexpensecommissionamoun' />
                                <attribute name='lux_legalexpensestechnicalgrosspremium' />
                                <attribute name='lux_legalexpensestechnicalnetpremium' />
                                <attribute name='lux_elpremium' />
                                <attribute name='lux_plpremium' />
                                <attribute name='lux_carpremium' />
                                <order attribute='lux_inceptiondate' descending='true' />
                                <order attribute='lux_quotenumber' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_tradesmanid' operator='eq' uiname='Landcage LLP' uitype='lux_tradesman' value='{ParentTradesmanApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(parentfetch)).Entities.Count > 0)
                    {
                        var parentRecord = service.RetrieveMultiple(new FetchExpression(parentfetch)).Entities[0];
                        var mainRecord = service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities[0];

                        var mainGrossPremium = mainRecord.GetAttributeValue<Money>("lux_technicalpremiumbeforeipt").Value;
                        var parentGrossPremium = parentRecord.GetAttributeValue<Money>("lux_technicalpremiumbeforeipt").Value;

                        var mainBrokerComm = mainRecord.GetAttributeValue<Money>("lux_technicalbrokercommissionamount").Value;
                        var parentBrokerComm = parentRecord.GetAttributeValue<Money>("lux_technicalbrokercommissionamount").Value;

                        var mainGrossComm = mainRecord.GetAttributeValue<Money>("lux_technicalaciescommissionamount").Value;
                        var parentGrossComm = parentRecord.GetAttributeValue<Money>("lux_technicalaciescommissionamount").Value;

                        var mainLEGrossComm = mainRecord.GetAttributeValue<Money>("lux_technicalacieslegalexpensecommissionamoun").Value;
                        var parentLEGrossComm = parentRecord.GetAttributeValue<Money>("lux_technicalacieslegalexpensecommissionamoun").Value;

                        var mainLEGrossPremium = mainRecord.GetAttributeValue<Money>("lux_legalexpensestechnicalgrosspremium").Value;
                        var parentLEGrossPremium = parentRecord.GetAttributeValue<Money>("lux_legalexpensestechnicalgrosspremium").Value;

                        var mainLENetPremium = mainRecord.GetAttributeValue<Money>("lux_legalexpensestechnicalnetpremium").Value;
                        var parentLENetPremium = parentRecord.GetAttributeValue<Money>("lux_legalexpensestechnicalnetpremium").Value;

                        var mainELPremium = mainRecord.Attributes.Contains("lux_elpremium") ? mainRecord.GetAttributeValue<Money>("lux_elpremium").Value : 0;
                        var parentELPremium = parentRecord.Attributes.Contains("lux_elpremium") ? parentRecord.GetAttributeValue<Money>("lux_elpremium").Value : 0;

                        var mainPLPremium = mainRecord.Attributes.Contains("lux_plpremium") ? mainRecord.GetAttributeValue<Money>("lux_plpremium").Value : 0;
                        var parentPLPremium = parentRecord.Attributes.Contains("lux_plpremium") ? parentRecord.GetAttributeValue<Money>("lux_plpremium").Value : 0;

                        var mainCWPremium = mainRecord.Attributes.Contains("lux_carpremium") ? mainRecord.GetAttributeValue<Money>("lux_carpremium").Value : 0;
                        var parentCWPremium = parentRecord.Attributes.Contains("lux_carpremium") ? parentRecord.GetAttributeValue<Money>("lux_carpremium").Value : 0;

                        var PolicyDuration = (mainRecord.GetAttributeValue<DateTime>("lux_renewaldate") - mainRecord.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                        var LengthtillNow = (mainRecord.GetAttributeValue<DateTime>("lux_mtaeffectivedate") - mainRecord.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                        var remainingDays = PolicyDuration - LengthtillNow - 1;
                        //if (mainRecord.GetAttributeValue<DateTime>("lux_mtaeffectivedate").Date == mainRecord.GetAttributeValue<DateTime>("lux_renewaldate").Date)
                        //{
                        //    remainingDays = 0;
                        //}

                        if (Convert.ToDateTime(mainRecord.FormattedValues["lux_mtaeffectivedate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat).Date == Convert.ToDateTime(mainRecord.FormattedValues["lux_renewaldate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat).Date)
                        {
                            remainingDays = 0;
                        }

                        var MTAGrossPremium = (mainGrossPremium - parentGrossPremium) * remainingDays / PolicyDuration;
                        var MTABrokerCommission = (mainBrokerComm - parentBrokerComm) * remainingDays / PolicyDuration;
                        var MTAGrossCommission = (mainGrossComm - parentGrossComm) * remainingDays / PolicyDuration;
                        var MTALEGrossCommission = (mainLEGrossComm - parentLEGrossComm) * remainingDays / PolicyDuration;

                        var MTANetPremium = MTAGrossPremium - MTABrokerCommission - MTAGrossCommission - MTALEGrossCommission;

                        var MTAELPremium = (mainELPremium - parentELPremium) * remainingDays / PolicyDuration;
                        var MTAPLPremium = (mainPLPremium - parentPLPremium) * remainingDays / PolicyDuration;
                        var MTACWPremium = (mainCWPremium - parentCWPremium) * remainingDays / PolicyDuration;
                        var MTALEPremium = (mainLEGrossPremium - parentLEGrossPremium) * remainingDays / PolicyDuration;
                        var MTALENetPremium = (mainLENetPremium - parentLENetPremium) * remainingDays / PolicyDuration;

                        Entity appln = service.Retrieve("lux_tradesman", mainRecord.Id, new ColumnSet());
                        appln["lux_mtagrosspremium"] = new Money(MTAGrossPremium);
                        appln["lux_annualadditionalreturnpremium"] = new Money(mainGrossPremium - parentGrossPremium);
                        appln["lux_annualmtatechnicalpremium"] = new Money(mainGrossPremium - parentGrossPremium);
                        appln["lux_annualmtaipt"] = new Money((mainGrossPremium - parentGrossPremium) * 12 / 100);
                        appln["lux_mtabrokercommission"] = new Money(MTABrokerCommission);
                        appln["lux_mtaaciescommission"] = new Money(MTAGrossCommission);
                        appln["lux_mtanetpremium"] = new Money(MTANetPremium);
                        appln["lux_mtaipt"] = new Money(MTAGrossPremium * 12 / 100);
                        appln["lux_acieslegalexpensesmtacommissionamount"] = new Money(MTALEGrossCommission);

                        appln["lux_employersliabilitymtatechnicalpremium"] = new Money(MTAELPremium);
                        appln["lux_legalexpensesmtatechnicalpremium"] = new Money(MTALEPremium);
                        appln["lux_legalexpensesmtatechnicalnetpremium"] = new Money(MTALENetPremium);
                        appln["lux_publicproductsliabilitymtatechnicalpremiu"] = new Money(MTAPLPremium);
                        appln["lux_contractorsmtatechnicalpremium"] = new Money(MTACWPremium);
                        appln["lux_mtapolicyfee"] = new Money(0);

                        service.Update(appln);
                    }
                }
            }
        }
    }
}