﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculatePOLPremium : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                <attribute name='lux_propertyownersapplicationsid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_inceptiondate' />
                                <attribute name='lux_quotationdate' />
                                <attribute name='lux_applicationtype' />                                
                                <attribute name='lux_policy' />
                                <attribute name='lux_renewaldate' />
                                <attribute name='lux_propertyownersliabilitylimitofindemnity' />
                                <attribute name='lux_levelofcommission' />
                                <attribute name='lux_clericalcommercialandmanagerialwageroll' />
                                <attribute name='lux_caretakerscleanersporterswageroll' />
                                <attribute name='lux_alterationmaintenancerepairwageroll' />
                                <attribute name='lux_allotherswageroll' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplicationsid' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var appln = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                var quotationDate = appln.Contains("lux_quotationdate") ? appln.GetAttributeValue<DateTime>("lux_quotationdate") : appln.GetAttributeValue<DateTime>("lux_inceptiondate");
                var inceptionDate = appln.GetAttributeValue<DateTime>("lux_inceptiondate");
                var dateDiffDays = (appln.GetAttributeValue<DateTime>("lux_renewaldate") - appln.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                if (dateDiffDays == 364 || dateDiffDays == 365 || dateDiffDays == 366)
                {
                    dateDiffDays = 365;
                }
                CalculateRollupFieldRequest calculateRollup = new CalculateRollupFieldRequest();
                calculateRollup.FieldName = "lux_totalsuminsured";
                calculateRollup.Target = new EntityReference("lux_propertyownersapplications", appln.Id);
                CalculateRollupFieldResponse resp = (CalculateRollupFieldResponse)service.Execute(calculateRollup);
                Entity QuoteEntity = resp.Entity;
                decimal TotalSumInsured = ((Money)QuoteEntity.Attributes["lux_totalsuminsured"]).Value;

                var POL_indemnity = appln.GetAttributeValue<OptionSetValue>("lux_propertyownersliabilitylimitofindemnity");

                if (POL_indemnity != null)
                {
                    var TotalBuildingDeclaredFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_totalbuildingsdeclaredvaluerate'>
                                                            <attribute name='lux_upto2999999' />
                                                            <attribute name='lux_5mto9999999' />
                                                            <attribute name='lux_3mto4999999' />
                                                            <attribute name='lux_25mplus' />
                                                            <attribute name='lux_10mto24999999' />
                                                            <attribute name='lux_totalbuildingsdeclaredvaluerateid' />
                                                            <attribute name='lux_propertyownersliability' />
                                                            <order attribute='lux_upto2999999' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_propertyownersliability' operator='eq' value='{POL_indemnity.Value}' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";
                    if (service.RetrieveMultiple(new FetchExpression(TotalBuildingDeclaredFetch)).Entities.Count > 0)
                    {
                        var rating = "";
                        var BD_Rate = service.RetrieveMultiple(new FetchExpression(TotalBuildingDeclaredFetch)).Entities[0];
                        if (TotalSumInsured < 2999999)
                        {
                            rating = "lux_upto2999999";
                        }
                        else if (TotalSumInsured >= 3000000 && TotalSumInsured < 4999999)
                        {
                            rating = "lux_3mto4999999";
                        }
                        else if (TotalSumInsured >= 5000000 && TotalSumInsured < 9999999)
                        {
                            rating = "lux_5mto9999999";
                        }
                        else if (TotalSumInsured >= 10000000 && TotalSumInsured <= 25000000)
                        {
                            rating = "lux_10mto24999999";
                        }
                        else
                        {
                            rating = "lux_25mplus";
                        }
                        var BDRate = BD_Rate.GetAttributeValue<decimal>(rating);
                        //decimal GrossRate = 0;
                        //if (appln.Contains("lux_levelofcommission"))
                        //{
                        //    var ClaimsRatioFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                        //                                  <entity name='lux_claimslossratio'>
                        //                                    <attribute name='lux_name' />
                        //                                    <attribute name='lux_discountload' />
                        //                                    <attribute name='lux_claimslossratioid' />
                        //                                    <attribute name='lux_claimslossratio' />
                        //                                    <order attribute='lux_name' descending='false' />
                        //                                    <filter type='and'>
                        //                                      <condition attribute='statecode' operator='eq' value='0' />
                        //                                      <condition attribute='lux_claimslossratio' operator='eq' value='{appln.GetAttributeValue<OptionSetValue>("lux_levelofcommission").Value}' />
                        //                                    </filter>
                        //                                  </entity>
                        //                                </fetch>";

                        //    if (service.RetrieveMultiple(new FetchExpression(ClaimsRatioFetch)).Entities.Count > 0)
                        //    {
                        //        var ClaimData = service.RetrieveMultiple(new FetchExpression(ClaimsRatioFetch)).Entities[0];
                        //        var loadingDiscount = ClaimData.GetAttributeValue<decimal>("lux_discountload");
                        //        GrossRate = BDRate * loadingDiscount;
                        //    }
                        //}

                        var POLPremium = TotalSumInsured * BDRate / 100;
                        POLPremium = POLPremium * dateDiffDays / 365;

                        if (POLPremium < 25 && appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value != 972970001)
                        {
                            if (appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                            {
                                POLPremium = 25;
                            }
                            else
                            {
                                if (appln.Attributes.Contains("lux_policy"))
                                {
                                    var Policy = service.Retrieve("lux_policy", appln.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                    if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                    {
                                        if (quotationDate < new DateTime(2023, 02, 15))
                                        {
                                            POLPremium = 25;
                                        }
                                        else
                                        {
                                            if (POLPremium < 5)
                                            {
                                                POLPremium = 5;
                                            }
                                        }
                                    }
                                    else
                                    {
                                        POLPremium = 25;
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (POLPremium < 5)
                            {
                                POLPremium = 5;
                            }
                        }

                        var item1 = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet(true));
                        item1["lux_propertyownersliabilitypremium"] = new Money(POLPremium);
                        service.Update(item1);
                    }
                    else
                    {
                        var item1 = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet(true));
                        item1["lux_propertyownersliabilitypremium"] = new Money(0);
                        service.Update(item1);
                    }
                }
                else
                {
                    var item1 = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet(true));
                    item1["lux_propertyownersliabilitypremium"] = new Money(0);
                    service.Update(item1);
                }
            }
        }
    }
}
