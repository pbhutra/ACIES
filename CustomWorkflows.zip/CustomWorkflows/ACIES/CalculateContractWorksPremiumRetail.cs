﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculateContractWorksPremiumRetail : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Input("Product")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> Product { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var request = new RetrieveCurrentOrganizationRequest();
            var organzationResponse = (RetrieveCurrentOrganizationResponse)service.Execute(request);
            var uriString = organzationResponse.Detail.UrlName;

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                <attribute name='lux_propertyownersapplicationsid' />
                                <attribute name='lux_name' />
                                <attribute name='lux_quotationdate' />
                                <attribute name='lux_inceptiondate' />
                                <attribute name='lux_renewaldate' />
                                <attribute name='lux_hiredintemporarybuildingssuminsured' />
                                <attribute name='lux_hiredinplantcharges' />
                                <attribute name='lux_employeestoolstotalsuminsured' />
                                <attribute name='lux_owntemporarybuildingssuminsured' />                                
                                <attribute name='lux_ownplanttoolsandequipmenttotalreplacement' />
                                <attribute name='lux_maximumcontractvalue' />
                                <attribute name='lux_contractworksturnover' />
                                <attribute name='lux_contractorsprimarytrade' />
                                <attribute name='lux_contractorssecondarytrade' />
                                <attribute name='lux_primarytradeturnover' />
                                <attribute name='lux_secondarytradeturnover' />
                                <attribute name='lux_doyourequirecoverforcontractwork' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplicationsid' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var item = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                var quotationDate = item.Contains("lux_quotationdate") ? item.GetAttributeValue<DateTime>("lux_quotationdate") : item.GetAttributeValue<DateTime>("lux_inceptiondate");
                var inceptionDate = item.GetAttributeValue<DateTime>("lux_inceptiondate");

                if (item.GetAttributeValue<bool>("lux_doyourequirecoverforcontractwork") == true)
                {
                    decimal OwnPlantandTools = item.Attributes.Contains("lux_ownplanttoolsandequipmenttotalreplacement") ? item.GetAttributeValue<Money>("lux_ownplanttoolsandequipmenttotalreplacement").Value : 0;
                    decimal OwnTemporaryBuildings = item.Attributes.Contains("lux_owntemporarybuildingssuminsured") ? item.GetAttributeValue<Money>("lux_owntemporarybuildingssuminsured").Value : 0;
                    decimal EmployeesTools = item.Attributes.Contains("lux_employeestoolstotalsuminsured") ? item.GetAttributeValue<Money>("lux_employeestoolstotalsuminsured").Value : 0;
                    decimal HiredinPlantCharges = item.Attributes.Contains("lux_hiredinplantcharges") ? item.GetAttributeValue<Money>("lux_hiredinplantcharges").Value : 0;
                    decimal HiredinTemporaryBuildings = item.Attributes.Contains("lux_hiredintemporarybuildingssuminsured") ? item.GetAttributeValue<Money>("lux_hiredintemporarybuildingssuminsured").Value : 0;

                    decimal primaryTurnover = item.Contains("lux_primarytradeturnover") ? item.GetAttributeValue<Money>("lux_primarytradeturnover").Value : 0;
                    decimal secondaryTurnover = item.Contains("lux_secondarytradeturnover") ? item.GetAttributeValue<Money>("lux_secondarytradeturnover").Value : 0;
                    decimal totalTurnover = primaryTurnover + secondaryTurnover;
                    decimal primaryTradeRate = 0;

                    if (item.Attributes.Contains("lux_contractorsprimarytrade"))
                    {
                        var primaryTrade = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_contractorstrade'>
                                                    <attribute name='lux_contractorstradeid' />
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_tradecategory' />
                                                    <attribute name='lux_plrate' />
                                                    <attribute name='lux_materialdamagefirerate' />
                                                    <attribute name='lux_elrate' />
                                                    <attribute name='lux_carrate' />
                                                    <attribute name='lux_businessinterruptionrate' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                      <filter type='or'>
                                                        <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                        <condition attribute='lux_enddate' operator='null' />
                                                      </filter>
                                                      <condition attribute='lux_contractorstradeid' operator='eq' uiname='Aerial Erection' uitype='lux_contractorstrade' value='{item.GetAttributeValue<EntityReference>("lux_contractorsprimarytrade").Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(primaryTrade)).Entities.Count > 0)
                        {
                            var PLData = service.RetrieveMultiple(new FetchExpression(primaryTrade)).Entities[0];
                            primaryTradeRate = PLData.GetAttributeValue<decimal>("lux_carrate");
                        }
                    }

                    decimal CARTurnoverPremium = totalTurnover * primaryTradeRate / 100;

                    decimal ownplantpremium = OwnPlantandTools * Convert.ToDecimal(1.750) / 100;
                    decimal owntemporarybuildingpremium = OwnTemporaryBuildings * Convert.ToDecimal(1.750) / 100;
                    decimal employeetoolspremium = EmployeesTools * Convert.ToDecimal(2) / 100;
                    decimal hiredinplantpremium = HiredinPlantCharges * Convert.ToDecimal(2) / 100;
                    decimal hiredintemporarybuildingpremium = HiredinTemporaryBuildings * Convert.ToDecimal(2.5) / 100;

                    decimal totalContractPlantPremium = ownplantpremium + owntemporarybuildingpremium + employeetoolspremium + hiredinplantpremium + hiredintemporarybuildingpremium;

                    decimal totalCARPremium = CARTurnoverPremium + totalContractPlantPremium;

                    var item1 = service.Retrieve("lux_propertyownersapplications", item.Id, new ColumnSet(false));
                    var dateDiffDays = (item.GetAttributeValue<DateTime>("lux_renewaldate") - item.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                    if (dateDiffDays == 364 || dateDiffDays == 365 || dateDiffDays == 366)
                    {
                        dateDiffDays = 365;
                    }

                    totalCARPremium = totalCARPremium * dateDiffDays / 365;

                    item1["lux_contractorsturnoverpremium"] = new Money(CARTurnoverPremium * dateDiffDays / 365);
                    item1["lux_contractorsplantpremium"] = new Money(totalContractPlantPremium * dateDiffDays / 365);

                    //if (uriString.ToLower().Contains("uat"))
                    //{
                    var SizeDiscountFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_sizediscount'>
                                            <attribute name='lux_effectiveto' />
                                            <attribute name='lux_effectivefrom' />
                                            <attribute name='lux_below500k' />
                                            <attribute name='lux_above5m' />
                                            <attribute name='lux_501k1m' />
                                            <attribute name='lux_20000015m' />
                                            <attribute name='lux_10000012m' />
                                            <order attribute='createdon' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <filter type='or'>
                                                <condition attribute='lux_effectivefrom' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                <condition attribute='lux_effectivefrom' operator='null' />
                                              </filter>
                                              <filter type='or'>
                                                <condition attribute='lux_effectiveto' operator='on-or-after' value= '{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                <condition attribute='lux_effectiveto' operator='null' />
                                              </filter>
                                              <condition attribute='lux_section' operator='eq' value='972970001' />
                                              <condition attribute='lux_product' operator='eq' uiname='' uitype='product' value='{this.Product.Get(executionContext).Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(SizeDiscountFetch)).Entities.Count > 0)
                    {
                        var SI_data = service.RetrieveMultiple(new FetchExpression(SizeDiscountFetch)).Entities;
                        var SI_field = "";
                        if (totalTurnover <= 500000)
                        {
                            SI_field = "lux_below500k";
                        }
                        else if (totalTurnover > 500000 && totalTurnover <= 1000000)
                        {
                            SI_field = "lux_501k1m";
                        }
                        else if (totalTurnover > 1000000 && totalTurnover <= 2000000)
                        {
                            SI_field = "lux_10000012m";
                        }
                        else if (totalTurnover > 2000000 && totalTurnover <= 5000000)
                        {
                            SI_field = "lux_20000015m";
                        }
                        else if (totalTurnover > 5000000)
                        {
                            SI_field = "lux_above5m";
                        }
                        var discount = SI_data.FirstOrDefault().GetAttributeValue<decimal>(SI_field);
                        item1["lux_workawayaction"] = discount.ToString("#.##") + "%";

                        if (discount.ToString("#.##") == "")
                        {
                            item1["lux_workawayaction"] = "0%";
                        }
                    }
                    //}

                    if (totalCARPremium < 350)
                    {
                        item1["lux_contractorspremium"] = new Money(350);
                    }
                    else
                    {
                        item1["lux_contractorspremium"] = new Money(totalCARPremium);
                    }

                    service.Update(item1);
                }
                else
                {
                    var item1 = service.Retrieve("lux_propertyownersapplications", item.Id, new ColumnSet(false));
                    item1["lux_contractorspremium"] = new Money(0);
                    item1["lux_contractorsturnoverpremium"] = new Money(0);
                    item1["lux_contractorsplantpremium"] = new Money(0);
                    item1["lux_workawayaction"] = "";
                    service.Update(item1);
                }
            }
        }
    }
}
