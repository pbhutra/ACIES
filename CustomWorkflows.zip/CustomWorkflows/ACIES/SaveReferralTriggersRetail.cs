﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Net;
using System.ServiceModel.Description;
using System.Linq;

namespace CustomWorkflows
{
    public class SaveReferralTriggersRetail : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference applnref = PropertyOwnersApplication.Get<EntityReference>(executionContext);
            Entity appln = new Entity(applnref.LogicalName, applnref.Id);
            appln = service.Retrieve("lux_propertyownersapplications", applnref.Id, new ColumnSet(true));

            if (appln.Attributes.Contains("lux_declarationsquestion1"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_declarationsquestion1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion1") == false)
                    {
                        var FieldName1 = "The Proposers any Director or Partner in the company:";
                        FieldName1 += "a. Has never been convicted";
                        FieldName1 += "b. Has never been charged(but not yet tried)";
                        FieldName1 += "c. Has never been given an official police caution in respect of any criminal offence other than a than a(road traffic) motoring offence";
                        FieldName1 += "d. Has never been given an official police caution in respect of any criminal offence other than an offence that is now considered 'spent' under the Rehabilitation of Offenders Act 1974";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_declarationsquestion1";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_declarationanswer1") ? appln.Attributes["lux_declarationanswer1"] : "";
                        refer["lux_suppliedvalue"] = "Disagree";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion1") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true)
                            {
                                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                            }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_declarationsquestion2"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_declarationsquestion2' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion2") == false)
                    {
                        var FieldName1 = "The Proposers, any Director or Partner in the company:";
                        FieldName1 += "a. Has never been declared bankrupt (other than a bankruptcy that has been discharged) or insolvent";
                        FieldName1 += "b. Is not subject to any current bankruptcy or insolvency proceedings";
                        FieldName1 += "c. Has no outstanding County Court Judgement(s) or Sheriff Court Decree(s)";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_declarationsquestion2";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_declarationanswer2") ? appln.Attributes["lux_declarationanswer2"] : "";
                        refer["lux_suppliedvalue"] = "Disagree";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion2") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_declarationsquestion3"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_declarationsquestion3' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion3") == false)
                    {
                        var FieldName1 = "The Proposers any Director or Partner in the company have never been prosecuted or received notice of intended prosecution under:";
                        FieldName1 += "a. The Consumer Protection Act 1987";
                        FieldName1 += "b. The Food Safety Act 1990";
                        FieldName1 += "c. The Health & Safety Act 1974";
                        FieldName1 += "d. Any welfare or environmental protection legislation";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_declarationsquestion3";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_declarationanswer3") ? appln.Attributes["lux_declarationanswer3"] : "";
                        refer["lux_suppliedvalue"] = "Disagree";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion3") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_declarationsquestion4"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_declarationsquestion4' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion4") == false)
                    {
                        var FieldName1 = "The Proposers any Director or Partner in the company have not had:";
                        FieldName1 += "a. an insurance application refused or declined";
                        FieldName1 += "b. an insurance cancelled or renewal refused";
                        FieldName1 += "c. any increased or specific terms applied to any business insurance";
                        FieldName1 += "d. avioided any of your insurance policies for non-disclosure or misrepresentation of any material fact";
                        FieldName1 += "e. refused to pay a claim or restricted cover as a result of a policy terms or condition or risk improvement requirements.";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_declarationsquestion4";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_declarationanswer4") ? appln.Attributes["lux_declarationanswer4"] : "";
                        refer["lux_suppliedvalue"] = "Disagree";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_declarationsquestion4") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_claimmadewithinthelast5years") && appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value != 972970003)
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_claimmadewithinthelast5years' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == true)
                    {
                        var FieldName1 = "Has your business been involved in any losses, claims or incidents that may result in a claim within the last 5 years";

                        CalculateRollupFieldRequest calculateRollup = new CalculateRollupFieldRequest();
                        calculateRollup.FieldName = "lux_totalclaimamountpaidoutstanding";
                        calculateRollup.Target = new EntityReference("lux_propertyownersapplications", appln.Id);
                        CalculateRollupFieldResponse resp = (CalculateRollupFieldResponse)service.Execute(calculateRollup);

                        CalculateRollupFieldRequest calculateRollup1 = new CalculateRollupFieldRequest();
                        calculateRollup1.FieldName = "lux_totalnumberofclaims";
                        calculateRollup1.Target = new EntityReference("lux_propertyownersapplications", appln.Id);
                        CalculateRollupFieldResponse resp1 = (CalculateRollupFieldResponse)service.Execute(calculateRollup1);

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_claimmadewithinthelast5years";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_additionalinfo"] = "Total Claim Amount: " + appln.FormattedValues["lux_totalclaimamountpaidoutstanding"] + ", " + "Total Number of Claims: " + appln.GetAttributeValue<Int32>("lux_totalnumberofclaims");
                        service.Create(refer);
                    }
                }
                else
                {
                    var refer1 = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault();
                    if (refer1.GetAttributeValue<bool>("lux_approve") != true)
                    {
                        if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == false)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                            foreach (var item in reff)
                            {
                                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                            }
                        }
                        else if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == true)
                        {
                            var FieldName1 = "Has your business been involved in any losses, claims or incidents that may result in a claim within the last 5 years";

                            CalculateRollupFieldRequest calculateRollup = new CalculateRollupFieldRequest();
                            calculateRollup.FieldName = "lux_totalclaimamountpaidoutstanding";
                            calculateRollup.Target = new EntityReference("lux_propertyownersapplications", appln.Id);
                            CalculateRollupFieldResponse resp = (CalculateRollupFieldResponse)service.Execute(calculateRollup);

                            CalculateRollupFieldRequest calculateRollup1 = new CalculateRollupFieldRequest();
                            calculateRollup1.FieldName = "lux_totalnumberofclaims";
                            calculateRollup1.Target = new EntityReference("lux_propertyownersapplications", appln.Id);
                            CalculateRollupFieldResponse resp1 = (CalculateRollupFieldResponse)service.Execute(calculateRollup1);

                            Entity refer = new Entity("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Id);
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_claimmadewithinthelast5years";
                            refer["lux_suppliedvalue"] = "Yes";
                            refer["lux_additionalinfo"] = "Total Claim Amount: " + appln.FormattedValues["lux_totalclaimamountpaidoutstanding"] + ", " + "Total Number of Claims: " + appln.GetAttributeValue<Int32>("lux_totalnumberofclaims");
                            service.Update(refer);
                        }
                    }
                    else
                    {
                        if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == true)
                        {
                            var FieldName1 = "Has your business been involved in any losses, claims or incidents that may result in a claim within the last 5 years";

                            CalculateRollupFieldRequest calculateRollup = new CalculateRollupFieldRequest();
                            calculateRollup.FieldName = "lux_totalclaimamountpaidoutstanding";
                            calculateRollup.Target = new EntityReference("lux_propertyownersapplications", appln.Id);
                            CalculateRollupFieldResponse resp = (CalculateRollupFieldResponse)service.Execute(calculateRollup);

                            CalculateRollupFieldRequest calculateRollup1 = new CalculateRollupFieldRequest();
                            calculateRollup1.FieldName = "lux_totalnumberofclaims";
                            calculateRollup1.Target = new EntityReference("lux_propertyownersapplications", appln.Id);
                            CalculateRollupFieldResponse resp1 = (CalculateRollupFieldResponse)service.Execute(calculateRollup1);

                            Entity refer = service.Retrieve("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Id, new ColumnSet(true));
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_claimmadewithinthelast5years";
                            refer["lux_suppliedvalue"] = "Yes";
                            if (!refer["lux_additionalinfo"].ToString().Contains(appln.FormattedValues["lux_totalclaimamountpaidoutstanding"]))
                            {
                                refer["lux_approve"] = false;
                                refer["lux_approvaldate"] = null;
                                refer["lux_userapproval"] = null;
                                refer["lux_additionalinfo"] = "Total Claim Amount: " + appln.FormattedValues["lux_totalclaimamountpaidoutstanding"] + ", " + "Total Number of Claims: " + appln.GetAttributeValue<Int32>("lux_totalnumberofclaims");
                            }
                            else
                            {
                                refer["lux_additionalinfo"] = "Total Claim Amount: " + appln.FormattedValues["lux_totalclaimamountpaidoutstanding"] + ", " + "Total Number of Claims: " + appln.GetAttributeValue<Int32>("lux_totalnumberofclaims");
                            }
                            service.Update(refer);
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_claimmadewithinthelast5years") && appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value != 972970003)
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_claimmadewithinthelast5years1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='lux_subsidarycompanypreviousclaim'>
                                        <attribute name='lux_descriptionofclaim' />
                                        <attribute name='lux_dateofclaim' />
                                        <attribute name='lux_causeofclaim' />
                                        <attribute name='lux_amountpaid' />
                                        <attribute name='lux_amountoutstanding' />
                                        <attribute name='lux_totalclaimamount' />
                                        <attribute name='lux_subsidarycompanypreviousclaimid' />
                                        <order attribute='lux_causeofclaim' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='statecode' operator='eq' value='0' />
                                          <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                          <condition attribute='lux_causeofclaim' operator='eq' value='972970015' />
                                        </filter>
                                      </entity>
                                    </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == true && service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
                    {
                        var Claim = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities;
                        var claimCount = Claim.Count;
                        if (claimCount == 1 && Claim.Sum(x => x.GetAttributeValue<Money>("lux_totalclaimamount").Value) > 10000)
                        {
                            var FieldName1 = "ARAG Claims Referral";

                            Entity refer = new Entity("lux_referral");
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_claimmadewithinthelast5years1";
                            refer["lux_suppliedvalue"] = "Total Number of Claims: " + claimCount + ", Total Claim Amount: " + Claim.Sum(x => x.GetAttributeValue<Money>("lux_totalclaimamount").Value);
                            refer["lux_additionalinfo"] = "Refer to ARAG";
                            service.Create(refer);
                        }
                        else if (claimCount >= 2)
                        {
                            var FieldName1 = "ARAG Claims Referral";

                            Entity refer = new Entity("lux_referral");
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_claimmadewithinthelast5years1";
                            refer["lux_suppliedvalue"] = "Total Number of Claims: " + claimCount + ", Total Claim Amount: " + Claim.Sum(x => x.GetAttributeValue<Money>("lux_totalclaimamount").Value);
                            refer["lux_additionalinfo"] = "Refer to ARAG";
                            service.Create(refer);
                        }
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == false || service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count == 0)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                    else if (appln.GetAttributeValue<bool>("lux_claimmadewithinthelast5years") == true && service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
                    {
                        var Claim = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities;
                        var claimCount = Claim.Count;
                        if (claimCount == 1 && Claim.Sum(x => x.GetAttributeValue<Money>("lux_totalclaimamount").Value) > 10000)
                        {
                            var FieldName1 = "ARAG Claims Referral";

                            Entity refer = new Entity("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Id);
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_claimmadewithinthelast5years1";
                            refer["lux_suppliedvalue"] = "Total Number of Claims: " + claimCount + ", Total Claim Amount: " + Claim.Sum(x => x.GetAttributeValue<Money>("lux_totalclaimamount").Value);
                            refer["lux_additionalinfo"] = "Refer to ARAG";
                            service.Update(refer);
                        }
                        else if (claimCount >= 2)
                        {
                            var FieldName1 = "ARAG Claims Referral";

                            Entity refer = new Entity("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Id);
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_claimmadewithinthelast5years1";
                            refer["lux_suppliedvalue"] = "Total Number of Claims: " + claimCount + ", Total Claim Amount: " + Claim.Sum(x => x.GetAttributeValue<Money>("lux_totalclaimamount").Value);
                            refer["lux_additionalinfo"] = "Refer to ARAG";
                            service.Update(refer);
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_datethebusinessstarted"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_datethebusinessstarted' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if ((DateTime.Now.Year - 1) <= appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").Year)
                    {
                        var FieldName1 = "Date the business started";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_datethebusinessstarted";
                        refer["lux_additionalinfo"] = "Trading less than 12 months";
                        refer["lux_suppliedvalue"] = appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").ToShortDateString();
                        service.Create(refer);
                    }
                }
                else
                {
                    if ((DateTime.Now.Year - 1) > appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").Year)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                    else if ((DateTime.Now.Year - 1) <= appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").Year)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.GetAttributeValue<DateTime>("lux_datethebusinessstarted").ToShortDateString();
                        reff["lux_additionalinfo"] = "Trading less than 12 months";
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_anyheatworkawayundertaken"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_anyheatworkawayundertaken' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_anyheatworkawayundertaken") == true)
                    {
                        var FieldName1 = "Any heat work away undertaken";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_anyheatworkawayundertaken";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_anyheatworkawayundertaken") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_bonafidesubcontractorswageroll"))
            {
                var workawayWageroll = appln.Attributes.Contains("lux_workawaywageroll") ? appln.GetAttributeValue<Money>("lux_workawaywageroll").Value : 0;
                var bonafideWageroll = appln.Attributes.Contains("lux_bonafidesubcontractorswageroll") ? appln.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value : 0;
                decimal heat = 0;
                if (appln.Attributes.Contains("lux_anyheatworkawayundertaken"))
                {
                    if (appln.GetAttributeValue<bool>("lux_anyheatworkawayundertaken") == true)
                        heat = appln.Attributes.Contains("lux_heatworkawaywageroll") ? appln.GetAttributeValue<Money>("lux_heatworkawaywageroll").Value : 0;
                }
                var TotalTurnover = workawayWageroll + bonafideWageroll + heat;

                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_bonafidesubcontractorswageroll' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (TotalTurnover * 25 / 100 < appln.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value)
                    {
                        var FieldName1 = "Bonafide Subcontractors Wageroll";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_bonafidesubcontractorswageroll";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_bonafidesubcontractorswageroll"];
                        refer["lux_additionalinfo"] = (bonafideWageroll * 100 / TotalTurnover).ToString("#.##") + "%";
                        if (appln.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value > TotalTurnover * 80 / 100)
                        {
                            refer["lux_refertohcc"] = true;
                            refer["lux_additionalinfo"] = "Refer Risk to Liability Carrier for Approval as Bonafide Wageroll is: " + (bonafideWageroll * 100 / TotalTurnover).ToString("#.##") + "%";
                        }
                        service.Create(refer);
                    }
                }
                else
                {
                    if (TotalTurnover * 25 / 100 >= appln.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (TotalTurnover * 25 / 100 < appln.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_bonafidesubcontractorswageroll"];
                        reff["lux_additionalinfo"] = (bonafideWageroll * 100 / TotalTurnover).ToString("#.##") + "%";
                        if (appln.GetAttributeValue<Money>("lux_bonafidesubcontractorswageroll").Value > TotalTurnover * 80 / 100)
                        {
                            reff["lux_additionalinfo"] = "Refer Risk to Liability Carrier for Approval as Bonafide Wageroll is: " + (bonafideWageroll * 100 / TotalTurnover).ToString("#.##") + "%";
                            reff["lux_refertohcc"] = true;
                        }
                        else
                        {
                            reff["lux_refertohcc"] = false;
                            reff["lux_additionalinfo"] = (bonafideWageroll * 100 / TotalTurnover).ToString("#.##") + "%";
                        }
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_clericalcommercialandmanagerialwageroll"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_clericalcommercialandmanagerialwageroll' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_clericalcommercialandmanagerialwageroll").Value == 0 && appln.GetAttributeValue<Money>("lux_manualwageroll").Value == 0)
                    {
                        var FieldName1 = "Clerical/Manual Wageroll";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_clericalcommercialandmanagerialwageroll";
                        refer["lux_suppliedvalue"] = "£0";
                        refer["lux_additionalinfo"] = "Clerical/Manual Wageroll is entered as £0";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_clericalcommercialandmanagerialwageroll").Value > 0 || appln.GetAttributeValue<Money>("lux_manualwageroll").Value > 0)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<Money>("lux_clericalcommercialandmanagerialwageroll").Value == 0 && appln.GetAttributeValue<Money>("lux_manualwageroll").Value == 0)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = "£0";
                        reff["lux_additionalinfo"] = "Clerical/Manual Wageroll is entered as £0";
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_manualwageroll"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_manualwageroll' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_manualwageroll").Value > 5000000)
                    {
                        var FieldName1 = "Manual Wageroll";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_manualwageroll";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_manualwageroll"];
                        refer["lux_additionalinfo"] = "Refer Risk to Liability Carrier for Approval";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_manualwageroll").Value > 0 && appln.GetAttributeValue<Money>("lux_manualwageroll").Value <= 5000000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<Money>("lux_manualwageroll").Value > 5000000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_manualwageroll"];
                        reff["lux_additionalinfo"] = "Refer Risk to Liability Carrier for Approval";
                        reff["lux_refertohcc"] = true;
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_northamericaandcanadaturnover"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_northamericaandcanadaturnover' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_northamericaandcanadaturnover").Value > 0)
                    {
                        var FieldName1 = "North America and Canada Turnover";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_northamericaandcanadaturnover";
                        refer["lux_additionalinfo"] = "Refer Risk to Liability Carrier for Approval";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_northamericaandcanadaturnover"];
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_northamericaandcanadaturnover").Value <= 0)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<Money>("lux_northamericaandcanadaturnover").Value > 0)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_northamericaandcanadaturnover"];
                        reff["lux_additionalinfo"] = "Refer Risk to Liability Carrier for Approval";
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_ukturnover"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_ukturnover' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_turnover").Value * 50 / 100 > appln.GetAttributeValue<Money>("lux_ukturnover").Value)
                    {
                        var FieldName1 = "UK Turnover";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_ukturnover";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ukturnoverpercentage") ? appln.Attributes["lux_ukturnoverpercentage"] : "";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_ukturnover"];
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_turnover").Value * 50 / 100 <= appln.GetAttributeValue<Money>("lux_ukturnover").Value)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<Money>("lux_turnover").Value * 50 / 100 > appln.GetAttributeValue<Money>("lux_ukturnover").Value)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_additionalinfo"] = appln.Attributes.Contains("lux_ukturnoverpercentage") ? appln.Attributes["lux_ukturnoverpercentage"] : "";
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_northamericaandcanadaturnover"];
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_moneyonpremisesduringhours"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_moneyonpremisesduringhours' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<OptionSetValue>("lux_moneyonpremisesduringhours").Value > 972970003)
                    {
                        var FieldName1 = "Money on Premises during business hours";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_moneyonpremisesduringhours";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_moneyonpremisesduringhours"];
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<OptionSetValue>("lux_moneyonpremisesduringhours").Value <= 972970003)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<OptionSetValue>("lux_moneyonpremisesduringhours").Value > 972970003)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_moneyonpremisesduringhours"];
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_moneyinspecifiedsafe1"))
            {
                var Money1 = appln.GetAttributeValue<Money>("lux_moneyinspecifiedsafe1").Value;
                var Money2 = appln.Attributes.Contains("lux_moneyinspecifiedsafe2") ? appln.GetAttributeValue<Money>("lux_moneyinspecifiedsafe2").Value : 0;
                var Money3 = appln.Attributes.Contains("lux_moneyinspecifiedsafe3") ? appln.GetAttributeValue<Money>("lux_moneyinspecifiedsafe3").Value : 0;
                var Money4 = appln.Attributes.Contains("lux_moneyinspecifiedsafe4") ? appln.GetAttributeValue<Money>("lux_moneyinspecifiedsafe4").Value : 0;
                var Money5 = appln.Attributes.Contains("lux_moneyinspecifiedsafe5") ? appln.GetAttributeValue<Money>("lux_moneyinspecifiedsafe5").Value : 0;
                var totalMoney = Money1 + Money2 + Money3 + Money4 + Money5;

                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_moneyinspecifiedsafe1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (totalMoney >= 10000)
                    {
                        var FieldName1 = "Money in specified safe in excess of £10,000";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_moneyinspecifiedsafe1";
                        refer["lux_suppliedvalue"] = "£" + totalMoney;
                        service.Create(refer);
                    }
                }
                else
                {
                    if (totalMoney < 10000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (totalMoney >= 10000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = "£" + totalMoney;
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_allriskitems"))
            {
                var AllRiskfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_allriskitem'>
                                                <attribute name='lux_typeofequipment' />
                                                <attribute name='lux_territoriallimit' />
                                                <attribute name='lux_suminsured' />
                                                <attribute name='lux_excess' />
                                                <attribute name='lux_allriskitemid' />
                                                <order attribute='lux_typeofequipment' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                                </filter>
                                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_application' link-type='inner' alias='aa'>
                                                  <filter type='and'>
                                                    <condition attribute='lux_allriskitems' operator='eq' value='1' />
                                                  </filter>
                                                </link-entity>
                                              </entity>
                                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.Count > 0)
                {
                    var CheckAmt = service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.Where(x => x.GetAttributeValue<Money>("lux_suminsured").Value > 10000).Count();
                    var items = service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.Where(x => x.GetAttributeValue<Money>("lux_suminsured").Value > 10000).Select(y => y.FormattedValues["lux_typeofequipment"]).ToArray();

                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_referral'>
                                                    <attribute name='lux_suppliedvalue' />
                                                    <attribute name='lux_fieldname' />
                                                    <attribute name='lux_approve' />
                                                    <attribute name='lux_additionalinfo' />
                                                    <attribute name='lux_referralid' />
                                                    <order attribute='lux_suppliedvalue' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_allriskitems' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                    {
                        if (CheckAmt > 0 && appln.GetAttributeValue<bool>("lux_allriskitems") == true)
                        {
                            var FieldName1 = "All Risk Items";
                            Entity refer = new Entity("lux_referral");
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_allriskitems";
                            refer["lux_additionalinfo"] = "Sum Insured Amount Exceed £10,000";
                            refer["lux_suppliedvalue"] = String.Join(",", items);
                            service.Create(refer);
                        }
                    }
                    else
                    {
                        if (CheckAmt == 0 || appln.GetAttributeValue<bool>("lux_allriskitems") == false)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                        }
                        else if (CheckAmt > 0 && appln.GetAttributeValue<bool>("lux_allriskitems") == true)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            reff["lux_suppliedvalue"] = String.Join(",", items);
                            reff["lux_additionalinfo"] = "Sum Insured Amount Exceed £10,000";
                            service.Update(reff);
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_allriskitems"))
            {
                var AllRiskfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_allriskitem'>
                                                <attribute name='lux_typeofequipment' />
                                                <attribute name='lux_territoriallimit' />
                                                <attribute name='lux_suminsured' />
                                                <attribute name='lux_itemdescription' />
                                                <attribute name='lux_excess' />
                                                <attribute name='lux_allriskitemid' />
                                                <order attribute='lux_typeofequipment' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                                </filter>
                                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_application' link-type='inner' alias='aa'>
                                                  <filter type='and'>
                                                    <condition attribute='lux_allriskitems' operator='eq' value='1' />
                                                  </filter>
                                                </link-entity>
                                              </entity>
                                            </fetch>";

                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_referral'>
                                                    <attribute name='lux_suppliedvalue' />
                                                    <attribute name='lux_fieldname' />
                                                    <attribute name='lux_approve' />                                                    
                                                    <attribute name='lux_additionalinfo' />
                                                    <attribute name='lux_referralid' />
                                                    <order attribute='lux_suppliedvalue' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_allriskitemsothers' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.Count > 0)
                {
                    var items = service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_typeofequipment").Value == 972970010);

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                    {
                        if (items != null && appln.GetAttributeValue<bool>("lux_allriskitems") == true)
                        {
                            var FieldName1 = "All Risk Items - Other";
                            Entity refer = new Entity("lux_referral");
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_allriskitemsothers";
                            if (service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.FirstOrDefault().Attributes.Contains("lux_itemdescription"))
                            {
                                refer["lux_suppliedvalue"] = service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.FirstOrDefault().Attributes["lux_itemdescription"];
                            }
                            refer["lux_additionalinfo"] = "Other";
                            service.Create(refer);
                        }
                    }
                    else
                    {
                        if (items == null || appln.GetAttributeValue<bool>("lux_allriskitems") == false)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                        }
                        else if (items != null && appln.GetAttributeValue<bool>("lux_allriskitems") == true)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            if (service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.FirstOrDefault().Attributes.Contains("lux_itemdescription"))
                            {
                                reff["lux_suppliedvalue"] = service.RetrieveMultiple(new FetchExpression(AllRiskfetch)).Entities.FirstOrDefault().Attributes["lux_itemdescription"];
                            }
                            reff["lux_additionalinfo"] = "Other";
                            service.Update(reff);
                        }
                    }
                }
                else
                {
                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_employersliabilitypolicypremium"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_employersliabilitypolicypremium' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    var ELPremium = appln.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value;
                    if (ELPremium > 15000)
                    {
                        var FieldName1 = "Employer's Liability Premium";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_employersliabilitypolicypremium";
                        refer["lux_suppliedvalue"] = appln.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value.ToString();
                        refer["lux_additionalinfo"] = "Liability Survey Required";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value <= 15000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_publicproductsliabilitypremium"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_publicproductsliabilitypremium' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    var PLPremium = appln.GetAttributeValue<Money>("lux_publicproductsliabilitypremium").Value;
                    if (PLPremium > 15000)
                    {
                        var FieldName1 = "PL/Products Premium";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_publicproductsliabilitypremium";
                        refer["lux_suppliedvalue"] = appln.GetAttributeValue<Money>("lux_publicproductsliabilitypremium").Value.ToString();
                        refer["lux_additionalinfo"] = "Liability Survey Required";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_publicproductsliabilitypremium").Value <= 15000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_turnover"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_turnover' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_turnover").Value > 20000000)
                    {
                        var FieldName1 = "Total Turnover";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_turnover";
                        refer["lux_additionalinfo"] = "Refer Risk to Liability Carrier for Approval";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_turnover"];
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_turnover").Value <= 20000000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<Money>("lux_turnover").Value > 20000000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_additionalinfo"] = "Refer Risk to Liability Carrier for Approval";
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_turnover"];
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_turnover"))
            {
                var Turnover = appln.GetAttributeValue<Money>("lux_turnover").Value;
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_referral'>
                                            <attribute name='lux_suppliedvalue' />
                                            <attribute name='lux_fieldname' />
                                            <attribute name='lux_approve' />
                                            <attribute name='lux_additionalinfo' />
                                            <attribute name='lux_referralid' />
                                            <order attribute='lux_suppliedvalue' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                              <condition attribute='lux_fieldschemaname' operator='eq' value='lux_turnover' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (Turnover >= 10000000)
                    {
                        var FieldName1 = "Total Turnover";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_turnover";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_turnover"];
                        refer["lux_additionalinfo"] = "ARAG: TOTAL TURNOVER: LIMIT EXCEEDED";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (Turnover < 10000000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_postcode"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_postcode' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<string>("lux_postcode").StartsWith("BT"))
                    {
                        var FieldName1 = "Postcode";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_postcode";
                        refer["lux_additionalinfo"] = "Northern Ireland Postcode";
                        refer["lux_suppliedvalue"] = appln.Attributes.Contains("lux_postcode") ? appln.Attributes["lux_postcode"] : ""; ;
                        service.Create(refer);
                    }
                }
                else
                {
                    if (!appln.GetAttributeValue<string>("lux_postcode").StartsWith("BT"))
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_wheredoestheinsuredsourcegoodsfrom"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_wheredoestheinsuredsourcegoodsfrom' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<OptionSetValueCollection>("lux_wheredoestheinsuredsourcegoodsfrom").Contains(new OptionSetValue(972970003)))
                    {
                        var FieldName1 = "Imports – Asia";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_wheredoestheinsuredsourcegoodsfrom";
                        refer["lux_suppliedvalue"] = appln.Attributes["lux_asiagoods"].ToString();
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<OptionSetValueCollection>("lux_wheredoestheinsuredsourcegoodsfrom").Contains(new OptionSetValue(972970003)))
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.Attributes["lux_asiagoods"].ToString();
                        service.Update(reff);
                    }
                    else
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }

            var InceptionDate = appln.GetAttributeValue<DateTime>("lux_inceptiondate");
            var RenewalDate = appln.GetAttributeValue<DateTime>("lux_renewaldate");

            if (appln.Attributes.Contains("lux_renewaldate"))
            {
                var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_referral'>
                                            <attribute name='lux_suppliedvalue' />
                                            <attribute name='lux_fieldname' />
                                            <attribute name='lux_approve' />
                                            <attribute name='lux_additionalinfo' />
                                            <attribute name='lux_referralid' />
                                            <order attribute='lux_suppliedvalue' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                              <condition attribute='lux_fieldschemaname' operator='eq' value='lux_renewaldate' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                {
                    if ((RenewalDate - InceptionDate).Days < 364 || (RenewalDate - InceptionDate).Days > 540)
                    {
                        var FieldName1 = "Renewal Date";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_renewaldate";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_renewaldate"];
                        refer["lux_additionalinfo"] = "ARAG: PERIOD OF INSURANCES BOUND: 12 months(plus odd time not exceeding 18 months in total)";
                        service.Create(refer);
                    }
                }
                else
                {
                    if ((RenewalDate - InceptionDate).Days >= 364 && (RenewalDate - InceptionDate).Days <= 540)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch2)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_inceptiondate"))
            {
                var fetch3 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_referral'>
                                            <attribute name='lux_suppliedvalue' />
                                            <attribute name='lux_fieldname' />
                                            <attribute name='lux_approve' />
                                            <attribute name='lux_additionalinfo' />
                                            <attribute name='lux_referralid' />
                                            <order attribute='lux_suppliedvalue' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                              <condition attribute='lux_fieldschemaname' operator='eq' value='lux_inceptiondate' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch3)).Entities.Count == 0)
                {
                    if ((InceptionDate - DateTime.Now).Days > 60)
                    {
                        var FieldName1 = "Renewal Date";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_inceptiondate";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_inceptiondate"];
                        refer["lux_additionalinfo"] = "ARAG: MAXIMUM ADVANCE PERIOD FOR INCEPTION DATES: 60 days";
                        service.Create(refer);
                    }
                }
                else
                {
                    if ((InceptionDate - DateTime.Now).Days <= 60)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch3)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_icow"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_icow' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_icow").Value > 100000)
                    {
                        var FieldName1 = "Increased cost of working";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_icow";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_icow"];
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_icow").Value <= 100000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<Money>("lux_icow").Value > 100000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_icow"];
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_additionalincreasedcostofworking"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_additionalincreasedcostofworking' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_additionalincreasedcostofworking").Value > 100000)
                    {
                        var FieldName1 = "Additional increased cost of working";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_additionalincreasedcostofworking";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_additionalincreasedcostofworking"];
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_additionalincreasedcostofworking").Value <= 100000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<Money>("lux_additionalincreasedcostofworking").Value > 100000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_additionalincreasedcostofworking"];
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_bookdebts"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_bookdebts' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_bookdebts").Value > 100000)
                    {
                        var FieldName1 = "Book Debts";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_bookdebts";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_bookdebts"];
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_bookdebts").Value <= 100000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (appln.GetAttributeValue<Money>("lux_bookdebts").Value > 100000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_bookdebts"];
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_insuredtitle"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_insuredtitle' />
                                    </filter>
                                  </entity>
                                </fetch>";

                var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_policy'>
                                    <attribute name='createdon' />
                                    <attribute name='lux_product' />
                                    <attribute name='lux_policyholder' />
                                    <attribute name='lux_policystartdate' />
                                    <attribute name='lux_name' />
                                    <attribute name='lux_policynumber' />
                                    <attribute name='lux_policyid' />
                                    <order attribute='createdon' descending='true' />
                                    <filter type='and'>
                                      <condition attribute='statuscode' operator='in'>
                                        <value>972970000</value>
                                        <value>1</value>
                                        <value>972970002</value>
                                      </condition>
                                      <condition attribute='lux_name' operator='like' value='%{appln.Attributes["lux_insuredtitle"].ToString().Replace("&", "&amp;").Replace("'", "&apos;").Replace("\"", " &quot;")}%' />
                                    </filter>
                                    <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplication' visible='false' link-type='outer' alias='poa'>
                                      <attribute name='lux_quotenumber' />
                                    </link-entity>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0 && appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                    {
                        var FieldName1 = "Insured Name";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_insuredtitle";
                        refer["lux_suppliedvalue"] = appln.Attributes["lux_insuredtitle"].ToString();
                        refer["lux_additionalinfo"] = "Insured Name already exist for Bound Quote: " + service.RetrieveMultiple(new FetchExpression(fetch1)).Entities[0].GetAttributeValue<AliasedValue>("poa.lux_quotenumber").Value.ToString();
                        service.Create(refer);
                    }
                }
                else
                {
                    if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count == 0 || appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value != 972970001)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_insuredtitle"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_insuredtitle' />
                                    </filter>
                                  </entity>
                                </fetch>";

                var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_propertyownersapplications'>
                                    <attribute name='lux_name' />
                                    <attribute name='createdon' />
                                    <attribute name='lux_postcode' />
                                    <attribute name='lux_insuredtitle' />
                                    <attribute name='lux_quotenumber' />
                                    <attribute name='statuscode' />
                                    <attribute name='lux_inceptiondate' />
                                    <attribute name='lux_broker' />
                                    <attribute name='lux_quotedpremium' />
                                    <attribute name='lux_producttype' />
                                    <attribute name='lux_propertyownersapplicationsid' />
                                    <order attribute='createdon' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_insuredtitle' operator='like' value='%{appln.Attributes["lux_insuredtitle"].ToString().Replace("&", "&amp;").Replace("'", "&apos;").Replace("\"", " &quot;")}%' />
                                      <condition attribute='lux_applicationtype' operator='not-in'>
                                        <value>972970003</value>
                                        <value>972970002</value>
                                      </condition>
                                      <condition attribute='lux_propertyownersapplicationsid' operator='ne' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0 && appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                    {
                        var FieldName1 = "Duplicate title match";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_insuredtitle";
                        refer["lux_suppliedvalue"] = appln.Attributes["lux_insuredtitle"].ToString();
                        refer["lux_additionalinfo"] = "Insured Name already exist for Quote: " + service.RetrieveMultiple(new FetchExpression(fetch1)).Entities[0].GetAttributeValue<string>("lux_quotenumber").ToString();
                        service.Create(refer);
                    }
                }
                else
                {
                    if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count == 0 || appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value != 972970001)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }

            Guid Trade = new Guid();
            int MDBI = 0;
            int Products = 0;
            int EL = 0;
            int WorkAway = 0;
            int Theift = 0;

            var MDBIAction = "";
            var ProductsAction = "";
            var ELAction = "";
            var WorkAwayAction = "";
            var TheiftAction = "";
            if (appln.Attributes.Contains("lux_maintradeforthispremises"))
            {
                bool Terrorism = appln.Attributes.Contains("lux_isterrorismcoverrequired") ? appln.GetAttributeValue<bool>("lux_isterrorismcoverrequired") : false;
                var tradeName = appln.FormattedValues["lux_maintradeforthispremises"].ToString();
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_maintradeforthispremises' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (Terrorism == true && (tradeName.Contains("Church") || tradeName.Contains("Convents") || tradeName.Contains("Monasteries") || tradeName.Contains("Mosque") || tradeName.Contains("Religion") || tradeName.Contains("Synagogue") || tradeName.Contains("Gunsmith")))
                    {
                        var FieldName1 = "Occupation";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_maintradeforthispremises";
                        refer["lux_suppliedvalue"] = tradeName;
                        service.Create(refer);
                    }
                }
                else
                {
                    if (Terrorism == false || !(tradeName.Contains("Church") || tradeName.Contains("Convents") || tradeName.Contains("Monasteries") || tradeName.Contains("Mosque") || tradeName.Contains("Religion") || tradeName.Contains("Synagogue") || tradeName.Contains("Gunsmith")))
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (Terrorism == true && (tradeName.Contains("Church") || tradeName.Contains("Convents") || tradeName.Contains("Monasteries") || tradeName.Contains("Mosque") || tradeName.Contains("Religion") || tradeName.Contains("Synagogue") || tradeName.Contains("Gunsmith")))
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = tradeName;
                        service.Update(reff);
                    }
                }

                Trade = appln.GetAttributeValue<EntityReference>("lux_maintradeforthispremises").Id;
                var ELCover = appln.GetAttributeValue<bool>("lux_iselcoverrequired");
                var WorkAwayCover = appln.GetAttributeValue<bool>("lux_isanyworkawaycarriedoutotherthanforcollec");

                var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_propertyownersrateid' operator='eq' uiname='' uitype='lux_propertyownersrate' value='{Trade}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                {
                    var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];
                    MDBI = FireData.GetAttributeValue<int>("lux_mdbi");
                    Products = FireData.GetAttributeValue<int>("lux_prods");
                    EL = FireData.GetAttributeValue<int>("lux_el");
                    WorkAway = FireData.GetAttributeValue<int>("lux_workaway");
                    Theift = FireData.GetAttributeValue<int>("lux_theft");
                }

                var HazardFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_hazardgrouplogic'>
                                                <attribute name='lux_name' />
                                                <attribute name='createdon' />
                                                <attribute name='lux_producttype' />
                                                <attribute name='lux_action' />
                                                <attribute name='lux_hazardgrouplogicid' />
                                                <order attribute='lux_name' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                </filter>
                                              </entity>
                                            </fetch>";
                if (service.RetrieveMultiple(new FetchExpression(HazardFetch)).Entities.Count > 0)
                {
                    var records = service.RetrieveMultiple(new FetchExpression(HazardFetch)).Entities;
                    if (MDBI > 0 && MDBI < 8)
                        MDBIAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == MDBI.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970001))).FormattedValues["lux_action"];
                    if (Products > 0 && Products < 8)
                        ProductsAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == Products.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970002))).FormattedValues["lux_action"];
                    if (EL > 0 && EL < 8)
                        ELAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == EL.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970003))).FormattedValues["lux_action"];
                    if (WorkAway > 0 && WorkAway < 8)
                        WorkAwayAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == WorkAway.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970004))).FormattedValues["lux_action"];
                    if (Theift > 0 && Theift < 8)
                        TheiftAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == Theift.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970005))).FormattedValues["lux_action"];

                    if (appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                    {
                        if (MDBI == 5)
                        {
                            MDBIAction = "Proceed to Quote";
                        }
                    }

                    if (MDBI >= 6)
                    {
                        MDBIAction = "Decline";
                    }
                    if (Products >= 6)
                    {
                        ProductsAction = "Decline";
                    }
                    if (EL >= 6)
                    {
                        ELAction = "Decline";
                    }
                    if (WorkAway >= 7)
                    {
                        WorkAwayAction = "Decline";
                    }
                    if (Theift >= 6)
                    {
                        TheiftAction = "Decline";
                    }
                }

                Entity application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());

                application["lux_mdbihazardgroup"] = MDBI;
                application["lux_workawayhazardgroup"] = WorkAway;
                application["lux_thefthazardgroup"] = Theift;
                application["lux_mdbiaction"] = MDBIAction;
                application["lux_workawayaction"] = WorkAwayAction;
                application["lux_theftaction"] = TheiftAction;
                application["lux_elhazardgroup"] = EL;
                application["lux_elaction"] = ELAction;
                application["lux_plproductshazardgroup"] = Products;
                application["lux_plproductsaction"] = ProductsAction;
                service.Update(application);

                if (MDBIAction == "Decline" || MDBIAction == "Refer to Underwriter")
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='mdbiaction' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                    {
                        var FieldName1 = "MD/BI Hazard Group";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "mdbiaction";
                        refer["lux_suppliedvalue"] = MDBI.ToString();
                        refer["lux_additionalinfo"] = MDBIAction;
                        if (MDBIAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Create(refer);
                    }
                    else
                    {
                        var refer = service.Retrieve("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch2)).Entities[0].Id, new ColumnSet(true));
                        refer["lux_suppliedvalue"] = MDBI.ToString();
                        refer["lux_additionalinfo"] = MDBIAction;
                        if (MDBIAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Update(refer);
                    }
                }
                else
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='mdbiaction' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count > 0)
                    {
                        foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch2)).Entities)
                        {
                            if (item1.GetAttributeValue<bool>("lux_approve") != true)
                            {
                                service.Delete("lux_referral", item1.Id);
                            }
                        }
                    }
                }

                if ((ELAction == "Decline" || ELAction == "Refer to Underwriter") && ELCover == true)
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='elaction' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                    {
                        var FieldName1 = "EL Hazard Group";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "elaction";
                        refer["lux_suppliedvalue"] = EL.ToString();
                        refer["lux_additionalinfo"] = ELAction;
                        if (ELAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Create(refer);
                    }
                    else
                    {
                        var refer = service.Retrieve("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch2)).Entities[0].Id, new ColumnSet(true));
                        refer["lux_suppliedvalue"] = EL.ToString();
                        refer["lux_additionalinfo"] = ELAction;
                        if (ELAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Update(refer);
                    }
                }
                else
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='elaction' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count > 0)
                    {
                        foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch2)).Entities)
                        {
                            if (item1.GetAttributeValue<bool>("lux_approve") != true)
                            {
                                service.Delete("lux_referral", item1.Id);
                            }
                        }
                    }
                }

                if (ProductsAction == "Decline" || ProductsAction == "Refer to Underwriter")
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='productsaction' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                    {
                        var FieldName1 = "PL/Products Hazard Group";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "productsaction";
                        refer["lux_suppliedvalue"] = Products.ToString();
                        refer["lux_additionalinfo"] = ProductsAction;
                        if (ProductsAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Create(refer);
                    }
                    else
                    {
                        var refer = service.Retrieve("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch2)).Entities[0].Id, new ColumnSet(true));
                        refer["lux_suppliedvalue"] = Products.ToString();
                        refer["lux_additionalinfo"] = ProductsAction;
                        if (ProductsAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Update(refer);
                    }
                }
                else
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='productsaction' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count > 0)
                    {
                        foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch2)).Entities)
                        {
                            if (item1.GetAttributeValue<bool>("lux_approve") != true)
                            {
                                service.Delete("lux_referral", item1.Id);
                            }
                        }
                    }
                }

                if ((WorkAwayAction == "Decline" || WorkAwayAction == "Refer to Underwriter") && WorkAwayCover == true)
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='workawayaction' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                    {
                        var FieldName1 = "Work Away Hazard Group";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "workawayaction";
                        refer["lux_suppliedvalue"] = WorkAway.ToString();
                        refer["lux_additionalinfo"] = WorkAwayAction;
                        if (WorkAwayAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Create(refer);
                    }
                    else
                    {
                        var refer = service.Retrieve("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch2)).Entities[0].Id, new ColumnSet(true));
                        refer["lux_suppliedvalue"] = WorkAway.ToString();
                        refer["lux_additionalinfo"] = WorkAwayAction;
                        if (WorkAwayAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Update(refer);
                    }
                }
                else
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='workawayaction' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count > 0)
                    {
                        foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch2)).Entities)
                        {
                            if (item1.GetAttributeValue<bool>("lux_approve") != true)
                            {
                                service.Delete("lux_referral", item1.Id);
                            }
                        }
                    }
                }

                if (TheiftAction == "Decline" || TheiftAction == "Refer to Underwriter")
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='theftaction' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                    {
                        var FieldName1 = "Theft Hazard Group";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "theftaction";
                        refer["lux_suppliedvalue"] = Theift.ToString();
                        refer["lux_additionalinfo"] = TheiftAction;
                        if (TheiftAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Create(refer);
                    }
                    else
                    {
                        var refer = service.Retrieve("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch2)).Entities[0].Id, new ColumnSet(true));
                        refer["lux_suppliedvalue"] = Theift.ToString();
                        refer["lux_additionalinfo"] = TheiftAction;
                        if (TheiftAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Update(refer);
                    }
                }
                else
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='theftaction' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count > 0)
                    {
                        foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch2)).Entities)
                        {
                            if (item1.GetAttributeValue<bool>("lux_approve") != true)
                            {
                                service.Delete("lux_referral", item1.Id);
                            }
                        }
                    }
                }
            }

            if (appln.Attributes.Contains("lux_secondarytradeofthebusiness"))
            {
                bool Terrorism = appln.Attributes.Contains("lux_isterrorismcoverrequired") ? appln.GetAttributeValue<bool>("lux_isterrorismcoverrequired") : false;
                var tradeName = appln.FormattedValues["lux_secondarytradeofthebusiness"].ToString();
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_secondarytradeofthebusiness' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (Terrorism == true && (tradeName.Contains("Church") || tradeName.Contains("Convents") || tradeName.Contains("Monasteries") || tradeName.Contains("Mosque") || tradeName.Contains("Religion") || tradeName.Contains("Synagogue") || tradeName.Contains("Gunsmith")))
                    {
                        var FieldName1 = "Occupation";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_secondarytradeofthebusiness";
                        refer["lux_suppliedvalue"] = tradeName;
                        service.Create(refer);
                    }
                }
                else
                {
                    if (Terrorism == false || !(tradeName.Contains("Church") || tradeName.Contains("Convents") || tradeName.Contains("Monasteries") || tradeName.Contains("Mosque") || tradeName.Contains("Religion") || tradeName.Contains("Synagogue") || tradeName.Contains("Gunsmith")))
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (Terrorism == true && (tradeName.Contains("Church") || tradeName.Contains("Convents") || tradeName.Contains("Monasteries") || tradeName.Contains("Mosque") || tradeName.Contains("Religion") || tradeName.Contains("Synagogue") || tradeName.Contains("Gunsmith")))
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = tradeName;
                        service.Update(reff);
                    }
                }

                Trade = appln.GetAttributeValue<EntityReference>("lux_secondarytradeofthebusiness").Id;
                var ELCover = appln.GetAttributeValue<bool>("lux_iselcoverrequired");
                var WorkAwayCover = appln.GetAttributeValue<bool>("lux_isanyworkawaycarriedoutotherthanforcollec");

                var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_propertyownersrateid' operator='eq' uiname='' uitype='lux_propertyownersrate' value='{Trade}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                {
                    var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];
                    MDBI = FireData.GetAttributeValue<int>("lux_mdbi");
                    Products = FireData.GetAttributeValue<int>("lux_prods");
                    EL = FireData.GetAttributeValue<int>("lux_el");
                    WorkAway = FireData.GetAttributeValue<int>("lux_workaway");
                    Theift = FireData.GetAttributeValue<int>("lux_theft");
                }

                var HazardFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_hazardgrouplogic'>
                                                <attribute name='lux_name' />
                                                <attribute name='createdon' />
                                                <attribute name='lux_producttype' />
                                                <attribute name='lux_action' />
                                                <attribute name='lux_hazardgrouplogicid' />
                                                <order attribute='lux_name' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                </filter>
                                              </entity>
                                            </fetch>";
                if (service.RetrieveMultiple(new FetchExpression(HazardFetch)).Entities.Count > 0)
                {
                    var records = service.RetrieveMultiple(new FetchExpression(HazardFetch)).Entities;
                    if (MDBI > 0 && MDBI < 8)
                        MDBIAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == MDBI.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970001))).FormattedValues["lux_action"];
                    if (Products > 0 && Products < 8)
                        ProductsAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == Products.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970002))).FormattedValues["lux_action"];
                    if (EL > 0 && EL < 8)
                        ELAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == EL.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970003))).FormattedValues["lux_action"];
                    if (WorkAway > 0 && WorkAway < 8)
                        WorkAwayAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == WorkAway.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970004))).FormattedValues["lux_action"];
                    if (Theift > 0 && Theift < 8)
                        TheiftAction = records.FirstOrDefault(x => x.Attributes["lux_name"].ToString() == Theift.ToString() && x.GetAttributeValue<OptionSetValueCollection>("lux_producttype").Contains(new OptionSetValue(972970005))).FormattedValues["lux_action"];

                    if (appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                    {
                        if (MDBI == 5)
                        {
                            MDBIAction = "Proceed to Quote";
                        }
                    }

                    if (MDBI >= 6)
                    {
                        MDBIAction = "Decline";
                    }
                    if (Products >= 6)
                    {
                        ProductsAction = "Decline";
                    }
                    if (EL >= 6)
                    {
                        ELAction = "Decline";
                    }
                    if (WorkAway >= 7)
                    {
                        WorkAwayAction = "Decline";
                    }
                    if (Theift >= 6)
                    {
                        TheiftAction = "Decline";
                    }
                }

                Entity application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());

                application["lux_mdbihazardgroup"] = MDBI;
                application["lux_workawayhazardgroup"] = WorkAway;
                application["lux_thefthazardgroup"] = Theift;
                application["lux_mdbiaction"] = MDBIAction;
                application["lux_workawayaction"] = WorkAwayAction;
                application["lux_theftaction"] = TheiftAction;
                application["lux_elhazardgroup"] = EL;
                application["lux_elaction"] = ELAction;
                application["lux_plproductshazardgroup"] = Products;
                application["lux_plproductsaction"] = ProductsAction;
                service.Update(application);

                if (MDBIAction == "Decline" || MDBIAction == "Refer to Underwriter")
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='mdbiaction1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                    {
                        var FieldName1 = "MD/BI Hazard Group";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "mdbiaction1";
                        refer["lux_suppliedvalue"] = MDBI.ToString();
                        refer["lux_additionalinfo"] = MDBIAction;
                        if (MDBIAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Create(refer);
                    }
                    else
                    {
                        var refer = service.Retrieve("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch2)).Entities[0].Id, new ColumnSet(true));
                        refer["lux_suppliedvalue"] = MDBI.ToString();
                        refer["lux_additionalinfo"] = MDBIAction;
                        if (MDBIAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Update(refer);
                    }
                }
                else
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='mdbiaction1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count > 0)
                    {
                        foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch2)).Entities)
                        {
                            if (item1.GetAttributeValue<bool>("lux_approve") != true)
                            {
                                service.Delete("lux_referral", item1.Id);
                            }
                        }
                    }
                }

                if ((ELAction == "Decline" || ELAction == "Refer to Underwriter") && ELCover == true)
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='elaction1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                    {
                        var FieldName1 = "EL Hazard Group";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "elaction1";
                        refer["lux_suppliedvalue"] = EL.ToString();
                        refer["lux_additionalinfo"] = ELAction;
                        if (ELAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Create(refer);
                    }
                    else
                    {
                        var refer = service.Retrieve("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch2)).Entities[0].Id, new ColumnSet(true));
                        refer["lux_suppliedvalue"] = EL.ToString();
                        refer["lux_additionalinfo"] = ELAction;
                        if (ELAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Update(refer);
                    }
                }
                else
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='elaction1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count > 0)
                    {
                        foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch2)).Entities)
                        {
                            if (item1.GetAttributeValue<bool>("lux_approve") != true)
                            {
                                service.Delete("lux_referral", item1.Id);
                            }
                        }
                    }
                }

                if (ProductsAction == "Decline" || ProductsAction == "Refer to Underwriter")
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='productsaction1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                    {
                        var FieldName1 = "PL/Products Hazard Group";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "productsaction1";
                        refer["lux_suppliedvalue"] = Products.ToString();
                        refer["lux_additionalinfo"] = ProductsAction;
                        if (ProductsAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Create(refer);
                    }
                    else
                    {
                        var refer = service.Retrieve("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch2)).Entities[0].Id, new ColumnSet(true));
                        refer["lux_suppliedvalue"] = Products.ToString();
                        refer["lux_additionalinfo"] = ProductsAction;
                        if (ProductsAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Update(refer);
                    }
                }
                else
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='productsaction1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count > 0)
                    {
                        foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch2)).Entities)
                        {
                            if (item1.GetAttributeValue<bool>("lux_approve") != true)
                            {
                                service.Delete("lux_referral", item1.Id);
                            }
                        }
                    }
                }

                if ((WorkAwayAction == "Decline" || WorkAwayAction == "Refer to Underwriter") && WorkAwayCover == true)
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='workawayaction1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                    {
                        var FieldName1 = "Work Away Hazard Group";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "workawayaction1";
                        refer["lux_suppliedvalue"] = WorkAway.ToString();
                        refer["lux_additionalinfo"] = WorkAwayAction;
                        if (WorkAwayAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Create(refer);
                    }
                    else
                    {
                        var refer = service.Retrieve("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch2)).Entities[0].Id, new ColumnSet(true));
                        refer["lux_suppliedvalue"] = WorkAway.ToString();
                        refer["lux_additionalinfo"] = WorkAwayAction;
                        if (WorkAwayAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Update(refer);
                    }
                }
                else
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='workawayaction1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count > 0)
                    {
                        foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch2)).Entities)
                        {
                            if (item1.GetAttributeValue<bool>("lux_approve") != true)
                            {
                                service.Delete("lux_referral", item1.Id);
                            }
                        }
                    }
                }

                if (TheiftAction == "Decline" || TheiftAction == "Refer to Underwriter")
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='theftaction1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                    {
                        var FieldName1 = "Theft Hazard Group";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "theftaction1";
                        refer["lux_suppliedvalue"] = Theift.ToString();
                        refer["lux_additionalinfo"] = TheiftAction;
                        if (TheiftAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Create(refer);
                    }
                    else
                    {
                        var refer = service.Retrieve("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch2)).Entities[0].Id, new ColumnSet(true));
                        refer["lux_suppliedvalue"] = Theift.ToString();
                        refer["lux_additionalinfo"] = TheiftAction;
                        if (TheiftAction == "Decline")
                            refer["lux_declined"] = true;
                        else
                            refer["lux_declined"] = false;
                        service.Update(refer);
                    }
                }
                else
                {
                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='theftaction1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count > 0)
                    {
                        foreach (var item1 in service.RetrieveMultiple(new FetchExpression(fetch2)).Entities)
                        {
                            if (item1.GetAttributeValue<bool>("lux_approve") != true)
                            {
                                service.Delete("lux_referral", item1.Id);
                            }
                        }
                    }
                }
            }

            if (appln.Attributes.Contains("lux_whoisthepreviousinsurer"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_whoisthepreviousinsurer' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<OptionSetValue>("lux_whoisthepreviousinsurer").Value == 972970008)
                    {
                        var FieldName1 = "Existing insurer";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_whoisthepreviousinsurer";
                        refer["lux_suppliedvalue"] = "Tokio Marine";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<OptionSetValue>("lux_whoisthepreviousinsurer").Value != 972970008)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true)
                            {
                                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                            }
                        }
                    }
                }
            }

            if (appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
            {
                if (appln.Attributes.Contains("lux_businessdescription"))
                {
                    var primaryTrade = appln.Attributes.Contains("lux_maintradeforthispremises") ? appln.FormattedValues["lux_maintradeforthispremises"].ToString().Trim() : "";

                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_businessdescription' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                    {
                        if (primaryTrade != "" && primaryTrade != appln.Attributes["lux_businessdescription"].ToString().Trim())
                        {
                            var FieldName1 = "Business Description";

                            Entity refer = new Entity("lux_referral");
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_businessdescription";
                            refer["lux_additionalinfo"] = "Business Description difference";
                            refer["lux_suppliedvalue"] = appln.Attributes["lux_businessdescription"].ToString().Trim();
                            service.Create(refer);
                        }
                    }
                    else
                    {
                        if (primaryTrade == "" || primaryTrade == appln.Attributes["lux_businessdescription"].ToString().Trim())
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                            foreach (var item in reff)
                            {
                                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                            }
                        }
                        else if (primaryTrade != "" && primaryTrade != appln.Attributes["lux_businessdescription"].ToString().Trim())
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            reff["lux_suppliedvalue"] = appln.Attributes["lux_businessdescription"].ToString().Trim();
                            reff["lux_additionalinfo"] = "Business Description difference";
                            service.Update(reff);
                        }
                    }
                }

                var BrokernotesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='lux_note'>
                                        <attribute name='createdon' />
                                        <attribute name='lux_subject' />
                                        <attribute name='lux_notetext' />
                                        <attribute name='lux_addedby' />
                                        <attribute name='lux_noteid' />
                                        <order attribute='createdon' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='statecode' operator='eq' value='0' />
                                          <condition attribute='lux_regardingapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                        </filter>
                                      </entity>
                                    </fetch>";

                var CommentsFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_usercomment'>
                                            <attribute name='createdon' />
                                            <attribute name='lux_portaluser' />
                                            <attribute name='lux_comment' />
                                            <attribute name='lux_usercommentid' />
                                            <order attribute='createdon' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_application' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_brokernotes' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                {
                    if (service.RetrieveMultiple(new FetchExpression(BrokernotesFetch)).Entities.Count > 0 || service.RetrieveMultiple(new FetchExpression(CommentsFetch)).Entities.Count > 0)
                    {
                        var FieldName1 = "Broker Notes – Reason – See brokers Notes";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", appln.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_brokernotes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (service.RetrieveMultiple(new FetchExpression(BrokernotesFetch)).Entities.Count == 0 && service.RetrieveMultiple(new FetchExpression(CommentsFetch)).Entities.Count == 0)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch2)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }

            if (InceptionDate >= new DateTime(2024, 01, 01))
            {
                if (appln.Attributes.Contains("lux_pllimitofindemnity"))
                {
                    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_pllimitofindemnity' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                    {
                        if (appln.GetAttributeValue<OptionSetValue>("lux_pllimitofindemnity").Value == 972970003)
                        {
                            var FieldName1 = "PL/Products limit of indemnity";
                            Entity refer = new Entity("lux_referral");
                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnref.Id);
                            refer["lux_fieldname"] = FieldName1;
                            refer["lux_fieldschemaname"] = "lux_pllimitofindemnity";
                            refer["lux_suppliedvalue"] = appln.FormattedValues["lux_pllimitofindemnity"];
                            service.Create(refer);
                        }
                    }
                    else
                    {
                        if (appln.GetAttributeValue<OptionSetValue>("lux_pllimitofindemnity").Value != 972970003)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                        }
                        else if (appln.GetAttributeValue<OptionSetValue>("lux_pllimitofindemnity").Value == 972970003)
                        {
                            var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                            reff["lux_suppliedvalue"] = appln.FormattedValues["lux_pllimitofindemnity"];
                            service.Update(reff);
                        }
                    }
                }
            }

            if (appln.Attributes.Contains("lux_isbindertemplatemanuallyamended") && (appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001 || appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isbindertemplatemanuallyamended' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_isbindertemplatemanuallyamended") == true)
                    {
                        var FieldName1 = "Insurer selection";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", appln.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_isbindertemplatemanuallyamended";
                        if (appln.FormattedValues["lux_bindertemplate"].ToString() == "HCC")
                        {
                            refer["lux_additionalinfo"] = "Default Template: HCC + AXIS";
                        }
                        else
                        {
                            refer["lux_additionalinfo"] = "Default Template: HCC";
                        }

                        refer["lux_suppliedvalue"] = "Template Selected: " + appln.FormattedValues["lux_bindertemplate"].ToString();
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_isbindertemplatemanuallyamended") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
        }
    }
}
