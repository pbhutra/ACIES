﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System.Activities;
using System.Linq;

namespace CustomWorkflows
{
    public class SetTerrorismPremiseOccupancyType : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_terrorismpremise'>
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_totalnumberofcommercialoccupantsatthisadd' />
                                <attribute name='lux_commercialoccupant1' />
                                <attribute name='lux_commercialoccupant2' />
                                <attribute name='lux_commercialoccupant3' />
                                <attribute name='lux_commercialoccupant4' />
                                <attribute name='lux_commercialoccupant5' />
                                <attribute name='lux_commercialoccupant6' />
                                <attribute name='lux_commercialoccupant7' />
                                <attribute name='lux_commercialoccupant8' />
                                <attribute name='lux_commercialoccupant9' />
                                <attribute name='lux_commercialoccupant10' />
                                <attribute name='lux_commercialoccupant11' />
                                <attribute name='lux_commercialoccupant12' />
                                <attribute name='lux_commercialoccupant13' />
                                <attribute name='lux_commercialoccupant14' />
                                <attribute name='lux_commercialoccupant15' />
                                <attribute name='lux_commercialoccupant16' />
                                <attribute name='lux_commercialoccupant17' />
                                <attribute name='lux_commercialoccupant18' />
                                <attribute name='lux_commercialoccupant19' />
                                <attribute name='lux_commercialoccupant20' />
                                <attribute name='lux_terrorismpremiseid' />
                                <order attribute='lux_locationnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var CommTrade = "";
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    var CommercialTrades = "";

                    var numberofTrades = item.Attributes.Contains("lux_totalnumberofcommercialoccupantsatthisadd") ? item.GetAttributeValue<int>("lux_totalnumberofcommercialoccupantsatthisadd") : 0;
                    if (numberofTrades > 0)
                    {
                        for (int i = 1; i <= numberofTrades; i++)
                        {
                            var fieldName = "lux_commercialoccupant" + i;
                            if (CommTrade == "")
                            {
                                CommTrade = item.FormattedValues[fieldName];
                            }
                            else
                            {
                                if (!CommTrade.Contains(item.FormattedValues[fieldName]))
                                    CommTrade += ", " + item.FormattedValues[fieldName];
                            }

                            if (CommercialTrades == "")
                            {
                                CommercialTrades = item.FormattedValues[fieldName];
                            }
                            else
                            {
                                if (!CommercialTrades.Contains(item.FormattedValues[fieldName]))
                                    CommercialTrades += ", " + item.FormattedValues[fieldName];
                            }
                        }
                    }

                    var item1 = service.Retrieve("lux_terrorismpremise", item.Id, new ColumnSet(true));
                    item1["lux_terrorismoccupation"] = CommercialTrades;
                    service.Update(item1);
                }
                var item2 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                item2["lux_commercialtrades"] = CommTrade;
                service.Update(item2);
            }
        }
    }
}
