﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace CustomWorkflows
{
    public class CallFloodAPI : CodeActivity
    {
        [RequiredArgument]
        [Input("Postcode")]
        public InArgument<string> Postcode { get; set; }

        [RequiredArgument]
        [Input("Product")]
        public InArgument<string> Product { get; set; }

        [RequiredArgument]
        [Input("RecordID")]
        public InArgument<string> RecordID { get; set; }

        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var request = new RetrieveCurrentOrganizationRequest();
            var organzationResponse = (RetrieveCurrentOrganizationResponse)service.Execute(request);
            var uriString = organzationResponse.Detail.UrlName;

            EntityReference applnref = PropertyOwnersApplication.Get<EntityReference>(executionContext);
            Entity appln = new Entity(applnref.LogicalName, applnref.Id);
            appln = service.Retrieve("lux_propertyownersapplications", applnref.Id, new ColumnSet(true));

            var ProductName = Product.Get(executionContext).Trim();
            var schemaName = "";
            if (ProductName == "Property Owners" || ProductName == "Unoccupied")
            {
                schemaName = "lux_propertyownerspremise";
            }
            else if (ProductName == "Retail")
            {
                schemaName = "lux_propertyownersretail";
            }
            else if (ProductName == "Commercial Combined" || ProductName == "Office")
            {
                schemaName = "lux_commercialcombinedapplication";
            }
            else if (ProductName == "Pubs & Restaurants" || ProductName == "Hotels and Guesthouses")
            {
                schemaName = "lux_pubsrestaurantspropertyownersapplicatio";
            }

            var dictForApiParams = new Dictionary<string, string>();
            dictForApiParams.Add("postcode", Postcode.Get(executionContext).Trim());
            dictForApiParams.Add("product", schemaName);
            dictForApiParams.Add("PremiseId", RecordID.Get(executionContext).Trim());
            dictForApiParams.Add("ApplicationID", PropertyOwnersApplication.Get(executionContext).Id.ToString());

            var client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.BaseAddress = new Uri("https://msdynamicswebapi.azurewebsites.net/api/ACIES/GetFloodDataUpdated");

            if (uriString.ToLower().Contains("uat"))
            {
                client.BaseAddress = new Uri("https://msdynamicswebapi.azurewebsites.net/api/ACIES/GetFloodDataUpdatedSandbox");
            }

            var apiRequest = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress) { Content = new FormUrlEncodedContent(dictForApiParams) };
            var apiResponseString = ProcessWebResponse(client, apiRequest, tracingService);
            var apiResponse = apiResponseString.Result;
            tracingService.Trace(apiResponse);
        }

        public static async Task<string> ProcessWebResponse(HttpClient client, HttpRequestMessage apiRequest, ITracingService tracingService)
        {
            var reponseContentString = "";
            try
            {
                HttpResponseMessage apiResponse = await client.SendAsync(apiRequest);
                reponseContentString = await apiResponse.Content.ReadAsStringAsync();
            }
            catch (HttpRequestException ex)
            {
                tracingService.Trace(ex.Message + Environment.NewLine + ex.StackTrace);
            }
            tracingService.Trace(reponseContentString);
            return reponseContentString;
        }

        public string GetOptionSetTextUsingValue(string entityName, string fieldName, int optionSetValue, IOrganizationService service)
        {
            var attReq = new RetrieveAttributeRequest();
            attReq.EntityLogicalName = entityName;
            attReq.LogicalName = fieldName;
            attReq.RetrieveAsIfPublished = true;
            var attResponse = (RetrieveAttributeResponse)service.Execute(attReq);
            var attMetadata = (EnumAttributeMetadata)attResponse.AttributeMetadata;
            return attMetadata.OptionSet.Options.Where(x => x.Value == optionSetValue).FirstOrDefault().Label.UserLocalizedLabel.Label;
        }

        public IDictionary<int, string> GetGlobalOptionSetValues(IOrganizationService service, string optionSetLogicalName)
        {
            IDictionary<int, string> optionSet = new Dictionary<int, string>();
            if (string.IsNullOrEmpty(optionSetLogicalName))
                return null;
            var retrieveAttributeRequest = new RetrieveOptionSetRequest
            {
                Name = optionSetLogicalName
            };
            var retrieveAttributeResponse = (RetrieveOptionSetResponse)service.Execute(retrieveAttributeRequest);
            var retrievedPicklistAttributeMetadata = (OptionSetMetadata)retrieveAttributeResponse.OptionSetMetadata;
            for (int i = 0; i < retrievedPicklistAttributeMetadata.Options.Count(); i++)
            {
                optionSet.Add(new KeyValuePair<int, string>(retrievedPicklistAttributeMetadata.Options[i].Value.Value,
                    retrievedPicklistAttributeMetadata.Options[i].Label.LocalizedLabels[0].Label));
            }
            return optionSet;
        }

        public static string RetrieveAttributeDisplayName(string EntitySchemaName, string AttributeSchemaName, IOrganizationService service)
        {
            RetrieveAttributeRequest retrieveAttributeRequest = new RetrieveAttributeRequest
            {
                EntityLogicalName = EntitySchemaName,
                LogicalName = AttributeSchemaName,
                RetrieveAsIfPublished = true
            };
            RetrieveAttributeResponse retrieveAttributeResponse = (RetrieveAttributeResponse)service.Execute(retrieveAttributeRequest);
            AttributeMetadata retrievedAttributeMetadata = (AttributeMetadata)retrieveAttributeResponse.AttributeMetadata;
            return retrievedAttributeMetadata.DisplayName.UserLocalizedLabel.Label;
        }
    }
}