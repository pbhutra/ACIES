﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace CustomWorkflows
{
    public class CreateAXABDXRecordTerrorism : CodeActivity
    {
        [Input("Policy")]
        [ReferenceTarget("lux_constructionpolicy")]
        [RequiredArgument]
        public InArgument<EntityReference> Policy { get; set; }

        [Input("Application")]
        [ReferenceTarget("lux_constructionquotes")]
        [RequiredArgument]
        public InArgument<EntityReference> Application { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference policyref = Policy.Get<EntityReference>(executionContext);
            Entity policy = service.Retrieve("lux_constructionpolicy", policyref.Id, new ColumnSet(true));

            EntityReference applnref = Application.Get<EntityReference>(executionContext);
            Entity appln = service.Retrieve("lux_constructionquotes", applnref.Id, new ColumnSet(true));

            if (appln.GetAttributeValue<bool>("lux_isterrorismrequired") == true)
            {
                var TerrorismListFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_constructionterrorism'>
                                                    <attribute name='lux_zonepremiumexclipt' />
                                                    <attribute name='lux_previouszonesuminsured' />
                                                    <attribute name='lux_poolrezone' />
                                                    <attribute name='lux_newzonesuminsured' />
                                                    <attribute name='lux_firstpartofpostcodeofsiteaddress' />
                                                    <attribute name='lux_constructionterrorismid' />
                                                    <order attribute='lux_firstpartofpostcodeofsiteaddress' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_constructionquote' operator='eq' uiname='' uitype='lux_constructionquotes' value='{appln.Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                var TerrorismList = service.RetrieveMultiple(new FetchExpression(TerrorismListFetch));
                if (TerrorismList.Entities.Count() > 0)
                {
                    foreach (var item in TerrorismList.Entities)
                    {
                        Entity bdx = new Entity("lux_constructionterrorismbdx");
                        bdx["lux_constructionquote"] = new EntityReference("lux_constructionquotes", appln.Id);
                        bdx["lux_constructionpolicy"] = new EntityReference("lux_constructionpolicy", policy.Id);

                        bdx["lux_confirmedpurchasingpoolreterrorismcover"] = appln.Attributes.Contains("lux_confirmedpurchasingpoolreterrorismcover") ? appln.FormattedValues["lux_confirmedpurchasingpoolreterrorismcover"] : "No";


                        var NewZoneSI = item.Attributes.Contains("lux_newzonesuminsured") ? item.GetAttributeValue<Money>("lux_newzonesuminsured").Value : 0;
                        var PreviousZoneSI = item.Attributes.Contains("lux_previouszonesuminsured") ? item.GetAttributeValue<Money>("lux_previouszonesuminsured").Value : 0;

                        var NewBISI = appln.Attributes.Contains("lux_newbisuminsured") ? appln.GetAttributeValue<Money>("lux_newbisuminsured").Value : 0;
                        var PreviousBISI = appln.Attributes.Contains("lux_previousbisuminsured") ? appln.GetAttributeValue<Money>("lux_previousbisuminsured").Value : 0;

                        var ZonePremiumExIPT = item.Attributes.Contains("lux_zonepremiumexclipt") ? item.GetAttributeValue<Money>("lux_zonepremiumexclipt").Value : 0;
                        var BIPremiumExIPT = appln.Attributes.Contains("lux_bipremiumexclipt") ? appln.GetAttributeValue<Money>("lux_bipremiumexclipt").Value : 0;

                        var TerrorismBrokerComm = appln.Attributes.Contains("lux_terrorismcommissionpercentage") ? appln.GetAttributeValue<decimal>("lux_terrorismcommissionpercentage") : 0;
                        var TerrorismPSLComm = appln.Attributes.Contains("lux_terrorismcommission") ? appln.GetAttributeValue<decimal>("lux_terrorismcommission") : 0;

                        bdx["lux_terrorismzonead"] = item.FormattedValues["lux_poolrezone"];
                        bdx["lux_newzonesuminsured"] = new Money(NewZoneSI);
                        bdx["lux_previouszonesuminsured"] = new Money(PreviousZoneSI);

                        bdx["lux_newbisuminsured"] = new Money(NewBISI);
                        bdx["lux_previousbisuminsured"] = new Money(PreviousBISI);


                        bdx["lux_zonepremiumexclipt"] = new Money(ZonePremiumExIPT);
                        bdx["lux_bipremiumexclipt"] = new Money(BIPremiumExIPT);
                        bdx["lux_totalgrossterrorismpremiumexclipt"] = new Money(ZonePremiumExIPT + BIPremiumExIPT);
                        bdx["lux_ipt"] = new Money((ZonePremiumExIPT + BIPremiumExIPT) * 12 / 100);
                        bdx["lux_commissionamount"] = new Money((ZonePremiumExIPT + BIPremiumExIPT) * (TerrorismBrokerComm + TerrorismPSLComm) / 100);
                        bdx["lux_commission"] = (TerrorismBrokerComm + TerrorismPSLComm).ToString();

                        //bdx["lux_proratezonesuminsured"] = new Money((NewZoneSI - PreviousZoneSI) * Convert.ToInt32(appln.FormattedValues["lux_totaldurationindays"].Replace(",", "")) / 365);
                        //bdx["lux_proratebisuminsured"] = new Money((NewBISI - PreviousBISI) * Convert.ToInt32(appln.FormattedValues["lux_totaldurationindays"].Replace(",", "")) / 365);
                        //bdx["lux_premiumduetoaxa"] = new Money((ZonePremiumExIPT + BIPremiumExIPT) + ((ZonePremiumExIPT + BIPremiumExIPT) * 12 / 100) - ((ZonePremiumExIPT + BIPremiumExIPT) * (TerrorismBrokerComm + TerrorismPSLComm) / 100));
                        //bdx["lux_numberofdays"] = Convert.ToInt32(appln.FormattedValues["lux_totaldurationindays"].Replace(",", ""));

                        //if ((NewZoneSI - PreviousZoneSI) != 0)
                        //{
                        //    bdx["lux_zonerate"] = ZonePremiumExIPT / ((NewZoneSI - PreviousZoneSI) * Convert.ToInt32(appln.FormattedValues["lux_totaldurationindays"].Replace(",", "")) / 365);
                        //}
                        //else
                        //{
                        //    bdx["lux_zonerate"] = 0M;
                        //}

                        //if ((NewBISI - PreviousBISI) != 0)
                        //{
                        //    bdx["lux_birate"] = BIPremiumExIPT / ((NewBISI - PreviousBISI) * Convert.ToInt32(appln.FormattedValues["lux_totaldurationindays"].Replace(",", "")) / 365);
                        //}
                        //else
                        //{
                        //    bdx["lux_zonerate"] = 0M;
                        //}

                        var TerrorismInceptionDate = Convert.ToDateTime(appln.Attributes.Contains("lux_terrorismpolicyinceptiondate") == true ? appln.FormattedValues["lux_terrorismpolicyinceptiondate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        var TerrorismExpiryDate = Convert.ToDateTime(appln.Attributes.Contains("lux_terrorismpolicyexpirydate") == true ? appln.FormattedValues["lux_terrorismpolicyexpirydate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        var TotalDurationDays = (TerrorismExpiryDate - TerrorismInceptionDate).Days + 1;
                        if (TotalDurationDays == 364 || TotalDurationDays == 365 || TotalDurationDays == 366 || TotalDurationDays == 367)
                        {
                            TotalDurationDays = 365;
                        }

                        bdx["lux_proratezonesuminsured"] = new Money((NewZoneSI - PreviousZoneSI) * TotalDurationDays / 365);
                        bdx["lux_proratebisuminsured"] = new Money((NewBISI - PreviousBISI) * TotalDurationDays / 365);
                        bdx["lux_premiumduetoaxa"] = new Money((ZonePremiumExIPT + BIPremiumExIPT) - ((ZonePremiumExIPT + BIPremiumExIPT) * (TerrorismBrokerComm + TerrorismPSLComm) / 100));
                        bdx["lux_numberofdays"] = TotalDurationDays;

                        if ((NewZoneSI - PreviousZoneSI) != 0)
                        {
                            bdx["lux_zonerate"] = ZonePremiumExIPT / ((NewZoneSI - PreviousZoneSI) * TotalDurationDays / 365);
                        }
                        else
                        {
                            bdx["lux_zonerate"] = 0M;
                        }

                        if ((NewBISI - PreviousBISI) != 0)
                        {
                            bdx["lux_birate"] = BIPremiumExIPT / ((NewBISI - PreviousBISI) * TotalDurationDays / 365);
                        }
                        else
                        {
                            bdx["lux_zonerate"] = 0M;
                        }

                        bdx["lux_policynumber"] = policy.Attributes.Contains("lux_policynumber") ? policy.Attributes["lux_policynumber"].ToString() : "";
                        bdx["lux_product"] = appln.Attributes.Contains("lux_typeofpolicy2") ? appln.FormattedValues["lux_typeofpolicy2"] : "";

                        bdx["lux_inceptiondate"] = Convert.ToDateTime(appln.Attributes.Contains("lux_terrorismpolicyinceptiondate") == true ? appln.FormattedValues["lux_terrorismpolicyinceptiondate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                        bdx["lux_expirydate"] = Convert.ToDateTime(appln.Attributes.Contains("lux_terrorismpolicyexpirydate") == true ? appln.FormattedValues["lux_terrorismpolicyexpirydate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);


                        if (appln.FormattedValues["lux_applicationtype"] == "New Business")
                        {
                            bdx["lux_transactiontype"] = new OptionSetValue(972970001);
                            bdx["lux_witheffectdate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_entrydate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_reason"] = "New Business";
                        }
                        else if (appln.FormattedValues["lux_applicationtype"] == "Renewal")
                        {
                            bdx["lux_transactiontype"] = new OptionSetValue(972970002);
                            bdx["lux_witheffectdate"] = Convert.ToDateTime(policy.Attributes.Contains("lux_policystartdate") == true ? policy.FormattedValues["lux_policystartdate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_entrydate"] = Convert.ToDateTime(policy.Attributes.Contains("createdon") == true ? policy.FormattedValues["createdon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_reason"] = "Renewal";
                        }
                        else if (appln.FormattedValues["lux_applicationtype"] == "Cancellation")
                        {
                            bdx["lux_transactiontype"] = new OptionSetValue(972970003);
                            bdx["lux_witheffectdate"] = Convert.ToDateTime(appln.Attributes.Contains("lux_mtadate") == true ? appln.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_entrydate"] = Convert.ToDateTime(policy.Attributes.Contains("modifiedon") == true ? policy.FormattedValues["modifiedon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_reason"] = "Cancellation";
                        }
                        else if (appln.FormattedValues["lux_applicationtype"] == "MTA")
                        {
                            bdx["lux_transactiontype"] = new OptionSetValue(972970004);
                            bdx["lux_witheffectdate"] = Convert.ToDateTime(appln.Attributes.Contains("lux_mtadate") == true ? appln.FormattedValues["lux_mtadate"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_entrydate"] = Convert.ToDateTime(policy.Attributes.Contains("modifiedon") == true ? policy.FormattedValues["modifiedon"] : "", System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                            bdx["lux_reason"] = "MTA";
                        }


                        var fetch = $@"<fetch name='table1' relationshipname='lux_contact_lux_constructionquotes' mapping='logical'>
                             <entity name='contact'>                             
                                  <attribute name='address1_postalcode' />
                                  <attribute name='address1_line1' />
                                  <attribute name='address1_line2' />
                                  <attribute name='address1_line3' />
                                  <attribute name='address1_city' />
                                  <attribute name='createdon' />
                                  <attribute name='fullname' />
                                  <attribute name='lux_matchstatus' />
                                  <order attribute='createdon' descending='false' priority='1000' sorttype='datetime' />
                                  <link-entity relationshipname='MTOMFilter' name='lux_contact_lux_constructionquotes' from='contactid' visible='false' intersect='true'>
                                       <link-entity name='lux_constructionquotes' to='lux_constructionquotesid'>
                                            <filter type='and'>
                                                 <condition attribute='lux_constructionquotesid' operator='in'>
                                                      <value>{appln.Id}</value>
                                                 </condition>
                                            </filter>
                                       </link-entity>
                                  </link-entity>
                             </entity>
                        </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                        {
                            bdx["lux_clientname"] = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault().Attributes.Contains("fullname") ? service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault().Attributes["fullname"].ToString() : "";
                        }

                        if (appln.FormattedValues["lux_typeofpolicy1"] == "Single Project")
                        {
                            bdx["lux_riskaddressline1"] = appln.Attributes.Contains("lux_housenumber") ? appln.Attributes["lux_housenumber"].ToString() + ", " : "";
                            bdx["lux_riskaddressline2"] = appln.Attributes.Contains("lux_street") ? appln.Attributes["lux_street"].ToString() + ", " : "";
                            bdx["lux_riskaddressline3"] = "";
                            bdx["lux_riskaddressline4"] = appln.Attributes.Contains("lux_citycounty") ? appln.Attributes["lux_citycounty"].ToString() : "";
                            bdx["lux_postcode"] = appln.Attributes.Contains("lux_postcode") == true ? appln.Attributes["lux_postcode"].ToString() : "";
                        }
                        else
                        {
                            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
                            {
                                bdx["lux_riskaddressline1"] = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault().Attributes.Contains("address1_line1") ? service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault().Attributes["address1_line1"].ToString() : "";
                                bdx["lux_riskaddressline2"] = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault().Attributes.Contains("address1_line2") ? service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault().Attributes["address1_line2"].ToString() : "";
                                bdx["lux_riskaddressline3"] = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault().Attributes.Contains("address1_line3") ? service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault().Attributes["address1_line3"].ToString() : "";
                                bdx["lux_riskaddressline4"] = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault().Attributes.Contains("address1_city") ? service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault().Attributes["address1_city"].ToString() : "";
                                bdx["lux_postcode"] = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault().Attributes.Contains("address1_postalcode") ? service.RetrieveMultiple(new FetchExpression(fetch)).Entities.FirstOrDefault().Attributes["address1_postalcode"].ToString() : "";
                            }
                        }

                        service.Create(bdx);
                    }
                }
            }
        }
    }
}