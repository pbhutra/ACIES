﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Net;
using System.ServiceModel.Description;
using System.Linq;

namespace CustomWorkflows
{
    public class SaveReferralTriggersTradesman : CodeActivity
    {
        [Input("Tradesman Application")]
        [ReferenceTarget("lux_tradesman")]
        public InArgument<EntityReference> TradesmanApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference applnref = TradesmanApplication.Get<EntityReference>(executionContext);
            Entity appln = new Entity(applnref.LogicalName, applnref.Id);
            appln = service.Retrieve("lux_tradesman", applnref.Id, new ColumnSet(true));

            var InceptionDate = appln.GetAttributeValue<DateTime>("lux_inceptiondate");
            var RenewalDate = appln.GetAttributeValue<DateTime>("lux_renewaldate");

            if (appln.Attributes.Contains("lux_whatisyourtrade"))
            {
                var trade = service.Retrieve("lux_tradeprofession", appln.GetAttributeValue<EntityReference>("lux_whatisyourtrade").Id, new ColumnSet("lux_ratinggroup", "lux_name"));
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_whatisyourtrade' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (trade.GetAttributeValue<OptionSetValue>("lux_ratinggroup").Value == 972970001 || (trade.GetAttributeValue<OptionSetValue>("lux_ratinggroup").Value == 972970003 && !(trade.Attributes["lux_name"].ToString().Contains("Sign Installation/Erection") || trade.Attributes["lux_name"].ToString().Contains("Sign Writers") || trade.Attributes["lux_name"].ToString().Contains("Double Glazing") || trade.Attributes["lux_name"].ToString().Contains("Windows/Doors Installation") || trade.Attributes["lux_name"].ToString().Contains("Glazing Contractor"))) || trade.GetAttributeValue<OptionSetValue>("lux_ratinggroup").Value == 972970006 || trade.GetAttributeValue<OptionSetValue>("lux_ratinggroup").Value == 972970007)
                    {
                        var FieldName1 = "Rating Group";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_whatisyourtrade";
                        refer["lux_suppliedvalue"] = trade.FormattedValues["lux_ratinggroup"].ToString();
                        service.Create(refer);
                    }
                }
                else
                {
                    if (!(trade.GetAttributeValue<OptionSetValue>("lux_ratinggroup").Value == 972970001 || (trade.GetAttributeValue<OptionSetValue>("lux_ratinggroup").Value == 972970003 && !(trade.Attributes["lux_name"].ToString().Contains("Sign Installation/Erection") || trade.Attributes["lux_name"].ToString().Contains("Sign Writers") || trade.Attributes["lux_name"].ToString().Contains("Double Glazing") || trade.Attributes["lux_name"].ToString().Contains("Windows/Doors Installation") || trade.Attributes["lux_name"].ToString().Contains("Glazing Contractor"))) || trade.GetAttributeValue<OptionSetValue>("lux_ratinggroup").Value == 972970006 || trade.GetAttributeValue<OptionSetValue>("lux_ratinggroup").Value == 972970007))
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }

            //var FieldsToShow = "";
            //for (int i = 1; i <= 7; i++)
            //{
            //    var fieldName = "lux_generalquestion" + i;
            //    if (trade.Attributes.Contains(fieldName))
            //    {
            //        if (FieldsToShow == "")
            //            FieldsToShow = trade.Attributes[fieldName].ToString();
            //        else
            //            FieldsToShow += ", " + trade.Attributes[fieldName];
            //    }
            //}

            //if (InceptionDate >= new DateTime(2024, 01, 01))
            //{
            //    if (appln.Attributes.Contains("lux_iscontractorsallriskscoverrequired"))
            //    {
            //        var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            //                      <entity name='lux_referral'>
            //                        <attribute name='lux_suppliedvalue' />
            //                        <attribute name='lux_fieldname' />
            //                        <attribute name='lux_approve' />
            //                        <attribute name='lux_additionalinfo' />
            //                        <attribute name='lux_referralid' />
            //                        <order attribute='lux_suppliedvalue' descending='false' />
            //                        <filter type='and'>
            //                          <condition attribute='statecode' operator='eq' value='0' />
            //                          <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
            //                          <condition attribute='lux_fieldschemaname' operator='eq' value='lux_iscontractorsallriskscoverrequired' />
            //                        </filter>
            //                      </entity>
            //                    </fetch>";

            //        if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
            //        {
            //            if (appln.GetAttributeValue<bool>("lux_iscontractorsallriskscoverrequired") == true)
            //            {
            //                var FieldName1 = "CAR Cover";

            //                Entity refer = new Entity("lux_referral");
            //                refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", appln.Id);
            //                refer["lux_fieldname"] = FieldName1;
            //                refer["lux_fieldschemaname"] = "lux_iscontractorsallriskscoverrequired";
            //                refer["lux_suppliedvalue"] = "Yes";
            //                refer["lux_declined"] = true;
            //                refer["lux_additionalinfo"] = "CAR Risk Not Covered";
            //                service.Create(refer);
            //            }
            //        }
            //        else
            //        {
            //            if (appln.GetAttributeValue<bool>("lux_iscontractorsallriskscoverrequired") == false)
            //            {
            //                var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
            //                foreach (var item in reff)
            //                {
            //                    if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
            //                }
            //            }
            //        }
            //    }
            //}

            if (appln.Attributes.Contains("lux_youhaveatleast3yearsexperience"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_youhaveatleast3yearsexperience' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_youhaveatleast3yearsexperience") == false)
                    {
                        var FieldName1 = "Can you (the insured) confirm that you have at least 3 years’ experience within this trade/profession?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_youhaveatleast3yearsexperience";
                        refer["lux_suppliedvalue"] = "No";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_pleaseprovidedetailsofyourtheinsuredsexp") ? appln.Attributes["lux_pleaseprovidedetailsofyourtheinsuredsexp"].ToString() : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_youhaveatleast3yearsexperience") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_yourcompanyisdomiciledintheuk"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_yourcompanyisdomiciledintheuk' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_yourcompanyisdomiciledintheuk") == false)
                    {
                        var FieldName1 = "Can you (the insured) confirm your company is domiciled in the UK and does not undertake any work outside the UK?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_yourcompanyisdomiciledintheuk";
                        refer["lux_suppliedvalue"] = "No";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques3fulldetailsoflocation") ? appln.Attributes["lux_ques3fulldetailsoflocation"].ToString() : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_yourcompanyisdomiciledintheuk") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_isyourcompanydomiciledintheunitedkingdom"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isyourcompanydomiciledintheunitedkingdom' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_isyourcompanydomiciledintheunitedkingdom") == false)
                    {
                        var FieldName1 = "Is your company domiciled in the United Kingdom?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_isyourcompanydomiciledintheunitedkingdom";
                        refer["lux_suppliedvalue"] = "No";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_isyourcompanydomiciledintheunitedkingdom") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_noofemployees"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_noofemployees' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<int>("lux_noofemployees") >= 10)
                    {
                        var FieldName1 = "The total number of people working in business (including all partners, principals and proprietors)";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_noofemployees";
                        refer["lux_suppliedvalue"] = appln.GetAttributeValue<int>("lux_noofemployees").ToString();
                        refer["lux_additionalinfo"] = "Total number of employees exceeds the limit";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<int>("lux_noofemployees") <= 9)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_totalestimatedturnover"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_totalestimatedturnover' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<Money>("lux_totalestimatedturnover").Value >= 500000)
                    {
                        var FieldName1 = "What is the Total Estimated Turnover";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_totalestimatedturnover";
                        refer["lux_additionalinfo"] = "Total Estimated Turnover exceeds the limit";
                        refer["lux_suppliedvalue"] = appln.Contains("lux_totalestimatedturnover") ? appln.FormattedValues["lux_totalestimatedturnover"].ToString() : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<Money>("lux_totalestimatedturnover").Value < 500000)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doesnotincludeworkatheightsexceeding15mt"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doesnotincludeworkatheightsexceeding15mt' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doesnotincludeworkatheightsexceeding15mt") == false)
                    {
                        var FieldName1 = "Does not include work at heights exceeding 15 metres (or floor level when working internally of a building/premises) or depths exceeding 3 metres from ground level.";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doesnotincludeworkatheightsexceeding15mt";
                        refer["lux_suppliedvalue"] = "Disagree";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_doesnotincludeworkatheightsfurtherdetails") ? appln.Attributes["lux_doesnotincludeworkatheightsfurtherdetails"].ToString() : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doesnotincludeworkatheightsexceeding15mt") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_donotundertakeanyscaffoldingwork"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_donotundertakeanyscaffoldingwork' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_donotundertakeanyscaffoldingwork") == false)
                    {
                        var FieldName1 = "Do not undertake any scaffolding work (other than scaffolding towers to a maximum of 5 metres), other than when it’s solely undertaken and sub-contracted to Bone Fide Sub-Contractors only.";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_donotundertakeanyscaffoldingwork";
                        refer["lux_suppliedvalue"] = "Disagree";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_donotundertakeanyscaffoldingworkfurtherde") ? appln.Attributes["lux_donotundertakeanyscaffoldingworkfurtherde"].ToString() : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_donotundertakeanyscaffoldingwork") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_yourtradedoesnotcarryoutanyworks"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_yourtradedoesnotcarryoutanyworks' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_yourtradedoesnotcarryoutanyworks") == false)
                    {
                        var FieldName1 = "Does not carry out any works in, on or immediately adjacent to towers, steeples, chimney shafts, bridges, viaducts, motorways, flyovers, underpasses, airports, airside, railway, railway installations for conveyance of goods or people, power stations, oil refineries, gas/chemical/petrochemical plants, fuel depots, nuclear installations, collieries, mines, quarries, tunnels, ships, vessels, water-borne craft, docks, harbours, piers, jetties, dams, reservoirs, lakes, rivers, water diversions/canals, sea defences or offshore rigs/platforms/structures.";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_yourtradedoesnotcarryoutanyworks";
                        refer["lux_suppliedvalue"] = "Disagree";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_tradedoesnotcarryfurtherdetails") ? appln.Attributes["lux_tradedoesnotcarryfurtherdetails"].ToString() : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_yourtradedoesnotcarryoutanyworks") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doesnotgoairsideortrackside"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doesnotgoairsideortrackside' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doesnotgoairsideortrackside") == false)
                    {
                        var FieldName1 = "Does not go airside or trackside";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doesnotgoairsideortrackside";
                        refer["lux_suppliedvalue"] = "Disagree";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_doesnotgoairsidetracksidefurtherinformati") ? appln.Attributes["lux_doesnotgoairsidetracksidefurtherinformati"].ToString() : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doesnotgoairsideortrackside") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doesnotusehandlestoreortransport"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doesnotusehandlestoreortransport' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doesnotusehandlestoreortransport") == false)
                    {
                        var FieldName1 = "Does not use, handle, store or transport hazardous substances, such as; explosives, fumes or vapours, radioactive or toxic substances, asbestos or materials giving rise to dust.";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doesnotusehandlestoreortransport";
                        refer["lux_suppliedvalue"] = "Disagree";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_doesnotuseorhandlefurtherdetails") ? appln.Attributes["lux_doesnotuseorhandlefurtherdetails"].ToString() : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doesnotusehandlestoreortransport") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_beenconvictedoforhaveanypendingprosecutio"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_beenconvictedoforhaveanypendingprosecutio' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_beenconvictedoforhaveanypendingprosecutio") == false)
                    {
                        var FieldName1 = "Been convicted of or have any pending prosecutions other than motoring offences or offences which are spent under the Rehabilitation of Offenders Act 1974.";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_beenconvictedoforhaveanypendingprosecutio";
                        refer["lux_suppliedvalue"] = "Disagree";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_pleaseprovidefulldetailsincludingdates") ? appln.Attributes["lux_pleaseprovidefulldetailsincludingdates"].ToString() : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_beenconvictedoforhaveanypendingprosecutio") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_beendeclaredbankrupt"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_beendeclaredbankrupt' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_beendeclaredbankrupt") == false)
                    {
                        var FieldName1 = "Been declared bankrupt, insolvent or been the subject of bankruptcy proceedings, voluntary liquidations, a winding up/administration order, administrative receivership proceedings or a County Court Judgement (or the Scottish equivalent) within the last 10 years.";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_beendeclaredbankrupt";
                        refer["lux_suppliedvalue"] = "Disagree";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_beendeclaredbankruptfurtherdetails") ? appln.Attributes["lux_beendeclaredbankruptfurtherdetails"].ToString() : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_beendeclaredbankrupt") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_hadthehseorotherrelevant"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_hadthehseorotherrelevant' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_hadthehseorotherrelevant") == false)
                    {
                        var FieldName1 = "Had the HSE, or other relevant enforcing authority taken any formal enforcement actions against you, such as; Improvement Notices; Prohibition Notices or Formal court proceedings.";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_hadthehseorotherrelevant";
                        refer["lux_suppliedvalue"] = "Disagree";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_hadthehseorotherrelevantfurtherdetails") ? appln.Attributes["lux_hadthehseorotherrelevantfurtherdetails"].ToString() : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_hadthehseorotherrelevant") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_hadanyliabilityorcontractorsallriskclaims"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_hadanyliabilityorcontractorsallriskclaims' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_hadanyliabilityorcontractorsallriskclaims") == true)
                    {
                        var FieldName1 = "Have you(the insured) had any Liability or Contractors All Risk claims against you in the last five years or are you aware of any incidents that have occurred that could give rise to a claim against you ?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_hadanyliabilityorcontractorsallriskclaims";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_hadanyliabilityorcontractorsallriskclaims") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_hadaninsurancepolicycancelledrenewalrefus"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_hadaninsurancepolicycancelledrenewalrefus' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_hadaninsurancepolicycancelledrenewalrefus") == true)
                    {
                        var FieldName1 = "Have you (the insured) had an insurance policy cancelled, renewal refused or had special terms imposed by an insurer?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_hadaninsurancepolicycancelledrenewalrefus";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_hadaninsurancepolicycancelledrenewalrefus") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_currentlyhavealiabilitypolicywithhcc"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_currentlyhavealiabilitypolicywithhcc' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_currentlyhavealiabilitypolicywithhcc") == true)
                    {
                        var FieldName1 = "Do you currently have a Liability or Contractors All Risks policy with Faraday?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_currentlyhavealiabilitypolicywithhcc";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_currentlyhavealiabilitypolicywithhcc") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_undertakeanyworkotherthanshopinterior"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_undertakeanyworkotherthanshopinterior' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_undertakeanyworkotherthanshopinterior") == true)
                    {
                        var FieldName1 = "Do you undertake any works other than those in the following business description? Shop / Interior / office fit out including artexing, carpet fitting, ceiling, painting / decoration(excluding spray painting), dry lining, flooring, interior designing, internal mastic sealants, partitioning, plastering, tiling, carpentry and joinery.Associated general electrical work and small non-structural building works as part of an overall shop/interior/office fit out contract";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_undertakeanyworkotherthanshopinterior";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques12fulldetailsoflocation") ? appln.Attributes["lux_ques12fulldetailsoflocation"].ToString() : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_undertakeanyworkotherthanshopinterior") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouuseanyoxyacetyleneorweldingequipment"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouuseanyoxyacetyleneorweldingequipment' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouuseanyoxyacetyleneorweldingequipment") == true)
                    {
                        var FieldName1 = "Do you use any oxy acetylene or welding equipment?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouuseanyoxyacetyleneorweldingequipment";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_pleaseprovideanestimateofhowfrequentyouma") ? appln.Attributes["lux_pleaseprovideanestimateofhowfrequentyouma"] : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouuseanyoxyacetyleneorweldingequipment") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworkinvolvingtheexterior"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworkinvolvingtheexterior' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworkinvolvingtheexterior") == true)
                    {
                        var FieldName1 = "Do you undertake any work involving the exterior cladding of a building or installation of shop fronts?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworkinvolvingtheexterior";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques15fulldetailsoflocation") ? appln.Attributes["lux_ques15fulldetailsoflocation"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworkinvolvingtheexterior") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworksotherthanflooring"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworksotherthanflooring' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthanflooring") == true)
                    {
                        var FieldName1 = "Do you undertake any works other than those in the following business description? Flooring, tiling, flooring preparation, carpet laying, underlay, and floor restoration and staining excluding any excavation activities";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworksotherthanflooring";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques17fulldetailsoflocation") ? appln.Attributes["lux_ques17fulldetailsoflocation"] : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthanflooring") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanysportssurfaceorspecialis"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanysportssurfaceorspecialis' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanysportssurfaceorspecialis") == true)
                    {
                        var FieldName1 = "Do you undertake any sports surface or specialist/protective coatings work?";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanysportssurfaceorspecialis";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques18fulldetailsoflocation") ? appln.Attributes["lux_ques18fulldetailsoflocation"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanysportssurfaceorspecialis") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworksotherthancarpentry"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworksotherthancarpentry' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthancarpentry") == true)
                    {
                        var FieldName1 = "Do you undertake any works other than those in the following business description? Carpentry / Joinery contractor(installation, repair and supply only).Associated painting / decoration(excluding spray painting) and small non - structural building works as part of an overall Carpentry/ Joinery contract";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworksotherthancarpentry";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques19fulldetailsoflocation") ? appln.Attributes["lux_ques19fulldetailsoflocation"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthancarpentry") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanystructuraltimberworks"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanystructuraltimberworks' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanystructuraltimberworks") == true)
                    {
                        var FieldName1 = "Do you undertake any structural timber works on properties/buildings?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanystructuraltimberworks";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_additionalinfo"] = "Decline CAR Product";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanystructuraltimberworks") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeworksotherthancommercialpai"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeworksotherthancommercialpai' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeworksotherthancommercialpai") == true)
                    {
                        var FieldName1 = "Do you undertake any works other than those in the following business description? Commercial and domestic painting and decorating contractor.Associated small non - structural building works as part of an overall painting and decorating contract";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeworksotherthancommercialpai";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques21fulldetailsoflocation") ? appln.Attributes["lux_ques21fulldetailsoflocation"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeworksotherthancommercialpai") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyspecialistprotectivecoat"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyspecialistprotectivecoat' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyspecialistprotectivecoat") == true)
                    {
                        var FieldName1 = "Do you undertake any specialist/protective coatings work?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyspecialistprotectivecoat";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques22fulldetailsoflocation") ? appln.Attributes["lux_ques22fulldetailsoflocation"] : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyspecialistprotectivecoat") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyougainaccessbyusingropes"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyougainaccessbyusingropes' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyougainaccessbyusingropes") == true)
                    {
                        var FieldName1 = "Do you gain access by using ropes, harnesses or suspended platforms (this does not include scaffolding or cherry pickers)?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyougainaccessbyusingropes";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyougainaccessbyusingropes") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworksinvolvingspraypaint"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworksinvolvingspraypaint' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksinvolvingspraypaint") == true)
                    {
                        var FieldName1 = "Do you undertake any works involving spray painting?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworksinvolvingspraypaint";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksinvolvingspraypaint") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworksotherthanlaying"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworksotherthanlaying' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthanlaying") == true)
                    {
                        var FieldName1 = "Do you undertake any works other than those in the following business description? Laying or maintenance of paths, patio, paving and driveways(excluding roads)";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworksotherthanlaying";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques25fulldetailsoflocation") ? appln.Attributes["lux_ques25fulldetailsoflocation"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthanlaying") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouworktodepthgreaterthan1metrebgl"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouworktodepthgreaterthan1metrebgl' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouworktodepthgreaterthan1metrebgl") == true)
                    {
                        var FieldName1 = "Do you work to depth greater than 1 metre below ground level?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouworktodepthgreaterthan1metrebgl";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_pleaseconfirmthemaximumdepthbelowgroundle") ? appln.Attributes["lux_pleaseconfirmthemaximumdepthbelowgroundle"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouworktodepthgreaterthan1metrebgl") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworksotherthanacoustic"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworksotherthanacoustic' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthanacoustic") == true)
                    {
                        var FieldName1 = "Do you undertake any works other than those in the following business description? Acoustic and sound proofing  audio testing, noise control and wall lining installation excluding cavity wall insulation and vibration control. Associated small non - structural building works in relation to an acoustic/ sound proofing contract.";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworksotherthanacoustic";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques27fulldetailsoflocation") ? appln.Attributes["lux_ques27fulldetailsoflocation"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthanacoustic") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouworkonpremisesotherthanprivatedwelli"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouworkonpremisesotherthanprivatedwelli' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouworkonpremisesotherthanprivatedwelli") == true)
                    {
                        var FieldName1 = "Do you work on any premises other than private dwellings, studios, shops, schools, hotels or offices?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouworkonpremisesotherthanprivatedwelli";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_pleaseprovideadditionalareasofwork") ? appln.Attributes["lux_pleaseprovideadditionalareasofwork"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouworkonpremisesotherthanprivatedwelli") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworkinvolvingthecladding"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworkinvolvingthecladding' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworkinvolvingthecladding") == true)
                    {
                        var FieldName1 = "Do you undertake any work involving the exterior cladding of a building?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworkinvolvingthecladding";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques29fulldetailsoflocation") ? appln.Attributes["lux_ques29fulldetailsoflocation"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworkinvolvingthecladding") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworksotherthanbricklayin"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworksotherthanbricklayin' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthanbricklayin") == true)
                    {
                        var FieldName1 = "Do you undertake any works other than those in the following business description? Bricklaying, hod carrying, stonework and blockwork and external rendering.";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworksotherthanbricklayin";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques30fulldetailsoflocation") ? appln.Attributes["lux_ques30fulldetailsoflocation"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthanbricklayin") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouworkonanyindustrialpremises"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouworkonanyindustrialpremises' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouworkonanyindustrialpremises") == true)
                    {
                        var FieldName1 = "Do you work on any industrial premises or any premises exceeding three storeys in height (including ground level)?";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouworkonanyindustrialpremises";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques31fulldetailsoflocation") ? appln.Attributes["lux_ques31fulldetailsoflocation"].ToString() : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouworkonanyindustrialpremises") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworksotherthanplastering"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworksotherthanplastering' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthanplastering") == true)
                    {
                        var FieldName1 = "Do you undertake any works other than those in the following business description? Plastering, dry lining, artexing, ceiling, painting/ decoration(excluding spray painting), floor screeding, internal mastic sealants and metal partitioning.";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworksotherthanplastering";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques32fulldetailsoflocation") ? appln.Attributes["lux_ques32fulldetailsoflocation"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthanplastering") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworksotherthaninstallati"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworksotherthaninstallati' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthaninstallati") == true)
                    {
                        var FieldName1 = "Do you undertake any works other than those in the following business description? Installation, service, maintenance, breakdown and repair of electrical systems. Fault finding, data cabling, visual / audio systems, PAT testing, sockets and lighting, rewiring, visual inspections, testing and certification, CCTV, fuse boards and emergency repairs.Small non-structural associated building work in relation to an electrical contract.";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworksotherthaninstallati";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques33fulldetailsoflocation") ? appln.Attributes["lux_ques33fulldetailsoflocation"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthaninstallati") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyoucarryoutanyworksatanydatacentres"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyoucarryoutanyworksatanydatacentres' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyoucarryoutanyworksatanydatacentres") == true)
                    {
                        var FieldName1 = "Do you carry out any works at any data centres?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyoucarryoutanyworksatanydatacentres";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques34fulldetailsoflocation") ? appln.Attributes["lux_ques34fulldetailsoflocation"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyoucarryoutanyworksatanydatacentres") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeworkinvolvinglifecriticalpr"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeworkinvolvinglifecriticalpr' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeworkinvolvinglifecriticalpr") == true)
                    {
                        var FieldName1 = "Do you undertake any work involving life critical products?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeworkinvolvinglifecriticalpr";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeworkinvolvinglifecriticalpr") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanythreephasework"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanythreephasework' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanythreephasework") == true)
                    {
                        var FieldName1 = "Do you undertake any Three-Phase work?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanythreephasework";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques36fulldetailsoflocation") ? appln.Attributes["lux_ques36fulldetailsoflocation"] : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanythreephasework") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworksotherthanerection"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworksotherthanerection' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthanerection") == true)
                    {
                        var FieldName1 = "Do you undertake any works other than those in the following business description? Installation, maintenance and erection of posters and signs, excluding billboards. Sign Writers. Associated small non - structural building works as part of an overall signage contract";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworksotherthanerection";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques37fulldetailsoflocation") ? appln.Attributes["lux_ques37fulldetailsoflocation"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthanerection") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworksotherthanwindows"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworksotherthanwindows' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthanwindows") == true)
                    {
                        var FieldName1 = "Do you undertake any works other than those in the following business description? Installation of internal and external windows & doors, glazing repairs/maintenance, draught proofing or internal/external mastic sealants.Associated small non-structural building works, as part of an overall glazing contract.";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworksotherthanwindows";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques38fulldetailsoflocation") ? appln.Attributes["lux_ques38fulldetailsoflocation"] : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthanwindows") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworksthatinvolveroofing"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworksthatinvolveroofing' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksthatinvolveroofing") == true)
                    {
                        var FieldName1 = "Do you undertake any works that involve roofing, cladding or external curtain walling?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworksthatinvolveroofing";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques39fulldetailsoflocation") ? appln.Attributes["lux_ques39fulldetailsoflocation"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksthatinvolveroofing") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworksinvolvingconservato"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworksinvolvingconservato' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksinvolvingconservato") == true)
                    {
                        var FieldName1 = "Do you undertake any works involving conservatories or shop fronts?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworksinvolvingconservato";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksinvolvingconservato") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworksotherthanfencing"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworksotherthanfencing' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthanfencing") == true)
                    {
                        var FieldName1 = "Do you undertake any works other than those in the following business description? Installation, maintenance and design of fencing, garden and driveway gates. Associated general landscaping(including clearance) and small non - structural building works, as part of an overall fencing contract.";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworksotherthanfencing";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques41fulldetailsoflocation") ? appln.Attributes["lux_ques41fulldetailsoflocation"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworksotherthanfencing") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeworksinvolvingautomatedgate"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeworksinvolvingautomatedgate' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeworksinvolvingautomatedgate") == true)
                    {
                        var FieldName1 = "Do you undertake any works involving automated gates or barriers?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeworksinvolvingautomatedgate";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeworksinvolvingautomatedgate") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouinstallormaintainanysecuirtyfencing"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouinstallormaintainanysecuirtyfencing' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouinstallormaintainanysecuirtyfencing") == true)
                    {
                        var FieldName1 = "Do you install or maintain any secuirty fencing for any commercial, industrial or high risk premises?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouinstallormaintainanysecuirtyfencing";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques43fulldetailsoflocation") ? appln.Attributes["lux_ques43fulldetailsoflocation"] : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouinstallormaintainanysecuirtyfencing") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeworksotherthanairconditioni"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeworksotherthanairconditioni' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeworksotherthanairconditioni") == true)
                    {
                        var FieldName1 = "Do you undertake any works other than those in the following business description? Installation of Air conditioning/ refrigeration systems and units.Service, maintenance, breakdown and repair of Air Conditioning/ refrigeration systems.Ductwork Installation and repair(Excluding cleaning/ degreasing).  Associated small non - structural building and electrical works in relation to an air-conditioning / refrigeration contract.";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeworksotherthanairconditioni";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques44fulldetailsoflocation") ? appln.Attributes["lux_ques44fulldetailsoflocation"] : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeworksotherthanairconditioni") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyformofdegreasingcleaning"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyformofdegreasingcleaning' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyformofdegreasingcleaning") == true)
                    {
                        var FieldName1 = "Do you undertake any form of degreasing/cleaning of ductwork/kitchen extractor systems?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyformofdegreasingcleaning";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyformofdegreasingcleaning") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanyworkinvolvingcleanairroo"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanyworkinvolvingcleanairroo' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworkinvolvingcleanairroo") == true)
                    {
                        var FieldName1 = "Do you undertake any work involving clean-air rooms or cold stores?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanyworkinvolvingcleanairroo";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques46fulldetailsoflocation") ? appln.Attributes["lux_ques46fulldetailsoflocation"] : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyworkinvolvingcleanairroo") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeworksotherthandomesticplumb"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeworksotherthandomesticplumb' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeworksotherthandomesticplumb") == true)
                    {
                        var FieldName1 = "Do you undertake any works other than those in the following business description? Domestic plumbers, heating and air conditioning installation, servicing and repair including bathroom, kitchen and boiler installations.Associated small non - structural building and general electrical works in relation to an air-conditioning contract.";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeworksotherthandomesticplumb";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques47fulldetailsoflocation") ? appln.Attributes["lux_ques47fulldetailsoflocation"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeworksotherthandomesticplumb") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouworkonpremisesotherthanthreestoreys"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouworkonpremisesotherthanthreestoreys' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouworkonpremisesotherthanthreestoreys") == true)
                    {
                        var FieldName1 = "Do you work on any premises other than private dwellings not exceeding three storeys high (including ground level)?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouworkonpremisesotherthanthreestoreys";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouworkonpremisesotherthanthreestoreys") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeworksotherthangeneralbuildi"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeworksotherthangeneralbuildi' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeworksotherthangeneralbuildi") == true)
                    {
                        var FieldName1 = "Do you undertake any works other than those in the following business description? General building, new build, refurbishment, maintenance and development contractor including artexing, carpet fitting, ceiling / partitioning, painting / decoration(excluding spray painting), dry lining, flooring, interior design, internal mastic sealants, plastering, tiling, carpentry and joinery.";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeworksotherthangeneralbuildi";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques50fulldetailsoflocation") ? appln.Attributes["lux_ques50fulldetailsoflocation"] : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeworksotherthangeneralbuildi") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeanybasementconstruction"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeanybasementconstruction' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanybasementconstruction") == true)
                    {
                        var FieldName1 = "Do you undertake any basement construction or structural alterations of existing basements?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeanybasementconstruction";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanybasementconstruction") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeactivitiesoutsidegeneralroa"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeactivitiesoutsidegeneralroa' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeactivitiesoutsidegeneralroa") == true)
                    {
                        var FieldName1 = "Do you (the insured) undertake any activities outside of the following business description? General road haulage, non - hazardous goods delivery, parcel/ packages delivery, refrigerated transport, pallet distribution, aggregates delivery, low loader haulage, container haulage and freight forwarding.";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeactivitiesoutsidegeneralroa";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques54fulldetailsoflocation") ? appln.Attributes["lux_ques54fulldetailsoflocation"] : "";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeactivitiesoutsidegeneralroa") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeactivitiesotherthandelivery"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeactivitiesotherthandelivery' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeactivitiesotherthandelivery") == true)
                    {
                        var FieldName1 = "Do you undertake any activities other than the collection and delivery of third party items/products/goods, or empty/unpack these items/products/goods contained within their relevant packaging (i.e. pallets, boxes, bags, drums or containers) once they have been collected or delivered?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeactivitiesotherthandelivery";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeactivitiesotherthandelivery") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouhaveinvolvementinloadingorunloading"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouhaveinvolvementinloadingorunloading' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouhaveinvolvementinloadingorunloading") == true)
                    {
                        var FieldName1 = "Do you have any involvement in the loading or unloading of goods?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouhaveinvolvementinloadingorunloading";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques55detailsofanyotherservices") ? appln.Attributes["lux_ques55detailsofanyotherservices"] : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouhaveinvolvementinloadingorunloading") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyoucarryanygoodsbywayofatanker"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyoucarryanygoodsbywayofatanker' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyoucarryanygoodsbywayofatanker") == true)
                    {
                        var FieldName1 = "Do you carry any goods by way of a tanker?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyoucarryanygoodsbywayofatanker";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyoucarryanygoodsbywayofatanker") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyoucarryanyhazardousgoodswastes"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyoucarryanyhazardousgoodswastes' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyoucarryanyhazardousgoodswastes") == true)
                    {
                        var FieldName1 = "Do you carry any hazardous goods/wastes (as defined within the Approved Carriage List of the Carriage of Danagerous Goods by Road and Rail (Classification, Packaging and Labelling) Regulations 1994 or any further amendment made to the legislation) , waste, fuels, chemicals, animal feeds, fertilisers, pesticides, abnormal loads or livestock?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyoucarryanyhazardousgoodswastes";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyoucarryanyhazardousgoodswastes") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_confirmyoudonotundertakeworkoutsidetheeu"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_confirmyoudonotundertakeworkoutsidetheeu' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_confirmyoudonotundertakeworkoutsidetheeu") == false)
                    {
                        var FieldName1 = "Can you (the insured) confirm you do not undertake any work outside the European Union?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_confirmyoudonotundertakeworkoutsidetheeu";
                        refer["lux_suppliedvalue"] = "No";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_confirmyoudonotundertakeworkoutsidetheeu") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_canyouconfirmyourtradedoesnotcarrywork"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_canyouconfirmyourtradedoesnotcarrywork' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_canyouconfirmyourtradedoesnotcarrywork") == false)
                    {
                        var FieldName1 = "Does not carry out any works in, on or immediately adjacent to offshore rigs/platforms/structures.";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_canyouconfirmyourtradedoesnotcarrywork";
                        refer["lux_suppliedvalue"] = "No";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_canyouconfirmyourtradedoesnotcarrywork") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeworksotherthangroundwork"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeworksotherthangroundwork' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeworksotherthangroundwork") == true)
                    {
                        var FieldName1 = "Do you undertake any works other than those in the following business description? Groundwork contractors including trenching, excavation, site preparation, earthworks, kerbing, paving, roads and footpaths";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeworksotherthangroundwork";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_additionalinfo"] = appln.Attributes.Contains("lux_ques63fulldetailsoflocation") ? appln.Attributes["lux_ques63fulldetailsoflocation"] : "";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeworksotherthangroundwork") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouworkorexavatetodepthsgreaterthan2m"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouworkorexavatetodepthsgreaterthan2m' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouworkorexavatetodepthsgreaterthan2m") == true)
                    {
                        var FieldName1 = "Do you work or exavate to depths greater than 2 metres below ground level?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouworkorexavatetodepthsgreaterthan2m";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouworkorexavatetodepthsgreaterthan2m") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouworkonanymotorways"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouworkonanymotorways' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouworkonanymotorways") == true)
                    {
                        var FieldName1 = "Do you work on any motorways?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouworkonanymotorways";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouworkonanymotorways") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakepilingunderpinning"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakepilingunderpinning' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakepilingunderpinning") == true)
                    {
                        var FieldName1 = "Do you undertake any of the following: -Piling - Underpinning - Demolition - Formwork / Shuttering";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakepilingunderpinning";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakepilingunderpinning") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakenanytrafficmanagement"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakenanytrafficmanagement' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakenanytrafficmanagement") == true)
                    {
                        var FieldName1 = "Do you undertaken any traffic management?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakenanytrafficmanagement";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakenanytrafficmanagement") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_renewaldate"))
            {
                var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_referral'>
                                            <attribute name='lux_suppliedvalue' />
                                            <attribute name='lux_fieldname' />
                                            <attribute name='lux_approve' />
                                            <attribute name='lux_additionalinfo' />
                                            <attribute name='lux_referralid' />
                                            <order attribute='lux_suppliedvalue' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                              <condition attribute='lux_fieldschemaname' operator='eq' value='lux_renewaldate' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                {
                    if ((RenewalDate - InceptionDate).Days < 364 || (RenewalDate - InceptionDate).Days > 540)
                    {
                        var FieldName1 = "Renewal Date";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_renewaldate";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_renewaldate"];
                        refer["lux_additionalinfo"] = "ARAG: PERIOD OF INSURANCES BOUND: 12 months(plus odd time not exceeding 18 months in total)";
                        service.Create(refer);
                    }
                }
                else
                {
                    if ((RenewalDate - InceptionDate).Days >= 364 && (RenewalDate - InceptionDate).Days <= 540)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch2)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_inceptiondate"))
            {
                var fetch3 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_referral'>
                                            <attribute name='lux_suppliedvalue' />
                                            <attribute name='lux_fieldname' />
                                            <attribute name='lux_approve' />
                                            <attribute name='lux_additionalinfo' />
                                            <attribute name='lux_referralid' />
                                            <order attribute='lux_suppliedvalue' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                              <condition attribute='lux_fieldschemaname' operator='eq' value='lux_inceptiondate' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch3)).Entities.Count == 0)
                {
                    if ((InceptionDate - DateTime.Now).Days > 60)
                    {
                        var FieldName1 = "Renewal Date";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_inceptiondate";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_inceptiondate"];
                        refer["lux_additionalinfo"] = "ARAG: MAXIMUM ADVANCE PERIOD FOR INCEPTION DATES: 60 days";
                        service.Create(refer);
                    }
                }
                else
                {
                    if ((InceptionDate - DateTime.Now).Days <= 60)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch3)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_isthisworksolelyundertakenbybfsc"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isthisworksolelyundertakenbybfsc' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doesassociatedplumbingairconditioning") == true && appln.GetAttributeValue<bool>("lux_isthisworksolelyundertakenbybfsc") == false)
                    {
                        var FieldName1 = "Does associated plumbing, air conditioning, heating and ventilation form part of your overall contract?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_isthisworksolelyundertakenbybfsc";
                        refer["lux_suppliedvalue"] = "No";
                        refer["lux_additionalinfo"] = "Second Question: Referral - Load PL rates as follows: trade group 2 by 34%, trade group 3 by 65%";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doesassociatedplumbingairconditioning") == false || appln.GetAttributeValue<bool>("lux_isthisworksolelyundertakenbybfsc") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_isanyofthisworkgreatedthan3storyshigh"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isanyofthisworkgreatedthan3storyshigh' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_isthisworksolelyundertakenbybfsc") == false && appln.GetAttributeValue<bool>("lux_isanyofthisworkgreatedthan3storyshigh") == true)
                    {
                        var FieldName1 = "Does associated plumbing, air conditioning, heating and ventilation form part of your overall contract?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_isanyofthisworkgreatedthan3storyshigh";
                        refer["lux_suppliedvalue"] = "Yes";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Third Question: Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_isthisworksolelyundertakenbybfsc") == true || appln.GetAttributeValue<bool>("lux_isanyofthisworkgreatedthan3storyshigh") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_isthisworksolelyundertakenbybfsc1"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isthisworksolelyundertakenbybfsc1' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyscaffoldingwork") == true && appln.GetAttributeValue<bool>("lux_isthisworksolelyundertakenbybfsc1") == false)
                    {
                        var FieldName1 = "Do you undertake any scaffolding work (other than scaffolding towers to a maximum of 5 metres from ground level or floor level when working internally of a building/property)?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_isthisworksolelyundertakenbybfsc1";
                        refer["lux_suppliedvalue"] = "No";
                        refer["lux_additionalinfo"] = "Second Question: Referral";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyscaffoldingwork") == false || appln.GetAttributeValue<bool>("lux_isthisworksolelyundertakenbybfsc1") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_areyougassaferegisteredorsubcontractwork"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_areyougassaferegisteredorsubcontractwork' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doesassociatedgasworkformpartofyouroveral") == true && appln.GetAttributeValue<bool>("lux_areyougassaferegisteredorsubcontractwork") == false)
                    {
                        var FieldName1 = "Does associated gas work form part of your overall contract?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_areyougassaferegisteredorsubcontractwork";
                        refer["lux_suppliedvalue"] = "No";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Second Question: Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doesassociatedgasworkformpartofyouroveral") == false || appln.GetAttributeValue<bool>("lux_areyougassaferegisteredorsubcontractwork") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_isthisworksolelyundertakenbybfsc2"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isthisworksolelyundertakenbybfsc2' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyroofingworkactivities") == true && appln.GetAttributeValue<bool>("lux_isthisworksolelyundertakenbybfsc2") == false)
                    {
                        var FieldName1 = "Do you undertake any roofing work/activities?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_isthisworksolelyundertakenbybfsc2";
                        refer["lux_suppliedvalue"] = "No";
                        refer["lux_additionalinfo"] = "Second Question: Referral";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyroofingworkactivities") == false || appln.GetAttributeValue<bool>("lux_isthisworksolelyundertakenbybfsc2") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_isallroofingworklimitedtoancillaryrooftil"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isallroofingworklimitedtoancillaryrooftil' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_isthisworksolelyundertakenbybfsc2") == false && appln.GetAttributeValue<bool>("lux_isallroofingworklimitedtoancillaryrooftil") == false)
                    {
                        var FieldName1 = "Do you undertake any roofing work/activities?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_isallroofingworklimitedtoancillaryrooftil";
                        refer["lux_suppliedvalue"] = "No";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Third Question: Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_isthisworksolelyundertakenbybfsc2") == true || appln.GetAttributeValue<bool>("lux_isallroofingworklimitedtoancillaryrooftil") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakespecialistbuildingwork"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakespecialistbuildingwork' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakespecialistbuildingwork") == true)
                    {
                        var FieldName1 = "Do you undertake any of the following specialist building work, including but not limited to: - Piling - Underpinning - Demolition - Steel Erection - Formwork / Shuttering";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakespecialistbuildingwork";
                        refer["lux_suppliedvalue"] = "Yes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakespecialistbuildingwork") == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_isthisworksolelyundertakenbybfsc3"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isthisworksolelyundertakenbybfsc3' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakespecialistbuildingwork") == true && appln.GetAttributeValue<bool>("lux_isthisworksolelyundertakenbybfsc3") == false)
                    {
                        var FieldName1 = "Do you undertake any of the following specialist building work, including but not limited to: - Piling - Underpinning - Demolition - Steel Erection - Formwork / Shuttering";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_isthisworksolelyundertakenbybfsc3";
                        refer["lux_suppliedvalue"] = "No";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Second Question: Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakespecialistbuildingwork") == false || appln.GetAttributeValue<bool>("lux_isthisworksolelyundertakenbybfsc3") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_isthisactivitysolelyofficeclericalbased"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isthisactivitysolelyofficeclericalbased' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyfreightforwarding") == true && appln.GetAttributeValue<bool>("lux_isthisactivitysolelyofficeclericalbased") == false)
                    {
                        var FieldName1 = "Do you undertake any freight forwarding?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_isthisactivitysolelyofficeclericalbased";
                        refer["lux_suppliedvalue"] = "No";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Second Question: Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyfreightforwarding") == false || appln.GetAttributeValue<bool>("lux_isthisactivitysolelyofficeclericalbased") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_doyouundertakeworksolelyonyourownvehicles"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_doyouundertakeworksolelyonyourownvehicles' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyvehiclemaintenancerepair") == true && appln.GetAttributeValue<bool>("lux_doyouundertakeworksolelyonyourownvehicles") == false)
                    {
                        var FieldName1 = "Do you undertake any vehicle maintenance, repairs or MOT’s including any vehicle inspection?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_doyouundertakeworksolelyonyourownvehicles";
                        refer["lux_suppliedvalue"] = "No";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Second Question: Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyvehiclemaintenancerepair") == false || appln.GetAttributeValue<bool>("lux_doyouundertakeworksolelyonyourownvehicles") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_isallworkundertakenbyaqualifiedpersonwith"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isallworkundertakenbyaqualifiedpersonwith' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyvehiclemaintenancerepair") == true && appln.GetAttributeValue<bool>("lux_isallworkundertakenbyaqualifiedpersonwith") == false)
                    {
                        var FieldName1 = "Do you undertake any vehicle maintenance, repairs or MOT’s including any vehicle inspection?";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_isallworkundertakenbyaqualifiedpersonwith";
                        refer["lux_suppliedvalue"] = "No";
                        refer["lux_declined"] = true;
                        refer["lux_additionalinfo"] = "Second Question: Declined";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakeanyvehiclemaintenancerepair") == false || appln.GetAttributeValue<bool>("lux_isallworkundertakenbyaqualifiedpersonwith") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_isthisworklimitedtofoundationsforstructur"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isthisworklimitedtofoundationsforstructur' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_isthisworklimitedtofoundationsforstructur") == true && appln.GetAttributeValue<bool>("lux_isthisworklimitedtofoundationsforstructur") == false)
                    {
                        var FieldName1 = "Do you undertake any foundation work?";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_isthisworklimitedtofoundationsforstructur";
                        refer["lux_suppliedvalue"] = "No";
                        refer["lux_additionalinfo"] = "Second Question: Referral";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_isthisworklimitedtofoundationsforstructur") == false || appln.GetAttributeValue<bool>("lux_isthisworklimitedtofoundationsforstructur") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_isthisworksolelyundertakenbybfsc4"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_isthisworksolelyundertakenbybfsc4' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakenanytrafficmanagement") == true && appln.GetAttributeValue<bool>("lux_isthisworksolelyundertakenbybfsc4") == false)
                    {
                        var FieldName1 = "Do you undertaken any traffic management?";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_isthisworksolelyundertakenbybfsc4";
                        refer["lux_suppliedvalue"] = "No";
                        refer["lux_additionalinfo"] = "Second Question: Referral";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<bool>("lux_doyouundertakenanytrafficmanagement") == false || appln.GetAttributeValue<bool>("lux_isthisworksolelyundertakenbybfsc4") == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
            if (appln.Attributes.Contains("lux_arebonafidecontractorsemployed"))
            {
                var BFSCEmployed = appln.Attributes.Contains("lux_arebonafidecontractorsemployed") ? appln.GetAttributeValue<bool>("lux_arebonafidecontractorsemployed") : false;
                var TotalTurnover = appln.Attributes.Contains("lux_totalestimatedturnover") ? appln.GetAttributeValue<Money>("lux_totalestimatedturnover").Value : 0;
                var BFSCTurnover = appln.Attributes.Contains("lux_estimatedpaymentstobonafidesubcontractors") ? appln.GetAttributeValue<Money>("lux_estimatedpaymentstobonafidesubcontractors").Value : 0;

                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_estimatedpaymentstobonafidesubcontractors' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (BFSCTurnover > TotalTurnover * 50 / 100 && BFSCEmployed == true)
                    {
                        var FieldName1 = "Estimated payments to Bona fide Sub-contractors";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_estimatedpaymentstobonafidesubcontractors";
                        refer["lux_suppliedvalue"] = appln.FormattedValues["lux_estimatedpaymentstobonafidesubcontractors"];
                        refer["lux_additionalinfo"] = "Refer Risk to Liability Carrier for Approval as Bonafide Wageroll is: " + (BFSCTurnover * 100 / TotalTurnover).ToString("#.##") + "%";
                        if (BFSCTurnover > TotalTurnover * 75 / 100)
                        {
                            refer["lux_declined"] = true;
                            refer["lux_additionalinfo"] = "Decline as Bonafide Wageroll is: " + (BFSCTurnover * 100 / TotalTurnover).ToString("#.##") + "%";
                        }
                        service.Create(refer);
                    }
                }
                else
                {
                    if (TotalTurnover * 50 / 100 >= BFSCTurnover || BFSCEmployed == false)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        if (reff.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", reff.Id); }
                    }
                    else if (BFSCTurnover > TotalTurnover * 50 / 100 || BFSCEmployed == true)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                        reff["lux_suppliedvalue"] = appln.FormattedValues["lux_estimatedpaymentstobonafidesubcontractors"];
                        reff["lux_additionalinfo"] = "Refer Risk to Liability Carrier for Approval as Bonafide Wageroll is: " + (BFSCTurnover * 100 / TotalTurnover).ToString("#.##") + "%";
                        if (BFSCTurnover > TotalTurnover * 75 / 100)
                        {
                            reff["lux_declined"] = true;
                            reff["lux_additionalinfo"] = "Decline as Bonafide Wageroll is: " + (BFSCTurnover * 100 / TotalTurnover).ToString("#.##") + "%";
                        }
                        else
                        {
                            reff["lux_declined"] = false;
                            reff["lux_additionalinfo"] = "Refer Risk to Liability Carrier for Approval as Bonafide Wageroll is: " + (BFSCTurnover * 100 / TotalTurnover).ToString("#.##") + "%";
                        }
                        service.Update(reff);
                    }
                }
            }
            if (appln.Attributes.Contains("lux_whoisthepreviousinsurer"))
            {
                var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_whoisthepreviousinsurer' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count == 0)
                {
                    if (appln.GetAttributeValue<OptionSetValue>("lux_whoisthepreviousinsurer").Value == 972970008)
                    {
                        var FieldName1 = "Existing insurer";
                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", applnref.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_whoisthepreviousinsurer";
                        refer["lux_suppliedvalue"] = "Tokio Marine";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (appln.GetAttributeValue<OptionSetValue>("lux_whoisthepreviousinsurer").Value != 972970008)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true)
                            {
                                if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                            }
                        }
                    }
                }
            }

            if (appln.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
            {
                var BrokernotesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='lux_note'>
                                        <attribute name='createdon' />
                                        <attribute name='lux_subject' />
                                        <attribute name='lux_notetext' />
                                        <attribute name='lux_addedby' />
                                        <attribute name='lux_noteid' />
                                        <order attribute='createdon' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='statecode' operator='eq' value='0' />
                                          <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                        </filter>
                                      </entity>
                                    </fetch>";

                var CommentsFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_usercomment'>
                                            <attribute name='createdon' />
                                            <attribute name='lux_portaluser' />
                                            <attribute name='lux_comment' />
                                            <attribute name='lux_usercommentid' />
                                            <order attribute='createdon' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <condition attribute='lux_tradesman' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_tradesmanapplication' operator='eq' uiname='' uitype='lux_tradesman' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='lux_brokernotes' />
                                    </filter>
                                  </entity>
                                </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count == 0)
                {
                    if (service.RetrieveMultiple(new FetchExpression(BrokernotesFetch)).Entities.Count > 0 || service.RetrieveMultiple(new FetchExpression(CommentsFetch)).Entities.Count > 0)
                    {
                        var FieldName1 = "Broker Notes – Reason – See brokers Notes";

                        Entity refer = new Entity("lux_referral");
                        refer["lux_tradesmanapplication"] = new EntityReference("lux_tradesman", appln.Id);
                        refer["lux_fieldname"] = FieldName1;
                        refer["lux_fieldschemaname"] = "lux_brokernotes";
                        service.Create(refer);
                    }
                }
                else
                {
                    if (service.RetrieveMultiple(new FetchExpression(BrokernotesFetch)).Entities.Count == 0 && service.RetrieveMultiple(new FetchExpression(CommentsFetch)).Entities.Count == 0)
                    {
                        var reff = service.RetrieveMultiple(new FetchExpression(fetch2)).Entities;
                        foreach (var item in reff)
                        {
                            if (item.GetAttributeValue<bool>("lux_approve") != true) { service.Delete("lux_referral", item.Id); }
                        }
                    }
                }
            }
        }
    }
}
