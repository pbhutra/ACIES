﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CustomWorkflows.ACIES
{
    public class SetAutoDiscounts : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Input("Product")]
        public InArgument<string> Product { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            Entity application = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet("lux_commercialloaddiscount", "statuscode", "lux_noclaimdiscount", "lux_applicationtype", "lux_rpocpoproducttype"));

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownerspremise'>
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_tenanttype' />
                                <attribute name='lux_declaredvalueforrebuildingthisproperty' />
                                <attribute name='lux_buildingconstruction' />
                                <attribute name='lux_occupancytype' />
                                <attribute name='lux_totalsuminsuredforthislocation' />
                                <attribute name='lux_landlordscontentsinresidentialareas' />
                                <attribute name='lux_totalnumberofcommercialunitsatthisaddress' />
                                <attribute name='lux_howmanyfloorsareofconcreteconstruction' />
                                <attribute name='lux_howmanyfloorsareofwoodenconstruction' />
                                <attribute name='lux_floodscore' />      
                                <attribute name='lux_crimescore' />      
                                <attribute name='lux_subsidencescore' />
                                <attribute name='lux_mdbihazardgroup' />
                                <attribute name='lux_materialdamagefirerate' />
                                <attribute name='lux_indemnityperiodrequired' />
                                <attribute name='lux_propertyownerspremiseid' />
                                <attribute name='lux_covers' />
                                <attribute name='lux_businessinterruptionperilsrate' />
                                <attribute name='lux_businessinterruptionpremium' />
                                <attribute name='lux_materialdamageperilsrate' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplication' visible='false' link-type='outer' alias='poa'>
                                  <attribute name='lux_levelofcommission' />
                                  <attribute name='lux_rpocpoproducttype' />                                
                                  <filter type='and'>
                                      <condition attribute='lux_applicationtype' operator='neq' value='972970003' />
                                  </filter>
                                </link-entity>
                              </entity>
                            </fetch>";

            var premises = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;

            if (premises.Count > 0)
            {
                var premiseCount = premises.Count;
                decimal discount = 0;

                foreach (var item in premises)
                {
                    decimal premiseDiscount = 0;

                    var floodScore = item.Attributes.Contains("lux_floodscore") ? item.GetAttributeValue<int>("lux_floodscore") : 0;
                    var subsidenceScore = item.Attributes.Contains("lux_subsidencescore") ? item.GetAttributeValue<int>("lux_subsidencescore") : 0;
                    var crimeScore = item.Attributes.Contains("lux_crimescore") ? item.GetAttributeValue<int>("lux_crimescore") : 0;

                    if (floodScore >= 1 && floodScore <= 5)
                    {
                        premiseDiscount += Convert.ToDecimal(2.5);
                    }
                    if (subsidenceScore >= 1 && subsidenceScore <= 3)
                    {
                        premiseDiscount += Convert.ToDecimal(2.5);
                    }
                    if (crimeScore >= 1 && crimeScore <= 4)
                    {
                        premiseDiscount += Convert.ToDecimal(2.5);
                    }

                    if (application.GetAttributeValue<OptionSetValue>("lux_rpocpoproducttype").Value == 972970001 || application.GetAttributeValue<OptionSetValue>("lux_rpocpoproducttype").Value == 972970003)
                    {
                        var mdbiHazardGroup = item.Attributes.Contains("lux_mdbihazardgroup") ? item.GetAttributeValue<int>("lux_mdbihazardgroup") : 0;
                        if (mdbiHazardGroup == 1 || mdbiHazardGroup == 2)
                        {
                            premiseDiscount += 5;
                        }
                        else if (mdbiHazardGroup == 3)
                        {
                            premiseDiscount += 4;
                        }
                        else if (mdbiHazardGroup == 4)
                        {
                            premiseDiscount += 3;
                        }
                    }

                    Entity premise = service.Retrieve("lux_propertyownerspremise", item.Id, new ColumnSet(false));
                    premise["lux_discount"] = -1 * premiseDiscount;
                    service.Update(premise);

                    discount += premiseDiscount;
                }

                discount = discount / premiseCount;

                var claimfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='lux_subsidarycompanypreviousclaim'>
                                        <attribute name='lux_descriptionofclaim' />
                                        <attribute name='lux_dateofclaim' />
                                        <attribute name='lux_causeofclaim' />
                                        <attribute name='lux_amountpaid' />
                                        <attribute name='lux_amountoutstanding' />
                                        <attribute name='lux_totalclaimamount' />
                                        <attribute name='lux_subsidarycompanypreviousclaimid' />
                                        <order attribute='lux_causeofclaim' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='statecode' operator='eq' value='0' />
                                          <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                        </filter>
                                      </entity>
                                    </fetch>";
                if (service.RetrieveMultiple(new FetchExpression(claimfetch)).Entities.Count == 0)
                {
                    discount += 5;
                    application["lux_noclaimdiscount"] = Convert.ToDecimal(5);
                }

                if (premiseCount >= 2 && premiseCount <= 5)
                {
                    discount += Convert.ToDecimal(2.5);
                }
                else if (premiseCount >= 6 && premiseCount <= 10)
                {
                    discount += 5;
                }
                else if (premiseCount >= 11 && premiseCount <= 20)
                {
                    discount += Convert.ToDecimal(7.5);
                }
                else if (premiseCount > 20)
                {
                    discount += 10;
                }

                if (!application.Attributes.Contains("lux_commercialloaddiscount"))
                {
                    if (application.GetAttributeValue<OptionSetValue>("statuscode").Value == 1 || application.GetAttributeValue<OptionSetValue>("statuscode").Value == 972970007) //inprogress & referral required
                    {
                        application["lux_commercialloaddiscount"] = -1 * discount;
                        service.Update(application);
                    }
                }
                else if (application.Attributes.Contains("lux_commercialloaddiscount"))
                {
                    if (application.GetAttributeValue<decimal>("lux_commercialloaddiscount") == 0)
                    {
                        if (application.GetAttributeValue<OptionSetValue>("statuscode").Value == 1 || application.GetAttributeValue<OptionSetValue>("statuscode").Value == 972970007) //inprogress & referral required
                        {
                            application["lux_commercialloaddiscount"] = -1 * discount;
                            service.Update(application);
                        }
                    }
                }
            }
        }
    }
}
