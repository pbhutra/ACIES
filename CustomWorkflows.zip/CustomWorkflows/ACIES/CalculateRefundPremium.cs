﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculateRefundPremium : CodeActivity
    {
        [Input("Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> Application { get; set; }

        [Input("IsTradesman")]
        public InArgument<bool> IsTradesman { get; set; }

        [Input("TradesmanApplication")]
        [ReferenceTarget("lux_tradesman")]
        public InArgument<EntityReference> TradesmanApplication { get; set; }

        [Input("Policy")]
        [ReferenceTarget("lux_policy")]
        public InArgument<EntityReference> Policy { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            if (IsTradesman.Get(executionContext) == false)
            {
                Entity applnref = service.Retrieve("lux_propertyownersapplications", Application.Get(executionContext).Id, new ColumnSet(true));
                Entity appln = service.Retrieve(applnref.LogicalName, applnref.Id, new ColumnSet(true));

                var mainfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_quotedpremium' />                               
                                <attribute name='lux_quotedpremiumbrokercommissionamount' />                                
                                <attribute name='lux_quotedpremiumaciescommissionamount' />
                                <attribute name='lux_lepolicygrosscommission' />
                                <attribute name='lux_lepolicynetpremium' />
                                <attribute name='lux_totalpolicypremiumincterrorism' />
                                <attribute name='lux_terrorismpremium' />
                                <attribute name='lux_terrorismquotedpremiumbrokercommissionamo' />
                                <attribute name='lux_terrorismquotedpremiumaciescommissionamou' />
                                <attribute name='lux_terrorismpolicynetpremiumexcludingipt' />
                                <attribute name='lux_totalpolicypremiuminciptfee' />
                                <attribute name='lux_policyfee' />
                                <attribute name='lux_mtadate' />
                                <attribute name='lux_lepolicygrosspremium' />
                                <attribute name='lux_propertyownersapplicationsid' />
                                <attribute name='lux_renewaldate' />
                                <attribute name='lux_postcode' />
                                <attribute name='lux_isterrorismcoverrequired' />
                                <attribute name='lux_inceptiondate' /> 
                                <attribute name='lux_materialdamagepolicypremium' />
                                <attribute name='lux_businessinterruptionpolicypremium' />
                                <attribute name='lux_employersliabilitypolicypremium' />
                                <attribute name='lux_propertyownersliabilitypolicypremium' />
                                <attribute name='lux_moneypolicypremium' />
                                <attribute name='lux_publicproductsliabilitypolicypremium' />
                                <attribute name='lux_contractorspolicypremium' />
                                <attribute name='lux_allriskpolicypremium' />
                                <attribute name='lux_goodsintransitpolicypremium' />
                                <order attribute='lux_quotenumber' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_quotenumber' operator='eq' value='{appln.Attributes["lux_originalquotenumber"].ToString()}' />
                                </filter>
                              </entity>
                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities.Count > 0)
                {
                    var MTAfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersapplications'>
                                                <attribute name='lux_name' />
                                                <attribute name='createdon' />
                                                <attribute name='lux_quotedpremium' />
                                                <attribute name='lux_totalpolicypremiumincterrorism' />
                                                <attribute name='lux_terrorismpremium' />
                                                <attribute name='lux_terrorismquotedpremiumbrokercommissionamo' />
                                                <attribute name='lux_terrorismquotedpremiumaciescommissionamou' />
                                                <attribute name='lux_terrorismpolicynetpremiumexcludingipt' />
                                                <attribute name='lux_totalpolicypremiuminciptfee' />
                                                <attribute name='lux_postcode' />
                                                <attribute name='lux_policyfee' />
                                                <attribute name='lux_lepolicygrosspremium' />
                                                <attribute name='lux_lepolicynetpremium' />
                                                <attribute name='lux_quotedpremium' />                                
                                                <attribute name='lux_quotedpremiumbrokercommissionamount' />                                
                                                <attribute name='lux_quotedpremiumaciescommissionamount' />
                                                <attribute name='lux_lepolicygrosscommission' />                                
                                                <attribute name='lux_isterrorismcoverrequired' />
                                                <attribute name='lux_propertyownersapplicationsid' />
                                                <attribute name='lux_materialdamagepolicypremium' />
                                                <attribute name='lux_businessinterruptionpolicypremium' />
                                                <attribute name='lux_employersliabilitypolicypremium' />
                                                <attribute name='lux_propertyownersliabilitypolicypremium' />
                                                <attribute name='lux_moneypolicypremium' />
                                                <attribute name='lux_publicproductsliabilitypolicypremium' />
                                                <attribute name='lux_allriskpolicypremium' />
                                                <attribute name='lux_goodsintransitpolicypremium' />
                                                <attribute name='lux_mtagrosspremium' />
                                                <attribute name='lux_mtabrokercommission' />
                                                <attribute name='lux_mtaaciescommission' />
                                                <attribute name='lux_acieslegalexpensesmtacommissionamount' />
                                                <attribute name='lux_legalexpensesmtapremium' />
                                                <attribute name='lux_legalexpensesmtanetpremium' />
                                                <attribute name='lux_materialdamagemtapremium' />
                                                <attribute name='lux_businessinterruptionmtapremium' />
                                                <attribute name='lux_employersliabilitymtapremium' />
                                                <attribute name='lux_propertyownersliabilitymtapremium' />
                                                <attribute name='lux_moneymtapremium' />
                                                <attribute name='lux_publicproductsliabilitymtapremium' />
                                                <attribute name='lux_contractorsmtapremium' />
                                                <attribute name='lux_allriskmtapremium' />
                                                <attribute name='lux_goodsintransitmtapremium' />
                                                <attribute name='lux_terrorismquotedpremiumbrokercommissionamo' />
                                                <attribute name='lux_terrorismquotedpremiumaciescommissionamou' />
                                                <attribute name='lux_terrorismmtabrokercommissionamount' />
                                                <attribute name='lux_terrorismmtaaciescommissionamount' />
                                                <attribute name='lux_terrorismmtanetpremium' />
                                                <attribute name='lux_terrorismpolicynetpremiumexcludingipt' />
                                                <order attribute='lux_quotenumber' descending='true' />
                                                <filter type='and'>
                                                    <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{Policy.Get(executionContext).Id}' />
                                                    <condition attribute='lux_applicationtype' operator='eq' value='972970002' />     
                                                    <condition attribute='statuscode' operator='eq' value='972970006' />
                                                 </filter>
                                              </entity>
                                            </fetch>";

                    var mainRecord = service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities[0];
                    var mainGrossPremium = mainRecord.Attributes.Contains("lux_quotedpremium") ? mainRecord.GetAttributeValue<Money>("lux_quotedpremium").Value : 0;
                    var mainBrokerComm = mainRecord.Attributes.Contains("lux_quotedpremiumbrokercommissionamount") ? mainRecord.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value : 0;
                    var mainGrossComm = mainRecord.Attributes.Contains("lux_quotedpremiumaciescommissionamount") ? mainRecord.GetAttributeValue<Money>("lux_quotedpremiumaciescommissionamount").Value : 0;
                    var mainLEGrossComm = mainRecord.Attributes.Contains("lux_lepolicygrosscommission") ? mainRecord.GetAttributeValue<Money>("lux_lepolicygrosscommission").Value : 0;
                    var mainLEGrossPremium = mainRecord.Attributes.Contains("lux_lepolicygrosspremium") ? mainRecord.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value : 0;
                    var mainLENetPremium = mainRecord.Attributes.Contains("lux_lepolicynetpremium") ? mainRecord.GetAttributeValue<Money>("lux_lepolicynetpremium").Value : 0;
                    var mainMDPremium = mainRecord.Attributes.Contains("lux_materialdamagepolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_materialdamagepolicypremium").Value : 0;
                    var mainBIPremium = mainRecord.Attributes.Contains("lux_businessinterruptionpolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_businessinterruptionpolicypremium").Value : 0;
                    var mainELPremium = mainRecord.Attributes.Contains("lux_employersliabilitypolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_employersliabilitypolicypremium").Value : 0;
                    var mainPOLPremium = mainRecord.Attributes.Contains("lux_propertyownersliabilitypolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_propertyownersliabilitypolicypremium").Value : 0;
                    var mainMoneyPremium = mainRecord.Attributes.Contains("lux_moneypolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_moneypolicypremium").Value : 0;
                    var mainPLPremium = mainRecord.Attributes.Contains("lux_publicproductsliabilitypolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_publicproductsliabilitypolicypremium").Value : 0;
                    var mainARPremium = mainRecord.Attributes.Contains("lux_allriskpolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_allriskpolicypremium").Value : 0;
                    var mainGITPremium = mainRecord.Attributes.Contains("lux_goodsintransitpolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_goodsintransitpolicypremium").Value : 0;
                    var mainCARPremium = mainRecord.Attributes.Contains("lux_contractorspolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_contractorspolicypremium").Value : 0;
                    var mainPolicyFee = mainRecord.Attributes.Contains("lux_policyfee") ? mainRecord.GetAttributeValue<Money>("lux_policyfee").Value : 0;

                    var mtaGrossPremium = 0M;
                    var mtaBrokerComm = 0M;
                    var mtaGrossComm = 0M;
                    var mtaLEGrossComm = 0M;
                    var mtaLEGrossPremium = 0M;
                    var mtaLENetPremium = 0M;
                    var mtaLEBrokerCommission = 0M;
                    decimal mainTerrorismBrokerComm = 0;
                    decimal mainTerrorismGrossComm = 0;
                    decimal mainTerrorismNetPremium = 0;

                    var mtaMDPremium = 0M;
                    var mtaBIPremium = 0M;
                    var mtaELPremium = 0M;
                    var mtaPOLPremium = 0M;
                    var mtaMoneyPremium = 0M;
                    var mtaPLPremium = 0M;
                    var mtaARPremium = 0M;
                    var mtaGITPremium = 0M;
                    var mtaCARPremium = 0M;
                    decimal mtaTerrorismBrokerComm = 0;
                    decimal mtaTerrorismGrossComm = 0;
                    decimal mtaTerrorismNetPremium = 0;


                    if (service.RetrieveMultiple(new FetchExpression(MTAfetch)).Entities.Count > 0)
                    {
                        var mtaRocords = service.RetrieveMultiple(new FetchExpression(MTAfetch)).Entities;
                        mtaGrossPremium = mtaRocords.Sum(x => x.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);
                        mtaBrokerComm = mtaRocords.Sum(x => x.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                        mtaGrossComm = mtaRocords.Sum(x => x.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);
                        mtaLEGrossComm = mtaRocords.Sum(x => x.Contains("lux_acieslegalexpensesmtacommissionamount") ? x.GetAttributeValue<Money>("lux_acieslegalexpensesmtacommissionamount").Value : 0);
                        mtaLEGrossPremium = mtaRocords.Sum(x => x.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);
                        mtaLENetPremium = mtaRocords.Sum(x => x.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);

                        mtaLEBrokerCommission = mtaLEGrossPremium - mtaLENetPremium - mtaLEGrossComm;

                        mtaMDPremium = mtaRocords.Sum(x => x.Contains("lux_materialdamagemtapremium") ? x.GetAttributeValue<Money>("lux_materialdamagemtapremium").Value : 0);
                        mtaBIPremium = mtaRocords.Sum(x => x.Contains("lux_businessinterruptionmtapremium") ? x.GetAttributeValue<Money>("lux_businessinterruptionmtapremium").Value : 0);
                        mtaELPremium = mtaRocords.Sum(x => x.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);
                        mtaPOLPremium = mtaRocords.Sum(x => x.Contains("lux_propertyownersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_propertyownersliabilitymtapremium").Value : 0);
                        mtaMoneyPremium = mtaRocords.Sum(x => x.Contains("lux_moneymtapremium") ? x.GetAttributeValue<Money>("lux_moneymtapremium").Value : 0);
                        mtaPLPremium = mtaRocords.Sum(x => x.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);
                        mtaARPremium = mtaRocords.Sum(x => x.Contains("lux_allriskmtapremium") ? x.GetAttributeValue<Money>("lux_allriskmtapremium").Value : 0);
                        mtaGITPremium = mtaRocords.Sum(x => x.Contains("lux_goodsintransitmtapremium") ? x.GetAttributeValue<Money>("lux_goodsintransitmtapremium").Value : 0);
                        mtaCARPremium = mtaRocords.Sum(x => x.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);

                        mtaTerrorismBrokerComm = mtaRocords.Sum(x => x.Contains("lux_terrorismmtabrokercommissionamount") ? x.GetAttributeValue<Money>("lux_terrorismmtabrokercommissionamount").Value : 0);
                        mtaTerrorismGrossComm = mtaRocords.Sum(x => x.Contains("lux_terrorismmtaaciescommissionamount") ? x.GetAttributeValue<Money>("lux_terrorismmtaaciescommissionamount").Value : 0);
                        mtaTerrorismNetPremium = mtaRocords.Sum(x => x.Contains("lux_terrorismmtanetpremium") ? x.GetAttributeValue<Money>("lux_terrorismmtanetpremium").Value : 0);
                    }

                    if (mainRecord.Contains("lux_isterrorismcoverrequired") && mainRecord.GetAttributeValue<bool>("lux_isterrorismcoverrequired") == true)
                    {
                        mainTerrorismBrokerComm = mainRecord.GetAttributeValue<Money>("lux_terrorismquotedpremiumbrokercommissionamo").Value;
                        mainTerrorismGrossComm = mainRecord.GetAttributeValue<Money>("lux_terrorismquotedpremiumaciescommissionamou").Value;
                        mainTerrorismNetPremium = mainRecord.GetAttributeValue<Money>("lux_terrorismpolicynetpremiumexcludingipt").Value;
                    }

                    var PolicyDuration = (appln.GetAttributeValue<DateTime>("lux_renewaldate") - appln.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                    var LengthtillNow = (appln.GetAttributeValue<DateTime>("lux_mtadate") - appln.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                    var remainingDays = PolicyDuration - LengthtillNow;

                    var MTAGrossPremium = (mainGrossPremium + mtaGrossPremium) * remainingDays / PolicyDuration;
                    var MTABrokerCommission = (mainBrokerComm + mtaBrokerComm) * remainingDays / PolicyDuration;
                    var MTAGrossCommission = (mainGrossComm + mtaGrossComm) * remainingDays / PolicyDuration;
                    var MTALEGrossCommission = (mainLEGrossComm + mtaLEGrossComm) * remainingDays / PolicyDuration;

                    var TerrorismBrokerComm = (mainTerrorismBrokerComm + mtaTerrorismBrokerComm) * remainingDays / PolicyDuration;
                    var TerrorismGrossComm = (mainTerrorismGrossComm + mtaTerrorismGrossComm) * remainingDays / PolicyDuration;
                    var TerrorismNetPremium = (mainTerrorismNetPremium + mtaTerrorismNetPremium) * remainingDays / PolicyDuration;

                    var MTANetPremium = MTAGrossPremium - MTABrokerCommission - MTAGrossCommission - MTALEGrossCommission;

                    var MTAMDPremium = (mainMDPremium + mtaMDPremium) * remainingDays / PolicyDuration;
                    var MTABIPremium = (mainBIPremium + mtaBIPremium) * remainingDays / PolicyDuration;
                    var MTAELPremium = (mainELPremium + mtaELPremium) * remainingDays / PolicyDuration;
                    var MTAPLPremium = (mainPLPremium + mtaPLPremium) * remainingDays / PolicyDuration;
                    var MTAPOLPremium = (mainPOLPremium + mtaPOLPremium) * remainingDays / PolicyDuration;
                    var MTAMoneyPremium = (mainMoneyPremium + mtaMoneyPremium) * remainingDays / PolicyDuration;
                    var MTAARPremium = (mainARPremium + mtaARPremium) * remainingDays / PolicyDuration;
                    var MTACARPremium = (mainCARPremium + mtaCARPremium) * remainingDays / PolicyDuration;
                    var MTAGITPremium = (mainGITPremium + mtaGITPremium) * remainingDays / PolicyDuration;
                    var MTALEPremium = (mainLEGrossPremium + mtaLEGrossPremium) * remainingDays / PolicyDuration;
                    var MTALENetPremium = (mainLENetPremium + mtaLENetPremium) * remainingDays / PolicyDuration;

                    appln["lux_mtagrosspremium"] = new Money(-1 * MTAGrossPremium);
                    appln["lux_mtabrokercommission"] = new Money(-1 * MTABrokerCommission);
                    appln["lux_mtaaciescommission"] = new Money(-1 * MTAGrossCommission);
                    appln["lux_mtanetpremium"] = new Money(-1 * MTANetPremium);

                    if (appln.Attributes.Contains("lux_isisleofmanrisk") && appln.GetAttributeValue<bool>("lux_isisleofmanrisk") == true)
                    {
                        appln["lux_mtaipt"] = new Money(0);
                    }
                    else
                    {
                        appln["lux_mtaipt"] = new Money(-1 * MTAGrossPremium * 12 / 100);
                    }

                    appln["lux_acieslegalexpensesmtacommissionamount"] = new Money(-1 * MTALEGrossCommission);

                    appln["lux_materialdamagemtatechnicalpremium"] = new Money(-1 * MTAMDPremium);
                    appln["lux_businessinterruptionmtatechnicalpremium"] = new Money(-1 * MTABIPremium);
                    appln["lux_employersliabilitymtatechnicalpremium"] = new Money(-1 * MTAELPremium);
                    appln["lux_propertyownersliabilitymtatechnicalpremiu"] = new Money(-1 * MTAPOLPremium);
                    appln["lux_legalexpensesmtatechnicalpremium"] = new Money(-1 * MTALEPremium);
                    appln["lux_legalexpensesmtatechnicalnetpremium"] = new Money(-1 * MTALENetPremium);

                    appln["lux_terrorismmtabrokercommissionamount"] = new Money(-1 * TerrorismBrokerComm);
                    appln["lux_terrorismmtaaciescommissionamount"] = new Money(-1 * TerrorismGrossComm);
                    appln["lux_terrorismmtanetpremium"] = new Money(-1 * TerrorismNetPremium);
                    appln["lux_terrorismmtapremium"] = new Money(-1 * (TerrorismNetPremium + TerrorismGrossComm + TerrorismBrokerComm));
                    appln["lux_terrorismmtatechnicalpremium"] = new Money(-1 * (TerrorismNetPremium + TerrorismGrossComm + TerrorismBrokerComm));

                    if (appln.Attributes.Contains("lux_isisleofmanrisk") && appln.GetAttributeValue<bool>("lux_isisleofmanrisk") == true)
                    {
                        appln["lux_terrorismmtaipt"] = new Money(0);
                    }
                    else
                    {
                        appln["lux_terrorismmtaipt"] = new Money(-1 * (TerrorismNetPremium + TerrorismGrossComm + TerrorismBrokerComm) * 12 / 100);
                    }

                    appln["lux_moneymtatechnicalpremium"] = new Money(-1 * MTAMoneyPremium);
                    appln["lux_publicproductsliabilitymtatechnicalpremiu"] = new Money(-1 * MTAPLPremium);
                    appln["lux_allriskmtatechnicalpremium"] = new Money(-1 * MTAARPremium);
                    appln["lux_goodsintransitmtatechnicalpremium"] = new Money(-1 * MTAGITPremium);
                    appln["lux_contractorsmtatechnicalpremium"] = new Money(-1 * MTACARPremium);

                    appln["lux_contractorsmtapremium"] = new Money(-1 * MTACARPremium);
                    appln["lux_materialdamagemtapremium"] = new Money(-1 * MTAMDPremium);
                    appln["lux_businessinterruptionmtapremium"] = new Money(-1 * MTABIPremium);
                    appln["lux_employersliabilitymtapremium"] = new Money(-1 * MTAELPremium);
                    appln["lux_propertyownersliabilitymtapremium"] = new Money(-1 * MTAPOLPremium);
                    appln["lux_legalexpensesmtapremium"] = new Money(-1 * MTALEPremium);
                    appln["lux_legalexpensesmtanetpremium"] = new Money(-1 * MTALENetPremium);
                    appln["lux_moneymtapremium"] = new Money(-1 * MTAMoneyPremium);
                    appln["lux_publicproductsliabilitymtapremium"] = new Money(-1 * MTAPLPremium);
                    appln["lux_allriskmtapremium"] = new Money(-1 * MTAARPremium);
                    appln["lux_goodsintransitmtapremium"] = new Money(-1 * MTAGITPremium);
                    if (LengthtillNow == 0)
                    {
                        appln["lux_mtapolicyfee"] = new Money(-1 * mainPolicyFee);
                    }
                    else
                    {
                        appln["lux_mtapolicyfee"] = new Money(0);
                    }

                    service.Update(appln);
                }
            }
            else if (IsTradesman.Get(executionContext) == true)
            {
                Entity applnref = service.Retrieve("lux_tradesman", TradesmanApplication.Get(executionContext).Id, new ColumnSet(true));
                Entity appln = service.Retrieve(applnref.LogicalName, applnref.Id, new ColumnSet(true));

                var mainfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_tradesman'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_policypremiumbeforeipt' />                               
                                <attribute name='lux_policybrokercommissionamount' />                                
                                <attribute name='lux_policyaciescommissionamount' />
                                <attribute name='lux_policyacieslegalexpensescommissionamount' />
                                <attribute name='lux_legalexpensespolicynetpremium' />
                                <attribute name='lux_policytotalpremiuminciptandfee' />
                                <attribute name='lux_policyfee' />
                                <attribute name='lux_postcode' />
                                <attribute name='lux_mtaeffectivedate' />
                                <attribute name='lux_legalexpensespolicygrosspremium' />
                                <attribute name='lux_tradesmanid' />
                                <attribute name='lux_renewaldate' />
                                <attribute name='lux_inceptiondate' /> 
                                <attribute name='lux_elpolicypremium' />
                                <attribute name='lux_plpolicypremium' />                                
                                <attribute name='lux_carpolicypremium' />
                                <attribute name='lux_technicalpremiumbeforeipt' />                                
                                <attribute name='lux_technicalbrokercommissionamount' />
                                <attribute name='lux_technicalaciescommissionamount' />
                                <attribute name='lux_technicalacieslegalexpensecommissionamoun' />
                                <attribute name='lux_legalexpensestechnicalgrosspremium' />
                                <attribute name='lux_legalexpensestechnicalnetpremium' />
                                <attribute name='lux_elpremium' />
                                <attribute name='lux_plpremium' />                             
                                <attribute name='lux_carpremium' />
                                <order attribute='lux_inceptiondate' descending='true' />
                                <order attribute='lux_quotenumber' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_quotenumber' operator='eq' value='{appln.Attributes["lux_originalquotenumber"].ToString()}' />
                                </filter>
                              </entity>
                            </fetch>";

                if (service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities.Count > 0)
                {
                    var MTAfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_tradesman'>
                                            <attribute name='lux_name' />
                                            <attribute name='createdon' />
                                            <attribute name='lux_policypremiumbeforeipt' />
                                            <attribute name='lux_policytotalpremiuminciptandfee' />
                                            <attribute name='lux_policyfee' />
                                            <attribute name='lux_postcode' />
                                            <attribute name='lux_legalexpensespolicygrosspremium' />
                                            <attribute name='lux_legalexpensespolicynetpremium' />                             
                                            <attribute name='lux_policybrokercommissionamount' />                                
                                            <attribute name='lux_policyaciescommissionamount' />
                                            <attribute name='lux_policyacieslegalexpensescommissionamount' />                                
                                            <attribute name='lux_tradesmanid' />
                                            <attribute name='lux_elpolicypremium' />
                                            <attribute name='lux_plpolicypremium' />
                                            <attribute name='lux_carpolicypremium' />
                                            <attribute name='lux_technicalpremiumbeforeipt' />                                
                                            <attribute name='lux_technicalbrokercommissionamount' />
                                            <attribute name='lux_technicalaciescommissionamount' />
                                            <attribute name='lux_technicalacieslegalexpensecommissionamoun' />
                                            <attribute name='lux_legalexpensestechnicalgrosspremium' />
                                            <attribute name='lux_legalexpensestechnicalnetpremium' />
                                            <attribute name='lux_mtagrosspremium' />
                                            <attribute name='lux_mtabrokercommission' />
                                            <attribute name='lux_mtaaciescommission' />
                                            <attribute name='lux_acieslegalexpensesmtacommissionamount' />
                                            <attribute name='lux_legalexpensesmtapremium' />
                                            <attribute name='lux_legalexpensesmtanetpremium' />
                                            <attribute name='lux_employersliabilitymtapremium' />
                                            <attribute name='lux_publicproductsliabilitymtapremium' />
                                            <attribute name='lux_contractorsmtapremium' />
                                            <attribute name='lux_legalexpensesmtapremium' />
                                            <attribute name='lux_elpremium' />
                                            <attribute name='lux_plpremium' />
                                            <attribute name='lux_carpremium' />
                                            <order attribute='lux_inceptiondate' descending='true' />
                                            <order attribute='lux_quotenumber' descending='true' />
                                            <filter type='and'>
                                                  <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{Policy.Get(executionContext).Id}' />
                                                  <condition attribute='lux_applicationtype' operator='eq' value='972970002' />     
                                                  <condition attribute='statuscode' operator='eq' value='972970006' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities.Count > 0)
                    {
                        var mainRecord = service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities[0];

                        var mainGrossPremium = mainRecord.GetAttributeValue<Money>("lux_policypremiumbeforeipt").Value;
                        var mainBrokerComm = mainRecord.GetAttributeValue<Money>("lux_policybrokercommissionamount").Value;
                        var mainGrossComm = mainRecord.GetAttributeValue<Money>("lux_policyaciescommissionamount").Value;
                        var mainLEGrossComm = mainRecord.GetAttributeValue<Money>("lux_policyacieslegalexpensescommissionamount").Value;
                        var mainLEGrossPremium = mainRecord.GetAttributeValue<Money>("lux_legalexpensespolicygrosspremium").Value;
                        var mainLENetPremium = mainRecord.GetAttributeValue<Money>("lux_legalexpensespolicynetpremium").Value;
                        var mainELPremium = mainRecord.Attributes.Contains("lux_elpolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_elpolicypremium").Value : 0;
                        var mainPLPremium = mainRecord.Attributes.Contains("lux_plpolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_plpolicypremium").Value : 0;
                        var mainCARPremium = mainRecord.Attributes.Contains("lux_carpolicypremium") ? mainRecord.GetAttributeValue<Money>("lux_carpolicypremium").Value : 0;
                        var mainPolicyFee = mainRecord.Attributes.Contains("lux_policyfee") ? mainRecord.GetAttributeValue<Money>("lux_policyfee").Value : 0;

                        var mtaGrossPremium = 0M;
                        var mtaBrokerComm = 0M;
                        var mtaGrossComm = 0M;
                        var mtaLEGrossComm = 0M;
                        var mtaLEGrossPremium = 0M;
                        var mtaLENetPremium = 0M;
                        var mtaLEBrokerCommission = 0M;
                        var mtaELPremium = 0M;
                        var mtaPLPremium = 0M;
                        var mtaCARPremium = 0M;

                        if (service.RetrieveMultiple(new FetchExpression(MTAfetch)).Entities.Count > 0)
                        {
                            var mtaRocords = service.RetrieveMultiple(new FetchExpression(MTAfetch)).Entities;
                            mtaGrossPremium = mtaRocords.Sum(x => x.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);
                            mtaBrokerComm = mtaRocords.Sum(x => x.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
                            mtaGrossComm = mtaRocords.Sum(x => x.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);
                            mtaLEGrossComm = mtaRocords.Sum(x => x.Contains("lux_acieslegalexpensesmtacommissionamount") ? x.GetAttributeValue<Money>("lux_acieslegalexpensesmtacommissionamount").Value : 0);
                            mtaLEGrossPremium = mtaRocords.Sum(x => x.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);
                            mtaLENetPremium = mtaRocords.Sum(x => x.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);

                            mtaLEBrokerCommission = mtaLEGrossPremium - mtaLENetPremium - mtaLEGrossComm;

                            mtaELPremium = mtaRocords.Sum(x => x.Contains("lux_employersliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_employersliabilitymtapremium").Value : 0);
                            mtaPLPremium = mtaRocords.Sum(x => x.Contains("lux_publicproductsliabilitymtapremium") ? x.GetAttributeValue<Money>("lux_publicproductsliabilitymtapremium").Value : 0);
                            mtaCARPremium = mtaRocords.Sum(x => x.Contains("lux_contractorsmtapremium") ? x.GetAttributeValue<Money>("lux_contractorsmtapremium").Value : 0);
                        }

                        var PolicyDuration = (appln.GetAttributeValue<DateTime>("lux_renewaldate") - appln.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                        var LengthtillNow = (appln.GetAttributeValue<DateTime>("lux_mtaeffectivedate") - appln.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                        var remainingDays = PolicyDuration - LengthtillNow;

                        var MTAGrossPremium = (mainGrossPremium + mtaGrossPremium) * remainingDays / PolicyDuration;
                        var MTABrokerCommission = (mainBrokerComm + mtaBrokerComm) * remainingDays / PolicyDuration;
                        var MTAGrossCommission = (mainGrossComm + mtaGrossComm) * remainingDays / PolicyDuration;
                        var MTALEGrossCommission = (mainLEGrossComm + mtaLEGrossComm) * remainingDays / PolicyDuration;

                        var MTANetPremium = MTAGrossPremium - MTABrokerCommission - MTAGrossCommission - MTALEGrossCommission;

                        var MTAELPremium = (mainELPremium + mtaELPremium) * remainingDays / PolicyDuration;
                        var MTAPLPremium = (mainPLPremium + mtaPLPremium) * remainingDays / PolicyDuration;
                        var MTACARPremium = (mainCARPremium + mtaCARPremium) * remainingDays / PolicyDuration;
                        var MTALEPremium = (mainLEGrossPremium + mtaLEGrossPremium) * remainingDays / PolicyDuration;
                        var MTALENetPremium = (mainLENetPremium + mtaLENetPremium) * remainingDays / PolicyDuration;


                        appln["lux_mtagrosspremium"] = new Money(-1 * MTAGrossPremium);
                        appln["lux_mtabrokercommission"] = new Money(-1 * MTABrokerCommission);
                        appln["lux_mtaaciescommission"] = new Money(-1 * MTAGrossCommission);
                        appln["lux_mtanetpremium"] = new Money(-1 * MTANetPremium);
                        if (appln.Attributes.Contains("lux_postcode") && appln.Attributes["lux_postcode"].ToString().StartsWith("IM"))
                        {
                            appln["lux_mtaipt"] = new Money(0);
                        }
                        else
                        {
                            appln["lux_mtaipt"] = new Money(-1 * MTAGrossPremium * 12 / 100);
                        }

                        appln["lux_acieslegalexpensesmtacommissionamount"] = new Money(-1 * MTALEGrossCommission);

                        appln["lux_employersliabilitymtatechnicalpremium"] = new Money(-1 * MTAELPremium);
                        appln["lux_legalexpensesmtatechnicalpremium"] = new Money(-1 * MTALEPremium);
                        appln["lux_legalexpensesmtatechnicalnetpremium"] = new Money(-1 * MTALENetPremium);
                        appln["lux_publicproductsliabilitymtatechnicalpremiu"] = new Money(-1 * MTAPLPremium);
                        appln["lux_contractorsmtatechnicalpremium"] = new Money(-1 * MTACARPremium);

                        appln["lux_employersliabilitymtapremium"] = new Money(-1 * MTAELPremium);
                        appln["lux_publicproductsliabilitymtapremium"] = new Money(-1 * MTAPLPremium);
                        appln["lux_contractorsmtapremium"] = new Money(-1 * MTACARPremium);
                        appln["lux_legalexpensesmtapremium"] = new Money(-1 * MTALEPremium);
                        appln["lux_legalexpensesmtanetpremium"] = new Money(-1 * MTALENetPremium);

                        if (LengthtillNow == 0)
                        {
                            appln["lux_mtapolicyfee"] = new Money(-1 * mainPolicyFee);
                        }
                        else
                        {
                            appln["lux_mtapolicyfee"] = new Money(0);
                        }

                        service.Update(appln);
                    }
                }
            }
        }
    }
}

//namespace CustomWorkflows
//{
//    public class CalculateRefundPremium : CodeActivity
//    {
//        [Input("Policy")]
//        [ReferenceTarget("lux_policy")]
//        public InArgument<EntityReference> Policy { get; set; }

//        protected override void Execute(CodeActivityContext executionContext)
//        {
//            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
//            tracingService.Trace("Application Started");

//            //Create the context
//            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
//            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
//            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

//            EntityReference polref = Policy.Get<EntityReference>(executionContext);
//            Entity policy = new Entity(polref.LogicalName, polref.Id);
//            policy = service.Retrieve("lux_policy", polref.Id, new ColumnSet(true));

//            var mainfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
//                              <entity name='lux_propertyownersapplications'>
//                                <attribute name='lux_name' />
//                                <attribute name='createdon' />
//                                <attribute name='lux_quotedpremium' />                               
//                                <attribute name='lux_quotedpremiumbrokercommissionamount' />                                
//                                <attribute name='lux_quotedpremiumaciescommissionamount' />
//                                <attribute name='lux_lepolicygrosscommission' />
//                                <attribute name='lux_lepolicynetpremium' />
//                                <attribute name='lux_totalpolicypremiumincterrorism' />
//                                <attribute name='lux_terrorismpremium' />
//                                <attribute name='lux_terrorismbrokercommissionamount' />
//                                <attribute name='lux_terrorismaciescommissionamout' />
//                                <attribute name='lux_terrorismnetpremium' />
//                                <attribute name='lux_totalpolicypremiuminciptfee' />
//                                <attribute name='lux_policyfee' />
//                                <attribute name='lux_mtadate' />
//                                <attribute name='lux_lepolicygrosspremium' />
//                                <attribute name='lux_propertyownersapplicationsid' />
//                                <attribute name='lux_renewaldate' />
//                                <attribute name='lux_isterrorismcoverrequired' />
//                                <attribute name='lux_inceptiondate' /> 
//                                <attribute name='lux_materialdamagepolicypremium' />
//                                <attribute name='lux_businessinterruptionpolicypremium' />
//                                <attribute name='lux_employersliabilitypolicypremium' />
//                                <attribute name='lux_propertyownersliabilitypolicypremium' />
//                                <attribute name='lux_moneypolicypremium' />
//                                <attribute name='lux_publicproductsliabilitypolicypremium' />
//                                <attribute name='lux_allriskpolicypremium' />
//                                <attribute name='lux_goodsintransitpolicypremium' />
//                                <order attribute='lux_inceptiondate' descending='true' />
//                                <order attribute='lux_quotenumber' descending='true' />
//                                <filter type='and'>
//                                    <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{Policy.Get(executionContext).Id}' />
//                                    <condition attribute='lux_applicationtype' operator='ne' value='972970002' />
//                                    <condition attribute='statuscode' operator='eq' value='972970006' />
//                                </filter>
//                              </entity>
//                            </fetch>";

//            if (service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities.Count > 0)
//            {
//                var MTAfetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
//                              <entity name='lux_propertyownersapplications'>
//                                <attribute name='lux_name' />
//                                <attribute name='createdon' />
//                                <attribute name='lux_quotedpremium' />
//                                <attribute name='lux_totalpolicypremiumincterrorism' />
//                                <attribute name='lux_terrorismpremium' />
//                                <attribute name='lux_terrorismbrokercommissionamount' />
//                                <attribute name='lux_terrorismaciescommissionamout' />
//                                <attribute name='lux_terrorismnetpremium' />
//                                <attribute name='lux_totalpolicypremiuminciptfee' />
//                                <attribute name='lux_policyfee' />
//                                <attribute name='lux_lepolicygrosspremium' />
//                                <attribute name='lux_lepolicynetpremium' />
//                                <attribute name='lux_quotedpremium' />                                
//                                <attribute name='lux_quotedpremiumbrokercommissionamount' />                                
//                                <attribute name='lux_quotedpremiumaciescommissionamount' />
//                                <attribute name='lux_lepolicygrosscommission' />                                
//                                <attribute name='lux_isterrorismcoverrequired' />
//                                <attribute name='lux_propertyownersapplicationsid' />
//                                <attribute name='lux_materialdamagepolicypremium' />
//                                <attribute name='lux_businessinterruptionpolicypremium' />
//                                <attribute name='lux_employersliabilitypolicypremium' />
//                                <attribute name='lux_propertyownersliabilitypolicypremium' />
//                                <attribute name='lux_moneypolicypremium' />
//                                <attribute name='lux_publicproductsliabilitypolicypremium' />
//                                <attribute name='lux_allriskpolicypremium' />
//                                <attribute name='lux_goodsintransitpolicypremium' />
//                                <order attribute='lux_inceptiondate' descending='true' />
//                                <order attribute='lux_quotenumber' descending='true' />
//                                <filter type='and'>
//                                    <condition attribute='lux_policy' operator='eq' uiname='' uitype='lux_policy' value='{Policy.Get(executionContext).Id}' />
//                                    <condition attribute='lux_applicationtype' operator='eq' value='972970002' />     
//                                    <condition attribute='statuscode' operator='eq' value='972970006' />
//                                 </filter>
//                              </entity>
//                            </fetch>";

//                var mainRecord = service.RetrieveMultiple(new FetchExpression(mainfetch)).Entities[0];
//                var mainGrossPremium = mainRecord.GetAttributeValue<Money>("lux_totalpolicypremiumincterrorism").Value;
//                var mainBrokerComm = mainRecord.GetAttributeValue<Money>("lux_quotedpremiumbrokercommissionamount").Value;
//                var mainGrossComm = mainRecord.GetAttributeValue<Money>("lux_quotedpremiumaciescommissionamount").Value;
//                var mainLEGrossComm = mainRecord.GetAttributeValue<Money>("lux_lepolicygrosscommission").Value;
//                var mainLEGrossPremium = mainRecord.GetAttributeValue<Money>("lux_lepolicygrosspremium").Value;
//                var mainLENetPremium = mainRecord.GetAttributeValue<Money>("lux_lepolicynetpremium").Value;
//                var mainLEBrokerCommission = mainLEGrossPremium - mainLENetPremium - mainLEGrossComm;

//                decimal mtaGrossPremium = 0;
//                decimal mtaBrokerComm = 0;
//                decimal mtaGrossComm = 0;
//                decimal mtaLEGrossComm = 0;
//                decimal mtaLEGrossPremium = 0;
//                decimal mtaLENetPremium = 0;
//                decimal mtaLEBrokerCommission = 0;

//                if (service.RetrieveMultiple(new FetchExpression(MTAfetch)).Entities.Count > 0)
//                {
//                    var mtaRocords = service.RetrieveMultiple(new FetchExpression(MTAfetch)).Entities;
//                    mtaGrossPremium = mtaRocords.Sum(x => x.Contains("lux_mtagrosspremium") ? x.GetAttributeValue<Money>("lux_mtagrosspremium").Value : 0);
//                    mtaBrokerComm = mtaRocords.Sum(x => x.Contains("lux_mtabrokercommission") ? x.GetAttributeValue<Money>("lux_mtabrokercommission").Value : 0);
//                    mtaGrossComm = mtaRocords.Sum(x => x.Contains("lux_mtaaciescommission") ? x.GetAttributeValue<Money>("lux_mtaaciescommission").Value : 0);
//                    mtaLEGrossComm = mtaRocords.Sum(x => x.Contains("lux_acieslegalexpensesmtacommissionamount") ? x.GetAttributeValue<Money>("lux_acieslegalexpensesmtacommissionamount").Value : 0);
//                    mtaLEGrossPremium = mtaRocords.Sum(x => x.Contains("lux_legalexpensesmtapremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtapremium").Value : 0);
//                    mtaLENetPremium = mtaRocords.Sum(x => x.Contains("lux_legalexpensesmtanetpremium") ? x.GetAttributeValue<Money>("lux_legalexpensesmtanetpremium").Value : 0);
//                    mtaLEBrokerCommission = mtaLEGrossPremium - mtaLENetPremium - mtaLEGrossComm;
//                }

//                var PolicyDuration = (mainRecord.GetAttributeValue<DateTime>("lux_renewaldate") - mainRecord.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
//                var LengthtillNow = (policy.GetAttributeValue<DateTime>("lux_cancellationdate") - mainRecord.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
//                var remainingDays = PolicyDuration - LengthtillNow;

//                var RefundGrossPremium = (mainGrossPremium + mtaGrossPremium) * remainingDays / PolicyDuration;
//                var RefundBrokerCommission = (mainBrokerComm + mtaBrokerComm) * remainingDays / PolicyDuration;
//                var RefundGrossCommission = (mainGrossComm + mtaGrossComm) * remainingDays / PolicyDuration;
//                var RefundNetPremium = RefundGrossPremium - RefundBrokerCommission - RefundGrossCommission;

//                var RefundLEPremium = (mainLEGrossPremium + mtaLEGrossPremium) * remainingDays / PolicyDuration;
//                var RefundLEGrossCommission = (mainLEGrossComm + mtaLEGrossComm) * remainingDays / PolicyDuration;
//                var RefundLEBrokerCommission = (mainLEBrokerCommission + mtaLEBrokerCommission) * remainingDays / PolicyDuration;
//                var RefundLENetPremium = (mainLENetPremium + mtaLENetPremium) * remainingDays / PolicyDuration;

//                Entity pol = service.Retrieve("lux_policy", policy.Id, new ColumnSet());
//                pol["lux_refundnetpremium"] = new Money(RefundGrossPremium);
//                pol["lux_refundgrosspremium"] = new Money(RefundGrossPremium + RefundGrossPremium * 12 / 100);
//                pol["lux_refundbrokercommission"] = new Money(RefundBrokerCommission);
//                pol["lux_refundgrosscommission"] = new Money(RefundGrossCommission + RefundLEGrossCommission);
//                pol["lux_refundipt"] = new Money(RefundGrossPremium * 12 / 100);

//                pol["lux_refundlenetpremium"] = new Money(RefundLENetPremium);
//                pol["lux_refundlepremium"] = new Money(RefundLEPremium);
//                pol["lux_refundlegrosscommission"] = new Money(RefundLEGrossCommission);
//                pol["lux_refundlebrokercommission"] = new Money(RefundLEPremium - RefundLENetPremium - RefundLEGrossCommission);
//                pol["lux_refundleipt"] = new Money(RefundLEPremium * 12 / 100);
//                service.Update(pol);
//            }
//        }
//    }
//}