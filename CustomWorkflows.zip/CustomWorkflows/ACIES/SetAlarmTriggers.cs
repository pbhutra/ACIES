﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class SetAlarmTriggers : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Input("Product")]
        public InArgument<string> Product { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            Entity appln = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));

            var fetch = "";
            var entityName = "";
            var attributeName = "";
            if (Product.Get(executionContext).ToString() == "Retail")
            {
                entityName = "lux_propertyownersretail";
                attributeName = "lux_retailproduct";
                fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersretail'>
                                <attribute name='lux_propertyownersretailid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_riskpostcode' />                               
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_generalcontentsdeclaredvalueincludingmach' />
                                <attribute name='lux_buildingsdeclaredvalue' />
                                <attribute name='lux_listhighvaluestock' />
                                <attribute name='lux_stockexcludinghighvaluestock' />
                                <attribute name='lux_computerandelectronicbusinessequipment' />
                                <attribute name='lux_winesfortifiedwinesspiritsfinesuminsured' />
                                <attribute name='lux_materialdamagecoverdetails' />
                                <attribute name='lux_powertoolssuminsured' />                                
                                <attribute name='lux_tenantsimprovementsdeclaredvalue' />
                                <attribute name='lux_nonferrousmetalssuminsured' />
                                <attribute name='lux_mobilephonessuminsured' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_computerequipmentsuminsured' />
                                <attribute name='lux_audiovideoequipmentsuminsured' />
                                <attribute name='lux_alcoholsuminsured' />
                                <attribute name='lux_computergamesandorconsolessuminsured' />
                                <attribute name='lux_materialdamagelossofrentpayable' />
                                <attribute name='lux_cigarettescigarsortobaccoproductssuminsur' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_fineartsuminsured' />
                                <attribute name='lux_whattypeofalarmisinstalled' />                                
                                <attribute name='lux_isthereanintruderalarminstalled' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplications' visible='false' link-type='outer' alias='appln'>
                                  <attribute name='lux_maintradeforthispremises' />
                                  <attribute name='lux_propertyownersapplicationsid' />
                                  <attribute name='lux_thefthazardgroup' />
                                </link-entity>
                              </entity>
                            </fetch>";
            }
            else if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
            {
                entityName = "lux_commercialcombinedapplication";
                attributeName = "lux_commercialcombined";
                fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_commercialcombinedapplication'>
                                <attribute name='lux_commercialcombinedapplicationid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_riskpostcode' />                               
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_generalcontentsdeclaredvalueincludingmach' />
                                <attribute name='lux_buildingsdeclaredvalue' />
                                <attribute name='lux_listhighvaluestock' />
                                <attribute name='lux_stockexcludinghighvaluestock' />
                                <attribute name='lux_computerandelectronicbusinessequipment' />
                                <attribute name='lux_winesfortifiedwinesspiritsfinesuminsured' />
                                <attribute name='lux_materialdamagecoverdetails' />
                                <attribute name='lux_powertoolssuminsured' />                                
                                <attribute name='lux_tenantsimprovementsdeclaredvalue' />
                                <attribute name='lux_nonferrousmetalssuminsured' />
                                <attribute name='lux_mobilephonessuminsured' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_computerequipmentsuminsured' />
                                <attribute name='lux_audiovideoequipmentsuminsured' />
                                <attribute name='lux_alcoholsuminsured' />
                                <attribute name='lux_computergamesandorconsolessuminsured' />
                                <attribute name='lux_materialdamagelossofrentpayable' />
                                <attribute name='lux_cigarettescigarsortobaccoproductssuminsur' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_fineartsuminsured' />
                                <attribute name='lux_whattypeofalarmisinstalled' />                                
                                <attribute name='lux_isthereanintruderalarminstalledandinworki' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplications' visible='false' link-type='outer' alias='appln'>
                                  <attribute name='lux_maintradeforthispremises' />
                                  <attribute name='lux_propertyownersapplicationsid' />
                                  <attribute name='lux_thefthazardgroup' />
                                </link-entity>
                              </entity>
                            </fetch>";
            }
            else if (Product.Get(executionContext).ToString() == "Pubs & Restaurants" || Product.Get(executionContext).ToString() == "Hotels and Guesthouses")
            {
                entityName = "lux_pubsrestaurantspropertyownersapplicatio";
                attributeName = "lux_pubsrestaurants";
                fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_pubsrestaurantspropertyownersapplicatio'>
                                <attribute name='lux_pubsrestaurantspropertyownersapplicatioid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_riskpostcode' />                               
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_generalcontentsdeclaredvalueincludingmach' />
                                <attribute name='lux_buildingsdeclaredvalue' />
                                <attribute name='lux_listhighvaluestock' />
                                <attribute name='lux_stockexcludinghighvaluestock' />
                                <attribute name='lux_computerandelectronicbusinessequipment' />
                                <attribute name='lux_winesfortifiedwinesspiritsfinesuminsured' />
                                <attribute name='lux_materialdamagecoverdetails' />
                                <attribute name='lux_powertoolssuminsured' />                                
                                <attribute name='lux_tenantsimprovementsdeclaredvalue' />
                                <attribute name='lux_nonferrousmetalssuminsured' />
                                <attribute name='lux_mobilephonessuminsured' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_computerequipmentsuminsured' />
                                <attribute name='lux_audiovideoequipmentsuminsured' />
                                <attribute name='lux_alcoholsuminsured' />
                                <attribute name='lux_computergamesandorconsolessuminsured' />
                                <attribute name='lux_materialdamagelossofrentpayable' />
                                <attribute name='lux_cigarettescigarsortobaccoproductssuminsur' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_fineartsuminsured' />
                                <attribute name='lux_whattypeofalarmisinstalled' />                                
                                <attribute name='lux_isthereanintruderalarminstalledandinworki' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplications' visible='false' link-type='outer' alias='appln'>
                                  <attribute name='lux_maintradeforthispremises' />
                                  <attribute name='lux_propertyownersapplicationsid' />
                                  <attribute name='lux_thefthazardgroup' />
                                </link-entity>
                              </entity>
                            </fetch>";
            }
            else if (Product.Get(executionContext).ToString() == "Contractors Combined")
            {
                entityName = "lux_contractorscombined";
                attributeName = "lux_contractorscombined";
                fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_contractorscombined'>
                                <attribute name='lux_contractorscombinedid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_riskpostcode' />                               
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_generalcontentsdeclaredvalueincludingmach' />
                                <attribute name='lux_buildingsdeclaredvalue' />
                                <attribute name='lux_listhighvaluestock' />
                                <attribute name='lux_stockexcludinghighvaluestock' />
                                <attribute name='lux_computerandelectronicbusinessequipment' />
                                <attribute name='lux_winesfortifiedwinesspiritsfinesuminsured' />
                                <attribute name='lux_materialdamagecoverdetails' />
                                <attribute name='lux_powertoolssuminsured' />                                
                                <attribute name='lux_tenantsimprovementsdeclaredvalue' />
                                <attribute name='lux_nonferrousmetalssuminsured' />
                                <attribute name='lux_mobilephonessuminsured' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_computerequipmentsuminsured' />
                                <attribute name='lux_audiovideoequipmentsuminsured' />
                                <attribute name='lux_alcoholsuminsured' />
                                <attribute name='lux_computergamesandorconsolessuminsured' />
                                <attribute name='lux_materialdamagelossofrentpayable' />
                                <attribute name='lux_cigarettescigarsortobaccoproductssuminsur' />
                                <attribute name='lux_jewellerywatchessuminsured' />
                                <attribute name='lux_fineartsuminsured' />
                                <attribute name='lux_whattypeofalarmisinstalled' />                                
                                <attribute name='lux_isthereanintruderalarminstalledandinworki' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplications' visible='false' link-type='outer' alias='appln'>
                                  <attribute name='lux_maintradeforthispremises' />
                                  <attribute name='lux_propertyownersapplicationsid' />
                                  <attribute name='lux_thefthazardgroup' />
                                </link-entity>
                              </entity>
                            </fetch>";
            }

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var additionalInfo1 = "";
                var alarmTriggerFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_referral'>
                                                    <attribute name='lux_suppliedvalue' />
                                                    <attribute name='lux_fieldname' />
                                                    <attribute name='lux_approve' />
                                                    <attribute name='lux_additionalinfo' />
                                                    <attribute name='lux_referralid' />
                                                    <order attribute='lux_suppliedvalue' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                                      <condition attribute='lux_fieldschemaname' operator='eq' value='alarmtrigger' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    var alarmFieldName = "";
                    if (Product.Get(executionContext).ToString() == "Pubs & Restaurants" || Product.Get(executionContext).ToString() == "Hotels and Guesthouses" || Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
                    {
                        alarmFieldName = "lux_isthereanintruderalarminstalledandinworki";
                    }
                    else
                    {
                        alarmFieldName = "lux_isthereanintruderalarminstalled";
                    }
                    var AlarmInstalled = item.GetAttributeValue<bool>(alarmFieldName);
                    var alarmType = item.GetAttributeValue<OptionSetValue>("lux_whattypeofalarmisinstalled");

                    var applnId = (Guid)((service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].GetAttributeValue<AliasedValue>("appln.lux_propertyownersapplicationsid")).Value);
                    if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Contains("appln.lux_thefthazardgroup"))
                    {
                        var theftHazardGroup = (int)((service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].GetAttributeValue<AliasedValue>("appln.lux_thefthazardgroup")).Value);
                        var TargetStockItem = item.GetAttributeValue<OptionSetValueCollection>("lux_listhighvaluestock");
                        decimal TargetStock = 0;

                        var Contents = item.Attributes.Contains("lux_generalcontentsdeclaredvalueincludingmach") ? item.GetAttributeValue<Money>("lux_generalcontentsdeclaredvalueincludingmach").Value : 0;
                        var ComputerEquipment = item.Attributes.Contains("lux_computerandelectronicbusinessequipment") ? item.GetAttributeValue<Money>("lux_computerandelectronicbusinessequipment").Value : 0;
                        var StockExcludingTargetStock = item.Attributes.Contains("lux_stockexcludinghighvaluestock") ? item.GetAttributeValue<Money>("lux_stockexcludinghighvaluestock").Value : 0;
                        var MachAndContentIncCompEquip = Contents + ComputerEquipment;
                        if (TargetStockItem != null)
                        {
                            decimal WineSumInsured = item.Attributes.Contains("lux_winesfortifiedwinesspiritsfinesuminsured") ? item.GetAttributeValue<Money>("lux_winesfortifiedwinesspiritsfinesuminsured").Value : 0;
                            decimal NonFerrusInsured = item.Attributes.Contains("lux_nonferrousmetalssuminsured") ? item.GetAttributeValue<Money>("lux_nonferrousmetalssuminsured").Value : 0;
                            decimal MobileInsured = item.Attributes.Contains("lux_mobilephonessuminsured") ? item.GetAttributeValue<Money>("lux_mobilephonessuminsured").Value : 0;
                            decimal ComputerSumInsured = item.Attributes.Contains("lux_computerequipmentsuminsured") ? item.GetAttributeValue<Money>("lux_computerequipmentsuminsured").Value : 0;
                            decimal AlcoholSumInsured = item.Attributes.Contains("lux_alcoholsuminsured") ? item.GetAttributeValue<Money>("lux_alcoholsuminsured").Value : 0;
                            decimal AudioSumInsured = item.Attributes.Contains("lux_audiovideoequipmentsuminsured") ? item.GetAttributeValue<Money>("lux_audiovideoequipmentsuminsured").Value : 0;
                            decimal CigarettesSumInsured = item.Attributes.Contains("lux_cigarettescigarsortobaccoproductssuminsur") ? item.GetAttributeValue<Money>("lux_cigarettescigarsortobaccoproductssuminsur").Value : 0;
                            decimal ComputerGamesInsured = item.Attributes.Contains("lux_computergamesandorconsolessuminsured") ? item.GetAttributeValue<Money>("lux_computergamesandorconsolessuminsured").Value : 0;
                            decimal JewelleryInsured = item.Attributes.Contains("lux_jewellerywatchessuminsured") ? item.GetAttributeValue<Money>("lux_jewellerywatchessuminsured").Value : 0;
                            decimal PowerToolsSumInsured = item.Attributes.Contains("lux_powertoolssuminsured") ? item.GetAttributeValue<Money>("lux_powertoolssuminsured").Value : 0;
                            decimal FineArtSumInsured = item.Attributes.Contains("lux_fineartsuminsured") ? item.GetAttributeValue<Money>("lux_fineartsuminsured").Value : 0;
                            TargetStock = WineSumInsured + NonFerrusInsured + MobileInsured + ComputerSumInsured + AlcoholSumInsured + AudioSumInsured + CigarettesSumInsured + ComputerGamesInsured + JewelleryInsured + PowerToolsSumInsured + FineArtSumInsured;
                        }

                        var alarmFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_alarmtrigger'>
                                            <attribute name='lux_name' />
                                            <attribute name='lux_totalsuminsured' />
                                            <attribute name='lux_targetstocksuminsured' />
                                            <attribute name='lux_stockthefthazardgroup' />
                                            <attribute name='lux_nontargetstocksuminsured' />
                                            <attribute name='lux_machinerycontentsincludingcomputerequipme' />
                                            <attribute name='lux_alarmtriggerid' />
                                            <order attribute='lux_name' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                            </filter>
                                          </entity>
                                        </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(alarmFetch)).Entities.Count > 0)
                        {
                            var alarmData = service.RetrieveMultiple(new FetchExpression(alarmFetch)).Entities;

                            var NoAlarmNonTargetstock = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "No Alarm").GetAttributeValue<Money>("lux_nontargetstocksuminsured").Value;
                            var BellsOnlyNonTargetstock = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "Bells only").GetAttributeValue<Money>("lux_nontargetstocksuminsured").Value;
                            var RedcareNonTargetstock = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "Redcare").GetAttributeValue<Money>("lux_nontargetstocksuminsured").Value;
                            var RedcareGSMNonTargetstock = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "Redcare GSM").GetAttributeValue<Money>("lux_nontargetstocksuminsured").Value;
                            var DualComNonTargetstock = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "Dual com").GetAttributeValue<Money>("lux_nontargetstocksuminsured").Value;
                            var DigicomNonTargetstock = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "Redcare").GetAttributeValue<Money>("lux_nontargetstocksuminsured").Value;

                            var NoAlarmTargetstock = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "No Alarm").GetAttributeValue<Money>("lux_targetstocksuminsured").Value;
                            var BellsOnlyTargetstock = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "Bells only").GetAttributeValue<Money>("lux_targetstocksuminsured").Value;
                            var RedcareTargetstock = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "Redcare").GetAttributeValue<Money>("lux_targetstocksuminsured").Value;
                            var RedcareGSMTargetstock = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "Redcare GSM").GetAttributeValue<Money>("lux_targetstocksuminsured").Value;
                            var DualComTargetstock = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "Dual com").GetAttributeValue<Money>("lux_targetstocksuminsured").Value;
                            var DigicomTargetstock = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "Redcare").GetAttributeValue<Money>("lux_targetstocksuminsured").Value;

                            var NoAlarmMachAndContentIncCompEquip = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "No Alarm").GetAttributeValue<Money>("lux_machinerycontentsincludingcomputerequipme").Value;
                            var BellsOnlyMachAndContentIncCompEquip = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "Bells only").GetAttributeValue<Money>("lux_machinerycontentsincludingcomputerequipme").Value;
                            var RedcareMachAndContentIncCompEquip = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "Redcare").GetAttributeValue<Money>("lux_machinerycontentsincludingcomputerequipme").Value;
                            var RedcareGSMMachAndContentIncCompEquip = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "Redcare GSM").GetAttributeValue<Money>("lux_machinerycontentsincludingcomputerequipme").Value;
                            var DualComMachAndContentIncCompEquip = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "Dual com").GetAttributeValue<Money>("lux_machinerycontentsincludingcomputerequipme").Value;
                            var DigicomMachAndContentIncCompEquip = alarmData.FirstOrDefault(x => x.GetAttributeValue<int>("lux_stockthefthazardgroup") == theftHazardGroup && x.Attributes["lux_name"].ToString() == "Redcare").GetAttributeValue<Money>("lux_machinerycontentsincludingcomputerequipme").Value;

                            if (AlarmInstalled == true)
                            {
                                if (alarmType.Value == 972970001)
                                {
                                    var application1 = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                    application1["lux_targetstockminimumalarmrequirement"] = "Bells only";
                                    application1["lux_minimumalarmrequirement"] = "Bells only";
                                    application1["lux_machinerycontentsminimumalarmrequirement"] = "Bells only";
                                    service.Update(application1);

                                    if (StockExcludingTargetStock <= NoAlarmNonTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);

                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (StockExcludingTargetStock > NoAlarmNonTargetstock && StockExcludingTargetStock <= BellsOnlyNonTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (StockExcludingTargetStock > BellsOnlyNonTargetstock && StockExcludingTargetStock <= RedcareNonTargetstock)
                                    {
                                        var FieldName1 = "Alarm: Redcare or Digicom Alarm";
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            Entity refer = new Entity("lux_referral");
                                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            refer["lux_fieldname"] = "Alarm Trigger";
                                            refer["lux_fieldschemaname"] = "alarmtrigger";
                                            var referId = service.Create(refer);

                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "Bells only";
                                            premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Non Target Stock - Alarm Required";
                                            service.Create(premiserefer);

                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                            {
                                                Entity premiserefer = new Entity("lux_premisereferral");
                                                premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                                premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                                premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                                premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                                premiserefer["lux_fieldname"] = FieldName1;
                                                premiserefer["lux_suppliedvalue"] = "Bells only";
                                                premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                                premiserefer["lux_additionalinfo"] = "Non Target Stock - Alarm Required";
                                                service.Create(premiserefer);
                                                additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            }
                                            else
                                            {
                                                var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                                premiserefer["lux_suppliedvalue"] = "Bells only";
                                                if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Non Target Stock - Alarm Required"))
                                                {
                                                    premiserefer["lux_additionalinfo"] += ", Non Target Stock - Alarm Required";
                                                }
                                                service.Update(premiserefer);
                                            }
                                            if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString()))
                                                additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                        }
                                    }
                                    else if (StockExcludingTargetStock > RedcareNonTargetstock && StockExcludingTargetStock <= RedcareGSMNonTargetstock)
                                    {
                                        var FieldName1 = "Alarm: Redcare GSM or Dualcom Alarm";
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            Entity refer = new Entity("lux_referral");
                                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            refer["lux_fieldname"] = "Alarm Trigger";
                                            refer["lux_fieldschemaname"] = "alarmtrigger";
                                            var referId = service.Create(refer);

                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "Bells only";
                                            premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Non Target Stock - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                            {
                                                Entity premiserefer = new Entity("lux_premisereferral");
                                                premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                                premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                                premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                                premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                                premiserefer["lux_fieldname"] = FieldName1;
                                                premiserefer["lux_suppliedvalue"] = "Bells only";
                                                premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                                premiserefer["lux_additionalinfo"] = "Non Target Stock - Alarm Required";
                                                service.Create(premiserefer);
                                                additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            }
                                            else
                                            {
                                                var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                                premiserefer["lux_suppliedvalue"] = "Bells only";
                                                premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                                if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Non Target Stock - Alarm Required"))
                                                {
                                                    premiserefer["lux_additionalinfo"] += ", Non Target Stock - Alarm Required";
                                                }
                                                service.Update(premiserefer);
                                            }
                                            if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                    }

                                    if (TargetStock <= NoAlarmTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (TargetStock > NoAlarmTargetstock && TargetStock <= BellsOnlyTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (TargetStock > BellsOnlyTargetstock && TargetStock <= RedcareTargetstock)
                                    {
                                        var FieldName1 = "Alarm: Redcare or Digicom Alarm";
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            Entity refer = new Entity("lux_referral");
                                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            refer["lux_fieldname"] = "Alarm Trigger";
                                            refer["lux_fieldschemaname"] = "alarmtrigger";
                                            var referId = service.Create(refer);

                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "Bells only";
                                            premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Target Stock - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                            {
                                                Entity premiserefer = new Entity("lux_premisereferral");
                                                premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                                premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                                premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                                premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                                premiserefer["lux_fieldname"] = FieldName1;
                                                premiserefer["lux_suppliedvalue"] = "Bells only";
                                                premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                                premiserefer["lux_additionalinfo"] = "Target Stock - Alarm Required";
                                                service.Create(premiserefer);
                                                additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            }
                                            else
                                            {
                                                var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                                premiserefer["lux_suppliedvalue"] = "Bells only";
                                                if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Target Stock - Alarm Required"))
                                                {
                                                    premiserefer["lux_additionalinfo"] += ", Target Stock - Alarm Required";
                                                }
                                                service.Update(premiserefer);
                                            }
                                            if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                        }
                                    }
                                    else if (TargetStock > RedcareTargetstock && TargetStock <= RedcareGSMTargetstock)
                                    {
                                        var FieldName1 = "Alarm: Redcare GSM or Dualcom Alarm";
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            Entity refer = new Entity("lux_referral");
                                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            refer["lux_fieldname"] = "Alarm Trigger";
                                            refer["lux_fieldschemaname"] = "alarmtrigger";
                                            var referId = service.Create(refer);

                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "Bells only";
                                            premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Target Stock - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                            {
                                                Entity premiserefer = new Entity("lux_premisereferral");
                                                premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                                premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                                premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                                premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                                premiserefer["lux_fieldname"] = FieldName1;
                                                premiserefer["lux_suppliedvalue"] = "Bells only";
                                                premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                                premiserefer["lux_additionalinfo"] = "Target Stock - Alarm Required";
                                                service.Create(premiserefer);
                                                additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            }
                                            else
                                            {
                                                var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                                premiserefer["lux_suppliedvalue"] = "Bells only";
                                                premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                                if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Target Stock - Alarm Required"))
                                                {
                                                    premiserefer["lux_additionalinfo"] += ", Target Stock - Alarm Required";
                                                }
                                                service.Update(premiserefer);
                                            }
                                            if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString()))
                                                additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                    }

                                    if (MachAndContentIncCompEquip <= NoAlarmMachAndContentIncCompEquip)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (MachAndContentIncCompEquip > NoAlarmMachAndContentIncCompEquip && MachAndContentIncCompEquip <= BellsOnlyMachAndContentIncCompEquip)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (MachAndContentIncCompEquip > BellsOnlyMachAndContentIncCompEquip && MachAndContentIncCompEquip <= RedcareMachAndContentIncCompEquip)
                                    {
                                        var FieldName1 = "Alarm: Redcare or Digicom Alarm";
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            Entity refer = new Entity("lux_referral");
                                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            refer["lux_fieldname"] = "Alarm Trigger";
                                            refer["lux_fieldschemaname"] = "alarmtrigger";
                                            var referId = service.Create(refer);

                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "Bells only";
                                            premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Machinery & Contents - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                            {
                                                Entity premiserefer = new Entity("lux_premisereferral");
                                                premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                                premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                                premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                                premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                                premiserefer["lux_fieldname"] = FieldName1;
                                                premiserefer["lux_suppliedvalue"] = "Bells only";
                                                premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                                premiserefer["lux_additionalinfo"] = "Machinery & Contents - Alarm Required";
                                                service.Create(premiserefer);
                                                additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            }
                                            else
                                            {
                                                var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                                premiserefer["lux_suppliedvalue"] = "Bells only";
                                                premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                                if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Machinery & Contents - Alarm Required"))
                                                {
                                                    premiserefer["lux_additionalinfo"] += ", Machinery & Contents - Alarm Required";
                                                }
                                                service.Update(premiserefer);
                                            }
                                            if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                        }
                                    }
                                    else if (MachAndContentIncCompEquip > RedcareMachAndContentIncCompEquip && MachAndContentIncCompEquip <= RedcareGSMMachAndContentIncCompEquip)
                                    {
                                        var FieldName1 = "Alarm: Redcare GSM or Dualcom Alarm";
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            Entity refer = new Entity("lux_referral");
                                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            refer["lux_fieldname"] = "Alarm Trigger";
                                            refer["lux_fieldschemaname"] = "alarmtrigger";
                                            var referId = service.Create(refer);

                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "Bells only";
                                            premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Machinery & Contents - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                            {
                                                Entity premiserefer = new Entity("lux_premisereferral");
                                                premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                                premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                                premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                                premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                                premiserefer["lux_fieldname"] = FieldName1;
                                                premiserefer["lux_suppliedvalue"] = "Bells only";
                                                premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                                premiserefer["lux_additionalinfo"] = "Machinery & Contents - Alarm Required";
                                                service.Create(premiserefer);
                                                additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            }
                                            else
                                            {
                                                var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                                premiserefer["lux_suppliedvalue"] = "Bells only";
                                                premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                                if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Machinery & Contents - Alarm Required"))
                                                {
                                                    premiserefer["lux_additionalinfo"] += ", Machinery & Contents - Alarm Required";
                                                }
                                                service.Update(premiserefer);
                                            }
                                            if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                    }
                                }
                                else if (alarmType.Value == 972970002)
                                {
                                    var application1 = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                    application1["lux_targetstockminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                    application1["lux_minimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                    application1["lux_machinerycontentsminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                    service.Update(application1);

                                    if (StockExcludingTargetStock <= NoAlarmNonTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (StockExcludingTargetStock > NoAlarmNonTargetstock && StockExcludingTargetStock <= BellsOnlyNonTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Bells only";
                                            service.Update(application);

                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (StockExcludingTargetStock > BellsOnlyNonTargetstock && StockExcludingTargetStock <= RedcareNonTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (StockExcludingTargetStock > RedcareNonTargetstock && StockExcludingTargetStock <= RedcareGSMNonTargetstock)
                                    {
                                        var FieldName1 = "Alarm: Redcare GSM or Dualcom Alarm";
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            Entity refer = new Entity("lux_referral");
                                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            refer["lux_fieldname"] = "Alarm Trigger";
                                            refer["lux_fieldschemaname"] = "alarmtrigger";
                                            var referId = service.Create(refer);

                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "Redcare";
                                            premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Non Target Stock - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                            {
                                                Entity premiserefer = new Entity("lux_premisereferral");
                                                premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                                premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                                premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                                premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                                premiserefer["lux_fieldname"] = FieldName1;
                                                premiserefer["lux_suppliedvalue"] = "Redcare";
                                                premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                                premiserefer["lux_additionalinfo"] = "Non Target Stock - Alarm Required";
                                                service.Create(premiserefer);
                                                additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            }
                                            else
                                            {
                                                var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                                premiserefer["lux_suppliedvalue"] = "Redcare";
                                                premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                                if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Non Target Stock - Alarm Required"))
                                                {
                                                    premiserefer["lux_additionalinfo"] += ", Non Target Stock - Alarm Required";
                                                }
                                                service.Update(premiserefer);
                                            }
                                            if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                    }

                                    if (TargetStock <= NoAlarmTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (TargetStock > NoAlarmTargetstock && TargetStock <= BellsOnlyTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (TargetStock > BellsOnlyTargetstock && TargetStock <= RedcareTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (TargetStock > RedcareTargetstock && TargetStock <= RedcareGSMTargetstock)
                                    {
                                        var FieldName1 = "Alarm: Redcare GSM or Dualcom Alarm";
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            Entity refer = new Entity("lux_referral");
                                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            refer["lux_fieldname"] = "Alarm Trigger";
                                            refer["lux_fieldschemaname"] = "alarmtrigger";
                                            var referId = service.Create(refer);

                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "Redcare";
                                            premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Target Stock - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                            {
                                                Entity premiserefer = new Entity("lux_premisereferral");
                                                premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                                premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                                premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                                premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                                premiserefer["lux_fieldname"] = FieldName1;
                                                premiserefer["lux_suppliedvalue"] = "Redcare";
                                                premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                                premiserefer["lux_additionalinfo"] = "Target Stock - Alarm Required";
                                                service.Create(premiserefer);
                                                additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            }
                                            else
                                            {
                                                var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                                premiserefer["lux_suppliedvalue"] = "Redcare";
                                                premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                                if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Target Stock - Alarm Required"))
                                                {
                                                    premiserefer["lux_additionalinfo"] += ", Target Stock - Alarm Required";
                                                }
                                                service.Update(premiserefer);
                                            }
                                            if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                    }

                                    if (MachAndContentIncCompEquip <= NoAlarmMachAndContentIncCompEquip)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (MachAndContentIncCompEquip > NoAlarmMachAndContentIncCompEquip && MachAndContentIncCompEquip <= BellsOnlyMachAndContentIncCompEquip)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (MachAndContentIncCompEquip > BellsOnlyMachAndContentIncCompEquip && MachAndContentIncCompEquip <= RedcareMachAndContentIncCompEquip)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (MachAndContentIncCompEquip > RedcareMachAndContentIncCompEquip && MachAndContentIncCompEquip <= RedcareGSMMachAndContentIncCompEquip)
                                    {
                                        var FieldName1 = "Alarm: Redcare GSM or Dualcom Alarm";
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            Entity refer = new Entity("lux_referral");
                                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            refer["lux_fieldname"] = "Alarm Trigger";
                                            refer["lux_fieldschemaname"] = "alarmtrigger";
                                            var referId = service.Create(refer);

                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "Redcare";
                                            premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Machinery & Contents - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                            {
                                                Entity premiserefer = new Entity("lux_premisereferral");
                                                premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                                premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                                premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                                premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                                premiserefer["lux_fieldname"] = FieldName1;
                                                premiserefer["lux_suppliedvalue"] = "Redcare";
                                                premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                                premiserefer["lux_additionalinfo"] = "Machinery & Contents - Alarm Required";
                                                service.Create(premiserefer);
                                                additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            }
                                            else
                                            {
                                                var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                                premiserefer["lux_suppliedvalue"] = "Redcare";
                                                premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                                if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Machinery & Contents - Alarm Required"))
                                                {
                                                    premiserefer["lux_additionalinfo"] += ", Machinery & Contents - Alarm Required";
                                                }
                                                service.Update(premiserefer);
                                            }
                                            if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                    }
                                }
                                else if (alarmType.Value == 972970003)
                                {
                                    var application1 = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                    application1["lux_targetstockminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                    application1["lux_minimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                    application1["lux_machinerycontentsminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                    service.Update(application1);

                                    if (StockExcludingTargetStock <= NoAlarmNonTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (StockExcludingTargetStock > NoAlarmNonTargetstock && StockExcludingTargetStock <= BellsOnlyNonTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (StockExcludingTargetStock > BellsOnlyNonTargetstock && StockExcludingTargetStock <= RedcareNonTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (StockExcludingTargetStock > RedcareNonTargetstock && StockExcludingTargetStock <= RedcareGSMNonTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }

                                    if (TargetStock <= NoAlarmTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (TargetStock > NoAlarmTargetstock && TargetStock <= BellsOnlyTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (TargetStock > BellsOnlyTargetstock && TargetStock <= RedcareTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (TargetStock > RedcareTargetstock && TargetStock <= RedcareGSMTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }

                                    if (MachAndContentIncCompEquip <= NoAlarmMachAndContentIncCompEquip)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (MachAndContentIncCompEquip > NoAlarmMachAndContentIncCompEquip && MachAndContentIncCompEquip <= BellsOnlyMachAndContentIncCompEquip)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (MachAndContentIncCompEquip > BellsOnlyMachAndContentIncCompEquip && MachAndContentIncCompEquip <= RedcareMachAndContentIncCompEquip)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (MachAndContentIncCompEquip > RedcareMachAndContentIncCompEquip && MachAndContentIncCompEquip <= RedcareGSMMachAndContentIncCompEquip)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (alarmType.Value == 972970004)
                                {
                                    var application1 = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                    application1["lux_targetstockminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                    application1["lux_minimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                    application1["lux_machinerycontentsminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                    service.Update(application1);

                                    if (StockExcludingTargetStock <= NoAlarmNonTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (StockExcludingTargetStock > NoAlarmNonTargetstock && StockExcludingTargetStock <= BellsOnlyNonTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (StockExcludingTargetStock > BellsOnlyNonTargetstock && StockExcludingTargetStock <= RedcareNonTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (StockExcludingTargetStock > RedcareNonTargetstock && StockExcludingTargetStock <= RedcareGSMNonTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }

                                    if (TargetStock <= NoAlarmTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (TargetStock > NoAlarmTargetstock && TargetStock <= BellsOnlyTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (TargetStock > BellsOnlyTargetstock && TargetStock <= RedcareTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (TargetStock > RedcareTargetstock && TargetStock <= RedcareGSMTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }

                                    if (MachAndContentIncCompEquip <= NoAlarmMachAndContentIncCompEquip)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (MachAndContentIncCompEquip > NoAlarmMachAndContentIncCompEquip && MachAndContentIncCompEquip <= BellsOnlyMachAndContentIncCompEquip)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (MachAndContentIncCompEquip > BellsOnlyMachAndContentIncCompEquip && MachAndContentIncCompEquip <= RedcareMachAndContentIncCompEquip)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (MachAndContentIncCompEquip > RedcareMachAndContentIncCompEquip && MachAndContentIncCompEquip <= RedcareGSMMachAndContentIncCompEquip)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                }
                                else if (alarmType.Value == 972970005)
                                {
                                    var application1 = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                    application1["lux_targetstockminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                    application1["lux_minimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                    application1["lux_machinerycontentsminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                    service.Update(application1);

                                    if (StockExcludingTargetStock <= NoAlarmNonTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (StockExcludingTargetStock > NoAlarmNonTargetstock && StockExcludingTargetStock <= BellsOnlyNonTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (StockExcludingTargetStock > BellsOnlyNonTargetstock && StockExcludingTargetStock <= RedcareNonTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (StockExcludingTargetStock > RedcareNonTargetstock && StockExcludingTargetStock <= RedcareGSMNonTargetstock)
                                    {
                                        var FieldName1 = "Alarm: Redcare GSM or Dualcom Alarm";
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            Entity refer = new Entity("lux_referral");
                                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            refer["lux_fieldname"] = "Alarm Trigger";
                                            refer["lux_fieldschemaname"] = "alarmtrigger";
                                            var referId = service.Create(refer);

                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "Digicom";
                                            premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Non Target Stock - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                            {
                                                Entity premiserefer = new Entity("lux_premisereferral");
                                                premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                                premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                                premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                                premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                                premiserefer["lux_fieldname"] = FieldName1;
                                                premiserefer["lux_suppliedvalue"] = "Digicom";
                                                premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                                premiserefer["lux_additionalinfo"] = "Non Target Stock - Alarm Required";
                                                service.Create(premiserefer);
                                                additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            }
                                            else
                                            {
                                                var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                                premiserefer["lux_suppliedvalue"] = "Digicom";
                                                premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                                if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Non Target Stock - Alarm Required"))
                                                {
                                                    premiserefer["lux_additionalinfo"] += ", Non Target Stock - Alarm Required";
                                                }
                                                service.Update(premiserefer);
                                            }
                                            if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_minimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                    }

                                    if (TargetStock <= NoAlarmTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (TargetStock > NoAlarmTargetstock && TargetStock <= BellsOnlyTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (TargetStock > BellsOnlyTargetstock && TargetStock <= RedcareTargetstock)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (TargetStock > RedcareTargetstock && TargetStock <= RedcareGSMTargetstock)
                                    {
                                        var FieldName1 = "Alarm: Redcare GSM or Dualcom Alarm";
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            Entity refer = new Entity("lux_referral");
                                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            refer["lux_fieldname"] = "Alarm Trigger";
                                            refer["lux_fieldschemaname"] = "alarmtrigger";
                                            var referId = service.Create(refer);

                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "Digicom";
                                            premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Target Stock - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                            {
                                                Entity premiserefer = new Entity("lux_premisereferral");
                                                premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                                premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                                premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                                premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                                premiserefer["lux_fieldname"] = FieldName1;
                                                premiserefer["lux_suppliedvalue"] = "Digicom";
                                                premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                                premiserefer["lux_additionalinfo"] = "Target Stock - Alarm Required";
                                                service.Create(premiserefer);
                                                additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            }
                                            else
                                            {
                                                var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                                premiserefer["lux_suppliedvalue"] = "Digicom";
                                                premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                                if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Target Stock - Alarm Required"))
                                                {
                                                    premiserefer["lux_additionalinfo"] += ", Target Stock - Alarm Required";
                                                }
                                                service.Update(premiserefer);
                                            }
                                            if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_targetstockminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                    }

                                    if (MachAndContentIncCompEquip <= NoAlarmMachAndContentIncCompEquip)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "No Alarm";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (MachAndContentIncCompEquip > NoAlarmMachAndContentIncCompEquip && MachAndContentIncCompEquip <= BellsOnlyMachAndContentIncCompEquip)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Bells only";
                                            service.Update(application);
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (MachAndContentIncCompEquip > BellsOnlyMachAndContentIncCompEquip && MachAndContentIncCompEquip <= RedcareMachAndContentIncCompEquip)
                                    {
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                            {
                                                foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                                {
                                                    service.Delete("lux_premisereferral", referitem.Id);
                                                }
                                            }
                                        }
                                    }
                                    else if (MachAndContentIncCompEquip > RedcareMachAndContentIncCompEquip && MachAndContentIncCompEquip <= RedcareGSMMachAndContentIncCompEquip)
                                    {
                                        var FieldName1 = "Alarm: Redcare GSM or Dualcom Alarm";
                                        if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                        {
                                            Entity refer = new Entity("lux_referral");
                                            refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            refer["lux_fieldname"] = "Alarm Trigger";
                                            refer["lux_fieldschemaname"] = "alarmtrigger";
                                            var referId = service.Create(refer);

                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "Digicom";
                                            premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Machinery & Contents - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                        else
                                        {
                                            var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                            if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                            {
                                                Entity premiserefer = new Entity("lux_premisereferral");
                                                premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                                premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                                premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                                premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                                premiserefer["lux_fieldname"] = FieldName1;
                                                premiserefer["lux_suppliedvalue"] = "Digicom";
                                                premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                                premiserefer["lux_additionalinfo"] = "Machinery & Contents - Alarm Required";
                                                service.Create(premiserefer);
                                                additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            }
                                            else
                                            {
                                                var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                                premiserefer["lux_suppliedvalue"] = "Digicom";
                                                premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                                if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Machinery & Contents - Alarm Required"))
                                                {
                                                    premiserefer["lux_additionalinfo"] += ", Machinery & Contents - Alarm Required";
                                                }
                                                service.Update(premiserefer);
                                            }
                                            if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                            else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                            var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                            application["lux_machinerycontentsminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                            service.Update(application);
                                        }
                                    }
                                }
                            }
                            else
                            {
                                var application1 = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                application1["lux_targetstockminimumalarmrequirement"] = "No Alarm";
                                application1["lux_minimumalarmrequirement"] = "No Alarm";
                                application1["lux_machinerycontentsminimumalarmrequirement"] = "No Alarm";
                                application1["lux_machinerycontentsminimumalarmrequirement"] = "No Alarm";
                                service.Update(application1);

                                if (StockExcludingTargetStock <= NoAlarmNonTargetstock)
                                {
                                    if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                    {
                                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                        if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                        {
                                            foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                            {
                                                service.Delete("lux_premisereferral", referitem.Id);
                                            }
                                        }
                                    }
                                }
                                else if (StockExcludingTargetStock > NoAlarmNonTargetstock && StockExcludingTargetStock <= BellsOnlyNonTargetstock)
                                {
                                    var FieldName1 = "Alarm: Bells only Alarm";
                                    if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                    {
                                        Entity refer = new Entity("lux_referral");
                                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        refer["lux_fieldname"] = "Alarm Trigger";
                                        refer["lux_fieldschemaname"] = "alarmtrigger";
                                        var referId = service.Create(refer);

                                        Entity premiserefer = new Entity("lux_premisereferral");
                                        premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                        premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                        premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                        premiserefer["lux_fieldname"] = FieldName1;
                                        premiserefer["lux_suppliedvalue"] = "No Alarm";
                                        premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                        premiserefer["lux_additionalinfo"] = "Non Target Stock - Alarm Required";
                                        service.Create(premiserefer);
                                        additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_minimumalarmrequirement"] = "Bells only Alarm";
                                        service.Update(application);
                                    }
                                    else
                                    {
                                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                        if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                        {
                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Non Target Stock - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        }
                                        else
                                        {
                                            var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                            if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Non Target Stock - Alarm Required"))
                                            {
                                                premiserefer["lux_additionalinfo"] += ", Non Target Stock - Alarm Required";
                                            }
                                            service.Update(premiserefer);
                                        }
                                        if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_minimumalarmrequirement"] = "Bells only Alarm";
                                        service.Update(application);
                                    }
                                }
                                else if (StockExcludingTargetStock > BellsOnlyNonTargetstock && StockExcludingTargetStock <= RedcareNonTargetstock)
                                {
                                    var FieldName1 = "Alarm: Redcare or Digicom Alarm";
                                    if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                    {
                                        Entity refer = new Entity("lux_referral");
                                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        refer["lux_fieldname"] = "Alarm Trigger";
                                        refer["lux_fieldschemaname"] = "alarmtrigger";
                                        var referId = service.Create(refer);

                                        Entity premiserefer = new Entity("lux_premisereferral");
                                        premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                        premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                        premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                        premiserefer["lux_fieldname"] = FieldName1;
                                        premiserefer["lux_suppliedvalue"] = "No Alarm";
                                        premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                        premiserefer["lux_additionalinfo"] = "Non Target Stock - Alarm Required";
                                        service.Create(premiserefer);
                                        additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_minimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                        service.Update(application);
                                    }
                                    else
                                    {
                                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                        if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                        {
                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Non Target Stock - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        }
                                        else
                                        {
                                            var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                            if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Non Target Stock - Alarm Required"))
                                            {
                                                premiserefer["lux_additionalinfo"] += ", Non Target Stock - Alarm Required";
                                            }
                                            service.Update(premiserefer);
                                        }
                                        if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_minimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                        service.Update(application);
                                    }
                                }
                                else if (StockExcludingTargetStock > RedcareNonTargetstock && StockExcludingTargetStock <= RedcareGSMNonTargetstock)
                                {
                                    var FieldName1 = "Alarm: Redcare GSM or Dualcom Alarm";
                                    if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                    {
                                        Entity refer = new Entity("lux_referral");
                                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        refer["lux_fieldname"] = "Alarm Trigger";
                                        refer["lux_fieldschemaname"] = "alarmtrigger";
                                        var referId = service.Create(refer);

                                        Entity premiserefer = new Entity("lux_premisereferral");
                                        premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                        premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                        premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                        premiserefer["lux_fieldname"] = FieldName1;
                                        premiserefer["lux_suppliedvalue"] = "No Alarm";
                                        premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                        premiserefer["lux_additionalinfo"] = "Non Target Stock - Alarm Required";
                                        service.Create(premiserefer);
                                        additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_minimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                        service.Update(application);
                                    }
                                    else
                                    {
                                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='nontargetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                        if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                        {
                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Non Target Stock - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        }
                                        else
                                        {
                                            var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "nontargetalarmtrigger";
                                            if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Non Target Stock - Alarm Required"))
                                            {
                                                premiserefer["lux_additionalinfo"] += ", Non Target Stock - Alarm Required";
                                            }
                                            service.Update(premiserefer);
                                        }
                                        if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_minimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                        service.Update(application);
                                    }
                                }

                                if (TargetStock <= NoAlarmTargetstock)
                                {
                                    if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                    {
                                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                        if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                        {
                                            foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                            {
                                                service.Delete("lux_premisereferral", referitem.Id);
                                            }
                                        }
                                    }
                                }
                                else if (TargetStock > NoAlarmTargetstock && TargetStock <= BellsOnlyTargetstock)
                                {
                                    var FieldName1 = "Alarm: Bells only Alarm";
                                    if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                    {
                                        Entity refer = new Entity("lux_referral");
                                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        refer["lux_fieldname"] = "Alarm Trigger";
                                        refer["lux_fieldschemaname"] = "alarmtrigger";
                                        var referId = service.Create(refer);

                                        Entity premiserefer = new Entity("lux_premisereferral");
                                        premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                        premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                        premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                        premiserefer["lux_fieldname"] = FieldName1;
                                        premiserefer["lux_suppliedvalue"] = "No Alarm";
                                        premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                        premiserefer["lux_additionalinfo"] = "Target Stock - Alarm Required";
                                        service.Create(premiserefer);
                                        additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_targetstockminimumalarmrequirement"] = "Bells only Alarm";
                                        service.Update(application);
                                    }
                                    else
                                    {
                                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                        if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                        {
                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Target Stock - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        }
                                        else
                                        {
                                            var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                            if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Target Stock - Alarm Required"))
                                            {
                                                premiserefer["lux_additionalinfo"] += ", Target Stock - Alarm Required";
                                            }
                                            service.Update(premiserefer);
                                        }
                                        if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_targetstockminimumalarmrequirement"] = "Bells only Alarm";
                                        service.Update(application);
                                    }
                                }
                                else if (TargetStock > BellsOnlyTargetstock && TargetStock <= RedcareTargetstock)
                                {
                                    var FieldName1 = "Alarm: Redcare or Digicom Alarm";
                                    if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                    {
                                        Entity refer = new Entity("lux_referral");
                                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        refer["lux_fieldname"] = "Alarm Trigger";
                                        refer["lux_fieldschemaname"] = "alarmtrigger";
                                        var referId = service.Create(refer);

                                        Entity premiserefer = new Entity("lux_premisereferral");
                                        premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                        premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                        premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                        premiserefer["lux_fieldname"] = FieldName1;
                                        premiserefer["lux_suppliedvalue"] = "No Alarm";
                                        premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                        premiserefer["lux_additionalinfo"] = "Target Stock - Alarm Required";
                                        service.Create(premiserefer);
                                        additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_targetstockminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                        service.Update(application);
                                    }
                                    else
                                    {
                                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                        if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                        {
                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Target Stock - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        }
                                        else
                                        {
                                            var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                            if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Target Stock - Alarm Required"))
                                            {
                                                premiserefer["lux_additionalinfo"] += ", Target Stock - Alarm Required";
                                            }
                                            service.Update(premiserefer);
                                        }
                                        if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_targetstockminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                        service.Update(application);
                                    }
                                }
                                else if (TargetStock > RedcareTargetstock && TargetStock <= RedcareGSMTargetstock)
                                {
                                    var FieldName1 = "Alarm: Redcare GSM or Dualcom Alarm";
                                    if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                    {
                                        Entity refer = new Entity("lux_referral");
                                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        refer["lux_fieldname"] = "Alarm Trigger";
                                        refer["lux_fieldschemaname"] = "alarmtrigger";
                                        var referId = service.Create(refer);

                                        Entity premiserefer = new Entity("lux_premisereferral");
                                        premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                        premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                        premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                        premiserefer["lux_fieldname"] = FieldName1;
                                        premiserefer["lux_suppliedvalue"] = "No Alarm";
                                        premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                        premiserefer["lux_additionalinfo"] = "Target Stock - Alarm Required";
                                        service.Create(premiserefer);
                                        additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_targetstockminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                        service.Update(application);
                                    }
                                    else
                                    {
                                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='targetalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                        if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                        {
                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Target Stock - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        }
                                        else
                                        {
                                            var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "targetalarmtrigger";
                                            if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Target Stock - Alarm Required"))
                                            {
                                                premiserefer["lux_additionalinfo"] += ", Target Stock - Alarm Required";
                                            }
                                            service.Update(premiserefer);
                                        }
                                        if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_targetstockminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                        service.Update(application);
                                    }
                                }

                                if (MachAndContentIncCompEquip <= NoAlarmMachAndContentIncCompEquip)
                                {
                                    if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count > 0)
                                    {
                                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                        if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count > 0)
                                        {
                                            foreach (var referitem in service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities)
                                            {
                                                service.Delete("lux_premisereferral", referitem.Id);
                                            }
                                        }
                                    }
                                }
                                else if (MachAndContentIncCompEquip > NoAlarmMachAndContentIncCompEquip && MachAndContentIncCompEquip <= BellsOnlyMachAndContentIncCompEquip)
                                {
                                    var FieldName1 = "Alarm: Bells only Alarm";
                                    if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                    {
                                        Entity refer = new Entity("lux_referral");
                                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        refer["lux_fieldname"] = "Alarm Trigger";
                                        refer["lux_fieldschemaname"] = "alarmtrigger";
                                        var referId = service.Create(refer);

                                        Entity premiserefer = new Entity("lux_premisereferral");
                                        premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                        premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                        premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                        premiserefer["lux_fieldname"] = FieldName1;
                                        premiserefer["lux_suppliedvalue"] = "No Alarm";
                                        premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                        premiserefer["lux_additionalinfo"] = "Machinery & Contents - Alarm Required";
                                        service.Create(premiserefer);
                                        additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_machinerycontentsminimumalarmrequirement"] = "Bells only Alarm";
                                        service.Update(application);
                                    }
                                    else
                                    {
                                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                        if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                        {
                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Machinery & Contents - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        }
                                        else
                                        {
                                            var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                            if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Machinery & Contents - Alarm Required"))
                                            {
                                                premiserefer["lux_additionalinfo"] += ", Machinery & Contents - Alarm Required";
                                            }
                                            service.Update(premiserefer);
                                        }
                                        if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_machinerycontentsminimumalarmrequirement"] = "Bells only Alarm";
                                        service.Update(application);
                                    }
                                }
                                else if (MachAndContentIncCompEquip > BellsOnlyMachAndContentIncCompEquip && MachAndContentIncCompEquip <= RedcareMachAndContentIncCompEquip)
                                {
                                    var FieldName1 = "Alarm: Redcare or Digicom Alarm";
                                    if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                    {
                                        Entity refer = new Entity("lux_referral");
                                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        refer["lux_fieldname"] = "Alarm Trigger";
                                        refer["lux_fieldschemaname"] = "alarmtrigger";
                                        var referId = service.Create(refer);

                                        Entity premiserefer = new Entity("lux_premisereferral");
                                        premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                        premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                        premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                        premiserefer["lux_fieldname"] = FieldName1;
                                        premiserefer["lux_suppliedvalue"] = "No Alarm";
                                        premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                        premiserefer["lux_additionalinfo"] = "Machinery & Contents - Alarm Required";
                                        service.Create(premiserefer);
                                        additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_machinerycontentsminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                        service.Update(application);
                                    }
                                    else
                                    {
                                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                        if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                        {
                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Machinery & Contents - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        }
                                        else
                                        {
                                            var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                            if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Machinery & Contents - Alarm Required"))
                                            {
                                                premiserefer["lux_additionalinfo"] += ", Machinery & Contents - Alarm Required";
                                            }
                                            service.Update(premiserefer);
                                        }
                                        if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");

                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_machinerycontentsminimumalarmrequirement"] = "Redcare or Digicom Alarm";
                                        service.Update(application);
                                    }
                                }
                                else if (MachAndContentIncCompEquip > RedcareMachAndContentIncCompEquip && MachAndContentIncCompEquip <= RedcareGSMMachAndContentIncCompEquip)
                                {
                                    var FieldName1 = "Alarm: Redcare GSM or Dualcom Alarm";
                                    if (service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities.Count == 0)
                                    {
                                        Entity refer = new Entity("lux_referral");
                                        refer["lux_propertyownersapplication"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        refer["lux_fieldname"] = "Alarm Trigger";
                                        refer["lux_fieldschemaname"] = "alarmtrigger";
                                        var referId = service.Create(refer);

                                        Entity premiserefer = new Entity("lux_premisereferral");
                                        premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                        premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                        premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                        premiserefer["lux_referral"] = new EntityReference("lux_referral", referId);
                                        premiserefer["lux_fieldname"] = FieldName1;
                                        premiserefer["lux_suppliedvalue"] = "No Alarm";
                                        premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                        premiserefer["lux_additionalinfo"] = "Machinery & Contents - Alarm Required";
                                        service.Create(premiserefer);
                                        additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");

                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_machinerycontentsminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                        service.Update(application);
                                    }
                                    else
                                    {
                                        var premisefetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                          <entity name='lux_premisereferral'>
                                                            <attribute name='lux_premisereferralid' />
                                                            <attribute name='lux_name' />
                                                            <attribute name='createdon' />
                                                            <attribute name='lux_suppliedvalue' />
                                                            <attribute name='lux_retailproduct' />
                                                            <attribute name='lux_referral' />
                                                            <attribute name='lux_fieldname' />
                                                            <attribute name='lux_application' />
                                                            <attribute name='lux_additionalinfo' />
                                                            <order attribute='lux_name' descending='false' />
                                                            <filter type='and'>
                                                              <condition attribute='statecode' operator='eq' value='0' />
                                                              <condition attribute='lux_referral' operator='eq' uiname='' uitype='lux_referral' value='{service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id}' />
                                                              <condition attribute='{attributeName}' operator='eq' uiname='' uitype='{entityName}' value='{item.Id}' />
                                                              <condition attribute='lux_fieldschemaname' operator='eq' value='machineryalarmtrigger' />
                                                            </filter>
                                                          </entity>
                                                        </fetch>";

                                        if (service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities.Count == 0)
                                        {
                                            Entity premiserefer = new Entity("lux_premisereferral");
                                            premiserefer[attributeName] = new EntityReference(entityName, item.Id);
                                            premiserefer["lux_application"] = new EntityReference("lux_propertyownersapplications", applnId);
                                            premiserefer["lux_riskpostcode"] = item.Attributes["lux_riskpostcode"].ToString();
                                            premiserefer["lux_referral"] = new EntityReference("lux_referral", service.RetrieveMultiple(new FetchExpression(alarmTriggerFetch)).Entities[0].Id);
                                            premiserefer["lux_fieldname"] = FieldName1;
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                            premiserefer["lux_additionalinfo"] = "Machinery & Contents - Alarm Required";
                                            service.Create(premiserefer);
                                            additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        }
                                        else
                                        {
                                            var premiserefer = service.RetrieveMultiple(new FetchExpression(premisefetch)).Entities[0];
                                            premiserefer["lux_suppliedvalue"] = "No Alarm";
                                            premiserefer["lux_fieldschemaname"] = "machineryalarmtrigger";
                                            if (!premiserefer.Attributes["lux_additionalinfo"].ToString().Contains("Machinery & Contents - Alarm Required"))
                                            {
                                                premiserefer["lux_additionalinfo"] += ", Machinery & Contents - Alarm Required";
                                            }
                                            service.Update(premiserefer);
                                        }
                                        if (additionalInfo1 == "") additionalInfo1 = "Refer Premises: " + item.GetAttributeValue<int>("lux_locationnumber");
                                        else if (!additionalInfo1.Contains(item.GetAttributeValue<int>("lux_locationnumber").ToString())) additionalInfo1 += ", " + item.GetAttributeValue<int>("lux_locationnumber");


                                        var application = service.Retrieve("lux_propertyownersapplications", appln.Id, new ColumnSet());
                                        application["lux_machinerycontentsminimumalarmrequirement"] = "Redcare GSM or Dualcom Alarm";
                                        service.Update(application);
                                    }
                                }
                            }
                        }
                    }

                    var fetch2 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_referral'>
                                    <attribute name='lux_suppliedvalue' />
                                    <attribute name='lux_fieldname' />
                                    <attribute name='lux_approve' />
                                    <attribute name='lux_additionalinfo' />
                                    <attribute name='lux_referralid' />
                                    <order attribute='lux_suppliedvalue' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                      <condition attribute='lux_fieldschemaname' operator='eq' value='alarmtrigger' />
                                    </filter>
                                  </entity>
                                </fetch>";

                    if (service.RetrieveMultiple(new FetchExpression(fetch2)).Entities.Count > 0)
                    {
                        Entity refer = new Entity("lux_referral", service.RetrieveMultiple(new FetchExpression(fetch2)).Entities[0].Id);
                        refer["lux_additionalinfo"] = additionalInfo1;
                        service.Update(refer);
                    }
                }
            }
        }
    }
}