﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculateMDPremiumcopy : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownerspremise'>
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_tenanttype' />
                                <attribute name='lux_declaredvalueforrebuildingthisproperty' />
                                <attribute name='lux_buildingconstruction' />
                                <attribute name='lux_totalsuminsuredforthislocation' />
                                <attribute name='lux_basisofcover' />
                                <attribute name='lux_occupancytype' />
                                <attribute name='lux_suminsuredwithupliftedamount' />
                                <attribute name='lux_landlordscontentsinresidentialareas' />
                                <attribute name='lux_totalnumberofcommercialunitsatthisaddress' />
                                <attribute name='lux_howmanyfloorsareofconcreteconstruction' />
                                <attribute name='lux_howmanyfloorsareofwoodenconstruction' />
                                <attribute name='lux_commercialunit1' />
                                <attribute name='lux_commercialunit2' />
                                <attribute name='lux_commercialunit3' />
                                <attribute name='lux_commercialunit4' />
                                <attribute name='lux_commercialunit5' />
                                <attribute name='lux_commercialunit6' />
                                <attribute name='lux_commercialunit7' />
                                <attribute name='lux_commercialunit8' />
                                <attribute name='lux_commercialunit9' />
                                <attribute name='lux_commercialunit10' />
                                <attribute name='lux_lossofannualrentalincome' />
                                <attribute name='lux_indemnityperiodrequired' />
                                <attribute name='lux_propertyownerspremiseid' />
                                <attribute name='lux_materialdamagepremium' />
                                <attribute name='lux_materialdamageperilsrate' />
                                <attribute name='lux_covers' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplication' visible='false' link-type='outer' alias='poa'>
                                  <attribute name='lux_levelofcommission' />
                                  <attribute name='lux_whatisyourtrade' />
                                </link-entity>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var NoOfLocations = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count;
                decimal TotalMDPremium = 0;
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    var premise_data = item;
                    var covers = premise_data.GetAttributeValue<OptionSetValueCollection>("lux_covers");
                    var sum_Insured = premise_data.Contains("lux_totalsuminsuredforthislocation") ? premise_data.GetAttributeValue<Money>("lux_totalsuminsuredforthislocation").Value : 0;
                    var BuildingDeclaredValue = premise_data.Contains("lux_declaredvalueforrebuildingthisproperty") ? premise_data.GetAttributeValue<Money>("lux_declaredvalueforrebuildingthisproperty").Value : 0;
                    var ContentsDeclaredValue = premise_data.Contains("lux_landlordscontentsinresidentialareas") ? premise_data.GetAttributeValue<Money>("lux_landlordscontentsinresidentialareas").Value : 0;

                    decimal MDFireRate = 0;
                    decimal SI_rate = 0;
                    decimal TotalRate = 0;
                    decimal GrossRate = 0;
                    Guid Trade = new Guid();
                    if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970002 || item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970003) //residential and unoccupied
                    {
                        Trade = new Guid("a5b3a7d4-9481-eb11-b1b3-000d3a7ed67b");
                        if (item.Contains("poa.lux_whatisyourtrade"))
                        {
                            if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970001)
                            {
                                Trade = new Guid("c2ada7d4-9481-eb11-b1b3-000d3a7ed67b");
                            }
                            else if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970002)
                            {
                                Trade = new Guid("9fb3a7d4-9481-eb11-b1b3-000d3a7ed67b");
                            }
                            else if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970003)
                            {
                                Trade = new Guid("a5b3a7d4-9481-eb11-b1b3-000d3a7ed67b");
                            }
                            else if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970004)
                            {
                                Trade = new Guid("a5b3a7d4-9481-eb11-b1b3-000d3a7ed67b");
                            }
                            else if (((OptionSetValue)((item.GetAttributeValue<AliasedValue>("poa.lux_whatisyourtrade")).Value)).Value == 972970005)
                            {
                                Trade = new Guid("a3b3a7d4-9481-eb11-b1b3-000d3a7ed67b");
                            }
                        }

                        var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_propertyownersrateid' operator='eq' uiname='' uitype='lux_propertyownersrate' value='{Trade}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                        {
                            var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];
                            MDFireRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");

                            var timberCount = 0;
                            decimal ConstructionLoad = 0;
                            decimal TenantLoad = 0;
                            decimal ConsructionFireRate = MDFireRate;

                            var timber = premise_data.Contains("lux_howmanyfloorsareofwoodenconstruction") ? premise_data.Attributes["lux_howmanyfloorsareofwoodenconstruction"].ToString() : "";

                            if (timber != "" && !timber.Contains("0"))
                            {
                                timberCount = 1;
                            }

                            if (timberCount == 1)
                            {
                                ConstructionLoad = 15;
                                ConsructionFireRate = MDFireRate + MDFireRate * ConstructionLoad / 100;
                            }

                            var tenantType = premise_data.Contains("lux_tenanttype") ? premise_data.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value : 0;
                            if (tenantType != 0)
                            {
                                var TenantFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                              <entity name='lux_tenanttypeloaddiscount'>
                                                                <attribute name='lux_name' />
                                                                <attribute name='createdon' />
                                                                <attribute name='lux_loaddiscount' />
                                                                <attribute name='lux_tenanttypeloaddiscountid' />
                                                                <order attribute='lux_name' descending='false' />
                                                                <filter type='and'>
                                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                                  <condition attribute='lux_tenanttype' operator='eq' value='{tenantType}' />
                                                                </filter>
                                                              </entity>
                                                            </fetch>";
                                if (service.RetrieveMultiple(new FetchExpression(TenantFetch)).Entities.Count > 0)
                                {
                                    var LoadData = service.RetrieveMultiple(new FetchExpression(TenantFetch)).Entities[0];
                                    TenantLoad = LoadData.GetAttributeValue<decimal>("lux_loaddiscount");
                                }
                            }
                            GrossRate = ConsructionFireRate + ConsructionFireRate * TenantLoad / 100;
                        }
                    }
                    else if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970004) //commercial with residential
                    {
                        var numberofTrades = item.Attributes.Contains("lux_totalnumberofcommercialunitsatthisaddress") ? item.GetAttributeValue<int>("lux_totalnumberofcommercialunitsatthisaddress") : 0;
                        decimal FireRate = 0;
                        if (numberofTrades > 0)
                        {
                            for (int i = 1; i <= numberofTrades; i++)
                            {
                                var fieldName = "lux_commercialunit" + i;
                                Trade = item.GetAttributeValue<EntityReference>(fieldName).Id;

                                var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_propertyownersrateid' operator='eq' uiname='' uitype='lux_propertyownersrate' value='{Trade}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                                {
                                    var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];
                                    FireRate += FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                }
                            }

                            MDFireRate = FireRate / numberofTrades;

                            var timberCount = 0;
                            decimal ConstructionLoad = 0;
                            decimal TenantLoad = 0;
                            decimal ConsructionFireRate = MDFireRate;

                            var timber = premise_data.Contains("lux_howmanyfloorsareofwoodenconstruction") ? premise_data.Attributes["lux_howmanyfloorsareofwoodenconstruction"].ToString() : "";

                            if (timber != "" && !timber.Contains("0"))
                            {
                                timberCount = 1;
                            }

                            if (timberCount == 1)
                            {
                                ConstructionLoad = 15;
                                ConsructionFireRate = MDFireRate + MDFireRate * ConstructionLoad / 100;
                            }

                            var tenantType = premise_data.Contains("lux_tenanttype") ? premise_data.GetAttributeValue<OptionSetValue>("lux_tenanttype").Value : 0;
                            if (tenantType != 0)
                            {
                                var TenantFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                              <entity name='lux_tenanttypeloaddiscount'>
                                                                <attribute name='lux_name' />
                                                                <attribute name='createdon' />
                                                                <attribute name='lux_loaddiscount' />
                                                                <attribute name='lux_tenanttypeloaddiscountid' />
                                                                <order attribute='lux_name' descending='false' />
                                                                <filter type='and'>
                                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                                  <condition attribute='lux_tenanttype' operator='eq' value='{tenantType}' />
                                                                </filter>
                                                              </entity>
                                                            </fetch>";
                                if (service.RetrieveMultiple(new FetchExpression(TenantFetch)).Entities.Count > 0)
                                {
                                    var LoadData = service.RetrieveMultiple(new FetchExpression(TenantFetch)).Entities[0];
                                    TenantLoad = LoadData.GetAttributeValue<decimal>("lux_loaddiscount");
                                }
                            }
                            GrossRate = ConsructionFireRate + ConsructionFireRate * TenantLoad / 100;
                        }
                    }
                    else if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970001) //commercial
                    {
                        var numberofTrades = item.Attributes.Contains("lux_totalnumberofcommercialunitsatthisaddress") ? item.GetAttributeValue<int>("lux_totalnumberofcommercialunitsatthisaddress") : 0;
                        decimal FireRate = 0;
                        if (numberofTrades > 0)
                        {
                            for (int i = 1; i <= numberofTrades; i++)
                            {
                                var fieldName = "lux_commercialunit" + i;
                                Trade = item.GetAttributeValue<EntityReference>(fieldName).Id;

                                var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_propertyownersrateid' operator='eq' uiname='' uitype='lux_propertyownersrate' value='{Trade}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                                if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                                {
                                    var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];
                                    FireRate += FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                }
                            }

                            MDFireRate = FireRate / numberofTrades;

                            var timberCount = 0;
                            decimal ConstructionLoad = 0;
                            decimal ConsructionFireRate = MDFireRate;

                            var timber = premise_data.Contains("lux_howmanyfloorsareofwoodenconstruction") ? premise_data.Attributes["lux_howmanyfloorsareofwoodenconstruction"].ToString() : "";

                            if (timber != "" && !timber.Contains("0"))
                            {
                                timberCount = 1;
                            }

                            if (timberCount == 1)
                            {
                                ConstructionLoad = 15;
                                ConsructionFireRate = MDFireRate + MDFireRate * ConstructionLoad / 100;
                            }
                            GrossRate = ConsructionFireRate;
                        }
                    }

                    if (covers != null && sum_Insured > 0)
                    {
                        var TotalSumInsuredFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_totalsuminsuredrate'>
                                                    <attribute name='lux_5m25m' />
                                                    <attribute name='lux_50m100m' />
                                                    <attribute name='lux_25m50m' />
                                                    <attribute name='lux_100m200m' />
                                                    <attribute name='lux_05m' />
                                                    <attribute name='lux_totalsuminsuredrateid' />
                                                    <attribute name='lux_peril' />
                                                    <order attribute='lux_05m' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />";
                        if (covers != null)
                        {
                            TotalSumInsuredFetch += $@"<condition attribute='lux_peril' operator='contain-values'>";
                            foreach (var cover in covers)
                            {
                                TotalSumInsuredFetch += $@"<value>" + cover.Value + "</value>";
                            }
                            TotalSumInsuredFetch += $@"</condition>";
                        }
                        TotalSumInsuredFetch += $@"</filter>
                                                  </entity>
                                                </fetch>";

                        if (service.RetrieveMultiple(new FetchExpression(TotalSumInsuredFetch)).Entities.Count > 0)
                        {
                            var SI_data = service.RetrieveMultiple(new FetchExpression(TotalSumInsuredFetch)).Entities;
                            var SI_field = "";
                            if (sum_Insured < 5000000)
                            {
                                SI_field = "lux_05m";
                            }
                            else if (sum_Insured >= 5000000 && sum_Insured < 25000000)
                            {
                                SI_field = "lux_5m25m";
                            }
                            else if (sum_Insured >= 25000000 && sum_Insured < 50000000)
                            {
                                SI_field = "lux_25m50m";
                            }
                            else if (sum_Insured >= 50000000 && sum_Insured < 100000000)
                            {
                                SI_field = "lux_50m100m";
                            }
                            else if (sum_Insured >= 100000000 && sum_Insured < 200000000)
                            {
                                SI_field = "lux_100m200m";
                            }
                            SI_rate = SI_data.Sum(x => x.GetAttributeValue<decimal>(SI_field)) * 100;
                        }

                        //if (item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970002 || item.GetAttributeValue<OptionSetValue>("lux_occupancytype").Value == 972970004) //residential and commercial with residential
                        //{
                        TotalRate = GrossRate + SI_rate;
                        //}
                        //else
                        //{
                        //    TotalRate = MDFireRate + SI_rate;
                        //}
                        var MD_Total_Premium = BuildingDeclaredValue * TotalRate / 100 + ContentsDeclaredValue * Convert.ToDecimal(0.125) / 100;

                        TotalMDPremium += MD_Total_Premium;

                        var item1 = service.Retrieve("lux_propertyownerspremise", item.Id, new ColumnSet(false));
                        if (MD_Total_Premium < Convert.ToDecimal(37.5))
                        {
                            item1["lux_materialdamagepremium"] = new Money(Convert.ToDecimal(37.5));
                        }
                        else
                        {
                            item1["lux_materialdamagepremium"] = new Money(MD_Total_Premium);
                        }
                        item1["lux_materialdamageperilsrate"] = Convert.ToDecimal(SI_rate);
                        item1["lux_materialdamagefirerate"] = Convert.ToDecimal(MDFireRate);

                        item1["lux_buildingpremium"] = new Money(BuildingDeclaredValue * TotalRate / 100);
                        item1["lux_contentspremium"] = new Money(ContentsDeclaredValue * Convert.ToDecimal(0.125) / 100);
                        item1["lux_contentsrate"] = Convert.ToDecimal(0.125);

                        item1["lux_materialdamageloadedfirerate"] = Convert.ToDecimal(GrossRate);
                        service.Update(item1);

                    }
                    else
                    {
                        TotalMDPremium += Convert.ToDecimal(37.5);
                        var item1 = service.Retrieve("lux_propertyownerspremise", item.Id, new ColumnSet(false));
                        item1["lux_materialdamagepremium"] = new Money(Convert.ToDecimal(37.5));
                        item1["lux_materialdamageperilsrate"] = Convert.ToDecimal(0);
                        item1["lux_materialdamagefirerate"] = Convert.ToDecimal(0);
                        item1["lux_materialdamageloadedfirerate"] = Convert.ToDecimal(0);
                        service.Update(item1);
                    }
                }
                var item2 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                if (TotalMDPremium < 75)
                {
                    TotalMDPremium = 75;
                }
                item2["lux_materialdamagepremium"] = new Money(TotalMDPremium);
                service.Update(item2);
            }
        }
    }
}
