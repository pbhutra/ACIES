﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace CustomWorkflows
{
    public class GetPremiseCount : CodeActivity
    {
        [RequiredArgument]
        [Input("Product")]
        public InArgument<string> Product { get; set; }

        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Output("Premise Count")]
        public OutArgument<int> PremiseCount { get; set; }

        [Output("Risk Address")]
        public OutArgument<string> RiskAddress { get; set; }

        [Output("Risk Country")]
        public OutArgument<string> RiskCountry { get; set; }

        [Output("Risk Postcode")]
        public OutArgument<string> RiskPostcode { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference applnref = PropertyOwnersApplication.Get<EntityReference>(executionContext);
            Entity appln = new Entity(applnref.LogicalName, applnref.Id);
            appln = service.Retrieve("lux_propertyownersapplications", applnref.Id, new ColumnSet(true));

            var ProductName = Product.Get(executionContext).Trim();
            var fetch = "";
            if (ProductName == "Property Owners" || ProductName == "Unoccupied")
            {
                fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownerspremise'>
                                <attribute name='lux_riskpostcode' />                                
                                <attribute name='lux_housenumber' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_citycounty' />
                                <attribute name='lux_propertyownerspremiseid' />
                                <attribute name='lux_isthepropertyinagoodstateofrepair' />
                                <attribute name='lux_isthepropertytoundergoamajorrefurbishment' />
                                <order attribute='lux_locationnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id.ToString()}' />
                                </filter>
                              </entity>
                            </fetch>";
            }
            else if (ProductName == "Retail")
            {
                fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersretail'>
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_housenumber' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_citycounty' />
                                <attribute name='lux_propertyownersretailid' />
                                <attribute name='lux_isthereanintruderalarminstalled' />  
                                <order attribute='lux_locationnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                </filter>
                              </entity>
                            </fetch>";
            }
            else if (ProductName == "Pubs & Restaurants" || ProductName == "Hotels and Guesthouses")
            {
                fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_pubsrestaurantspropertyownersapplicatio'>
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_housenumber' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_citycounty' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_pubsrestaurantspropertyownersapplicatioid' /> 
                                <order attribute='lux_locationnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                </filter>
                              </entity>
                            </fetch>";
            }
            else if (ProductName == "Commercial Combined" || ProductName == "Office")
            {
                fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_commercialcombinedapplication'>
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_housenumber' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_citycounty' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_commercialcombinedapplicationid' />
                                <order attribute='lux_locationnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                </filter>
                              </entity>
                            </fetch>";
            }
            else if (ProductName == "Contractors Combined")
            {
                fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_contractorscombined'>
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_housenumber' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_citycounty' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_contractorscombinedid' />
                                <order attribute='lux_locationnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplications' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{appln.Id}' />
                                </filter>
                              </entity>
                            </fetch>";
            }

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                PremiseCount.Set(executionContext, service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count);
                var PremiseAddress = "";
                var PremisePostcode = "";
                var PremiseCountry = "";

                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    if (PremiseAddress == "")
                        PremiseAddress = ((item.Attributes.Contains("lux_housenumber") ? item.Attributes["lux_housenumber"].ToString().Trim() : "") + " " + (item.Attributes.Contains("lux_riskaddress") ? item.Attributes["lux_riskaddress"].ToString().Trim() : "") + " " + (item.Attributes.Contains("lux_citycounty") ? item.Attributes["lux_citycounty"].ToString().Trim() : "")).Replace(",", "").Trim();
                    else
                        PremiseAddress += ("|" + (item.Attributes.Contains("lux_housenumber") ? item.Attributes["lux_housenumber"].ToString().Trim() : "") + " " + (item.Attributes.Contains("lux_riskaddress") ? item.Attributes["lux_riskaddress"].ToString().Trim() : "") + " " + (item.Attributes.Contains("lux_citycounty") ? item.Attributes["lux_citycounty"].ToString().Trim() : "")).Replace(",", "").Trim();

                    if (PremiseCountry == "")
                        PremiseCountry = "United Kingdom";
                    else
                        PremiseCountry += "|United Kingdom";

                    if (PremisePostcode == "")
                        PremisePostcode = item.Attributes["lux_riskpostcode"].ToString().Trim();
                    else
                        PremisePostcode += "|" + item.Attributes["lux_riskpostcode"].ToString().Trim();
                }

                RiskAddress.Set(executionContext, PremiseAddress.Trim().Replace(",", "").Replace("\n", "").Replace("\t", ""));
                RiskPostcode.Set(executionContext, PremisePostcode.Trim().Replace(",", "").Replace("\n", "").Replace("\t", ""));
                RiskCountry.Set(executionContext, PremiseCountry.Trim().Replace(",", "").Replace("\n", "").Replace("\t", ""));
            }
        }
    }
}