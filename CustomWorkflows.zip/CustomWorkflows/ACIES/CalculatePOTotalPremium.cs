﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculatePOTotalPremium : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Input("Broker")]
        [ReferenceTarget("account")]
        public InArgument<EntityReference> Broker { get; set; }

        [RequiredArgument]
        [Input("Product")]
        [ReferenceTarget("product")]
        public InArgument<EntityReference> Product { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownerspremise'>
                                <attribute name='lux_riskpostcode' />
                                <attribute name='lux_riskaddress' />
                                <attribute name='lux_locationnumber' />
                                <attribute name='lux_declaredvalueforrebuildingthisproperty' />
                                <attribute name='lux_buildingconstruction' />
                                <attribute name='lux_totalsuminsuredforthislocation' />
                                <attribute name='lux_indemnityperiodrequired' />
                                <attribute name='lux_propertyownersliabilitylimitofindemnity' />
                                <attribute name='lux_iselcoverrequired' />
                                <attribute name='lux_landlordscontentsinresidentialareas' />
                                <attribute name='lux_lossofannualrentalincome' />
                                <attribute name='lux_indemnityperiodrequired' />
                                <attribute name='lux_propertyownerspremiseid' />
                                <attribute name='lux_covers' />
                                <attribute name='lux_businessinterruptionpremium' />
                                <attribute name='lux_materialdamagepremium' />
                                <attribute name='lux_terrorismpremium' />
                                <order attribute='lux_riskpostcode' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplication' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                                <link-entity name='lux_propertyownersapplications' from='lux_propertyownersapplicationsid' to='lux_propertyownersapplication' visible='false' link-type='outer' alias='poa'>
                                    <attribute name='lux_levelofcommission' />
                                    <attribute name='lux_employersliabilitypremium' />
                                    <attribute name='lux_propertyownersliabilitypremium' />
                                    <attribute name='lux_clericalcommercialandmanagerialwageroll' />
                                    <attribute name='lux_caretakerscleanersporterswageroll' />
                                    <attribute name='lux_alterationmaintenancerepairwageroll' />
                                    <attribute name='lux_allotherswageroll' />
                                    <attribute name='lux_inceptiondate' />
                                    <attribute name='lux_quotationdate' />
                                    <attribute name='lux_legrosspremium' />                                    
                                    <attribute name='lux_technicalnetpremium' />
                                    <attribute name='lux_lenetpremium' />    
                                    <attribute name='lux_materialdamagepremium' />
                                    <attribute name='lux_rpocpoproducttype' />
                                    <attribute name='lux_applicationtype' />
                                    <attribute name='lux_businessinterruptionpremium' />
                                </link-entity>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var premises = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;

                EntityReference applnref = PropertyOwnersApplication.Get<EntityReference>(executionContext);
                Entity appln1 = new Entity(applnref.LogicalName, applnref.Id);
                appln1 = service.Retrieve("lux_propertyownersapplications", applnref.Id, new ColumnSet(true));

                var IsQuoteReferred = appln1.Attributes.Contains("lux_isquotereferred") ? appln1.GetAttributeValue<bool>("lux_isquotereferred") : false;

                decimal TotalMDPremium = premises[0].Contains("poa.lux_materialdamagepremium") ? ((Money)((premises[0].GetAttributeValue<AliasedValue>("poa.lux_materialdamagepremium")).Value)).Value : 0;
                decimal TotalBIPremium = premises[0].Contains("poa.lux_businessinterruptionpremium") ? ((Money)((premises[0].GetAttributeValue<AliasedValue>("poa.lux_businessinterruptionpremium")).Value)).Value : 0;

                decimal TotalELPremium = premises[0].Contains("poa.lux_employersliabilitypremium") ? ((Money)((premises[0].GetAttributeValue<AliasedValue>("poa.lux_employersliabilitypremium")).Value)).Value : 0;
                decimal TotalPOLPremium = premises[0].Contains("poa.lux_propertyownersliabilitypremium") ? ((Money)((premises[0].GetAttributeValue<AliasedValue>("poa.lux_propertyownersliabilitypremium")).Value)).Value : 0;
                decimal TotalLENetPremium = premises[0].Contains("poa.lux_lenetpremium") ? ((Money)((premises[0].GetAttributeValue<AliasedValue>("poa.lux_lenetpremium")).Value)).Value : 0;
                decimal TotalLEGrossPremium = premises[0].Contains("poa.lux_legrosspremium") ? ((Money)premises[0].GetAttributeValue<AliasedValue>("poa.lux_legrosspremium").Value).Value : 0;


                var inceptionDate = Convert.ToDateTime(appln1.FormattedValues["lux_inceptiondate"], System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                var quotationDate = premises[0].Contains("poa.lux_quotationdate") ? (DateTime)premises[0].GetAttributeValue<AliasedValue>("poa.lux_quotationdate").Value : inceptionDate;

                tracingService.Trace(inceptionDate.ToShortDateString());
                tracingService.Trace(quotationDate.ToShortDateString());

                var ApplicationType = appln1.Attributes.Contains("lux_applicationtype") ? appln1.FormattedValues["lux_applicationtype"] : "New Business";

                var TotalPropertyPremium = TotalMDPremium + TotalBIPremium + TotalPOLPremium;
                var TotalLiabilityPremium = TotalELPremium;
                var TotalPremium = TotalPropertyPremium + TotalLiabilityPremium;

                decimal Fee = 0;
                var FeeFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                      <entity name='lux_adminfeerule'>
                                        <attribute name='lux_to' />
                                        <attribute name='lux_from' />
                                        <attribute name='lux_fee' />
                                        <attribute name='lux_adminfeeruleid' />
                                        <order attribute='lux_to' descending='false' />
                                        <filter type='and'>
                                          <condition attribute='statecode' operator='eq' value='0' />
                                          <condition attribute='lux_from' operator='le' value='{TotalPremium + TotalLEGrossPremium}' />
                                          <filter type='or'>
                                            <condition attribute='lux_to' operator='ge' value='{TotalPremium + TotalLEGrossPremium}' />
                                            <condition attribute='lux_to' operator='null' />
                                          </filter>
                                        </filter>
                                      </entity>
                                    </fetch>";
                if (service.RetrieveMultiple(new FetchExpression(FeeFetch)).Entities.Count > 0)
                {
                    Fee = service.RetrieveMultiple(new FetchExpression(FeeFetch)).Entities[0].GetAttributeValue<Money>("lux_fee").Value;
                    if (inceptionDate >= new DateTime(2024, 02, 01))
                    {
                        if (TotalPremium + TotalLEGrossPremium >= 5000 && TotalPremium + TotalLEGrossPremium < 10000)
                        {
                            Fee = 75;
                        }
                        else if (TotalPremium + TotalLEGrossPremium >= 10000 && TotalPremium + TotalLEGrossPremium < 25000)
                        {
                            Fee = 100;
                        }
                        else if (TotalPremium + TotalLEGrossPremium >= 25000 && TotalPremium + TotalLEGrossPremium < 50000)
                        {
                            Fee = 150;
                        }
                        else if (TotalPremium + TotalLEGrossPremium >= 50000)
                        {
                            Fee = 200;
                        }
                    }
                }

                decimal BrokerComm = 25;
                decimal aciesComm = 10;
                decimal LiabilityaciesComm = 5;

                var rpoProductType = premises[0].Contains("poa.lux_rpocpoproducttype") ? ((OptionSetValue)((premises[0].GetAttributeValue<AliasedValue>("poa.lux_rpocpoproducttype")).Value)).Value : 0;

                var productId = Product.Get(executionContext).Id;

                if (rpoProductType == 972970003 || rpoProductType == 972970004)
                {
                    productId = new Guid("5a439c84-febd-eb11-bacc-000d3ad6a20a");
                }

                var BrokerFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='lux_brokercommission'>
                                            <attribute name='createdon' />
                                            <attribute name='lux_product' />
                                            <attribute name='lux_commission' />
                                            <attribute name='lux_renewalcommission' />
                                            <attribute name='lux_brokercommissionid' />
                                            <order attribute='createdon' descending='false' />
                                            <filter type='and'>
                                              <condition attribute='statecode' operator='eq' value='0' />
                                              <filter type='or'>
                                                <condition attribute='lux_effectivefrom' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", inceptionDate)}' />
                                                <condition attribute='lux_effectivefrom' operator='null' />
                                              </filter>
                                              <filter type='or'>
                                                <condition attribute='lux_effectiveto' operator='on-or-after' value= '{String.Format("{0:MM/dd/yyyy}", inceptionDate)}' />
                                                <condition attribute='lux_effectiveto' operator='null' />
                                              </filter>
                                              <condition attribute='lux_broker' operator='eq' uiname='' uitype='account' value='{Broker.Get(executionContext).Id}' />
                                              <condition attribute='lux_product' operator='eq' uiname='' uitype='product' value='{productId}' />
                                            </filter>
                                          </entity>
                                        </fetch>";
                if (service.RetrieveMultiple(new FetchExpression(BrokerFetch)).Entities.Count > 0)
                {
                    var BrokerCommission = service.RetrieveMultiple(new FetchExpression(BrokerFetch)).Entities[0];
                    BrokerComm = BrokerCommission.GetAttributeValue<decimal>("lux_commission");

                    if (BrokerCommission.Attributes.Contains("lux_renewalcommission"))
                    {
                        if (ApplicationType == "Renewal")
                        {
                            BrokerComm = BrokerCommission.GetAttributeValue<decimal>("lux_renewalcommission");
                        }
                        else if (ApplicationType == "MTA" || ApplicationType == "Cancellation")
                        {
                            if (appln1.Attributes.Contains("lux_policy"))
                            {
                                var Policy = service.Retrieve("lux_policy", appln1.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970002)
                                {
                                    BrokerComm = BrokerCommission.GetAttributeValue<decimal>("lux_renewalcommission");
                                }
                            }
                        }
                    }

                    aciesComm = 35 - BrokerComm;
                    LiabilityaciesComm = 30 - BrokerComm;
                }

                Entity appln = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet());
                appln["lux_totalpremium"] = new Money(TotalPremium + TotalLEGrossPremium);
                appln["lux_brokercommission"] = Convert.ToDouble(BrokerComm) + "%";
                appln["lux_aciestechnicalcommission"] = Convert.ToDouble(aciesComm) + "%";
                //appln["lux_policyaciescommissionliability"] = Convert.ToDouble(LiabilityaciesComm) + "%";
                appln["lux_totaltechnicalcommission"] = "35%";

                if (!premises[0].Contains("poa.lux_technicalnetpremium") || IsQuoteReferred == true)
                {
                    appln["lux_policybrokercommission"] = Convert.ToDouble(BrokerComm) + "%";
                    appln["lux_policyaciescommission"] = Convert.ToDouble(aciesComm) + "%";
                    appln["lux_policyaciescommissionliability"] = Convert.ToDouble(LiabilityaciesComm) + "%";
                    appln["lux_policytotalcommission"] = "35%";
                }


                var LEBrokerComm = TotalLEGrossPremium * BrokerComm / 100;
                var LeGrossComm = TotalLEGrossPremium - TotalLENetPremium - LEBrokerComm;

                appln["lux_brokercommissionamount"] = new Money(TotalPremium * BrokerComm / 100 + LEBrokerComm);
                appln["lux_legrosscommission"] = new Money(LeGrossComm);
                appln["lux_aciestechnicalcommissionamount"] = new Money(TotalPremium * aciesComm / 100);
                appln["lux_technicalnetpremium"] = new Money(TotalPremium + TotalLENetPremium - TotalPremium * BrokerComm / 100 - TotalPremium * aciesComm / 100);

                if (inceptionDate >= new DateTime(2023, 11, 01))
                {
                    appln["lux_aciestechnicalcommissionliability"] = Convert.ToDouble(LiabilityaciesComm) + "%";
                    appln["lux_aciestechnicalcommissionamountliability"] = new Money(TotalLiabilityPremium * LiabilityaciesComm / 100);
                    appln["lux_aciestechnicalcommissionamount"] = new Money(TotalPropertyPremium * aciesComm / 100 + TotalLiabilityPremium * LiabilityaciesComm / 100);
                    appln["lux_technicalnetpremium"] = new Money(TotalPremium + TotalLENetPremium - TotalPremium * BrokerComm / 100 - TotalPropertyPremium * aciesComm / 100 - TotalLiabilityPremium * LiabilityaciesComm / 100);
                }

                appln["lux_fees"] = new Money(Fee);
                appln["lux_quotetype"] = false;
                service.Update(appln);
            }
        }
    }
}