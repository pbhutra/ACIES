﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class GetBrokerTotalAmountDues : CodeActivity
    {
        [Input("Account")]
        [ReferenceTarget("account")]
        public InArgument<EntityReference> Account { get; set; }

        [Output("Amount DueThisMonth")]
        public OutArgument<Money> AmountDueThisMonth { get; set; }

        [Output("Amount OverDue")]
        public OutArgument<Money> AmountOverDue { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                  <entity name='lux_invoice'>
                                    <attribute name='lux_transactiontype' />
                                    <attribute name='lux_transactiondate' />
                                    <attribute name='lux_totalpremiumincludingiptfee' />
                                    <attribute name='lux_risktransaction' />
                                    <attribute name='lux_policynumber' />
                                    <attribute name='lux_netpremiumdueincludingiptfee' />
                                    <attribute name='lux_ipt' />
                                    <attribute name='lux_insured' />
                                    <attribute name='lux_inceptioneffectivedate' />
                                    <attribute name='lux_grosspremiumexciptfee' />
                                    <attribute name='lux_fee' />
                                    <attribute name='lux_duedate' />
                                    <attribute name='lux_commissionrate' />
                                    <attribute name='lux_commissionamount' />
                                    <attribute name='lux_invoiceid' />
                                    <order attribute='lux_transactiondate' descending='false' />
                                    <filter type='and'>
                                      <condition attribute='statecode' operator='eq' value='0' />
                                      <condition attribute='lux_broker' operator='eq' uiname='' uitype='account' value='{Account.Get(executionContext).Id}' />
                                      <condition attribute='lux_ispaid' operator='ne' value='1' />
                                      <condition attribute='lux_inceptioneffectivedate' operator='last-month' />
                                    </filter>
                                  </entity>
                                </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {

                var amount = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Sum(x => (x.Attributes.Contains("lux_netpremiumdueincludingiptfee") ? x.GetAttributeValue<Money>("lux_netpremiumdueincludingiptfee").Value : 0));
                AmountDueThisMonth.Set(executionContext, new Money(amount));
            }
            else
            {
                AmountDueThisMonth.Set(executionContext, new Money(0));
            }

            //var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
            //                      <entity name='lux_invoice'>
            //                        <attribute name='lux_transactiontype' />
            //                        <attribute name='lux_transactiondate' />
            //                        <attribute name='lux_totalpremiumincludingiptfee' />
            //                        <attribute name='lux_risktransaction' />
            //                        <attribute name='lux_policynumber' />
            //                        <attribute name='lux_netpremiumdueincludingiptfee' />
            //                        <attribute name='lux_ipt' />
            //                        <attribute name='lux_insured' />
            //                        <attribute name='lux_inceptioneffectivedate' />
            //                        <attribute name='lux_grosspremiumexciptfee' />
            //                        <attribute name='lux_fee' />
            //                        <attribute name='lux_duedate' />
            //                        <attribute name='lux_commissionrate' />
            //                        <attribute name='lux_commissionamount' />
            //                        <attribute name='lux_invoiceid' />
            //                        <order attribute='lux_transactiondate' descending='false' />
            //                        <filter type='and'>
            //                          <condition attribute='statecode' operator='eq' value='0' />
            //                          <condition attribute='lux_broker' operator='eq' uiname='' uitype='account' value='{Account.Get(executionContext).Id}' />
            //                          <condition attribute='lux_ispaid' operator='ne' value='1' />
            //                          <condition attribute='lux_inceptioneffectivedate' operator='olderthan-x-months' value='1' />
            //                        </filter>
            //                      </entity>
            //                    </fetch>";

            //if (service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Count > 0)
            //{

            //    var amount = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities.Sum(x => (x.Attributes.Contains("lux_netpremiumdueincludingiptfee") ? x.GetAttributeValue<Money>("lux_netpremiumdueincludingiptfee").Value : 0));
            //    AmountOverDue.Set(executionContext, new Money(amount));
            //}
            //else
            //{
            AmountOverDue.Set(executionContext, new Money(0));
            //}
        }
    }
}
