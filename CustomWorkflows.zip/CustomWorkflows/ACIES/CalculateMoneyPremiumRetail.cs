﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculateMoneyPremiumRetail : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                <attribute name='lux_propertyownersapplicationsid' />
                                <attribute name='lux_name' />
                                <attribute name='lux_moneyoutofsafeoutofbusinesshours' />
                                <attribute name='lux_moneyoutofhoursinunspecifiedsafe' />
                                <attribute name='lux_moneyonpremisesduringhours' />
                                <attribute name='lux_moneyintransit' />                                
                                <attribute name='lux_estimatedannualcarryings' />
                                <attribute name='lux_estimatedannualcarryings' />
                                <attribute name='lux_moneyinspecifiedsafe4' />
                                <attribute name='lux_moneyinspecifiedsafe3' />
                                <attribute name='lux_moneyinspecifiedsafe2' />
                                <attribute name='lux_moneyinspecifiedsafe1' />                                
                                <attribute name='lux_moneyinspecifiedsafe5' />
                                <attribute name='lux_ismoneycoverrequired' />
                                <attribute name='lux_ismaterialdamagecoverrequired' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplicationsid' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var item = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];

                //decimal MoneyDuringHours = item.Attributes.Contains("lux_moneyonpremisesduringhours") ? item.GetAttributeValue<OptionSetValue>("lux_moneyonpremisesduringhours").Value : 0;
                //decimal MoneyInTransit = item.Attributes.Contains("lux_moneyintransit") ? item.GetAttributeValue<OptionSetValue>("lux_moneyintransit").Value : 0;
                //decimal MoneyOutofSafe = item.Attributes.Contains("lux_moneyoutofsafeoutofbusinesshours") ? item.GetAttributeValue<OptionSetValue>("lux_moneyoutofsafeoutofbusinesshours").Value : 0;
                //decimal MoneyOutofHours = item.Attributes.Contains("lux_moneyoutofhoursinunspecifiedsafe") ? item.GetAttributeValue<OptionSetValue>("lux_moneyoutofhoursinunspecifiedsafe").Value : 0;

                decimal EstimatedAnnualCaryings = item.Attributes.Contains("lux_estimatedannualcarryings") ? item.GetAttributeValue<Money>("lux_estimatedannualcarryings").Value : 0;

                decimal Safe1 = item.Attributes.Contains("lux_moneyinspecifiedsafe1") ? item.GetAttributeValue<Money>("lux_moneyinspecifiedsafe1").Value : 0;
                decimal Safe2 = item.Attributes.Contains("lux_moneyinspecifiedsafe2") ? item.GetAttributeValue<Money>("lux_moneyinspecifiedsafe2").Value : 0;
                decimal Safe3 = item.Attributes.Contains("lux_moneyinspecifiedsafe3") ? item.GetAttributeValue<Money>("lux_moneyinspecifiedsafe3").Value : 0;
                decimal Safe4 = item.Attributes.Contains("lux_moneyinspecifiedsafe4") ? item.GetAttributeValue<Money>("lux_moneyinspecifiedsafe4").Value : 0;
                decimal Safe5 = item.Attributes.Contains("lux_moneyinspecifiedsafe5") ? item.GetAttributeValue<Money>("lux_moneyinspecifiedsafe5").Value : 0;

                //if (MoneyDuringHours == 972970001)
                //{
                //    MoneyDuringHours = 3000;
                //}
                //else if (MoneyDuringHours == 972970002)
                //{
                //    MoneyDuringHours = 5000;
                //}
                //else if (MoneyDuringHours == 972970003)
                //{
                //    MoneyDuringHours = 10000;
                //}
                //else if (MoneyDuringHours == 972970004)
                //{
                //    MoneyDuringHours = 15000;
                //}
                //else if (MoneyDuringHours == 972970005)
                //{
                //    MoneyDuringHours = 20000;
                //}

                //if (MoneyInTransit == 972970001)
                //{
                //    MoneyInTransit = 3000;
                //}
                //else if (MoneyInTransit == 972970002)
                //{
                //    MoneyInTransit = 5000;
                //}
                //else if (MoneyInTransit == 972970003)
                //{
                //    MoneyInTransit = 7500;
                //}
                //else if (MoneyInTransit == 972970004)
                //{
                //    MoneyInTransit = 10000;
                //}

                //if (MoneyOutofSafe == 972970001)
                //{
                //    MoneyOutofSafe = 500;
                //}

                //if (MoneyOutofHours == 972970001)
                //{
                //    MoneyOutofHours = 10000;
                //}

                decimal Estimatedannualcarryings = EstimatedAnnualCaryings; // MoneyDuringHours + MoneyInTransit + MoneyOutofSafe + MoneyOutofHours;
                decimal MoneyinSafe = Safe1 + Safe2 + Safe3 + Safe4 + Safe5;

                //old rates
                //var EstimatedannualcarryingsPremium = Estimatedannualcarryings * Convert.ToDecimal(0.05) / 100;
                //var MoneyinSafePremium = MoneyinSafe * Convert.ToDecimal(1.5) / 100;

                var EstimatedannualcarryingsPremium = Estimatedannualcarryings * Convert.ToDecimal(0.00) / 100;
                var MoneyinSafePremium = MoneyinSafe * Convert.ToDecimal(1) / 100;

                var totalPremium = EstimatedannualcarryingsPremium + MoneyinSafePremium;

                var item1 = service.Retrieve("lux_propertyownersapplications", item.Id, new ColumnSet(true));
                var dateDiffDays = (item1.GetAttributeValue<DateTime>("lux_renewaldate") - item1.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                if (dateDiffDays == 364 || dateDiffDays == 365 || dateDiffDays == 366)
                {
                    dateDiffDays = 365;
                }
                totalPremium = totalPremium * dateDiffDays / 365;

                if (totalPremium < 25)
                {
                    totalPremium = 25;
                }
                item1["lux_retailmoneypremium"] = new Money(totalPremium);
                item1["lux_estimatedannualcarryingsrate"] = Convert.ToDecimal(0.00);
                item1["lux_moneyinsaferate"] = Convert.ToDecimal(1);

                var product = item1.FormattedValues["lux_insuranceproductrequired"];
                if (product == "Commercial Combined" || product == "Office")
                {
                    if (item.GetAttributeValue<bool>("lux_ismoneycoverrequired") == false)
                    {
                        item1["lux_retailmoneypremium"] = new Money(0);
                        item1["lux_estimatedannualcarryingsrate"] = Convert.ToDecimal(0);
                        item1["lux_moneyinsaferate"] = Convert.ToDecimal(0);
                    }
                }
                if (product == "Contractors Combined")
                {
                    if (item.GetAttributeValue<bool>("lux_ismoneycoverrequired") == false || item.GetAttributeValue<bool>("lux_ismaterialdamagecoverrequired") == false)
                    {
                        item1["lux_retailmoneypremium"] = new Money(0);
                        item1["lux_estimatedannualcarryingsrate"] = Convert.ToDecimal(0);
                        item1["lux_moneyinsaferate"] = Convert.ToDecimal(0);
                    }
                }
                service.Update(item1);
            }
        }
    }
}
