﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata.Query;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using msdyncrmWorkflowTools;
using System.ServiceModel;

namespace CustomWorkflows
{
    public class AssociateNtoN : CodeActivity
    {
        #region "Parameter Definition"
        [RequiredArgument]
        [Input("Relationship Name")]
        [Default("")]
        public InArgument<String> RelationshipName { get; set; }

        [RequiredArgument]
        [Input("Primary Record URL")]
        [ReferenceTarget("")]
        public InArgument<String> PrimaryRecordURL { get; set; }

        [RequiredArgument]
        [Input("Parent Record URL")]
        [ReferenceTarget("")]
        public InArgument<String> ParentRecordURL { get; set; }

        #endregion

        protected override void Execute(CodeActivityContext executionContext)
        {
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            #region "Load CRM Service from context"

            Common objCommon = new Common(executionContext);
            objCommon.tracingService.Trace("Load CRM Service from context --- OK");
            #endregion

            #region "Read Parameters"
            String _relationshipName = this.RelationshipName.Get(executionContext);
            String _parentrecordURL = this.ParentRecordURL.Get(executionContext);
            String _primaryrecordURL = this.PrimaryRecordURL.Get(executionContext);
            if (_parentrecordURL == null || _parentrecordURL == "")
            {
                return;
            }
            if (_primaryrecordURL == null || _primaryrecordURL == "")
            {
                return;
            }
            string[] urlParts = _parentrecordURL.Split("?".ToArray());
            string[] urlParams = urlParts[1].Split("&".ToCharArray());
            string ParentObjectTypeCode = urlParams[0].Replace("etc=", "");
            string entityName = objCommon.sGetEntityNameFromCode(ParentObjectTypeCode, objCommon.service);
            string ParentId = urlParams[1].Replace("id=", "");

            objCommon.tracingService.Trace("ParentObjectTypeCode=" + entityName + "--ParentId=" + ParentId);

            string[] urlParts1 = _primaryrecordURL.Split("?".ToArray());
            string[] urlParams1 = urlParts1[1].Split("&".ToCharArray());
            string PrimaryObjectTypeCode = urlParams1[0].Replace("etc=", "");
            string PrimaryentityName = objCommon.sGetEntityNameFromCode(PrimaryObjectTypeCode, objCommon.service);
            string PrimaryId = urlParams1[1].Replace("id=", "");

            objCommon.tracingService.Trace("PrimaryObjectTypeCode=" + PrimaryentityName + "--ParentId=" + PrimaryId);
            #endregion

            #region "Associate Execution"

            try
            {

                var fetchXML = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                                  <entity name='contact'>
                                    <attribute name='fullname' />
                                    <attribute name='address1_composite' />
                                    <attribute name='lux_riskleval' />
                                    <attribute name='lux_matchstatus' />
                                    <attribute name='lux_creditscore' />
                                    <attribute name='lux_creditrating' />
                                    <attribute name='lux_hsecheck' />
                                    <attribute name='lux_companynumbercompanieshouse' />
                                    <attribute name='contactid' />
                                    <order attribute='fullname' descending='false' />
                                    <link-entity name='lux_contact_lux_constructionquotes' from='contactid' to='contactid' visible='false' intersect='true'>
                                      <link-entity name='lux_constructionquotes' from='lux_constructionquotesid' to='lux_constructionquotesid' alias='ac'>
                                        <filter type='and'>
                                          <condition attribute='lux_constructionquotesid' operator='eq' uiname='' uitype='lux_constructionquotes' value='{ParentId}' />
                                        </filter>
                                      </link-entity>
                                    </link-entity>
                                  </entity>
                                </fetch>";

                var entityrefcollection = new EntityReferenceCollection();
                EntityCollection ec = service.RetrieveMultiple(new FetchExpression(fetchXML));

                if (ec.Entities.Count > 0)
                {
                    foreach (var item in ec.Entities)
                    {
                        entityrefcollection.Add(new EntityReference("contact", item.Id));
                    }
                }

                AssociateRequest assreq = new AssociateRequest();
                assreq.Target = new EntityReference(PrimaryentityName, new Guid(PrimaryId));
                assreq.RelatedEntities = entityrefcollection;
                assreq.Relationship = new Relationship(_relationshipName);
                AssociateResponse response = (AssociateResponse)service.Execute(assreq);
            }
            catch (FaultException<OrganizationServiceFault> ex)
            {
                objCommon.tracingService.Trace("Error : {0} - {1}", ex.Message, ex.StackTrace);
            }
            catch (System.Exception ex)
            {
                objCommon.tracingService.Trace("Error : {0} - {1}", ex.Message, ex.StackTrace);
            }
            #endregion
        }
    }
}
