﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class CalculateGITPremiumRetail : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Input("Product")]
        public InArgument<string> Product { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                <attribute name='lux_propertyownersapplicationsid' />
                                <attribute name='lux_name' />
                                <attribute name='lux_goodsintransit' />
                                <attribute name='lux_gitcoverbasisrequired' />
                                <attribute name='lux_ownvehicles' />
                                <attribute name='lux_maximumsuminsuredpervehicle' />
                                <attribute name='lux_numberofvehicles' />
                                <attribute name='lux_annualcarryings' />
                                <attribute name='lux_consignmentlimit' />
                                <attribute name='lux_quotationdate' />
                                <attribute name='lux_inceptiondate' />
                                <attribute name='lux_packagelimit' />
                                <attribute name='lux_maintradeforthispremises' />                                
                                <attribute name='lux_insuranceproductrequired' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_propertyownersapplicationsid' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var item = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                var quotationDate = item.Contains("lux_quotationdate") ? item.GetAttributeValue<DateTime>("lux_quotationdate") : item.GetAttributeValue<DateTime>("lux_inceptiondate");
                var product = item.FormattedValues["lux_insuranceproductrequired"];
                decimal OwnVehicleSumInsured = 0;
                decimal TPSendingSumInsured = 0;
                decimal TotalSumInsured = 0;
                decimal OwnVehicleRate = 0;
                decimal TPSendingRate = 0;
                if (item.GetAttributeValue<bool>("lux_goodsintransit") == true)
                {
                    if (item.GetAttributeValue<OptionSetValueCollection>("lux_gitcoverbasisrequired") != null)
                    {
                        if (item.Attributes.Contains("lux_maintradeforthispremises"))
                        {
                            var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                  <filter type='or'>
                                                    <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                    <condition attribute='lux_enddate' operator='null' />
                                                  </filter>
                                                  <condition attribute='lux_name' operator='eq' uiname='' value='{item.FormattedValues["lux_maintradeforthispremises"].ToString()}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                            if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                            {
                                var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];

                                OwnVehicleRate = FireData.GetAttributeValue<decimal>("lux_transitrateownvehicle");
                                TPSendingRate = FireData.GetAttributeValue<decimal>("lux_transitratesendings");
                            }
                        }

                        var coll = item.GetAttributeValue<OptionSetValueCollection>("lux_gitcoverbasisrequired");
                        foreach (var data in coll)
                        {
                            if (data.Value == 972970001)
                            {
                                var NumberOfOwnVehicles = item.Attributes.Contains("lux_numberofvehicles") ? item.GetAttributeValue<int>("lux_numberofvehicles") : 0;
                                var VehicleLimit = item.Attributes.Contains("lux_maximumsuminsuredpervehicle") ? item.FormattedValues["lux_maximumsuminsuredpervehicle"].ToString().Replace("£", "") : "0";

                                //old rates
                                //OwnVehicleSumInsured = NumberOfOwnVehicles * Convert.ToDecimal(VehicleLimit) * Convert.ToDecimal(OwnVehicleRate) / 100;

                                OwnVehicleRate = 1;

                                if (NumberOfOwnVehicles == 1)
                                {
                                    OwnVehicleSumInsured = NumberOfOwnVehicles * Convert.ToDecimal(VehicleLimit) * Convert.ToDecimal(OwnVehicleRate) / 100;
                                }
                                else
                                {
                                    if (NumberOfOwnVehicles == 2)
                                    {
                                        OwnVehicleSumInsured = 1 * Convert.ToDecimal(VehicleLimit) * Convert.ToDecimal(OwnVehicleRate) / 100;
                                        var remainingContent = NumberOfOwnVehicles - 1;
                                        OwnVehicleSumInsured += remainingContent * Convert.ToDecimal(VehicleLimit) * (OwnVehicleRate * 75 / 100) / 100;
                                    }
                                    else if (NumberOfOwnVehicles == 3)
                                    {
                                        OwnVehicleSumInsured = 1 * Convert.ToDecimal(VehicleLimit) * Convert.ToDecimal(OwnVehicleRate) / 100;
                                        OwnVehicleSumInsured += 1 * Convert.ToDecimal(VehicleLimit) * (OwnVehicleRate * 75 / 100) / 100;
                                        var remainingContent = NumberOfOwnVehicles - 2;
                                        OwnVehicleSumInsured += remainingContent * Convert.ToDecimal(VehicleLimit) * (OwnVehicleRate * 5 / 100) / 100;
                                    }
                                    else
                                    {
                                        OwnVehicleSumInsured = 1 * Convert.ToDecimal(VehicleLimit) * Convert.ToDecimal(OwnVehicleRate) / 100;
                                        OwnVehicleSumInsured += 1 * Convert.ToDecimal(VehicleLimit) * (OwnVehicleRate * 75 / 100) / 100;
                                        OwnVehicleSumInsured += 1 * Convert.ToDecimal(VehicleLimit) * (OwnVehicleRate * 50 / 100) / 100;
                                        var remainingContent = NumberOfOwnVehicles - 3;
                                        OwnVehicleSumInsured += remainingContent * Convert.ToDecimal(VehicleLimit) * (OwnVehicleRate * 25 / 100) / 100;
                                    }
                                }
                            }
                            else if (data.Value == 972970002)
                            {
                                var AnnualCarryings = item.Attributes.Contains("lux_annualcarryings") ? item.GetAttributeValue<Money>("lux_annualcarryings").Value : 0;

                                //old rates
                                //var AnnualCarryingsSI = AnnualCarryings * Convert.ToDecimal(TPSendingRate) / 100;

                                var AnnualCarryingsSI = AnnualCarryings * Convert.ToDecimal(0) / 100;
                                TPSendingSumInsured = AnnualCarryingsSI;
                            }
                        }
                    }
                    TotalSumInsured = OwnVehicleSumInsured + TPSendingSumInsured;
                    var item1 = service.Retrieve("lux_propertyownersapplications", item.Id, new ColumnSet(true));
                    var dateDiffDays = (item1.GetAttributeValue<DateTime>("lux_renewaldate") - item1.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                    if (dateDiffDays == 364 || dateDiffDays == 365 || dateDiffDays == 366)
                    {
                        dateDiffDays = 365;
                    }
                    TotalSumInsured = TotalSumInsured * dateDiffDays / 365;

                    if (TotalSumInsured < 25)
                    {
                        TotalSumInsured = 25;
                    }
                    item1["lux_goodsintransitpremium"] = new Money(TotalSumInsured);
                    item1["lux_annualcarryingsrate"] = TPSendingRate;
                    item1["lux_vehiclelimitrate"] = OwnVehicleRate;
                    service.Update(item1);
                }
                else
                {
                    var item1 = service.Retrieve("lux_propertyownersapplications", item.Id, new ColumnSet(true));
                    item1["lux_goodsintransitpremium"] = new Money(0);
                    item1["lux_annualcarryingsrate"] = Convert.ToDecimal(0);
                    item1["lux_vehiclelimitrate"] = Convert.ToDecimal(0);
                    service.Update(item1);
                }

                if (product == "Contractors Combined")
                {
                    var item1 = service.Retrieve("lux_propertyownersapplications", item.Id, new ColumnSet(true));
                    item1["lux_goodsintransitpremium"] = new Money(0);
                    item1["lux_annualcarryingsrate"] = Convert.ToDecimal(0);
                    item1["lux_vehiclelimitrate"] = Convert.ToDecimal(0);
                    service.Update(item1);
                }
            }
        }
    }
}
