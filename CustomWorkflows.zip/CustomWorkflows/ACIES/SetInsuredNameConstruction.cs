﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace CustomWorkflows
{
    public class SetInsuredNameConstruction : CodeActivity
    {
        [Input("Application")]
        [ReferenceTarget("lux_constructionquotes")]
        [RequiredArgument]
        public InArgument<EntityReference> Application { get; set; }

        [Output("Insured Name")]
        public OutArgument<string> InsuredName { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference applnref = Application.Get<EntityReference>(executionContext);
            Entity appln = service.Retrieve("lux_constructionquotes", applnref.Id, new ColumnSet(true));

            var fetch = $@"<fetch name='table1' relationshipname='lux_contact_lux_constructionquotes' mapping='logical'>
                             <entity name='contact'>                             
                                  <attribute name='address1_postalcode' />
                                  <attribute name='address1_composite' />
                                  <attribute name='createdon' />
                                  <attribute name='fullname' />
                                  <attribute name='lux_matchstatus' />
                                  <order attribute='fullname' descending='false'/>
                                  <link-entity relationshipname='MTOMFilter' name='lux_contact_lux_constructionquotes' from='contactid' visible='false' intersect='true'>
                                       <link-entity name='lux_constructionquotes' to='lux_constructionquotesid'>
                                            <filter type='and'>
                                                 <condition attribute='lux_constructionquotesid' operator='in'>
                                                      <value>{appln.Id}</value>
                                                 </condition>
                                            </filter>
                                       </link-entity>
                                  </link-entity>
                             </entity>
                        </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                InsuredName.Set(executionContext, String.Join(", ", service.RetrieveMultiple(new FetchExpression(fetch)).Entities.ToList().Select(x => x.Attributes.Contains("fullname") ? x.Attributes["fullname"].ToString() : "")));
            }
        }
    }
}