﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;

namespace CustomWorkflows
{
    public class CalculateBIPremiumRetail : CodeActivity
    {
        [Input("Property Owners Application")]
        [ReferenceTarget("lux_propertyownersapplications")]
        public InArgument<EntityReference> PropertyOwnersApplication { get; set; }

        [Input("Product")]
        public InArgument<string> Product { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_propertyownersapplications'>
                                <attribute name='lux_propertyownersapplicationsid' />
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_rentreceivable' />
                                <attribute name='lux_icow' />
                                <attribute name='lux_typeofcover' />                                
                                <attribute name='lux_pubsrestaurantproducttype' />
                                <attribute name='lux_bookdebts' />
                                <attribute name='lux_lossoflicense' />
                                <attribute name='lux_lossoflicenseindemnitylimit' />
                                <attribute name='lux_amount' />
                                <attribute name='lux_quotationdate' />
                                <attribute name='lux_inceptiondate' />
                                <attribute name='lux_applicationtype' />
                                <attribute name='lux_maintradeforthispremises' />                                
                                <attribute name='lux_contractorsprimarytrade' />
                                <attribute name='lux_additionalincreasedcostofworking' />
                                <attribute name='lux_isbusinessinterruptioncoverrequired' />
                                <attribute name='lux_ismaterialdamagecoverrequired' />                                
                                <attribute name='lux_policy' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='lux_propertyownersapplicationsid' operator='eq' uiname='' uitype='lux_propertyownersapplications' value='{PropertyOwnersApplication.Get(executionContext).Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var applnData = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                //var quotationDate = applnData.Contains("lux_quotationdate") ? applnData.GetAttributeValue<DateTime>("lux_quotationdate") : applnData.GetAttributeValue<DateTime>("lux_inceptiondate");

                var quotationDate = Convert.ToDateTime((applnData.Contains("lux_quotationdate") ? applnData.GetAttributeValue<DateTime>("lux_quotationdate") : applnData.GetAttributeValue<DateTime>("lux_inceptiondate")), System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);
                var inceptionDate = Convert.ToDateTime(applnData.GetAttributeValue<DateTime>("lux_inceptiondate"), System.Globalization.CultureInfo.GetCultureInfo("en-GB").DateTimeFormat);

                var PremiseCount = service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count;

                decimal TotalBISumInsured = 0;
                decimal LORAmount = 0;

                decimal TotalBIPremium = 0;
                decimal TotalGrossProfitRevenuePremium = 0;
                decimal TotalGrossProfitRevenueRate = 0;
                decimal TotalIncreasedICOWPremium = 0;
                decimal TotalIncreasedICOWRate = 0;
                decimal TotalAdditionalIncreasedICOWPremium = 0;
                decimal TotalAdditionalIncreasedICOWRate = 0;
                decimal TotalLORPremium = 0;
                decimal TotalLORRate = 0;

                var item = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];

                var CoverBasis = item.GetAttributeValue<OptionSetValue>("lux_typeofcover");

                if (CoverBasis != null)
                {
                    decimal GrossProfitRevenue = item.Attributes.Contains("lux_amount") ? item.GetAttributeValue<Money>("lux_amount").Value : 0;
                    decimal IncreasedCOW = item.Attributes.Contains("lux_icow") ? item.GetAttributeValue<Money>("lux_icow").Value : 0;
                    decimal AdditionalIncreasedCOW = item.Attributes.Contains("lux_additionalincreasedcostofworking") ? item.GetAttributeValue<Money>("lux_additionalincreasedcostofworking").Value : 0;
                    decimal BookDebts = item.Attributes.Contains("lux_bookdebts") ? item.GetAttributeValue<Money>("lux_bookdebts").Value : 0;
                    decimal LOR = item.Attributes.Contains("lux_rentreceivable") ? item.GetAttributeValue<Money>("lux_rentreceivable").Value : 0;

                    var LOLRequired = item.Attributes.Contains("lux_lossoflicense") ? item.GetAttributeValue<bool>("lux_lossoflicense") : false;

                    if (LOLRequired == true)
                    {
                        var lolAmount = item.Attributes.Contains("lux_lossoflicenseindemnitylimit") ? item.GetAttributeValue<OptionSetValue>("lux_lossoflicenseindemnitylimit").Value : 0;
                        if (lolAmount == 972970002)
                        {
                            LORAmount = 250000;
                        }
                        else
                        {
                            LORAmount = 100000;
                        }
                    }

                    TotalBISumInsured = GrossProfitRevenue + IncreasedCOW + AdditionalIncreasedCOW + BookDebts + LOR + LORAmount;

                    decimal GPRRate = 0;
                    decimal LORRate = 0;

                    if (Product.Get(executionContext).ToString() != "Contractors Combined")
                    {
                        if (item.Attributes.Contains("lux_maintradeforthispremises"))
                        {
                            var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                              <entity name='lux_propertyownersrate'>
                                                <attribute name='lux_workaway' />
                                                <attribute name='lux_transitratesendings' />
                                                <attribute name='lux_transitrateownvehicle' />
                                                <attribute name='lux_tradesegment' />
                                                <attribute name='lux_tradesector' />
                                                <attribute name='lux_theftstockrate' />
                                                <attribute name='lux_theftcontentsrate' />
                                                <attribute name='lux_theftbyemployeetradebaserate' />
                                                <attribute name='lux_theft' />
                                                <attribute name='lux_productsrate' />
                                                <attribute name='lux_prods' />
                                                <attribute name='lux_plworkawaywagesrate' />
                                                <attribute name='lux_plpremiserate' />
                                                <attribute name='lux_mdbi' />
                                                <attribute name='lux_mdfirerate' />
                                                <attribute name='lux_fulldescription' />
                                                <attribute name='lux_elrate' />
                                                <attribute name='lux_blfirerate' />
                                                <attribute name='lux_el' />
                                                <attribute name='lux_propertyownersrateid' />
                                                <order attribute='lux_blfirerate' descending='false' />
                                                <filter type='and'>
                                                  <condition attribute='statecode' operator='eq' value='0' />
                                                  <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                  <filter type='or'>
                                                    <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                    <condition attribute='lux_enddate' operator='null' />
                                                  </filter>
                                                  <condition attribute='lux_name' operator='eq' uiname='' value='{item.FormattedValues["lux_maintradeforthispremises"].ToString()}' />
                                                </filter>
                                              </entity>
                                            </fetch>";

                            if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                            {
                                var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];

                                LORRate = FireData.GetAttributeValue<decimal>("lux_mdfirerate");
                                GPRRate = FireData.GetAttributeValue<decimal>("lux_blfirerate");

                                if (item.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970001)
                                {
                                    if (LORRate < 0.10M)
                                    {
                                        LORRate = 0.10M;
                                    }
                                    if (GPRRate < 0.06M)
                                    {
                                        GPRRate = 0.06M;
                                    }
                                }
                                else if (item.GetAttributeValue<OptionSetValue>("lux_applicationtype").Value == 972970003)
                                {
                                    if (inceptionDate >= new DateTime(2025, 08, 01))
                                    {
                                        if (LORRate < 0.10M)
                                        {
                                            LORRate = 0.10M;
                                        }
                                        if (GPRRate < 0.06M)
                                        {
                                            GPRRate = 0.06M;
                                        }
                                    }
                                }
                                else
                                {
                                    if (item.Attributes.Contains("lux_policy"))
                                    {
                                        var Policy = service.Retrieve("lux_policy", item.GetAttributeValue<EntityReference>("lux_policy").Id, new ColumnSet("lux_policytype"));
                                        if (Policy.GetAttributeValue<OptionSetValue>("lux_policytype").Value == 972970001)
                                        {
                                            if (quotationDate > new DateTime(2023, 02, 15))
                                            {
                                                if (LORRate < 0.10M)
                                                {
                                                    LORRate = 0.10M;
                                                }
                                                if (GPRRate < 0.06M)
                                                {
                                                    GPRRate = 0.06M;
                                                }
                                            }
                                        }
                                        else
                                        {
                                            if (inceptionDate >= new DateTime(2025, 08, 01))
                                            {
                                                if (LORRate < 0.10M)
                                                {
                                                    LORRate = 0.10M;
                                                }
                                                if (GPRRate < 0.06M)
                                                {
                                                    GPRRate = 0.06M;
                                                }
                                            }
                                        }
                                    }
                                }


                                if (Product.Get(executionContext).ToString() == "Pubs & Restaurants" || Product.Get(executionContext).ToString() == "Hotels and Guesthouses")
                                {
                                    if (item.GetAttributeValue<OptionSetValue>("lux_pubsrestaurantproducttype").Value == 972970001 || item.GetAttributeValue<OptionSetValue>("lux_pubsrestaurantproducttype").Value == 972970003)
                                    {
                                        GPRRate = 0.096M;
                                    }
                                    else if (item.GetAttributeValue<OptionSetValue>("lux_pubsrestaurantproducttype").Value == 972970002)
                                    {
                                        LORRate = 0.14M;
                                        GPRRate = 0.084M;
                                    }
                                }

                                if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
                                {
                                    if (LORRate < 0.10M)
                                    {
                                        LORRate = 0.10M;
                                    }

                                    if (FireData.FormattedValues["lux_tradesector"].ToString().Contains("Wholesaler's") || FireData.FormattedValues["lux_tradesector"].ToString().Contains("Business") || FireData.FormattedValues["lux_tradesector"].ToString().Contains("Leisure"))
                                    {
                                        if (FireData.GetAttributeValue<int>("lux_mdbi") == 2)
                                        {
                                            LORRate = 0.10M;
                                            GPRRate = 0.06M;
                                        }
                                        else if (FireData.GetAttributeValue<int>("lux_mdbi") == 3)
                                        {
                                            LORRate = 0.125M;
                                            GPRRate = 0.075M;
                                        }
                                        else if (FireData.GetAttributeValue<int>("lux_mdbi") == 4)
                                        {
                                            LORRate = 0.175M;
                                            GPRRate = 0.105M;
                                        }
                                        else if (FireData.GetAttributeValue<int>("lux_mdbi") == 5)
                                        {
                                            LORRate = 0.225M;
                                            GPRRate = 0.135M;
                                        }
                                        else if (FireData.GetAttributeValue<int>("lux_mdbi") == 6)
                                        {
                                            LORRate = 0.00M;
                                            GPRRate = 0.00M;
                                        }
                                    }

                                    if (FireData.FormattedValues["lux_tradesector"].ToString().Contains("Manufacturer's"))
                                    {
                                        if (FireData.GetAttributeValue<int>("lux_mdbi") == 2)
                                        {
                                            LORRate = 0.10M;
                                            GPRRate = 0.06M;
                                        }
                                        else if (FireData.GetAttributeValue<int>("lux_mdbi") == 3)
                                        {
                                            LORRate = 0.15M;
                                            GPRRate = 0.09M;
                                        }
                                        else if (FireData.GetAttributeValue<int>("lux_mdbi") == 4)
                                        {
                                            LORRate = 0.20M;
                                            GPRRate = 0.12M;
                                        }
                                        else if (FireData.GetAttributeValue<int>("lux_mdbi") == 5)
                                        {
                                            LORRate = 0.25M;
                                            GPRRate = 0.15M;
                                        }
                                        else if (FireData.GetAttributeValue<int>("lux_mdbi") == 6)
                                        {
                                            LORRate = 0.00M;
                                            GPRRate = 0.00M;
                                        }
                                    }
                                }
                            }

                            var GrossPRPremium = GrossProfitRevenue * Convert.ToDecimal(GPRRate) / 100;
                            var IncreasedCOWPremium = IncreasedCOW * Convert.ToDecimal(GPRRate * 2) / 100;
                            var AdditionalIncreasedCOWPremium = AdditionalIncreasedCOW * Convert.ToDecimal(GPRRate * 4) / 100;
                            var LORPremium = LOR * Convert.ToDecimal(LORRate) / 100;

                            TotalGrossProfitRevenuePremium += GrossPRPremium;
                            TotalAdditionalIncreasedICOWPremium += AdditionalIncreasedCOWPremium;
                            TotalIncreasedICOWPremium += IncreasedCOWPremium;
                            TotalLORPremium += LORPremium;

                            TotalGrossProfitRevenueRate += GPRRate;
                            TotalIncreasedICOWRate += GPRRate * 2;
                            TotalAdditionalIncreasedICOWRate += GPRRate * 4;
                            TotalLORRate += LORRate;

                            var totalPremium = GrossPRPremium + IncreasedCOWPremium + AdditionalIncreasedCOWPremium + LORPremium;

                            TotalBIPremium += totalPremium;
                        }
                    }
                    else if (Product.Get(executionContext).ToString() == "Contractors Combined")
                    {
                        if (item.Attributes.Contains("lux_contractorsprimarytrade"))
                        {
                            var FireRateFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                                  <entity name='lux_contractorstrade'>
                                                    <attribute name='lux_contractorstradeid' />
                                                    <attribute name='lux_name' />
                                                    <attribute name='createdon' />
                                                    <attribute name='lux_tradecategory' />
                                                    <attribute name='lux_plrate' />
                                                    <attribute name='lux_materialdamagefirerate' />
                                                    <attribute name='lux_elrate' />
                                                    <attribute name='lux_carrate' />
                                                    <attribute name='lux_businessinterruptionrate' />
                                                    <order attribute='lux_name' descending='false' />
                                                    <filter type='and'>
                                                      <condition attribute='statecode' operator='eq' value='0' />
                                                      <condition attribute='lux_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                      <filter type='or'>
                                                        <condition attribute='lux_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", quotationDate)}' />
                                                        <condition attribute='lux_enddate' operator='null' />
                                                      </filter>
                                                      <condition attribute='lux_contractorstradeid' operator='eq' uiname='Aerial Erection' uitype='lux_contractorstrade' value='{item.GetAttributeValue<EntityReference>("lux_contractorsprimarytrade").Id}' />
                                                    </filter>
                                                  </entity>
                                                </fetch>";

                            if (service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities.Count > 0)
                            {
                                var FireData = service.RetrieveMultiple(new FetchExpression(FireRateFetch)).Entities[0];
                                GPRRate = FireData.GetAttributeValue<decimal>("lux_businessinterruptionrate");
                                LORRate = FireData.GetAttributeValue<decimal>("lux_businessinterruptionrate");
                            }

                            var GrossPRPremium = GrossProfitRevenue * Convert.ToDecimal(GPRRate) / 100;
                            var IncreasedCOWPremium = IncreasedCOW * Convert.ToDecimal(GPRRate * 2) / 100;
                            var AdditionalIncreasedCOWPremium = AdditionalIncreasedCOW * Convert.ToDecimal(GPRRate * 4) / 100;
                            var LORPremium = LOR * Convert.ToDecimal(LORRate) / 100;

                            TotalGrossProfitRevenuePremium += GrossPRPremium;
                            TotalAdditionalIncreasedICOWPremium += AdditionalIncreasedCOWPremium;
                            TotalIncreasedICOWPremium += IncreasedCOWPremium;
                            TotalLORPremium += LORPremium;

                            TotalGrossProfitRevenueRate += GPRRate;
                            TotalIncreasedICOWRate += GPRRate * 2;
                            TotalAdditionalIncreasedICOWRate += GPRRate * 4;
                            TotalLORRate += LORRate;

                            var totalPremium = GrossPRPremium + IncreasedCOWPremium + AdditionalIncreasedCOWPremium + LORPremium;

                            TotalBIPremium += totalPremium;
                        }
                    }
                }

                var item2 = service.Retrieve("lux_propertyownersapplications", PropertyOwnersApplication.Get(executionContext).Id, new ColumnSet(true));
                var dateDiffDays = (item2.GetAttributeValue<DateTime>("lux_renewaldate") - item2.GetAttributeValue<DateTime>("lux_inceptiondate")).Days;
                if (dateDiffDays == 364 || dateDiffDays == 365 || dateDiffDays == 366)
                {
                    dateDiffDays = 365;
                }
                TotalBIPremium = TotalBIPremium * dateDiffDays / 365;

                if (TotalBIPremium < 75)
                {
                    TotalBIPremium = 75;
                }
                item2["lux_retailbipremium"] = new Money(TotalBIPremium);
                item2["lux_totalbisuminsured"] = new Money(TotalBISumInsured);
                item2["lux_grossprofitorrevenuerate"] = Convert.ToDecimal(TotalGrossProfitRevenueRate / PremiseCount);
                item2["lux_grossprofitorrevenuepremium"] = new Money(TotalGrossProfitRevenuePremium * dateDiffDays / 365);
                item2["lux_increasedcostofworkingrate"] = Convert.ToDecimal(TotalAdditionalIncreasedICOWRate / PremiseCount);
                item2["lux_increasedcostofworkingpremium"] = new Money(TotalIncreasedICOWPremium * dateDiffDays / 365);
                item2["lux_additionalincreasedcostofworkingrate"] = Convert.ToDecimal(TotalAdditionalIncreasedICOWRate / PremiseCount);
                item2["lux_additionalincreasedcostofworkingpremium"] = new Money(TotalAdditionalIncreasedICOWPremium * dateDiffDays / 365);
                item2["lux_bilossofrentrate"] = Convert.ToDecimal(TotalLORRate / PremiseCount);
                item2["lux_bilossofrentpremium"] = new Money(TotalLORPremium * dateDiffDays / 365);
                if (Product.Get(executionContext).ToString() == "Commercial Combined" || Product.Get(executionContext).ToString() == "Office")
                {
                    if (item.GetAttributeValue<bool>("lux_isbusinessinterruptioncoverrequired") == false)
                    {
                        item2["lux_retailbipremium"] = new Money(0);
                        item2["lux_totalbisuminsured"] = new Money(0);
                        item2["lux_grossprofitorrevenuerate"] = Convert.ToDecimal(0);
                        item2["lux_grossprofitorrevenuepremium"] = new Money(0);
                        item2["lux_increasedcostofworkingrate"] = Convert.ToDecimal(0);
                        item2["lux_increasedcostofworkingpremium"] = new Money(0);
                        item2["lux_additionalincreasedcostofworkingrate"] = Convert.ToDecimal(0);
                        item2["lux_additionalincreasedcostofworkingpremium"] = new Money(0);
                        item2["lux_bilossofrentrate"] = Convert.ToDecimal(0);
                        item2["lux_bilossofrentpremium"] = new Money(0);
                    }
                }
                if (Product.Get(executionContext).ToString() == "Contractors Combined")
                {
                    if (item.GetAttributeValue<bool>("lux_isbusinessinterruptioncoverrequired") == false || item.GetAttributeValue<bool>("lux_ismaterialdamagecoverrequired") == false)
                    {
                        item2["lux_retailbipremium"] = new Money(0);
                        item2["lux_totalbisuminsured"] = new Money(0);
                        item2["lux_grossprofitorrevenuerate"] = Convert.ToDecimal(0);
                        item2["lux_grossprofitorrevenuepremium"] = new Money(0);
                        item2["lux_increasedcostofworkingrate"] = Convert.ToDecimal(0);
                        item2["lux_increasedcostofworkingpremium"] = new Money(0);
                        item2["lux_additionalincreasedcostofworkingrate"] = Convert.ToDecimal(0);
                        item2["lux_additionalincreasedcostofworkingpremium"] = new Money(0);
                        item2["lux_bilossofrentrate"] = Convert.ToDecimal(0);
                        item2["lux_bilossofrentpremium"] = new Money(0);
                    }
                }
                service.Update(item2);
            }
        }
    }
}
