﻿using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomWorkflows
{
    public class ConvertTextIntoDecimal : CodeActivity
    {
        [RequiredArgument]
        [Input("InputText")]
        public InArgument<string> InputText { get; set; }

        [Output("Amount")]
        public OutArgument<decimal> Amount { get; set; }

        protected override void Execute(CodeActivityContext context)
        {
            if (string.IsNullOrEmpty(this.InputText.Get<string>(context)))
            {
                this.Amount.Set(context, 0);
            }
            else
            {
                if (this.InputText.Get<string>(context).Trim() == "£-" || this.InputText.Get<string>(context).Trim() == "$-")
                    this.Amount.Set(context, 0);
                else
                    this.Amount.Set(context, Convert.ToDecimal(this.InputText.Get<string>(context).Replace("$", "").Replace("£", "").Trim(new Char[] { ' ', '£', '$', '%' })));
            }
        }


        public static void ssss()
        {
            var amount = "-£835.40";
            if (amount == "£-" || amount == "$-")
                amount = "0";
            decimal amt = Convert.ToDecimal(amount.Replace("$", "").Replace("£", "").Trim(new Char[] { ' ', '£', '$' }));
        }
    }
}