﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CustomWorkflows
{
    public class AttachDocumentVersion : CodeActivity
    {
        [Input("InceptionDate")]
        public InArgument<DateTime> InceptionDate { get; set; }

        [Input("Product Variation")]
        [AttributeTarget("lux_productvariation", "lux_subproduct")]
        public InArgument<OptionSetValue> ProductVariation { get; set; }

        [Input("Entity Name")]
        [ReferenceTarget("")]
        public InArgument<String> EntityName { get; set; }

        [Input("Main Record URL")]
        [ReferenceTarget("")]
        public InArgument<String> MainRecordURL { get; set; }

        [Input("Secondary Entity Name")]
        [ReferenceTarget("")]
        public InArgument<String> SecondaryEntityName { get; set; }

        [Input("Secondary Record URL")]
        [ReferenceTarget("")]
        public InArgument<String> SecondaryRecordURL { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            #region "Load CRM Service from context"

            Common objCommon = new Common(executionContext);
            objCommon.tracingService.Trace("Load CRM Service from context --- OK");

            #endregion

            // Get parameters
            string mainRecordURL = MainRecordURL.Get(executionContext);

            string secondaryRecordURL = SecondaryRecordURL.Get(executionContext);

            TimeZoneInfo tst = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");

            TimeZoneInfo gmtZone = TimeZoneInfo.FindSystemTimeZoneById("GMT Standard Time");
            TimeZoneInfo utcZone = TimeZoneInfo.FindSystemTimeZoneById("UTC");

            var gmtStDT = TimeZoneInfo.ConvertTime(InceptionDate.Get(executionContext), utcZone, gmtZone);

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var product = ProductVariation.Get<OptionSetValue>(executionContext);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>
                              <entity name='ptm_mscrmaddons_dcptemplates'>
                                <attribute name='ptm_name' />
                                <attribute name='lux_validto' />
                                <attribute name='lux_validfrom' />
                                <attribute name='createdon' />
                                <attribute name='lux_documenttype' />
                                <attribute name='ptm_mscrmaddons_dcptemplatesid' />
                                <order attribute='createdon' descending='true' />
                                <filter type='and'>
                                  <condition attribute='statuscode' operator='eq' value='1' />
                                  <condition attribute='ptm_entitytype' operator='null' />
                                  <condition attribute='lux_product' operator='eq' value='{product.Value}' />
                                  <condition attribute='lux_validfrom' operator='on-or-before' value='{gmtStDT}' />
                                  <filter type='or'>
                                    <condition attribute='lux_validto' operator='null' />
                                    <condition attribute='lux_validto' operator='on-or-after' value='{gmtStDT}' />
                                  </filter>
                                </filter>
                              </entity>
                            </fetch>";

            tracingService.Trace(fetch);
            var data = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
            if (data.Count > 0)
            {
                foreach (var doc in data)
                {
                    var notesFetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                                          <entity name='annotation'>
                                            <attribute name='annotationid' />
                                            <attribute name='subject' />
                                            <attribute name='notetext' />
                                            <attribute name='modifiedby' />
                                            <attribute name='createdon' />
                                            <attribute name='filename' />
                                            <attribute name='documentbody' />
                                            <order attribute='createdon' descending='true' />
                                            <link-entity name='ptm_mscrmaddons_dcptemplates' from='ptm_mscrmaddons_dcptemplatesid' to='objectid' link-type='inner' alias='af'>
                                              <filter type='and'>
                                                <condition attribute='ptm_mscrmaddons_dcptemplatesid' operator='eq' uiname='' uitype='ptm_mscrmaddons_dcptemplates' value='{doc.Id}' />
                                              </filter>
                                            </link-entity>
                                          </entity>
                                        </fetch>";

                    var files = service.RetrieveMultiple(new FetchExpression(notesFetch)).Entities;

                    if (files.Count() > 0)
                    {
                        var file = files.FirstOrDefault();
                        if (mainRecordURL != "")
                        {
                            // Extract values from URL
                            string[] urlParts = mainRecordURL.Split("?".ToArray());
                            string[] urlParams = urlParts[1].Split("&".ToCharArray());
                            string ParentObjectTypeCode = urlParams[0].Replace("etc=", "");
                            string ParentId = urlParams[1].Replace("id=", "");

                            Entity Note = new Entity("annotation");
                            Note["objectid"] = new Microsoft.Xrm.Sdk.EntityReference(EntityName.Get(executionContext), new Guid(ParentId));
                            Note["objecttypecode"] = EntityName.Get(executionContext);
                            Note["filename"] = file.Attributes["filename"].ToString();
                            Note["subject"] = file.Attributes["subject"].ToString();
                            Note["documentbody"] = file.Attributes["documentbody"].ToString();
                            service.Create(Note);
                        }

                        if (secondaryRecordURL != "")
                        {
                            // Extract values from URL
                            string[] urlParts = secondaryRecordURL.Split("?".ToArray());
                            string[] urlParams = urlParts[1].Split("&".ToCharArray());
                            string ParentObjectTypeCode = urlParams[0].Replace("etc=", "");
                            string ParentId = urlParams[1].Replace("id=", "");

                            Entity Note = new Entity("annotation");
                            Note["objectid"] = new Microsoft.Xrm.Sdk.EntityReference(SecondaryEntityName.Get(executionContext), new Guid(ParentId));
                            Note["objecttypecode"] = SecondaryEntityName.Get(executionContext);
                            Note["filename"] = file.Attributes["filename"].ToString();
                            Note["subject"] = file.Attributes["subject"].ToString();
                            Note["documentbody"] = file.Attributes["documentbody"].ToString();
                            service.Create(Note);
                        }
                    }
                }
            }
        }
    }
}