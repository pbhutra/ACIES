﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.ServiceModel.Description;
using System.Threading.Tasks;

namespace CustomWorkflows
{
    public class UploadCropSchedule : CodeActivity
    {
        [Input("Applications")]
        [ReferenceTarget("lux_applications")]
        public InArgument<EntityReference> Applications { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference appRef = Applications.Get<EntityReference>(executionContext);
            Entity application = new Entity(appRef.LogicalName, appRef.Id);
            application = service.Retrieve("lux_applications", appRef.Id, new ColumnSet(true));
            string byteArray = application["lux_cropschedulebytearray"].ToString();

            var bytes = Convert.FromBase64String(byteArray);

            tracingService.Trace(byteArray);

            var dictForRefundParams = new Dictionary<string, string>();
            dictForRefundParams.Add("byteString", byteArray);
            dictForRefundParams.Add("applicationid", application.Id.ToString());

            var client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.BaseAddress = new Uri("https://msdynamicswebapi.azurewebsites.net/api/CRMWebApi/UploadCropScheduleData");
            var refundRequest = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress) { Content = new FormUrlEncodedContent(dictForRefundParams) };
            var refundResponseString = ProcessWebResponse(client, refundRequest, tracingService);
            var refundResponse = refundResponseString.Result;
        }

        public IDictionary<int, string> GetGlobalOptionSetValues(IOrganizationService service, string optionSetLogicalName)
        {
            IDictionary<int, string> optionSet = new Dictionary<int, string>();
            if (string.IsNullOrEmpty(optionSetLogicalName))
                return null;
            var retrieveAttributeRequest = new RetrieveOptionSetRequest
            {
                Name = optionSetLogicalName
            };
            var retrieveAttributeResponse = (RetrieveOptionSetResponse)service.Execute(retrieveAttributeRequest);
            var retrievedPicklistAttributeMetadata = (OptionSetMetadata)retrieveAttributeResponse.OptionSetMetadata;
            for (int i = 0; i < retrievedPicklistAttributeMetadata.Options.Count(); i++)
            {
                optionSet.Add(new KeyValuePair<int, string>(retrievedPicklistAttributeMetadata.Options[i].Value.Value,
                    retrievedPicklistAttributeMetadata.Options[i].Label.LocalizedLabels[0].Label));
            }
            return optionSet;
        }

        public static async Task<string> ProcessWebResponse(HttpClient client, HttpRequestMessage refundRequest, ITracingService tracingService)
        {
            var reponseContentString = "";
            try
            {
                HttpResponseMessage refundResponse = await client.SendAsync(refundRequest);
                reponseContentString = await refundResponse.Content.ReadAsStringAsync();
            }
            catch (HttpRequestException ex)
            {
                tracingService.Trace(ex.Message + Environment.NewLine + ex.StackTrace);
            }
            tracingService.Trace(reponseContentString);
            return reponseContentString;
        }

        //public static void ssss()
        //{
        //    ClientCredentials clientCredentials = new ClientCredentials();
        //    clientCredentials.UserName.UserName = "lucidadmin@scottishwoodlands.co.uk";
        //    clientCredentials.UserName.Password = "Angle-venus-away-located-44";

        //    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        //    // Copy and Paste Organization Service Endpoint Address URL
        //    var organizationService = (IOrganizationService)new OrganizationServiceProxy(new Uri("https://scottishwoodlands.api.crm11.dynamics.com/XRMServices/2011/Organization.svc"),
        //     null, clientCredentials, null);

        //    Entity application = new Entity("lux_applications", new Guid("5c56250a-89ea-e911-a812-000d3a86d6ba"));
        //    application = organizationService.Retrieve("lux_applications", new Guid("5c56250a-89ea-e911-a812-000d3a86d6ba"), new ColumnSet(true));
        //    string byteArray = application["lux_cropschedulebytearray"].ToString();

        //    var bytes = Convert.FromBase64String(byteArray);

        //    var dictForRefundParams = new Dictionary<string, string>();
        //    dictForRefundParams.Add("byteString", byteArray);
        //    dictForRefundParams.Add("applicationid", application.Id.ToString());

        //    var client = new HttpClient();
        //    client.DefaultRequestHeaders.Accept.Clear();
        //    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        //    client.BaseAddress = new Uri("http://localhost:59208/api/CRMWebApi/UploadCropScheduleData");
        //    var refundRequest = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress) { Content = new FormUrlEncodedContent(dictForRefundParams) };
        //    var refundResponseString = ProcessWebResponse1(client, refundRequest);
        //    var refundResponse = refundResponseString.Result;
        //}

        //public static async Task<string> ProcessWebResponse1(HttpClient client, HttpRequestMessage refundRequest)
        //{
        //    var reponseContentString = "";
        //    try
        //    {
        //        HttpResponseMessage refundResponse = await client.SendAsync(refundRequest);
        //        reponseContentString = await refundResponse.Content.ReadAsStringAsync();
        //    }
        //    catch (HttpRequestException ex)
        //    {
        //    }
        //    return reponseContentString;
        //}
    }
}
