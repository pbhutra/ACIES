﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class AssociateCropScheduleLines : CodeActivity
    {
        [Input("Policy")]
        [ReferenceTarget("lux_policy")]
        [RequiredArgument]
        public InArgument<EntityReference> Policy { get; set; }

        [Input("Application")]
        [ReferenceTarget("lux_applications")]
        [RequiredArgument]
        public InArgument<EntityReference> Application { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference policyref = Policy.Get<EntityReference>(executionContext);
            Entity policy = service.Retrieve("lux_policy", policyref.Id, new ColumnSet(true));

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_cropschedule'>
                                <attribute name='lux_subcompartment' />
                                <attribute name='lux_peril' />
                                <attribute name='lux_compartmentnumber' />
                                <attribute name='lux_areaha' />
                                <attribute name='lux_plantingyear' />
                                <attribute name='new_valueha' />
                                <attribute name='lux_regardingapplication' />
                                <attribute name='lux_totalpremium' />
                                <attribute name='lux_valueingbp' />
                                <attribute name='lux_species' />
                                <attribute name='createdon' />
                                <attribute name='lux_cropscheduleid' />
                                <order attribute='lux_compartmentnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_regardingapplication' operator='eq' uitype='lux_applications' value='{policy.GetAttributeValue<EntityReference>("lux_regardingapplication").Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                foreach (var item in service.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    Entity ent = new Entity("lux_cropschedule");
                    if (item.Attributes.Contains("lux_compartmentnumber") == true)
                    {
                        ent["lux_compartmentnumber"] = Convert.ToInt32(item.Attributes["lux_compartmentnumber"].ToString());
                    }
                    ent["lux_subcompartment"] = item.Attributes.Contains("lux_subcompartment") == true ? item.Attributes["lux_subcompartment"] : "";
                    if (item.Attributes.Contains("lux_species") == true)
                    {
                        ent["lux_species"] = new EntityReference("lux_treespecies", item.GetAttributeValue<EntityReference>("lux_species").Id);
                    }
                    ent["lux_plantingyear"] = item.Attributes.Contains("lux_plantingyear") == true ? item.Attributes["lux_plantingyear"] : "";
                    if (item.Attributes.Contains("lux_areaha") == true)
                    {
                        ent["lux_areaha"] = Convert.ToDecimal(item.Attributes["lux_areaha"].ToString());
                    }
                    if (item.Attributes.Contains("new_valueha") == true)
                    {
                        ent["new_valueha"] = item.Attributes["new_valueha"].ToString();
                    }
                    if (item.Attributes.Contains("lux_valueingbp") == true)
                    {
                        ent["lux_valueingbp"] = new Money(item.GetAttributeValue<Money>("lux_valueingbp").Value);
                    }
                    if (item.Attributes.Contains("lux_peril") == true)
                    {
                        ent["lux_peril"] = new OptionSetValue(item.GetAttributeValue<OptionSetValue>("lux_peril").Value);
                    }
                    if (item.Attributes.Contains("lux_totalpremium") == true)
                    {
                        ent["lux_totalpremium"] = new Money(item.GetAttributeValue<Money>("lux_totalpremium").Value);
                    }
                    ent["lux_regardingapplication"] = new EntityReference("lux_treespecies", Application.Get(executionContext).Id);
                    ent["lux_issystementry"] = true;
                    service.Create(ent);
                }
            }
        }

        public static void ssss()
        {
            ClientCredentials clientCredentials = new ClientCredentials();
            clientCredentials.UserName.UserName = "lucidadmin@scottishwoodlands.co.uk";
            clientCredentials.UserName.Password = "Angle-venus-away-located-44";

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            // Copy and Paste Organization Service Endpoint Address URL
            var organizationService = (IOrganizationService)new OrganizationServiceProxy(new Uri("https://scottishwoodlands.api.crm11.dynamics.com/XRMServices/2011/Organization.svc"),
             null, clientCredentials, null);

            Entity application = organizationService.Retrieve("lux_applications", new Guid("00578FB2-B3C5-EA11-A812-000D3A86D6EA"), new ColumnSet(true));

            Entity policy = organizationService.Retrieve("contract", new Guid("511845E8-BDC5-EA11-A812-000D3A86D74D"), new ColumnSet(true));

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_cropschedule'>
                                <attribute name='lux_subcompartment' />
                                <attribute name='lux_peril' />
                                <attribute name='lux_compartmentnumber' />
                                <attribute name='lux_areaha' />
                                <attribute name='lux_plantingyear' />
                                <attribute name='new_valueha' />
                                <attribute name='lux_regardingapplication' />
                                <attribute name='lux_totalpremium' />
                                <attribute name='lux_valueingbp' />
                                <attribute name='lux_species' />
                                <attribute name='createdon' />
                                <attribute name='lux_cropscheduleid' />
                                <order attribute='lux_compartmentnumber' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_regardingapplication' operator='eq' uitype='lux_applications' value='{policy.GetAttributeValue<EntityReference>("lux_regardingapplication").Id}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (organizationService.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                foreach (var item in organizationService.RetrieveMultiple(new FetchExpression(fetch)).Entities)
                {
                    Entity ent = new Entity("lux_cropschedule");
                    if (item.Attributes.Contains("lux_compartmentnumber") == true)
                    {
                        ent["lux_compartmentnumber"] = Convert.ToInt32(item.Attributes["lux_compartmentnumber"].ToString());
                    }
                    ent["lux_subcompartment"] = item.Attributes.Contains("lux_subcompartment") == true ? item.Attributes["lux_subcompartment"] : "";
                    if (item.Attributes.Contains("lux_species") == true)
                    {
                        ent["lux_species"] = new EntityReference("lux_treespecies", item.GetAttributeValue<EntityReference>("lux_species").Id);
                    }
                    ent["lux_plantingyear"] = item.Attributes.Contains("lux_plantingyear") == true ? item.Attributes["lux_plantingyear"] : "";
                    if (item.Attributes.Contains("lux_areaha") == true)
                    {
                        ent["lux_areaha"] = Convert.ToDecimal(item.Attributes["lux_areaha"].ToString());
                    }
                    if (item.Attributes.Contains("new_valueha") == true)
                    {
                        ent["new_valueha"] = item.Attributes["new_valueha"].ToString();
                    }
                    if (item.Attributes.Contains("lux_valueingbp") == true)
                    {
                        ent["lux_valueingbp"] = new Money(item.GetAttributeValue<Money>("lux_valueingbp").Value);
                    }
                    if (item.Attributes.Contains("lux_peril") == true)
                    {
                        ent["lux_peril"] = new OptionSetValue(item.GetAttributeValue<OptionSetValue>("lux_peril").Value);
                    }
                    if (item.Attributes.Contains("lux_totalpremium") == true)
                    {
                        ent["lux_totalpremium"] = new Money(item.GetAttributeValue<Money>("lux_totalpremium").Value);
                    }
                    ent["lux_regardingapplication"] = new EntityReference("lux_treespecies", application.Id);
                    ent["lux_issystementry"] = true;
                    organizationService.Create(ent);
                }
            }
        }
    }
}
