﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class UpdateBDXDetailsForCancellation : CodeActivity
    {
        [Input("PolicyNumber")]
        public InArgument<string> PolicyNumber { get; set; }

        [Input("Bordereau")]
        [ReferenceTarget("lux_bdx_transactions")]
        public InArgument<EntityReference> Bordereau { get; set; }

        [Input("Policy")]
        [ReferenceTarget("lux_policy")]
        public InArgument<EntityReference> Policy { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            decimal FIRE_SI = 0;
            decimal FIRE_WINDTHROW_SI = 0;
            decimal Total_SI = 0;
            decimal Crop_Premium_net_tax = 0;
            decimal Options_premium_net_tax = 0;
            decimal TAX = 0;
            decimal Crop_Premium_inc_tax = 0;
            decimal Property_Area_Ha = 0;

            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference bdxRef = Bordereau.Get<EntityReference>(executionContext);
            Entity bdx = new Entity(bdxRef.LogicalName, bdxRef.Id);
            bdx = service.Retrieve("lux_bdx_transactions", bdxRef.Id, new ColumnSet(true));

            EntityReference policyref = Policy.Get<EntityReference>(executionContext);
            Entity policy = new Entity(policyref.LogicalName, policyref.Id);
            policy = service.Retrieve("lux_policy", policyref.Id, new ColumnSet(true));

            FIRE_SI = policy.GetAttributeValue<Money>("lux_firesi").Value;
            FIRE_WINDTHROW_SI = policy.GetAttributeValue<Money>("lux_firewindthrowsi").Value;
            Total_SI = policy.GetAttributeValue<Money>("lux_totalsi").Value;
            Options_premium_net_tax = policy.GetAttributeValue<Money>("lux_optionspremiumnettax").Value;
            Property_Area_Ha = Convert.ToDecimal(policy["lux_propertyareaha"]);

            TAX = policy.GetAttributeValue<Money>("lux_refundiptamount").Value;
            Crop_Premium_inc_tax = policy.GetAttributeValue<Money>("lux_refundamount").Value;
            Crop_Premium_net_tax = policy.GetAttributeValue<Money>("lux_refundcroppremium").Value;

            bdx["lux_fire_si"] = new Money(-1 * FIRE_SI);
            bdx["lux_firewindthrow_si"] = new Money(-1 * FIRE_WINDTHROW_SI);
            bdx["lux_total_si"] = new Money(-1 * Total_SI);
            bdx["lux_optionspremiumnettax"] = new Money(0);
            bdx["lux_propertyareaha"] = Convert.ToDecimal(-1 * Property_Area_Ha);

            bdx["lux_croppremiumnettax"] = new Money(-1 * Crop_Premium_net_tax);
            bdx["lux_tax"] = new Money(-1 * TAX);
            bdx["lux_croppremiuminctax"] = new Money(-1 * Crop_Premium_inc_tax);

            service.Update(bdx);
        }

        //public static void ssss()
        //{
        //    decimal FIRE_SI = 0;
        //    decimal FIRE_WINDTHROW_SI = 0;
        //    decimal Total_SI = 0;
        //    decimal Crop_Premium_net_tax = 0;
        //    decimal Options_premium_net_tax = 0;
        //    decimal TAX = 0;
        //    decimal Crop_Premium_inc_tax = 0;
        //    decimal Property_Area_Ha = 0;

        //    ClientCredentials clientCredentials = new ClientCredentials();
        //    clientCredentials.UserName.UserName = "lucidadmin@scottishwoodlands.co.uk";
        //    clientCredentials.UserName.Password = "Angle-venus-away-located-44";

        //    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        //    // Copy and Paste Organization Service Endpoint Address URL
        //    var service = (IOrganizationService)new OrganizationServiceProxy(new Uri("https://scottishwoodlands.api.crm11.dynamics.com/XRMServices/2011/Organization.svc"),
        //     null, clientCredentials, null);


        //    Entity bdx = service.Retrieve("lux_bdx_transactions", new Guid("79b29b43-0611-ea11-a817-000d3a86d7e0"), new ColumnSet(true));
        //    Entity policy = service.Retrieve("contract", new Guid("bed0c519-0611-ea11-a817-000d3a86d7e0"), new ColumnSet(true));

        //    FIRE_SI = policy.GetAttributeValue<Money>("lux_fire_si").Value;
        //    FIRE_WINDTHROW_SI = policy.GetAttributeValue<Money>("lux_firewindthrow_si").Value;
        //    Total_SI = policy.GetAttributeValue<Money>("lux_total_si").Value;
        //    Crop_Premium_net_tax = policy.GetAttributeValue<Money>("lux_croppremiumnettax").Value;
        //    Options_premium_net_tax = policy.GetAttributeValue<Money>("lux_optionspremiumnettax").Value;
        //    TAX = policy.GetAttributeValue<Money>("lux_insurancepremiumtaxamount").Value;
        //    Crop_Premium_inc_tax = policy.GetAttributeValue<Money>("lux_grosspremium").Value;
        //    Property_Area_Ha = Convert.ToDecimal(policy["lux_propertyareaha"]);

        //}
    }
}
