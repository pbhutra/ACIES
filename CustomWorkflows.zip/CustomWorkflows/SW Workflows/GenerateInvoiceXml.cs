﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Net;
using System.ServiceModel.Description;
using System.Xml;
using System.Xml.Linq;

namespace CustomWorkflows
{
    public class GenerateInvoiceXml : CodeActivity
    {
        [Input("Invoice")]
        [ReferenceTarget("invoice")]
        public InArgument<EntityReference> Invoice { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference invoiceRef = Invoice.Get<EntityReference>(executionContext);
            Entity invoice = new Entity(invoiceRef.LogicalName, invoiceRef.Id);
            invoice = service.Retrieve("invoice", invoiceRef.Id, new ColumnSet(true));

            var policyRef = (EntityReference)invoice["lux_regardingnewpolicy"];

            Entity policy = new Entity(policyRef.LogicalName, policyRef.Id);
            policy = service.Retrieve(policyRef.LogicalName, policyRef.Id, new ColumnSet(true));


            var insuredRef = (EntityReference)policy["lux_policyholder"];

            Entity account = new Entity(insuredRef.LogicalName, insuredRef.Id);
            account = service.Retrieve(insuredRef.LogicalName, insuredRef.Id, new ColumnSet(true));

            var Desc = account["fullname"].ToString() + ";" + ((DateTime)policy["lux_policystartdate"]).ToString("dd/MM/yyyy").Replace("-", "").Replace("/", "") + ";" + ((DateTime)policy["lux_policyenddate"]).ToString("dd/MM/yyyy").Replace("-", "").Replace("/", "");

            var DocType = "Invoice";
            if (policy.GetAttributeValue<Money>("lux_grosspremium").Value < 0)
            {
                DocType = "Credit";
            }

            var xmlNode =
            new XElement("Coverpoint",
                          new XElement("Invoice",
                            new XElement("AccountNumber", "900783"),
                            new XElement("PostingDate", ((DateTime)invoice["createdon"]).ToString("dd/MM/yyyy").Replace("-", "").Replace("/", "")),
                            new XElement("DocumentType", DocType),
                            new XElement("DocumentNo", ""),
                            new XElement("Description", Desc),
                            new XElement("CurrencyCode", ""),
                            new XElement("TaxPerc", policy["lux_iptrate"]),
                            new XElement("Amount", policy.GetAttributeValue<Money>("lux_totalwithoptions").Value.ToString("#.##")),
                            new XElement("TaxAmount", policy.GetAttributeValue<Money>("lux_insurancepremiumtax").Value.ToString("#.##")),
                            new XElement("AmountIncTax", policy.GetAttributeValue<Money>("lux_grosspremium").Value.ToString("#.##")),
                            new XElement("CertRefNo", policy["lux_name"])
                        )
            );
            var invoiceXml = xmlNode;
            invoice["lux_invoicexml"] = invoiceXml.ToString();
            service.Update(invoice);
        }

        public static void ssss()
        {
            ClientCredentials clientCredentials = new ClientCredentials();
            clientCredentials.UserName.UserName = "lucidadmin@scottishwoodlands.co.uk";
            clientCredentials.UserName.Password = "Angle-venus-away-located-44";

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            // Copy and Paste Organization Service Endpoint Address URL
            var organizationService = (IOrganizationService)new OrganizationServiceProxy(new Uri("https://scottishwoodlands.api.crm11.dynamics.com/XRMServices/2011/Organization.svc"),
             null, clientCredentials, null);

            Entity invoice = new Entity("invoice", new Guid("b8eb65ee-152f-eb11-bf72-0022481ab5e8"));
            invoice = organizationService.Retrieve("invoice", new Guid("b8eb65ee-152f-eb11-bf72-0022481ab5e8"), new ColumnSet(true));

            var policyRef = (EntityReference)invoice["lux_regardingnewpolicy"];

            Entity policy = new Entity(policyRef.LogicalName, policyRef.Id);
            policy = organizationService.Retrieve(policyRef.LogicalName, policyRef.Id, new ColumnSet(true));


            var insuredRef = (EntityReference)policy["lux_policyholder"];

            Entity account = new Entity(insuredRef.LogicalName, insuredRef.Id);
            account = organizationService.Retrieve(insuredRef.LogicalName, insuredRef.Id, new ColumnSet(true));

            var Desc = account["fullname"].ToString() + ";" + ((DateTime)policy["lux_policystartdate"]).ToString("dd/MM/yyyy").Replace("-", "").Replace("/", "") + ";" + ((DateTime)policy["lux_policyenddate"]).ToString("dd/MM/yyyy").Replace("-", "").Replace("/", "");

            var DocType = "Invoice";
            if (policy.GetAttributeValue<Money>("lux_croppremiuminctax").Value < 0)
            {
                DocType = "Credit";
            }

            var xmlNode =
            new XElement("Coverpoint",
                          new XElement("Invoice",
                            new XElement("AccountNumber", "900783"),
                            new XElement("PostingDate", ((DateTime)invoice["createdon"]).ToString("dd/MM/yyyy").Replace("-", "").Replace("/", "")),
                            new XElement("DocumentType", DocType),
                            new XElement("DocumentNo", ""),
                            new XElement("Description", Desc),
                            new XElement("CurrencyCode", ""),
                            new XElement("TaxPerc", policy["lux_iptrate"]),
                            new XElement("Amount", policy.GetAttributeValue<Money>("lux_totalwithoptions").Value.ToString("#.##")),
                            new XElement("TaxAmount", policy.GetAttributeValue<Money>("lux_insurancepremiumtax").Value.ToString("#.##")),
                            new XElement("AmountIncTax", policy.GetAttributeValue<Money>("lux_croppremiuminctax").Value.ToString("#.##")),
                            new XElement("CertRefNo", policy["lux_name"])
                        )
            );
            var invoiceXml = xmlNode;

            invoice["lux_invoicexml"] = invoiceXml.ToString();
            organizationService.Update(invoice);
        }
    }
}
