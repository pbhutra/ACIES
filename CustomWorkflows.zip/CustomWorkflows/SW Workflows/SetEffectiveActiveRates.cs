﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class SetEffectiveActiveRates : CodeActivity
    {
        [RequiredArgument]
        [Input("RateName")]
        public InArgument<string> RateName { get; set; }

        [Output("PremiumRates")]
        [ReferenceTarget("lux_premiumrates")]
        public OutArgument<EntityReference> PremiumRates { get; set; }

        [Output("PercentageValue")]
        public OutArgument<decimal> PercentageValue { get; set; }

        [Output("CurrencyValue")]
        public OutArgument<decimal> CurrencyValue { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_premiumrates'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_value' />
                                <attribute name='new_valuepercentage' />
                                <attribute name='new_startdate' />
                                <attribute name='new_enddate' />
                                <attribute name='lux_premiumratesid' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='new_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", DateTime.UtcNow)}' />
                                  <condition attribute='new_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", DateTime.UtcNow) }' />
                                  <condition attribute='lux_name' operator='eq' value='{this.RateName.Get(executionContext)}' />
                                </filter>
                              </entity>
                            </fetch>";

            var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_premiumrates'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_value' />
                                <attribute name='new_valuepercentage' />
                                <attribute name='new_startdate' />
                                <attribute name='new_enddate' />
                                <attribute name='lux_premiumratesid' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_name' operator='eq' value='{this.RateName.Get(executionContext)}' />
                                </filter>
                              </entity>
                            </fetch>";

            tracingService.Trace(this.RateName.Get(executionContext).ToString());

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var Rates = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                PremiumRates.Set(executionContext, Rates.ToEntityReference());
                PercentageValue.Set(executionContext, Rates.Attributes.Contains("new_valuepercentage") == true ? Rates.GetAttributeValue<decimal>("new_valuepercentage") : 0);
                CurrencyValue.Set(executionContext, Rates.Attributes.Contains("lux_value") == true ? Rates.GetAttributeValue<Money>("lux_value").Value : 0);
            }
            else
            {
                var Rates = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities[0];
                PremiumRates.Set(executionContext, Rates.ToEntityReference());
                PercentageValue.Set(executionContext, Rates.Attributes.Contains("new_valuepercentage") == true ? Rates.GetAttributeValue<decimal>("new_valuepercentage") : 0);
                CurrencyValue.Set(executionContext, Rates.Attributes.Contains("lux_value") == true ? Rates.GetAttributeValue<Money>("lux_value").Value : 0);
            }
        }

        public static void ssss()
        {
            ClientCredentials clientCredentials = new ClientCredentials();
            clientCredentials.UserName.UserName = "lucidadmin@scottishwoodlands.co.uk";
            clientCredentials.UserName.Password = "Angle-venus-away-located-44";

            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            // Copy and Paste Organization Service Endpoint Address URL
            var service = (IOrganizationService)new OrganizationServiceProxy(new Uri("https://scottishwoodlands.api.crm11.dynamics.com/XRMServices/2011/Organization.svc"),
             null, clientCredentials, null);

            var Name = "Minimum premium (£)";

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_premiumrates'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_value' />
                                <attribute name='new_valuepercentage' />
                                <attribute name='new_startdate' />
                                <attribute name='new_enddate' />
                                <attribute name='lux_premiumratesid' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='new_startdate' operator='on-or-before' value='{String.Format("{0:MM/dd/yyyy}", DateTime.UtcNow)}' />
                                  <condition attribute='new_enddate' operator='on-or-after' value='{String.Format("{0:MM/dd/yyyy}", DateTime.UtcNow) }' />
                                  <condition attribute='lux_name' operator='eq' value='{Name}' />
                                </filter>
                              </entity>
                            </fetch>";

            var fetch1 = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_premiumrates'>
                                <attribute name='lux_name' />
                                <attribute name='createdon' />
                                <attribute name='lux_value' />
                                <attribute name='new_valuepercentage' />
                                <attribute name='new_startdate' />
                                <attribute name='new_enddate' />
                                <attribute name='lux_premiumratesid' />
                                <order attribute='lux_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_name' operator='eq' value='{Name}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var Rates = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                var data = Rates.ToEntityReference();
                var ddd = Rates.GetAttributeValue<decimal>("new_valuepercentage");
                var dff = Rates.GetAttributeValue<Money>("new_value").Value;
            }
            else
            {
                var Rates = service.RetrieveMultiple(new FetchExpression(fetch1)).Entities[0];
                var data = Rates.ToEntityReference();
                var ddd = Rates.Attributes.Contains("new_valuepercentage") == true ? Rates.GetAttributeValue<decimal>("new_valuepercentage") : 0;
                var dff = Rates.Attributes.Contains("lux_value") == true ? Rates.GetAttributeValue<Money>("lux_value").Value : 0;
            }
        }
    }
}
