﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CustomWorkflows
{
    public class GetMetLifeCoverRates : CodeActivity
    {
        [RequiredArgument]
        [AttributeTarget("lux_metlifeapplication", "lux_unitsselected")]
        [Input("No of Units")]
        public InArgument<OptionSetValue> NoofUnits { get; set; }

        [Output("Core Cover Amount")]
        public OutArgument<Money> CoreCoverAmount { get; set; }

        [Output("Child Cover Amount")]
        public OutArgument<Money> ChildCoverAmount { get; set; }

        [Output("Active Lifestyle Cover Amount")]
        public OutArgument<Money> ActiveLifestyleCoverAmount { get; set; }

        [Output("Helthcare Cover Amount")]
        public OutArgument<Money> HelthcareCoverAmount { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            int UnitNumber = 0;

            if (NoofUnits.Get(executionContext).Value == 972970001)
            {
                UnitNumber = 1;
            }
            else if (NoofUnits.Get(executionContext).Value == 972970002)
            {
                UnitNumber = 2;
            }
            else if (NoofUnits.Get(executionContext).Value == 972970003)
            {
                UnitNumber = 3;
            }
            else if (NoofUnits.Get(executionContext).Value == 972970004)
            {
                UnitNumber = 4;
            }
            else if (NoofUnits.Get(executionContext).Value == 972970005)
            {
                UnitNumber = 5;
            }


            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_metliferatescontroller'>
                                <attribute name='createdon' />
                                <attribute name='lux_unitamount' />
                                <attribute name='lux_covertype' />
                                <attribute name='lux_metliferatescontrollerid' />
                                <order attribute='createdon' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                </filter>
                              </entity>
                            </fetch>";

            var data = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
            if (data.Count > 0)
            {
                var CoreCover = data.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_covertype").Value == 972970001);
                CoreCoverAmount.Set(executionContext, new Money(UnitNumber * CoreCover.GetAttributeValue<Money>("lux_unitamount").Value));

                var ChildCover = data.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_covertype").Value == 972970002);
                ChildCoverAmount.Set(executionContext, new Money(UnitNumber * ChildCover.GetAttributeValue<Money>("lux_unitamount").Value));

                var ActiveLifestyleCover = data.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_covertype").Value == 972970003);
                ActiveLifestyleCoverAmount.Set(executionContext, new Money(UnitNumber * ActiveLifestyleCover.GetAttributeValue<Money>("lux_unitamount").Value));

                var HelthcareCover = data.FirstOrDefault(x => x.GetAttributeValue<OptionSetValue>("lux_covertype").Value == 972970004);
                HelthcareCoverAmount.Set(executionContext, new Money(UnitNumber * HelthcareCover.GetAttributeValue<Money>("lux_unitamount").Value));
            }
            else
            {
                CoreCoverAmount.Set(executionContext, new Money(0));
                ChildCoverAmount.Set(executionContext, new Money(0));
                ActiveLifestyleCoverAmount.Set(executionContext, new Money(0));
                HelthcareCoverAmount.Set(executionContext, new Money(0));
            }
        }
    }
}
