﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace CustomWorkflows
{
    public class PremfinaCancellation : CodeActivity
    {
        [RequiredArgument]
        [Input("Refund Amount")]
        public InArgument<Money> RefundAmount { get; set; }

        [RequiredArgument]
        [Input("Cancellation Type")]
        public InArgument<string> CancellationType { get; set; }

        [RequiredArgument]
        [Input("Agreement No")]
        public InArgument<string> AgreementNo { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");


            string tmaurl = "https://api.ipify.org";
            WebRequest request = WebRequest.Create(tmaurl);
            WebResponse response = request.GetResponse();

            WebHeaderCollection header = response.Headers;
            using (var reader = new System.IO.StreamReader(response.GetResponseStream()))
            {
                string responseText = reader.ReadToEnd();
                tracingService.Trace(responseText);
            }

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri("https://integrations-api.sandbox.premfina.com/login");
            client.DefaultRequestHeaders.Add("ContentType", "application/json");

            var tokenRequest = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress) { Content = new StringContent("{\r\n  \"user\": \"API_USER_CRA\",\r\n  \"password\": \"PWLAP1$U$3R781\"\r\n}", System.Text.Encoding.UTF8, "application/json") };
            var tokenResponseString = ProcessWebResponse(client, tokenRequest, tracingService);
            var tokenResponse = tokenResponseString.Result;
            tracingService.Trace(tokenResponse);
            tracingService.Trace(CancellationType.Get(executionContext).ToString());

            if (CancellationType.Get(executionContext).ToString() == "PRO")
            {
                HttpClient client1 = new HttpClient();
                client1.BaseAddress = new Uri("https://integrations-api.sandbox.premfina.com/cancellation/" + tokenResponse);
                client1.DefaultRequestHeaders.Add("ContentType", "application/json");

                //var canRequest = new HttpRequestMessage(HttpMethod.Post, client1.BaseAddress) { Content = new StringContent("{\r\n  \"agreementNo\": \"" + AgreementNo.Get(executionContext).ToString() + "\",\r\n  \"reason\": \"PRO\"\r\n ,\r\n  \"cancellationBalance\": \""+ RefundAmount.Get(executionContext).Value + "\"\r\n}", System.Text.Encoding.UTF8, "application/json") };

                var canRequest = new HttpRequestMessage(HttpMethod.Post, client1.BaseAddress) { Content = new StringContent("{\r\n  \"agreementNo\": \"" + AgreementNo.Get(executionContext).ToString() + "\",\r\n  \"reason\": \"PRO\"\r\n}", System.Text.Encoding.UTF8, "application/json") };

                var canResponseString = ProcessWebResponse(client1, canRequest, tracingService);
                var refundResponse = canResponseString.Result;
                tracingService.Trace(refundResponse);
            }
            else
            {
                HttpClient client1 = new HttpClient();
                client1.BaseAddress = new Uri("https://integrations-api.sandbox.premfina.com/cancellation/" + tokenResponse);
                client1.DefaultRequestHeaders.Add("ContentType", "application/json");

                var canRequest = new HttpRequestMessage(HttpMethod.Post, client1.BaseAddress) { Content = new StringContent("{\r\n  \"agreementNo\": \""+ AgreementNo.Get(executionContext).ToString() + "\",\r\n  \"reason\": \"NTU\"\r\n ,\r\n  \"cancellationReason\": \"Duplicated in Error\"\r\n}", System.Text.Encoding.UTF8, "application/json") };
                var canResponseString = ProcessWebResponse(client1, canRequest, tracingService);
                var refundResponse = canResponseString.Result;
                tracingService.Trace(refundResponse);
            }
        }

        public static async Task<string> ProcessWebResponse(HttpClient client, HttpRequestMessage refundRequest, ITracingService tracingService)
        {
            var reponseContentString = "";
            try
            {
                HttpResponseMessage refundResponse = await client.SendAsync(refundRequest);
                reponseContentString = await refundResponse.Content.ReadAsStringAsync();
            }
            catch (HttpRequestException ex)
            {
                tracingService.Trace(ex.Message + Environment.NewLine + ex.StackTrace);
            }
            tracingService.Trace(reponseContentString);
            return reponseContentString;
        }
    }
}
