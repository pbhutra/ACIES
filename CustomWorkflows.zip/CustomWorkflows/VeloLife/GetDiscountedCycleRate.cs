﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Linq;

namespace CustomWorkflows
{
    public class GetDiscountedCycleRate : CodeActivity
    {
        [Input("Cycle Application")]
        [ReferenceTarget("lux_cycleapplications")]
        [RequiredArgument]
        public InArgument<EntityReference> CycleApplication { get; set; }

        [RequiredArgument]
        [AttributeTarget("lux_cycleapplications", "lux_excessamount")]
        [Input("ExcessAmount")]
        public InArgument<OptionSetValue> ExcessAmount { get; set; }

        [Output("Discounted Rate")]
        [ReferenceTarget("lux_multibikediscount")]
        public OutArgument<EntityReference> DiscountedRate { get; set; }

        //[Output("Gross ex IPT Rate")]
        //public OutArgument<decimal> GrossexIPTRate { get; set; }

        //[Output("Gross inc IPT Rate")]
        //public OutArgument<decimal> GrossincIPTRate { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference appref = CycleApplication.Get<EntityReference>(executionContext);
            Entity appln = service.Retrieve("lux_cycleapplications", appref.Id, new ColumnSet(true));

            var BicycleExactvalue1 = appln.Attributes.Contains("lux_bicycleexactvalue");
            var BicycleExactvalue2 = appln.Attributes.Contains("lux_bicycleexactvalue2");
            var BicycleExactvalue3 = appln.Attributes.Contains("lux_bicycleexactvalue3");
            var BicycleExactvalue4 = appln.Attributes.Contains("lux_bicycleexactvalue4");
            var BicycleExactvalue5 = appln.Attributes.Contains("lux_bicycleexactvalue5");

            var BicycleSerialNumber1 = appln.Attributes.Contains("lux_bikeserialnumber");
            var BicycleSerialNumber2 = appln.Attributes.Contains("lux_bikeserialnumber2");
            var BicycleSerialNumber3 = appln.Attributes.Contains("lux_bikeserialnumber3");
            var BicycleSerialNumber4 = appln.Attributes.Contains("lux_bikeserialnumber4");
            var BicycleSerialNumber5 = appln.Attributes.Contains("lux_bikeserialnumber5");

            var BicycleType1 = appln.Attributes.Contains("lux_bicycletype");
            var BicycleType2 = appln.Attributes.Contains("lux_bicycletype2");
            var BicycleType3 = appln.Attributes.Contains("lux_bicycletype3");
            var BicycleType4 = appln.Attributes.Contains("lux_bicycletype4");
            var BicycleType5 = appln.Attributes.Contains("lux_bicycletype5");

            var BicycleMake1 = appln.Attributes.Contains("lux_bicyclemake");
            var BicycleMake2 = appln.Attributes.Contains("lux_bicyclemake2");
            var BicycleMake3 = appln.Attributes.Contains("lux_bicyclemake3");
            var BicycleMake4 = appln.Attributes.Contains("lux_bicyclemake4");
            var BicycleMake5 = appln.Attributes.Contains("lux_bicyclemake5");

            int BikeCount = 0;
            int BikeOptionsetValue = 0;

            if (BicycleExactvalue1 && BicycleMake1)
            {
                BikeCount += 1;
            }
            if (BicycleExactvalue2 && BicycleMake2)
            {
                BikeCount += 1;
            }
            if (BicycleExactvalue3 && BicycleMake3)
            {
                BikeCount += 1;
            }
            if (BicycleExactvalue4 && BicycleMake4)
            {
                BikeCount += 1;
            }
            if (BicycleExactvalue5 && BicycleMake5)
            {
                BikeCount += 1;
            }

            if (BikeCount == 1)
            {
                BikeOptionsetValue = 972970001;
            }
            else if (BikeCount == 2)
            {
                BikeOptionsetValue = 972970002;
            }
            else if (BikeCount >= 3)
            {
                BikeOptionsetValue = 972970003;
            }


            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='lux_multibikediscount'>
                                <attribute name='lux_noofbikes' />
                                <attribute name='lux_grossinciptdiscount' />
                                <attribute name='lux_grossexiptdiscount' />
                                <attribute name='lux_excessamount' />
                                <attribute name='lux_multibikediscountid' />
                                <order attribute='lux_excessamount' descending='false' />
                                <filter type='and'>
                                  <condition attribute='statecode' operator='eq' value='0' />
                                  <condition attribute='lux_excessamount' operator='eq' value='{ExcessAmount.Get(executionContext).Value}' />
                                  <condition attribute='lux_noofbikes' operator='eq' value='{BikeOptionsetValue}' />
                                </filter>
                              </entity>
                            </fetch>";

            var data = service.RetrieveMultiple(new FetchExpression(fetch)).Entities;
            if (data.Count > 0)
            {
                //var rate = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                //DiscountedRate.Set(executionContext, rate.ToEntityReference());

                DiscountedRate.Set(executionContext, data[0].ToEntityReference());

                //var GrossExIPT = data[0].GetAttributeValue<decimal>("lux_grossexiptdiscount");
                //GrossexIPTRate.Set(executionContext, GrossExIPT);

                //var GrossIncIPT = data[0].GetAttributeValue<decimal>("lux_grossinciptdiscount");
                //GrossincIPTRate.Set(executionContext, GrossIncIPT);
            }
            else
            {
                //GrossexIPTRate.Set(executionContext, 0);
                //GrossincIPTRate.Set(executionContext, 0);
            }
        }
    }
}
