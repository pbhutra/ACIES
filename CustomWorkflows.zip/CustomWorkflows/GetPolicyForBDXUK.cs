﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Client;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Net;
using System.ServiceModel.Description;

namespace CustomWorkflows
{
    public class GetPolicyForBDXUK : CodeActivity
    {
        [Input("Bordereau")]
        [ReferenceTarget("crb82_bordereau")]
        public InArgument<EntityReference> Bordereau { get; set; }

        [Output("Policy")]
        [ReferenceTarget("crb82_policy")]
        public OutArgument<EntityReference> Policy { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            EntityReference bdxRef = Bordereau.Get<EntityReference>(executionContext);
            Entity bdx = new Entity(bdxRef.LogicalName, bdxRef.Id);
            bdx = service.Retrieve("crb82_bordereau", bdxRef.Id, new ColumnSet(true));

            var bdxPolicyId = bdx["crb82_policyreferencecoverholder"].ToString().Trim();
            var GrossPremium = "0.00";
            if (bdx.Contains("crb82_grosspremiumpaidthistimeinclipt"))
                GrossPremium = bdx["crb82_grosspremiumpaidthistimeinclipt"].ToString().Replace("$", "").Replace("£", "").Trim(new Char[] { ' ', '£', '$' });

            //if (Convert.ToDecimal(GrossPremium) < 1000)
            //    GrossPremium = GrossPremium.Replace(".00", "");

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='crb82_policy'>
                                <attribute name='crb82_name' />
                                <attribute name='statecode' />
                                <attribute name='crb82_policyholder' />
                                <attribute name='crb82_policystartdate' />
                                <attribute name='crb82_policyenddate' />
                                <attribute name='crb82_insurer' />
                                <attribute name='crb82_broker' />
                                <attribute name='crb82_policyid' />
                                <order attribute='crb82_name' descending='false' />
                                <filter type='and'>
                                  <condition attribute='crb82_policynumber' operator='eq' value='{bdxPolicyId}' />
                                  <condition attribute='lux_grosspremium' operator='eq' value='{Convert.ToDecimal(GrossPremium)}' />
                                </filter>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                var bdxPolicy = service.RetrieveMultiple(new FetchExpression(fetch)).Entities[0];
                Policy.Set(executionContext, bdxPolicy.ToEntityReference());
            }
        }

        //public static void ssss()
        //{
        //    ClientCredentials clientCredentials = new ClientCredentials();
        //    clientCredentials.UserName.UserName = "crm@lucidtestbed.onmicrosoft.com"; //HttpContext.Current.Request.Form["UserName"];
        //    clientCredentials.UserName.Password = "$5i2t0Vo"; //HttpContext.Current.Request.Form["Password"];

        //    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
        //    // Copy and Paste Organization Service Endpoint Address URL
        //    var organizationService = (IOrganizationService)new OrganizationServiceProxy(new Uri("https://insurxchange.api.crm11.dynamics.com/XRMServices/2011/Organization.svc"),
        //     null, clientCredentials, null);

        //    Entity bdx = new Entity("crb82_bordereau", new Guid("8F32C67E-E31C-EA11-A812-000D3A7ED5A2"));
        //    bdx = organizationService.Retrieve("crb82_bordereau", new Guid("8F32C67E-E31C-EA11-A812-000D3A7ED5A2"), new ColumnSet(true));
        //    var bdxPolicyId = bdx["crb82_certificateref"].ToString().Trim();
        //    var GrossPremium = bdx["crb82_grosspremiumpaidthistimeinclipt"].ToString().Trim(new Char[] { ' ', '£', '$' });

        //    var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
        //                   <entity name='contract'>
        //                    <attribute name='title' />
        //                    <attribute name='contractid' />
        //                    <order attribute='title' descending='false' />
        //                    <filter type='and'>
        //                      <condition attribute='title' operator='eq' value='{bdxPolicyId}' />
        //                      <condition attribute='crb82_grosspremiumpaidthistime' operator='eq' value='{GrossPremium}' />
        //                    </filter>
        //                  </entity>
        //                </fetch>";
        //    if (organizationService.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
        //    {
        //        var bdxPolicy = organizationService.RetrieveMultiple(new FetchExpression(fetch)).Entities[0].Id;
        //    }
        //}

    }
}
