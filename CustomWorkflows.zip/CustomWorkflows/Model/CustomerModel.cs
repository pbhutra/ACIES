﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomWorkflows.Model
{
    public class CustomerModel
    {
        public string CustomerType { get; set; }
        public string CustomerName { get; set; }
        //public string Title { get; set; }
        //public string FirstName { get; set; }
        //public string LastName { get; set; }
        //public string CompanyName { get; set; }
        //public string CompanyWording { get; set; }
        public int CustomerNumber { get; set; }
    }
}
