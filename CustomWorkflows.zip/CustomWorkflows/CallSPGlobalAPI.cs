﻿using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Workflow;
using System;
using System.Activities;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace CustomWorkflows
{
    public class CallSPGlobalAPI : CodeActivity
    {
        [RequiredArgument]
        [Input("CompanyName")]
        public InArgument<string> CompanyName { get; set; }

        [RequiredArgument]
        [Input("CIQNumber")]
        public InArgument<string> CIQNumber { get; set; }

        [RequiredArgument]
        [Input("RecordGuid")]
        public InArgument<string> RecordGuid { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var request = new RetrieveCurrentOrganizationRequest();
            var organzationResponse = (RetrieveCurrentOrganizationResponse)service.Execute(request);
            var uriString = organzationResponse.Detail.UrlName;

            tracingService.Trace(CompanyName.Get(executionContext).Trim());
            tracingService.Trace(CIQNumber.Get(executionContext).Trim());
            tracingService.Trace(RecordGuid.Get(executionContext).Trim());

            var dictForApiParams = new Dictionary<string, string>();
            dictForApiParams.Add("CompanyName", CompanyName.Get(executionContext).Trim());
            dictForApiParams.Add("CIQNumber", CIQNumber.Get(executionContext).Trim());
            dictForApiParams.Add("RecordGuid", RecordGuid.Get(executionContext).Trim());

            var client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Clear();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            client.BaseAddress = new Uri("https://risingedgewebapi.azurewebsites.net/api/SPGlobal/SPGlobalRiskLive");
            if (uriString.ToLower().Contains("uat"))
            {
                client.BaseAddress = new Uri("https://risingedgewebapi.azurewebsites.net/api/SPGlobal/SPGlobalRiskUAT");
            }
           
            var apiRequest = new HttpRequestMessage(HttpMethod.Post, client.BaseAddress) { Content = new FormUrlEncodedContent(dictForApiParams) };
            var apiResponseString = ProcessWebResponse(client, apiRequest, tracingService);
            var apiResponse = apiResponseString.Result;

            tracingService.Trace(apiResponse);
        }

        public static async Task<string> ProcessWebResponse(HttpClient client, HttpRequestMessage apiRequest, ITracingService tracingService)
        {
            var reponseContentString = "";
            try
            {
                HttpResponseMessage apiResponse = await client.SendAsync(apiRequest);
                reponseContentString = await apiResponse.Content.ReadAsStringAsync();
            }
            catch (HttpRequestException ex)
            {
                tracingService.Trace(ex.Message + Environment.NewLine + ex.StackTrace);
            }
            tracingService.Trace(reponseContentString);
            return reponseContentString;
        }
    }
}