﻿using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Xrm.Sdk.Workflow;
using System.Activities;

namespace CustomWorkflows
{
    public class CheckifEmailActivityExist : CodeActivity
    {
        [Input("Email Address")]
        public InArgument<string> EmailAddress { get; set; }

        [Input("Email Subject")]
        public InArgument<string> EmailSubject { get; set; }

        [Output("IsExist")]
        public OutArgument<bool> IsExist { get; set; }

        protected override void Execute(CodeActivityContext executionContext)
        {
            ITracingService tracingService = executionContext.GetExtension<ITracingService>();
            tracingService.Trace("Application Started");

            //Create the context
            IWorkflowContext context = executionContext.GetExtension<IWorkflowContext>();
            IOrganizationServiceFactory serviceFactory = executionContext.GetExtension<IOrganizationServiceFactory>();
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            var fetch = $@"<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>
                              <entity name='email'>
                                <attribute name='subject' />
                                <attribute name='regardingobjectid' />
                                <attribute name='from' />
                                <attribute name='prioritycode' />
                                <attribute name='statuscode' />
                                <attribute name='activityid' />
                                <attribute name='to' />
                                <attribute name='createdon' />
                                <order attribute='subject' descending='false' />
                                <filter type='and'>
                                  <condition attribute='subject' operator='eq' value='{EmailSubject.Get(executionContext)}' />
                                  <condition attribute='createdon' operator='last-x-days' value='2' />
                                </filter>
                                <link-entity name='lead' from='leadid' to='regardingobjectid' link-type='inner' alias='lead'>
                                  <attribute name='emailaddress1' />
                                  <filter type='and'>
                                    <condition attribute='emailaddress1' operator='eq' value='{EmailAddress.Get(executionContext)}' />
                                  </filter>
                                </link-entity>
                              </entity>
                            </fetch>";

            if (service.RetrieveMultiple(new FetchExpression(fetch)).Entities.Count > 0)
            {
                this.IsExist.Set(executionContext, true);
            }
            else
            {
                this.IsExist.Set(executionContext, false);
            }
        }
    }
}
